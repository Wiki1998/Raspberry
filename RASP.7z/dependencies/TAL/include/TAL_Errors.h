/*
 * File    : $RCSfile: TAL_Errors.h,v $ (cvs $Revision: 1.4 $)
 *
 * Module  : TAL_ERRORS
 * Release : $Name: not supported by cvs2svn $
 * Date    : $Date: 2008-05-09 16:36:34 $
 * Author  : $Author: gebe $
 *
 * Description:
 * Interface header file defining error numbers.
 *
 * Copyright 2002-2007 DECOMSYS GmbH, http://www.decomsys.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of DECOMSYS GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * DECOMSYS GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifndef _TAL_ERRORS_H_
#define _TAL_ERRORS_H_

/*
 * EB ERROR messages start at id 0x0000 (if you are an EB colleague without
 * direct SVN access please request an id from guenter.ebermann@elektrobit.com)
 *
 * Common Error Numbers. Error numbers are constants. If an error packet
 * contains arguments they are described in the comment above the error.
 */

/* argument: none */
#define TAL_ERROR_UNKNOWN (0x0000)

/* argument: none */
#define TAL_ERROR_ERROR_QUEUE_OVERRUN (0x0001)

/*
 * argument 1: task number of preemted task
 * argument 2: time exceed of preemted task in microseconds
 */
#define TAL_ERROR_PREEMPTION (0x0002)

/*
 * argument 1: task number of task violating the deadline
 * argument 2: time the deadline was exceeded
 */
#define TAL_ERROR_DEADLINE (0x0003)

/*
 * argument 1: TUM number
 */
#define TAL_ERROR_TUM_REGISTER (0x0004)

/*
 * argument 1: number of duplicate TUM number
 */
#define TAL_ERROR_TUM_ID_DUPLICATED (0x0005)

/*
 * argument 1: Line number where BM_FATAL() macro was called
 * argument 2 - argument MAX: File name ASCII string including terminating \0
 *                            character
 */
#define TAL_ERROR_FATAL (0x0006)

/*
 * Thrown whenever a FlexRay task (Rx or Tx) misses its deadline.
 * The deadline for a Tx task is its slot.
 * The deadline for an Rx task is in its slot in the next cycle minus a 
 * configurable delay.
 *
 * argument 1: 0 (unused). Backward compatibility for firmware versions <= 4.1.0
 * argument 2: frame-triggering index (LPduIdx) which causes violation
 */
#define TAL_ERROR_FLEXRAY_DEADLINE (0x0007)

/*
 * Thrown whenever the FlexRay dispatcher is not called in-time.
 *
 * argument 1: Number of FlexRay communication cycles since the last time the
 *             FlexRay task dispatcher was called.
 */
#define TAL_ERROR_FLEXRAY_BIGTIMESHIFT (0x0008)

/*
 * Thrown whenever AUTOSAR modules on the target issue an error via
 * Det (Development Error Tracer).
 *
 * argument 1: ModuleId, Module ID of calling module.
 *             See *_MODULE_ID defines below for possible values.
 * argument 2: InstanceId, Instance ID of calling module.
 * argument 3: ApiId, ID of API service in which error is detected.
 *             See *_SID_* defines below for possible values.
 * argument 4: ErrorId, ID of detected development error.
 *             See *_E_* defines below for possible values.
 */
#define TAL_ERROR_DET (0x0009)
/* ModuleId */
#define TAL_COM_MODULE_ID 50
#define TAL_PDUR_MODULE_ID 51
#define TAL_CANIF_MODULE_ID 60
#define TAL_FRIF_MODULE_ID 61
#define TAL_FR_MODULE_ID 81
#define TAL_IPDUM_MODULE_ID 52
#define TAL_ETH_MODULE_ID 88
#define TAL_ETHTRCV_MODULE_ID 73
#define TAL_SOAD_MODULE_ID 56
#define TAL_TCPIP_MODULE_ID 170
#define TAL_SD_MODULE_ID 171
#define TAL_ETHIF_MODULE_ID 65
#define TAL_ETHSM_MODULE_ID 143
#define TAL_FRTSYN_MODULE_ID 163
#define TAL_ETHTSYN_MODULE_ID 164
/* ErrorId */
#define TAL_COM_E_PARAM 1U
#define TAL_COM_E_UNINIT 2U
#define TAL_COM_E_UNREACHABLE 0x20U
#define TAL_COM_E_SIGNAL_TOO_WIDE 0x21U
#define TAL_COM_E_INV_CONFIG 0x30U
#define TAL_CANIF_E_PARAM_CANID 10
#define TAL_CANIF_E_PARAM_DLC 11
#define TAL_CANIF_E_PARAM_HRH 12
#define TAL_CANIF_E_PARAM_LPDU 13
#define TAL_CANIF_E_PARAM_CONTROLLER 14
#define TAL_CANIF_E_PARAM_CONTROLLERID 15
#define TAL_CANIF_E_PARAM_WAKEUPSOURCE 16
#define TAL_CANIF_E_PARAM_TRCV 17
#define TAL_CANIF_E_PARAM_TRCVMODE 18
#define TAL_CANIF_E_PARAM_TRCVWAKEUPMODE 19
#define TAL_CANIF_E_PARAM_POINTER 20
#define TAL_CANIF_E_PARAM_CTRLMODE 21
#define TAL_CANIF_E_PARAM_PDUMODE 22
#define TAL_CANIF_E_UNINIT 30
#define TAL_CANIF_E_NOK_NOSUPPORT 40
#define TAL_CANIF_E_INVALID_TXPDUID 50
#define TAL_CANIF_E_INVALID_RXPDUID 60
#define TAL_CANIF_E_INVALID_DLC 61 
#define TAL_CANIF_E_NOT_SLEEP 71
#define TAL_SOAD_E_NOTINIT 0x01U
#define TAL_SOAD_E_NULL_PTR 0x02U
#define TAL_SOAD_E_INV_ARG 0x03U
#define TAL_SOAD_E_NOBUFS 0x04U
#define TAL_SOAD_E_INV_PDUHEADER_ID 0x05U
#define TAL_SOAD_E_INV_PDUID 0x06U
#define TAL_SOAD_E_INV_SOCKETID 0x07U
#define TAL_PDUR_E_CONFIG_PTR_INVALID 0x00U
#define TAL_PDUR_E_INVALID_REQUEST 0x01U
#define TAL_PDUR_E_PDU_ID_INVALID 0x02U
#define TAL_PDUR_E_TP_TX_REQ_REJECTED 0x03U
#define TAL_PDUR_E_NULL_POINTER 0x09U
#define TAL_PDUR_E_PDU_INSTANCES_LOST 0x0AU
#define TAL_SD_E_NOT_INITIALIZED 0x01U
#define TAL_SD_E_INV_POINTER 0x02U
#define TAL_SD_E_INV_MODE 0x03U
#define TAL_SD_E_INTERNAL_ERROR 0x04U
#define TAL_SD_E_TX 0x05U
#define TAL_SD_E_EVENT_QUEUE_OVERFLOW 0xF0U

/* ApiId */
#define TAL_COM_SID_INIT 0x01
#define TAL_COM_SID_DEINIT 0x02
#define TAL_COM_SID_IPDUGROUPSTART 0x03
#define TAL_COM_SID_IPDUGROUPSTOP 0x04
#define TAL_COM_SID_DISABLERECEPTIONDM 0x05
#define TAL_COM_SID_ENABLERECEPTIONDM 0x06
#define TAL_COM_SID_GETSTATUS 0x07
#define TAL_COM_SID_GETCONFIGURATIONID 0x08
#define TAL_COM_SID_GETVERSIONINFO 0x09
#define TAL_COM_SID_SENDSIGNAL 0x0A
#define TAL_COM_SID_RECEIVESIGNAL 0x0B
#define TAL_COM_SID_UPDATESHADOWSIGNAL 0x0C
#define TAL_COM_SID_SENDSIGNALGROUP 0x0D
#define TAL_COM_SID_INVALIDATESIGNALGROUP 0x1B
#define TAL_COM_SID_RECEIVESIGNALGROUP 0x0E
#define TAL_COM_SID_RECEIVESHADOWSIGNAL 0x0F
#define TAL_COM_SID_INVALIDATESIGNAL 0x10
#define TAL_COM_SID_ERRORGETSERVICEID 0x11
#define TAL_COM_SID_TRIGGERTRANSMIT 0x13
#define TAL_COM_SID_RXINDICATION 0x14
#define TAL_COM_SID_TXCONFIRMATION 0x15
#define TAL_COM_SID_INVALIDATESHADOWSIGNAL 0x16
#define TAL_COM_SID_TRIGGERIPDUSEND 0x17
#define TAL_COM_SID_MAINFUNCTIONRX 0x18
#define TAL_COM_SID_MAINFUNCTIONTX 0x19
#define TAL_COM_SID_MAINFUNCTIONROUTESIGNALS 0x1A
#define TAL_COM_SID_LIBRARY 0x20
#define TAL_CANIF_SID_INIT 0x01
#define TAL_CANIF_SID_SETCONTROLLERMODE 0x03
#define TAL_CANIF_SID_GETCONTROLLERMODE 0x04
#define TAL_CANIF_SID_TRANSMIT 0x05
#define TAL_CANIF_SID_READRXPDUDATA 0x06
#define TAL_CANIF_SID_READTXNOTIFSTATUS 0x07
#define TAL_CANIF_SID_READRXNOTIFSTATUS 0x08
#define TAL_CANIF_SID_SETPDUMODE 0x09
#define TAL_CANIF_SID_GETPDUMODE 0x0a
#define TAL_CANIF_SID_GETVERSIONINFO 0x0b
#define TAL_CANIF_SID_SETDYNAMICTXID 0x0c
#define TAL_CANIF_SID_SETTRANSCEIVERMODE 0x0d
#define TAL_CANIF_SID_GETTRANSCEIVERMODE 0x0e
#define TAL_CANIF_SID_GETTRCVWAKEUPREASON 0x0f
#define TAL_CANIF_SID_SETTRCVWAKEUPMODE 0x10
#define TAL_CANIF_SID_CHECKWAKEUP 0x11
#define TAL_CANIF_SID_CHECKVALIDATION 0x12
#define TAL_CANIF_SID_TXCONFIRMATION 0x13
#define TAL_CANIF_SID_RXINDICATION 0x14
#define TAL_CANIF_SID_CANCELTXCONFIRMATION 0x15
#define TAL_CANIF_SID_CONTROLLERBUSOFF 0x16
#define TAL_SOAD_SID_INIT 0x01
#define TAL_SOAD_SID_GETVERSIONINFO 0x02
#define TAL_SOAD_SID_IFTRANSMIT 0x03
#define TAL_SOAD_SID_TPTRANSMIT 0x04
#define TAL_SOAD_SID_TPCANCELTRANSMIT 0x05
#define TAL_SOAD_SID_TPCANCELRECEIVE 0x06
#define TAL_SOAD_SID_GETSOCONID 0x07
#define TAL_SOAD_SID_OPENSOCON 0x08
#define TAL_SOAD_SID_CLOSESOCON 0x09
#define TAL_SOAD_SID_REQUESTIPADDRASSIGNMENT 0x0A
#define TAL_SOAD_SID_RELEASEIPADDRASSIGNMENT 0x0B
#define TAL_SOAD_SID_GETLOCALADDR 0x0C
#define TAL_SOAD_SID_GETPHYSADDR 0x0D
#define TAL_SOAD_SID_ENABLEROUTING 0x0E
#define TAL_SOAD_SID_DISABLEROUTING 0x0F
#define TAL_SOAD_SID_SETREMOTEADDR 0x10
#define TAL_SOAD_SID_CHANGEPARAMETER 0x11
#define TAL_SOAD_SID_RXINDICATION 0x12
#define TAL_SOAD_SID_COPYTXDATA 0x13
#define TAL_SOAD_SID_TXCONFIRMATION 0x14
#define TAL_SOAD_SID_TCPACCEPTED 0x15
#define TAL_SOAD_SID_TCPCONNECTED 0x16
#define TAL_SOAD_SID_TCPIPEVENT 0x17
#define TAL_SOAD_SID_LOCALIPADDRASSIGNMENTCHG 0x18
#define TAL_SOAD_SID_MAINFUNCTION 0x19
#define TAL_SOAD_SID_READDHCPHOSTNAMEOPTION 0x1A
#define TAL_SOAD_SID_WRITEDHCPHOSTNAMEOPTION 0x1B
#define TAL_SOAD_SID_GETREMOTEADDR 0x1C
#define TAL_SOAD_SID_IFROUTINGGROUPTRANSMIT 0x1D
#define TAL_SOAD_SID_SETUNIQUEREMOTEADDR 0x1E
#define TAL_SOAD_SID_GETSOCONMODE 0xF0
#define TAL_SOAD_SID_INTERNAL 0xFF
#define TAL_PDUR_SID_INIT 0x01U
#define TAL_PDUR_SID_GET_VER_INF 0x02U
#define TAL_PDUR_SID_GET_CONF_ID 0x10U
#define TAL_PDUR_SID_LO_TXCONF 0x40U
#define TAL_PDUR_SID_LOTP_STRT_OF_RCPTN 0x34U
#define TAL_PDUR_SID_LOTP_COPY_RX_DATA  0x32U
#define TAL_PDUR_SID_LOTP_RXIND 0x33U
#define TAL_PDUR_SID_LOTP_COPY_TX_DATA 0x36U
#define TAL_PDUR_SID_LOTP_TX_CONF 0x37U
#define TAL_PDUR_SID_UP_CANCELTXREQ 0x1CU
#define TAL_PDUR_SID_UP_CHANGEPARAREQ 0x1DU
#define TAL_PDUR_SID_UP_CANCELRXREQ 0x21U
#define TAL_PDUR_SID_LO_RXIND 0x42U
#define TAL_PDUR_SID_LO_TRIGTX 0x41U
#define TAL_PDUR_SID_UP_TX 0x14U
#define TAL_PDUR_SID_IFGW_RXIND_DF 0x55U
#define TAL_PDUR_SID_IFGW_RXIND_TF 0x56U
#define TAL_PDUR_SID_IFGW_RXIND_SB 0x57U
#define TAL_PDUR_SID_IFGW_TRIGTX_TF 0x58U
#define TAL_PDUR_SID_IFGW_TRIGTX_SB 0x59U
#define TAL_SD_SID_INIT 0x01U
#define TAL_SD_SID_MAINFUNCTION 0x06U
#define TAL_SD_SID_GETVERSIONINFO 0x02U
#define TAL_SD_SID_SERVERSERVICESETSTATE 0x07U
#define TAL_SD_SID_CLIENTSERVICESETSTATE 0x08U
#define TAL_SD_SID_CONSUMEDEVENTGROUPSETSTATE 0x09U
#define TAL_SD_SID_LOCALIPADDRASSIGNMENTCHG 0x05U
#define TAL_SD_SID_RXINDICATION 0x42U
#define TAL_ETHTSYN_SID_INIT 0x01 
#define TAL_ETHTSYN_SID_GETVERSIONINFO 0x02
#define TAL_ETHTSYN_SID_GETCURRENTTIME 0x03
#define TAL_ETHTSYN_SID_SETTRANSMISSIONMODE 0x05
#define TAL_ETHTSYN_SID_TRCVLINKSTATECHG 0x08
#define TAL_ETHTSYN_SID_MAINFUNCTION 0x09
#define TAL_FRTSYN_SID_INIT 0x01
#define TAL_FRTSYN_SID_GETVERSIONINFO 0x02
#define TAL_FRTSYN_SID_SETTRANSMISSIONMODE 0x03
#define TAL_FRTSYN_SID_MAINFUNCTION 0x04
#define TAL_FRTSYN_SID_TRIGGERTRANSMIT 0x41
#define TAL_FRTSYN_SID_RXINDICATION 0x42

/*
 * Thrown whenever Host TAL tries to register, send, commit ...
 * a id (signal, pdu, frame) which is not available.
 *
 * argument 1: id which is invalid (not available).
 */
#define TAL_ERROR_INVALID_ID (0x000A)

/*
 * Thrown whenever a CAN controller on the target
 * generates an event
 *
 * argument 1: Index of CAN controller which generated the event
 * argument 2: Event (see type TAL_BM_CANEventFlagsType)
 */
#define TAL_ERROR_CAN (0x000B)

/*
 * Contains a TAL_ReturnType != TAL_SUCCESS.
 *
 * argument 1: TAL_ReturnType error code (Big-endian format)
 * argument 2: index or value which caused the error
 *             (Big-endian format)
 */
#define TAL_ERROR_API (0x000C)

/*
 * Someone tried to send data to a TUM via the data channel and the tum is not
 * available.
 *
 * argument 1: number of the unavailable TUM id
 * argument 2: number of the unavailable TUM instance id
 */
#define TAL_ERROR_TUM_UNAVAIL (0x000D)

/*
 * The table used for storing FlexRay frames to send is full
 *
 * argument 1: frame id
 */
#define TAL_ERROR_TIMED_FLEXRAY_FRAME_TABLE_FULL (0x000E)

/*
 * Overflow in Tx TAL queue (to host)
 *
 * argument 1: number of lost packets
 * argument 2 (optional): Queue number:
 *            0 .. Target to host (also if no arg2 is present)
 *            1 .. Core1 to core2
 *            2 .. Core1 to core2
 *            3 .. Core1 to host
 */
#define TAL_ERROR_TAL_QUEUE_OVERFLOW (0x000F)
#define TAL_ERROR_TAL_QUEUE_OVERFLOW_TARGET_TO_HOST 0
#define TAL_ERROR_TAL_QUEUE_OVERFLOW_CORE2_TO_CORE1 1
#define TAL_ERROR_TAL_QUEUE_OVERFLOW_CORE1_TO_CORE2 2
#define TAL_ERROR_TAL_QUEUE_OVERFLOW_CORE1_TO_HOST  3

/*
 * Contains host string error messages
 */
#define TAL_ERROR_HOST_STRING (0x0FFC)

/*
 * Tum test ended with failure
 */
#define TAL_TUM_TEST_NOK (0x0FFD)

/*
 * Tum test ended without failure
 */
#define TAL_TUM_TEST_OK (0x0FFE)

/*
 * Contains a free-form error string (Big-endian format)
 * Use with function 'BM_Puts()'
 */
#define TAL_ERROR_STRING (0x0FFF)

/*
 * EB INFO messages start at id 0x1000 (if you are an EB colleague without
 * direct SVN access please request an id from guenter.ebermann@elektrobit.com)
 
 * Common Info Numbers. Info numbers are constants. If an info packet
 * contains arguments they are described in the comment above the info.
 */

/*
 * argument 1: CPU load in percent of all jobdisp tasks [0 .. 100]
 */
#define TAL_INFO_CPU_LOAD (0x1000)

/*
 * argument 1: Task name (ASCII string encoded in uint32 without
 *             trailing '\0'
 * argument 2: Task id (returned when calling JobDisp_AddTask())
 * argument 3: Priority of task. Smaller values means higher priorities.
 * argument 4: maximal offset of the start time of a task in microseconds
 * argument 5: maximal runtime in microseconds of one task until it gives up
 *             CPU voluntary
 * argument 6: maximal runtime in microseconds of one non-interruptible task
 *             call
 * argument 7: average runtime in microseconds
 * argument 8: time reserved to let user measure runtime of certain functions.
 *             Can be set using JobDisp_StartWatch() and JobDisp_StopWatch().
 * argument 9: Pointer to the real function with the biggest runtime (based on
 *             maximal runtime of one non-interruptible task call)
 * argument 10: Period in microseconds. 0 means task will be executed once and
 *               then removed.
 * argument 11: CPU load of the task in percent [0 .. 100]
 */
#define TAL_INFO_TASK_LOAD (0x1001)

/*
 * CPU load in percent of all tasks
 * argument 1: Average CPU load in percent over the last 0.1s [0 .. 100]
 * argument 2: Average CPU load in percent over the last 1s [0 .. 100]
 * argument 3: Average CPU load in percent over the last 10s [0 .. 100]
 */
#define TAL_INFO_CPU_LOAD_OVERALL (0x1002)

/*
 * Det error handling:
 * Send the return address of the calling functions (3 levels deep)
 */
#define TAL_INFO_BACKTRACE_FUNC (0x1003u)

/*
 * Det error handling:
 * Send the stack frames of the call stack (3 levels deep)
 */
#define TAL_INFO_BACKTRACE_STACK (0x1004U)

/*
 * Customer ERROR messages start at id 0x2000
 *
 * Please use your own Header File e.g. TAL_TKPErrors.h
 */

/*
 * Customer INFO messages start at id 0x3000
 *
 * Please use your own Header File e.g. TAL_TKPErrors.h
 */

/*
 * TAL_DEBUG messages (id range 0x4000 - 0x4fff)
 */
#define TAL_DEBUG_START (0x4000u)
#define TAL_DEBUG_END (0x4fffu)

/*
 * Ethernet Tx debug message
 * argument 1: FPGA timestamp (MSB)
 * argument 2: FPGA timestamp (LSB)
 * argument 3: Flags - Tx-BD (16 bit) / Ethernet Packet Length (16 bit)
 * ---- Ethernet Packet ----
 * argument 4: MAC Dest. address (byte 0 ... 3)
 * argument 5: MAC Dest. address (byte 4 ... 5) / MAC Src. address (byte 0 ... 1)
 * argument 6: MAC Src. address (byte 2 ... 5)
 * argument 7: Type (16 bit) / optional Payload
 * argument 8: optional Payload 
 *             ...
 */
#define TAL_DEBUG_ETH_TX (0x4000u)
 
/*
 * Ethernet Tx debug message fragment
 * argument 1: optional Payload (cont. from previous TAL_DEBUG_ETH_TX message)
 *             ...
 */
#define TAL_DEBUG_ETH_TX_FRAG (0x4001u)

/*
 * Ethernet Rx debug message
 * argument 1: FPGA timestamp (MSB)
 * argument 2: FPGA timestamp (LSB)
 * argument 3: Flags - Rx-BD (16 bit) / Ethernet Packet Length (16 bit)
 * ---- Ethernet Packet ----
 * argument 4: MAC Dest. address (byte 0 ... 3)
 * argument 5: MAC Dest. address (byte 4 ... 5) / MAC Src. address (byte 0 ... 1)
 * argument 6: MAC Src. address (byte 2 ... 5)
 * argument 7: Type (16 bit) / optional Payload
 * argument 8: optional Payload 
 *             ...
 */
#define TAL_DEBUG_ETH_RX (0x4002u)
 
/*
 * Ethernet Rx debug message fragment
 * argument 1: optional Payload (cont. from previous TAL_DEBUG_ETH_RX message)
 *             ...
 */
#define TAL_DEBUG_ETH_RX_FRAG (0x4003u)

/*
 * Content of all EBx200 general pupose CPU registers (r0 ... r31)
 * argument 1: content of R0
 * argument 2: content of R1
 *             ...
 * argument 32: content of R31
 */
#define TAL_DEBUG_CPU_GPREG_CONTENT (0x4004u)

/*
 * Content of selected EBx200 special purpose CPU registers
 * argument 1: content of CR
 * argument 2: content of LR
 * argument 3: content of CTR
 * argument 4: content of XER 
 * argument 5: content of MSR
 * argument 6: content of PC
 * argument 7: content of SP
 */
#define TAL_DEBUG_CPU_SPREG_CONTENT (0x4005u)

/* 
 * Software scope events packet. Each packet contains events of type SwScope_EventType.
 * argument 1: ID of first event
 * argument 2: timestamp (lower 32 bits) of first event
 * argument 3: ID of 2nd event
 * argument 4: timestamp of second event
 * ...
 */
#define TAL_DEBUG_SWSCOPE_EVNTS     (0x4006u)

/* 
 * Software scope end of frame packet. Packets with this error number have no arguments. 
 * They are used to signals the host that all events (from preTrigger- until postTrigger) have been 
 * transmitted.
 */
#define TAL_DEBUG_SWSCOPE_EOF       (0x4007u)

/* 
 * Software scope resolution of ticks. The software scope sends events to the host which contains 
 * timestamps in CPU time ticks. The debugfile on the host should contain timestamps in nanoseconds. 
 * Therefore a conversion is required, which needs the information how long a tick duration is. 
 * This information is transmitted in a packet with this number.
 * argument 1: Duration of 1000000 (1 million) ticks in nano seconds
 */
#define TAL_DEBUG_SWSCOPE_TICK_RES  (0x4008u)

/*
 * For TUM ids in between 1 and 2047 there are reserved TAL debug IDs.
 * Simply add your TUM-ID to TAL_DEBUG_TUM_START and use this as id for logging with BM_Error()
 */
#define TAL_DEBUG_TUM_START (0x4800u)
#define TAL_DEBUG_TUM_END (0x4fffu)


#endif /* _TAL_ERRORS_H_ */

