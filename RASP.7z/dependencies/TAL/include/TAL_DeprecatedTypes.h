/*
 * File    : $RCSfile: TAL_TypesDeprecated.h,v $ (cvs $Revision: 1.19 $)
 *
 * Module  : TAL_DeprecatedTypes
 * Release : $Name: not supported by cvs2svn $
 * Date    : $Date: 2008-12-12 10:59:51 $
 * Author  : $Author: grfe2844 $
 *
 * Description:
 * Interface header file for deprecated TAL API Types (types which are only
 * used in deprecated TAL API).
 *
 * Copyright 2002-2010 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

/**
 *
 * @file TAL_DeprecatedTypes.h
 *
 * Interface header file for deprecated TAL API Types (types which are only
 * used in deprecated TAL API).
 *
 */

#ifndef _TAL_DEPRECATEDTYPES_H_
#define _TAL_DEPRECATEDTYPES_H_

#include "TAL_Deprecated.h"
#include "TAL_Types.h"

/**
 * @deprecated Do not use this type any more it is a implementation detail
 * @brief Constant, defining the maximal packet size.
 *
 * @def TAL_MAX_PACKET_SIZE
 */
#define TAL_MAX_PACKET_SIZE 1024

/**
 *
 * @brief Macros for offset of the cycle count inside the PCI target status reg
 * 
 * Defines to extract the cycle count
 *
 */
#define TAL_BM_NOTIFY_EVENT_CYCLECOUNT_SHIFT    26

/**
 *
 * @brief Macros for cycle count masking inside the PCI target status reg
 * 
 * Defines to mask the cycle count
 *
 */
#define TAL_BM_NOTIFY_EVENT_CYCLECOUNT_MASK    0x3FU

/**
 * @deprecated
 * @brief Constant, defining the maximum payload of a CAN message in bytes.
 *
 * @def TAL_BM_CAN_MAX_SIZE
 */
#define TAL_BM_CAN_MAX_SIZE 8

/**
 * @deprecated
 * @brief Constant, defining the maximum payload of a CAN-FD message in bytes.
 *
 * @def TAL_BM_CANFD_MAX_SIZE
 */
#define TAL_BM_CANFD_MAX_SIZE 64

/**
 * @brief The FlexRay frame which corresponds with the signal was received
 * successfully.
 *
 * The value of the communication status bit field can be obtained by using
 * the macro TAL_BM_GET_SIGNAL_STATUS_COM.
 *
 * @sa TAL_BM_GET_SIGNAL_STATUS_COM
 */
#define TAL_BM_SIGNAL_STATUS_COM_OK         0U

/**
 * @brief The FlexRay frame which corresponds with the signal could not be
 * received successfully for a period longer than the RX suspicious threshold.
 *
 * The value of the communication status bit field can be obtained by using
 * the macro TAL_BM_GET_SIGNAL_STATUS_COM.
 *
 * @sa TAL_BM_GET_SIGNAL_STATUS_COM
 */
#define TAL_BM_SIGNAL_STATUS_COM_SUSPICIOUS 1U

/**
 * @brief The FlexRay frame which corresponds with the signal could not be
 * received successfully for a period longer than the RX timeout threshold.
 *
 * The value of the communication status bit field can be obtained by using
 * the macro TAL_BM_GET_SIGNAL_STATUS_COM.
 *
 * @sa TAL_BM_GET_SIGNAL_STATUS_COM
 */
#define TAL_BM_SIGNAL_STATUS_COM_RX_TIMEOUT 2U

/**
 * @brief The FlexRay frame which corresponds with the signal has not been
 * received since power up.
 *
 * The value of the communication status bit field can be obtained by using
 * the macro TAL_BM_GET_SIGNAL_STATUS_COM.
 *
 * @sa TAL_BM_GET_SIGNAL_STATUS_COM
 */
#define TAL_BM_SIGNAL_STATUS_COM_NO_MSG     4U

/**
 *
 * @brief Macro for communication status information masking
 *
 * Defines a mask for communication status information of a signal. Do not
 * use this macro directly use the macro TAL_BM_GET_SIGNAL_STATUS_COM
 * instead.
 *
 * @sa TAL_BM_GET_SIGNAL_STATUS_COM
 *
 */
#define TAL_BM_SIGNAL_STATUS_COM_MASK    0xFFU

/**
 *
 * @brief Macro for status information masking
 *
 * Defines for specific status information of a signal. Do not use these
 * macros directly use the macros TAL_BM_GET_SIGNAL_STATUS_UPDATED,
 * TAL_BM_GET_SIGNAL_STATUS_SUBSCRIBED and TAL_BM_GET_SIGNAL_STATUS_INVALID
 * instead.
 *
 * @sa TAL_BM_GET_SIGNAL_STATUS_UPDATED TAL_BM_GET_SIGNAL_STATUS_SUBSCRIBED
 *  TAL_BM_GET_SIGNAL_STATUS_INVALID
 *
 */
#define TAL_BM_SIGNAL_STATUS_INVALID      (1U << 10U)

/*
 * @brief Get the targets communication status
 *
 * Possible return values are: TAL_BM_SIGNAL_STATUS_COM_OK,
 * TAL_BM_SIGNAL_STATUS_COM_SUSPICIOUS, TAL_BM_SIGNAL_STATUS_COM_RX_TIMEOUT
 * and TAL_BM_SIGNAL_STATUS_COM_NO_MSG.
 *
 * @sa TAL_BM_SIGNAL_STATUS_COM_OK, TAL_BM_SIGNAL_STATUS_COM_SUSPICIOUS,
 *  TAL_BM_SIGNAL_STATUS_COM_RX_TIMEOUT or TAL_BM_SIGNAL_STATUS_COM_NO_MSG.
 */
#define TAL_BM_GET_SIGNAL_STATUS_COM(signalStatus) \
    ((signalStatus) & TAL_BM_SIGNAL_STATUS_COM_MASK)

/**
 *
 * @brief Check if a signal is invalid
 *
 * If this macro returns a positive value the signal invalid value was
 * received. However as signal value the last valid signal value is returned.
 *
 */
#define TAL_BM_GET_SIGNAL_STATUS_INVALID(signalStatus) \
    ((signalStatus) & TAL_BM_SIGNAL_STATUS_INVALID)

/* deprecated version of TAL_BM_FrameStatusType */
typedef uint8 TAL_BM_FrameStatusComType;

/**
 *
 * @brief Type to store an identifier for a controller
 *
 * @typedef TAL_ControllerIDType
 *  This scalar type defines a type for identifying a controller index
 *  uniquely.
 *
 */
typedef uint8 TAL_ControllerIDType;

/**
 *
 * @brief Type to define the properties of the dummy device.
 *
 *  Can be used to define the properties of the dummy device.
 */
typedef uint8 TAL_DummyDeviceParameterType;

/**
 *
 * @brief Structure to encapsulate version information about the
 *        target
 *
 * @struct TAL_TargetVersionInfoType
 *  This struct holds version information about the target; where
 *  scalar values and some natural speech text is enclosed.
 *
 */
typedef struct
{
    uint16 redbootMajorVersion; /**< Major version number */
    uint16 redbootMinorVersion; /**< Minor version number */
    uint16 fpgaVersion;         /**< FPGA version number */
    uint16 fpgaGeneralImplementation; /**< FPGA general implementation
                                       * register value, enlists enclosed
                                       * modules */
} TAL_TargetFirmwareVersionInfoType;

/**
 *
 * @brief Enumeration for Baudrate of CAN network (controller)
 *
 *  This enum type defines identifiers to select the baudrate of a CAN
 *  network (controller).
 *
 */
typedef enum
{
     TAL_BM_BR_1000_KBIT = 0
    /**< 1 MBit/sec */
    ,TAL_BM_BR_800_KBIT = 1
    /**< 800 kBit/sec */
    ,TAL_BM_BR_500_KBIT = 2
    /**< 500 kBit/sec */
    ,TAL_BM_BR_250_KBIT = 3
    /**< 250 kBit/sec */
    ,TAL_BM_BR_125_KBIT = 4
    /**< 125 kBit/sec */
    ,TAL_BM_BR_100_KBIT = 5
    /**< 100 kBit/sec */
    ,TAL_BM_BR_SKIP_INIT = 6
    /**< skip baudrate initialization of CAN controller. Use this value if the
     * baudrate was already initialized from a TUM. */
}TAL_BM_CANBaudRateType;

typedef uint8 TAL_BM_ScalarCANBaudRateType;


#endif
