/*
 * File    : TAL_EBHSCR.h
 *
 * Description:
 * Interface header file for externally visible TAL API EBHSCR specific stuff.
 *
 * Copyright 2002-2021 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Note: if you want to have full control over target endianess, define the
 * macro CPU_BYTE_ORDER either to HIGH_BYTE_FIRST or LOW_BYTE_FIRST.
 * Otherwise the compiler tries to determine endianess by itself
 */

#ifndef _TAL_EBHSCR_H_
#define _TAL_EBHSCR_H_

#include <stdint.h>
#include "TAL_Endian.h"
#include "TAL_Bitfield.h"


/***************************************************/
/*  EBHSCR Major numbers (Customer specific area)  */
/***************************************************/

#define EBHSCR_MAJOR_LVDS320                        0x43
#define EBHSCR_MAJOR_LVDS160                        0x44
#define EBHSCR_MAJOR_LVDS3G                         0x45

/****************************************/
/*  EBHSCR Major numbers (Public area)  */
/****************************************/

/**
 * @brief Constant, defining EBHSCR Major Protocol number for BROADR REACH on EB7200 types
 *
 * @def EBHSCR_MAJOR_ETHERNET
 */
#define EBHSCR_MAJOR_ETHERNET                       0x50
/**
 * @brief Constant, defining EBHSCR Major Protocol number for NEMA types
 *
 * @def EBHSCR_MAJOR_NMEA
 */
#define EBHSCR_MAJOR_NMEA                           0x51
/**
 * @brief Constant, defining EBHSCR Major Protocol number for TimeState
 *
 * @def EBHSCR_MAJOR_TIMESTATE
 */
#define EBHSCR_MAJOR_TIMESTATE                      0x52
/**
 * @brief Constant, defining EBHSCR Major Protocol number for CAN & CAN FD types
 *
 * @def EBHSCR_MAJOR_CAN
 */
#define EBHSCR_MAJOR_CAN                            0x53
/**
 * @brief Constant, defining EBHSCR Major Protocol number for EOC types
 *
 * @def EBHSCR_MAJOR_MGMT
 */
#define EBHSCR_MAJOR_MGMT                           0x54
/**
 * @brief Constant, defining EBHSCR Major Protocol number for LIN types
 *
 * @def EBHSCR_MAJOR_LIN
 */
#define EBHSCR_MAJOR_LIN                            0x55
/**
 * @brief Constant, defining EBHSCR Major Protocol number for DETI types
 *
 * @def EBHSCR_MAJOR_DIGITAL_IO
 */
#define EBHSCR_MAJOR_DIGITAL_IO                     0x56
/**
 * @brief Constant, defining EBHSCR Major Protocol number for FlexRay types
 *
 * @def EBHSCR_MAJOR_FLEXRAY
 */
#define EBHSCR_MAJOR_FLEXRAY                        0x57
/**
 * @brief Constant, defining EBHSCR Major Protocol number for PDU types
 *
 * @def EBHSCR_MAJOR_PDU
 */
#define EBHSCR_MAJOR_PDU                            0x58

/**
 * @brief Constant, defining the minimum supported EBHSCR Major Protocol number
 *
 * @def EBHSCR_MAJOR_MIN
 */
#define EBHSCR_MAJOR_MIN                            0x43
/**
 * @brief Constant, defining the maximum supported EBHSCR Major Protocol number
 *
 * @def EBHSCR_MAJOR_MAX
 */
#define EBHSCR_MAJOR_MAX                            0x70

/**
 * @defgroup EBHSCR EBHSCR packet manipulation functions
 * @{
 */

/**
 *
 * @brief Constant, defining the maximum supported size of EBHSCR packets in bytes
 *
 * @def EBHSCR_MAX_PACKET_SIZE
 *
 */
#define EBHSCR_MAX_PACKET_SIZE                      (8 * 1024 * 1024 + EBHSCR_HEADER_SIZE)

/**
 *
 * @brief Constant, defining the header size of EBHSCR packets in bytes
 *
 * @def EBHSCR_HEADER_SIZE
 *
 */
#define EBHSCR_HEADER_SIZE                          32

/*
 * currently we support only version 0 of the protocol
 */
#define EBHSCR_VERSION_NUMBER                       0U

/**
 * @brief Structure to map to the header of an EBHSCR packet
 *
 * @struct ebhscr_header
 *  This struct defines the major components of an EBHSCR header as 64-bit values.
 *  You may use the ebhscr_set_ and ebhscr_get_ functions to set or get elements
 *  of the structure
 */
#pragma pack(push,4) /* the structure shall be aligned only at 4-byte boundaries */
struct ebhscr_header
{
    /* the chdr may be accessed as 64-bit entity or as individual elements */
    union
    {
        uint64_t full;
        struct
        {
            uint8_t major;
            uint8_t slot_channel;
            uint16_t version_status;
            uint32_t len;
        } part;
    } chdr;            /**< common header */
    uint64_t start_ts; /**< start timestamp in ns */
    uint64_t stop_ts;  /**< stop timestamp in ns */
    uint64_t mhdr;     /**< major number specific header */
};
#pragma pack(pop)

/* flexible array members are only defined for C (starting with C99),
 * and not for C++ therefore define it to be the maximum size otherwise
 * to prevent compiler warnings
 */
#if defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 199409L)
#define EBHSCR_DEFAULT_PAYLOAD_SIZE
#else
#define EBHSCR_DEFAULT_PAYLOAD_SIZE (EBHSCR_MAX_PACKET_SIZE / sizeof(uint64_t))
#endif

/**
 * @brief Structure to map to an EBHSCR packet
 *
 * @struct ebhscr
 *  This struct defines the header and payload of an EBHSCR packet.
 *
 * @note Do not allocate variables of this type because - depending on the used
 *       compiler - it may either define the maximum possible payload or no
 *       payload at all and thus you will waste a lot of memory by doing so
 *
 * @sa ebhscr_header
 */
#pragma pack(push,4) /* the structure shall be aligned only at 4-byte boundaries */
struct ebhscr
{
    struct ebhscr_header hdr;
    uint64_t payload[EBHSCR_DEFAULT_PAYLOAD_SIZE];
};
#pragma pack(pop)

/**
 * @brief Write the common header of an EBHSCR packet
 *
 * @param ebhscr  Pointer to the header of the EBHSCR packet
 * @param major   Major number of the EBHSCR packet
 * @param slot    Slot number of the EBHSCR packet
 * @param channel Channel number of the EBHSCR packet
 * @param status  Status field of the EBHSCR packet
 * @param len     Length in bytes of the payload of the EBHSCR packet
 *
 * @note The function writes the timestamp as a big endian value as specified for EBHSCR packets
 *
 * @retval None
 */
static inline void ebhscr_set_chdr(
    struct ebhscr_header *ebhscr,
    uint8_t major,
    uint8_t slot,
    uint8_t channel,
    uint16_t status,
    uint32_t len)
{
    uint64_t chdr = ((uint64_t)major << 56U) |
                    ((uint64_t)(slot & 0x03U) << 54) |
                    ((uint64_t)(channel & 0x3fU) << 48) |
                    ((uint64_t)(EBHSCR_VERSION_NUMBER & 0x0fU) << 44 ) | /* version number */
                    ((uint64_t)(status & 0xfffU) << 32U) | len;
    ebhscr->chdr.full = CpuToBigEndianU64(chdr);
}

/**
 * @brief Write the common header of an EBHSCR packet and convert the buffer pointer
 *        into an EBHSCR pointer
 *
 * @param buffer  Pointer to the EBHSCR packet memory
 * @param buffer_size Size of the buffer in bytes (including EBHSCR header)
 * @param major   Major number of the EBHSCR packet
 * @param slot    Slot number of the EBHSCR packet
 * @param channel Channel number of the EBHSCR packet
 * @param status  Status field of the EBHSCR packet
 * @param len     Length in bytes of the payload of the EBHSCR packet
 *
 * @note The function writes the timestamp as a big endian value as specified for EBHSCR packets
 *
 * @retval NULL if buffer is NULL or buffer_size is too low
 *         Pointer to buffer converted to a pointer to an EBHSCR packet otherwise
 */
static inline struct ebhscr* ebhscr_init(
    uint64_t* buffer,
    size_t buffer_size,
    uint8_t major,
    uint8_t slot,
    uint8_t channel,
    uint16_t status,
    uint32_t len)
{
    struct ebhscr* ebhscr_packet;

    if (buffer == NULL || buffer_size < EBHSCR_HEADER_SIZE + len)
    {
        return NULL;
    }

    ebhscr_packet = (struct ebhscr*)(buffer);
    ebhscr_set_chdr(&(ebhscr_packet->hdr), major, slot, channel, status, len);
    return ebhscr_packet;
}

/**
 * @brief Write start timestamp of an EBHSCR packet
 *
 * @param ebhscr  Pointer to the header of the EBHSCR packet
 * @param start_ts Start timestamp in units of nanoseconds
 *
 * @note The function writes the timestamp as a big endian value as specified for EBHSCR packets
 *
 * @retval None
 */
static inline void ebhscr_set_start_ts(struct ebhscr_header *ebhscr, uint64_t start_ts)
{
    ebhscr->start_ts = CpuToBigEndianU64(start_ts);
}

/**
 * @brief Write stop timestamp of an EBHSCR packet
 *
 * @param ebhscr  Pointer to the header of the EBHSCR packet
 * @param stop_ts Stop timestamp in units of nanoseconds
 *
 * @note The function writes the timestamp as a big endian value as specified for EBHSCR packets
 *
 * @retval None
 */
static inline void ebhscr_set_stop_ts(struct ebhscr_header *ebhscr, uint64_t stop_ts)
{
    ebhscr->stop_ts = CpuToBigEndianU64(stop_ts);
}

/**
 * @brief Write major number specific header of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 * @param mhdr   Value of major number specific header
 *
 * @note The function writes the major number specific header as a big endian value as specified for EBHSCR packets
 *
 * @retval None
 */
static inline void ebhscr_set_mhdr(struct ebhscr_header *ebhscr, uint64_t mhdr)
{
    ebhscr->mhdr = CpuToBigEndianU64(mhdr);
}

/**
 * @brief Get major number of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Major number of EBHSCR packet
 */
static inline uint8_t ebhscr_get_major(const struct ebhscr_header *ebhscr)
{
    return ebhscr->chdr.part.major;
}

/**
 * @brief Get slot number of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Slot number of EBHSCR packet
 */
static inline uint8_t ebhscr_get_slot(const struct ebhscr_header *ebhscr)
{
    return (ebhscr->chdr.part.slot_channel >> 6) & 0x03U;
}

/**
 * @brief Get channel number of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Channel number of EBHSCR packet
 */
static inline uint8_t ebhscr_get_channel(const struct ebhscr_header *ebhscr)
{
    return ebhscr->chdr.part.slot_channel & 0x3fU;
}

/**
 * @brief Get protocol version number of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Protocol version number of EBHSCR packet
 */
static inline uint8_t ebhscr_get_version(const struct ebhscr_header *ebhscr)
{
    return (BigEndianU16ToCpu(ebhscr->chdr.part.version_status) >> 12U) & 0x0fU;
}

/**
 * @brief Get status field of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Status field of EBHSCR packet
 *
 * @note Use the TAL_BITFIELD macros to access the members of the status field - the value should be suffixed with ULL
 * to avoid warnings
 *
 * @sa TAL_GET_BITFIELD
 * @sa TAL_SET_BITFIELD
 * @sa TAL_SET_BITFIELD_CONST
 * @sa TAL_BITFIELD
 * @sa TAL_BITFIELD_CONST
 */
static inline uint16_t ebhscr_get_status(const struct ebhscr_header *ebhscr)
{
    return BigEndianU16ToCpu(ebhscr->chdr.part.version_status) & 0x0fffU;
}

/**
 * @brief Get payload size of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Payload size of EBHSCR packet
 */
static inline uint32_t ebhscr_get_payload_size(const struct ebhscr_header *ebhscr)
{
    return BigEndianU32ToCpu(ebhscr->chdr.part.len);
}

/**
 * @brief Get start timestamp of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Start timestamp of EBHSCR packet in units of nanoseconds
 */
static inline uint64_t ebhscr_get_start_ts(const struct ebhscr_header *ebhscr)
{
    return BigEndianU64ToCpu(ebhscr->start_ts);
}

/**
 * @brief Get stop timestamp of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Stop timestamp of EBHSCR packet in units of nanoseconds
 */
static inline uint64_t ebhscr_get_stop_ts(const struct ebhscr_header *ebhscr)
{
    return BigEndianU64ToCpu(ebhscr->stop_ts);
}

/**
 * @brief Get major number specific header of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Major number specifid header of EBHSCR packet
 *
 * @note Use the TAL_BITFIELD macros to access the members of the major number specific header - the value should be suffixed with ULL
 * to avoid warnings
 *
 * @sa TAL_GET_BITFIELD
 * @sa TAL_SET_BITFIELD
 * @sa TAL_SET_BITFIELD_CONST
 * @sa TAL_BITFIELD
 * @sa TAL_BITFIELD_CONST
 */
static inline uint64_t ebhscr_get_mhdr(const struct ebhscr_header *ebhscr)
{
    return BigEndianU64ToCpu(ebhscr->mhdr);
}

/********************************************************************************************/
/* unaligned versions of functions - maybe removed after TAL_PP elements are uint32 aligned */
/********************************************************************************************/

/**
 * @brief Structure to map to the header of an EBHSCR packet
 *
 * @struct ebhscr_header
 *  This struct defines the major components of an EBHSCR header as 64-bit values.
 *  You may use the ebhscr_set_ and ebhscr_get_ functions to set or get elements
 *  of the structure
 */
#pragma pack(push,1) /* the structure shall be aligned at 1-byte boundaries */
struct ebhscr_header_ua
{
    /* the chdr may be accessed as 64-bit entity or as individual elements */
    union
    {
        uint64_t full;
        struct
        {
            uint8_t major;
            uint8_t slot_channel;
            uint16_t version_status;
            uint32_t len;
        } part;
    } chdr;            /**< common header */
    uint64_t start_ts; /**< start timestamp in ns */
    uint64_t stop_ts;  /**< stop timestamp in ns */
    uint64_t mhdr;     /**< major number specific header */
};
#pragma pack(pop)

/**
 * @brief Structure to map to an EBHSCR packet
 *
 * @struct ebhscr
 *  This struct defines the header and payload of an EBHSCR packet.
 *
 * @note Do not allocate variables of this type because - depending on the used
 *       compiler - it may either define the maximum possible payload or no
 *       payload at all and thus you will waste a lot of memory by doing so
 *
 * @sa ebhscr_header
 */
#pragma pack(push,1) /* the structure shall be aligned at 1-byte boundaries */
struct ebhscr_ua
{
    struct ebhscr_header_ua hdr;
    uint64_t payload[EBHSCR_DEFAULT_PAYLOAD_SIZE];
};
#pragma pack(pop)

/**
 * @brief Write the common header of an EBHSCR packet
 *
 * @param ebhscr  Pointer to the header of the EBHSCR packet
 * @param major   Major number of the EBHSCR packet
 * @param slot    Slot number of the EBHSCR packet
 * @param channel Channel number of the EBHSCR packet
 * @param status  Status field of the EBHSCR packet
 * @param len     Length in bytes of the payload of the EBHSCR packet
 *
 * @note The function writes the timestamp as a big endian value as specified for EBHSCR packets
 *
 * @retval None
 */
static inline void ebhscr_set_chdr_ua(
    struct ebhscr_header_ua *ebhscr,
    uint8_t major,
    uint8_t slot,
    uint8_t channel,
    uint16_t status,
    uint32_t len)
{
    uint64_t chdr = ((uint64_t)major << 56U) |
                    ((uint64_t)(slot & 0x03U) << 54) |
                    ((uint64_t)(channel & 0x3fU) << 48) |
                    ((uint64_t)(EBHSCR_VERSION_NUMBER & 0x0fU) << 44 ) | /* version number */
                    ((uint64_t)(status & 0xfffU) << 32U) | len;
    ebhscr->chdr.full = CpuToBigEndianU64(chdr);
}

/**
 * @brief Write the common header of an EBHSCR packet and convert the buffer pointer
 *        into an EBHSCR pointer
 *
 * @param buffer  Pointer to the EBHSCR packet memory
 * @param buffer_size Size of the buffer in bytes (including EBHSCR header)
 * @param major   Major number of the EBHSCR packet
 * @param slot    Slot number of the EBHSCR packet
 * @param channel Channel number of the EBHSCR packet
 * @param status  Status field of the EBHSCR packet
 * @param len     Length in bytes of the payload of the EBHSCR packet
 *
 * @note The function writes the timestamp as a big endian value as specified for EBHSCR packets
 *
 * @retval NULL if buffer is NULL or buffer_size is too low
 *         Pointer to buffer converted to a pointer to an EBHSCR packet otherwise
 */
static inline struct ebhscr_ua* ebhscr_init_ua(
    uint64_t* buffer,
    size_t buffer_size,
    uint8_t major,
    uint8_t slot,
    uint8_t channel,
    uint16_t status,
    uint32_t len)
{
    struct ebhscr_ua* ebhscr_packet;

    if (buffer == NULL || buffer_size < EBHSCR_HEADER_SIZE + len)
    {
        return NULL;
    }

    ebhscr_packet = (struct ebhscr_ua*)(buffer);
    ebhscr_set_chdr_ua(&(ebhscr_packet->hdr), major, slot, channel, status, len);
    return ebhscr_packet;
}

/**
 * @brief Write start timestamp of an EBHSCR packet
 *
 * @param ebhscr  Pointer to the header of the EBHSCR packet
 * @param start_ts Start timestamp in units of nanoseconds
 *
 * @note The function writes the timestamp as a big endian value as specified for EBHSCR packets
 *
 * @retval None
 */
static inline void ebhscr_set_start_ts_ua(struct ebhscr_header_ua *ebhscr, uint64_t start_ts)
{
    ebhscr->start_ts = CpuToBigEndianU64(start_ts);
}

/**
 * @brief Write stop timestamp of an EBHSCR packet
 *
 * @param ebhscr  Pointer to the header of the EBHSCR packet
 * @param stop_ts Stop timestamp in units of nanoseconds
 *
 * @note The function writes the timestamp as a big endian value as specified for EBHSCR packets
 *
 * @retval None
 */
static inline void ebhscr_set_stop_ts_ua(struct ebhscr_header_ua *ebhscr, uint64_t stop_ts)
{
    ebhscr->stop_ts = CpuToBigEndianU64(stop_ts);
}

/**
 * @brief Write major number specific header of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 * @param mhdr   Value of major number specific header
 *
 * @note The function writes the major number specific header as a big endian value as specified for EBHSCR packets
 *
 * @retval None
 */
static inline void ebhscr_set_mhdr_ua(struct ebhscr_header_ua *ebhscr, uint64_t mhdr)
{
    ebhscr->mhdr = CpuToBigEndianU64(mhdr);
}

/**
 * @brief Get major number of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Major number of EBHSCR packet
 */
static inline uint8_t ebhscr_get_major_ua(const struct ebhscr_header_ua *ebhscr)
{
    return ebhscr->chdr.part.major;
}

/**
 * @brief Get slot number of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Slot number of EBHSCR packet
 */
static inline uint8_t ebhscr_get_slot_ua(const struct ebhscr_header_ua *ebhscr)
{
    return (ebhscr->chdr.part.slot_channel >> 6) & 0x03U;
}

/**
 * @brief Get channel number of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Channel number of EBHSCR packet
 */
static inline uint8_t ebhscr_get_channel_ua(const struct ebhscr_header_ua *ebhscr)
{
    return ebhscr->chdr.part.slot_channel & 0x3fU;
}

/**
 * @brief Get protocol version number of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Protocol version number of EBHSCR packet
 */
static inline uint8_t ebhscr_get_version_ua(const struct ebhscr_header_ua *ebhscr)
{
    return (BigEndianU16ToCpu(ebhscr->chdr.part.version_status) >> 12U) & 0x0fU;
}

/**
 * @brief Get status field of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Status field of EBHSCR packet
 *
 * @note Use the TAL_BITFIELD macros to access the members of the status field - the value should be suffixed with ULL
 * to avoid warnings
 *
 * @sa TAL_GET_BITFIELD
 * @sa TAL_SET_BITFIELD
 * @sa TAL_SET_BITFIELD_CONST
 * @sa TAL_BITFIELD
 * @sa TAL_BITFIELD_CONST
 */
static inline uint16_t ebhscr_get_status_ua(const struct ebhscr_header_ua *ebhscr)
{
    return BigEndianU16ToCpu(ebhscr->chdr.part.version_status) & 0x0fffU;
}

/**
 * @brief Get payload size of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Payload size of EBHSCR packet
 */
static inline uint32_t ebhscr_get_payload_size_ua(const struct ebhscr_header_ua *ebhscr)
{
    return BigEndianU32ToCpu(ebhscr->chdr.part.len);
}

/**
 * @brief Get start timestamp of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Start timestamp of EBHSCR packet in units of nanoseconds
 */
static inline uint64_t ebhscr_get_start_ts_ua(const struct ebhscr_header_ua *ebhscr)
{
    return BigEndianU64ToCpu(ebhscr->start_ts);
}

/**
 * @brief Get stop timestamp of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Stop timestamp of EBHSCR packet in units of nanoseconds
 */
static inline uint64_t ebhscr_get_stop_ts_ua(const struct ebhscr_header_ua *ebhscr)
{
    return BigEndianU64ToCpu(ebhscr->stop_ts);
}

/**
 * @brief Get major number specific header of an EBHSCR packet
 *
 * @param ebhscr Pointer to the header of the EBHSCR packet
 *
 * @note The function converts the value from the big endian representation of the EBHSCR packet to the host representation
 *
 * @retval Major number specifid header of EBHSCR packet
 *
 * @note Use the TAL_BITFIELD macros to access the members of the major number specific header - the value should be suffixed with ULL
 * to avoid warnings
 *
 * @sa TAL_GET_BITFIELD
 * @sa TAL_SET_BITFIELD
 * @sa TAL_SET_BITFIELD_CONST
 * @sa TAL_BITFIELD
 * @sa TAL_BITFIELD_CONST
 */
static inline uint64_t ebhscr_get_mhdr_ua(const struct ebhscr_header_ua *ebhscr)
{
    return BigEndianU64ToCpu(ebhscr->mhdr);
}

/********************************************************************************************/
/********************************************************************************************/
/********************************************************************************************/

/************/
/* Ethernet */
/************/
/**
 * @defgroup ETHERNET Ethernet constants for TAL_BITFIELD macros
 * @ingroup EBHSCR
 *
 * @{
 */

/**
 * @defgroup ETH_CHANNEL Ethernet channel bits
 * @ingroup ETHERNET
 *
 * @{
 */

/** @brief packet is a captured transmit packet */
#define EBHSCR_CHANNEL_TX_CAPTURE_MASK              0x08U
#define EBHSCR_CHANNEL_TX_CAPTURE_SHIFT             3

/**
 * @}
 */

/**
 * @defgroup ETH_STATUS Ethernet status bits
 * @ingroup ETHERNET
 *
 * @{
 */

/** @brief  CRC error occurred */
#define EBHSCR_STATUS_ETH_CRC_ERR_MASK              0x001U
#define EBHSCR_STATUS_ETH_CRC_ERR_SHIFT             0U

/** @brief  MII FIFO overflow occurred */
#define EBHSCR_STATUS_ETH_MII_FIFO_OVFL_MASK        0x002U
#define EBHSCR_STATUS_ETH_MII_FIFO_OVFL_SHIFT       1U

/** @brief  Payload FIFO overflow occurred */
#define EBHSCR_STATUS_ETH_PAYLOAD_FIFO_OVFL_MASK    0x004U
#define EBHSCR_STATUS_ETH_PAYLOAD_FIFO_OVFL_SHIFT   2U

/** @brief  Header FIFO overflow occurred */
#define EBHSCR_STATUS_ETH_HEADER_FIFO_OVFL_MASK     0x008U
#define EBHSCR_STATUS_ETH_HEADER_FIFO_OVFL_SHIFT    3U

/** @brief  RX decoder error occurred */
#define EBHSCR_STATUS_ETH_RX_DECODER_ERR_MASK       0x010U
#define EBHSCR_STATUS_ETH_RX_DECODER_ERR_SHIFT      4U

/** @brief  Symbol error occurred */
#define EBHSCR_STATUS_ETH_SYMBOL_ERR_MASK           0x020U
#define EBHSCR_STATUS_ETH_SYMBOL_ERR_SHIFT          5U

/** @brief  Jabber error occurred */
#define EBHSCR_STATUS_ETH_JABBER_MASK               0x040U
#define EBHSCR_STATUS_ETH_JABBER_SHIFT              6U

/** @brief  Changed polarity error occurred */
#define EBHSCR_STATUS_ETH_POLARITY_CHG_MASK         0x080U
#define EBHSCR_STATUS_ETH_POLARITY_CHG_SHIFT        7U

/** @brief  False carrier error occurred */
#define EBHSCR_STATUS_ETH_FALSE_CARRIER_MASK        0x100U
#define EBHSCR_STATUS_ETH_FALSE_CARRIER_SHIFT       8U

/** @brief  packet truncated error occurred */
#define EBHSCR_STATUS_ETH_TRUNC_MASK                0x200U
#define EBHSCR_STATUS_ETH_TRUNC_SHIFT               9U

/** @brief  TX packet was discarded because it was too late */
#define EBHSCR_STATUS_ETH_TX_DISCARDED_ERR_MASK     0x400U /* capture */
#define EBHSCR_STATUS_ETH_TX_DISCARDED_ERR_SHIFT    10U    /* capture */

/** @brief  Set frame separation reference time with this packet */
#define EBHSCR_STATUS_ETH_START_FRAME_SEP_MASK      0x400U /* replay */
#define EBHSCR_STATUS_ETH_START_FRAME_SEP_SHIFT     10U    /* replay */

/** @brief  Wait for frame separation time */
#define EBHSCR_STATUS_ETH_WAIT_FRAME_SEP_MASK       0x800U
#define EBHSCR_STATUS_ETH_WAIT_FRAME_SEP_SHIFT      11U

/**
 * @}
 */

/**
 * @defgroup ETH_MHDR Ethernet major number specific header bits
 * @ingroup ETHERNET
 *
 * @{
 */

/** @brief  Packet truncation occurred on transmission */
#define EBHSCR_MHDR_ETH_TX_TR_MASK                  0x0001000000000000ULL
#define EBHSCR_MHDR_ETH_TX_TR_SHIFT                 48U

/** @brief  Packet transmitter underrun occurred */
#define EBHSCR_MHDR_ETH_TX_UR_MASK                  0x0002000000000000ULL
#define EBHSCR_MHDR_ETH_TX_UR_SHIFT                 49U

/** @brief  Packet retransmission limit exceeded */
#define EBHSCR_MHDR_ETH_TX_RL_MASK                  0x0004000000000000ULL
#define EBHSCR_MHDR_ETH_TX_RL_SHIFT                 50U

/** @brief  Late collision was detected on packet transmission */
#define EBHSCR_MHDR_ETH_TX_LC_MASK                  0x0008000000000000ULL
#define EBHSCR_MHDR_ETH_TX_LC_SHIFT                 51U

/** @brief  link is up */
#define EBHSCR_MHDR_ETH_LINK_UP_MASK                0x0000000100000000ULL
#define EBHSCR_MHDR_ETH_LINK_UP_SHIFT               32U

/** @brief  link is in master mode */
#define EBHSCR_MHDR_ETH_MASTER_MASK                 0x0000000200000000ULL
#define EBHSCR_MHDR_ETH_MASTER_SHIFT                33U

/** @brief  frame check sequence is not appended */
#define EBHSCR_MHDR_ETH_NO_FCS_MASK                 0x0000000400000000ULL
#define EBHSCR_MHDR_ETH_NO_FCS_SHIFT                34U

/* Bit 3 in Byte 4 is reserved (Position 35) */

/** @brief  interface speed */
#define EBHSCR_MHDR_ETH_BR_MASK                     0x000000F000000000ULL
#define EBHSCR_MHDR_ETH_BR_SHIFT                    36U
#define EBHSCR_MHDR_ETH_BR_10M                      0x00ULL
#define EBHSCR_MHDR_ETH_BR_100M                     0x01ULL
#define EBHSCR_MHDR_ETH_BR_1000M                    0x02ULL
#define EBHSCR_MHDR_ETH_BR_2_5G                     0x03ULL
#define EBHSCR_MHDR_ETH_BR_5G                       0x04ULL
#define EBHSCR_MHDR_ETH_BR_10G                      0x05ULL
#define EBHSCR_MHDR_ETH_BR_25G                      0x06ULL
#define EBHSCR_MHDR_ETH_BR_40G                      0x07ULL
#define EBHSCR_MHDR_ETH_BR_100G                     0x08ULL
#define EBHSCR_MHDR_ETH_BR_UNKNOWN                  0x0FULL

/** @brief  specified separation time */
#define EBHSCR_MHDR_ETH_STIME_MASK                  0x000000000000FFFFULL
#define EBHSCR_MHDR_ETH_STIME_SHIFT                 0U

/**
 * @}
 */

/**
 * @}
 */



/************/
/* FlexRay */
/************/
/**
 * @defgroup FLEXRAY FlexRay constants for TAL_BITFIELD macros
 * @ingroup EBHSCR
 *
 * @{
 */

/**
 * @defgroup FLEXRAY_CHANNEL FlexRay channel bits
 * @ingroup FLEXRAY
 *
 * @{
 */

/** @brief Flexray channel A packet */
#define EBHSCR_CHANNEL_FLEXRAY_CH_A_MASK    0x01U
#define EBHSCR_CHANNEL_FLEXRAY_CH_A_SHIFT   0U

/** @brief Flexray channel B packet */
#define EBHSCR_CHANNEL_FLEXRAY_CH_B_MASK    0x02U
#define EBHSCR_CHANNEL_FLEXRAY_CH_B_SHIFT   1U

/** @brief Controller id (zero based) */
#define EBHSCR_CHANNEL_FLEXRAY_CTRL_ID_MASK    0x1CU
#define EBHSCR_CHANNEL_FLEXRAY_CTRL_ID_SHIFT   2U

/**
 * @}
 */

/**
 * @defgroup FLEXRAY_STATUS Flexray status bits
 * @ingroup FLEXRAY
 *
 * @{
 */

/** @brief  Packet was generated by FlexRay synchronous monitoring */
#define EBHSCR_STATUS_FLEXRAY_SYNC_MON_MASK             0x001U
#define EBHSCR_STATUS_FLEXRAY_SYNC_MON_SHIFT            0U

/** @brief  FlexRay cluster is in sync  (only valid if bit 0 = 1) */
#define EBHSCR_STATUS_FLEXRAY_SYNC_MASK                 0x002U
#define EBHSCR_STATUS_FLEXRAY_SYNC_SHIFT                1U

/** @brief  Type of FlexRay packet */
#define EBHSCR_STATUS_FLEXRAY_PKT_TYPE_MASK             0x00CU
#define EBHSCR_STATUS_FLEXRAY_PKT_TYPE_SHIFT            2U
#define EBHSCR_STATUS_FLEXRAY_PKT_TYPE_FRAME            0x00U
#define EBHSCR_STATUS_FLEXRAY_PKT_TYPE_SYMBOL           0x01U
#define EBHSCR_STATUS_FLEXRAY_PKT_TYPE_SLOT_STATUS      0x02U
#define EBHSCR_STATUS_FLEXRAY_PKT_TYPE_START_OF_CYCLE   0x03U

/** @brief  Coding Error */
#define EBHSCR_STATUS_FLEXRAY_CODERR_MASK               0x010U
#define EBHSCR_STATUS_FLEXRAY_CODERR_SHIFT              4U

/** @brief  TSS violation */
#define EBHSCR_STATUS_FLEXRAY_TSSVIOL_MASK              0x020U
#define EBHSCR_STATUS_FLEXRAY_TSSVIOL_SHIFT             5U

/** @brief  Header CRC error */
#define EBHSCR_STATUS_FLEXRAY_HCRCERR_MASK              0x040U
#define EBHSCR_STATUS_FLEXRAY_HCRCERR_SHIFT             6U

/** @brief  Frame CRC error */
#define EBHSCR_STATUS_FLEXRAY_FCRCERR_MASK              0x080U
#define EBHSCR_STATUS_FLEXRAY_FCRCERR_SHIFT             7U

/** @brief  Frame end sequence error */
#define EBHSCR_STATUS_FLEXRAY_FESERR_MASK               0x100U
#define EBHSCR_STATUS_FLEXRAY_FESERR_SHIFT              8U

/** @brief  Frame start sequence error */
#define EBHSCR_STATUS_FLEXRAY_FSSERR_MASK               0x200U
#define EBHSCR_STATUS_FLEXRAY_FSSERR_SHIFT              9U

/** @brief  Byte start sequence error */
#define EBHSCR_STATUS_FLEXRAY_BSSERR_MASK               0x400U
#define EBHSCR_STATUS_FLEXRAY_BSSERR_SHIFT              10U

/** @brief  Timestamp could only be estimated */
#define EBHSCR_STATUS_FLEXRAY_ESTIMATED_TIMESTAMP_MASK  0x800U
#define EBHSCR_STATUS_FLEXRAY_ESTIMATED_TIMESTAMP_SHIFT 11U

/**
 * @}
 */

/**
 * @defgroup FLEXRAY_MHDR FlexRay major number specific header bits
 * @ingroup FLEXRAY
 *
 * @{
 */

/** @brief  Slot Information */
#define EBHSCR_MHDR_FLEXRAY_SLOT_INFO_MASK              0xFFFF000000000000ULL
#define EBHSCR_MHDR_FLEXRAY_SLOT_INFO_SHIFT             48U

/** @brief  Slot ID */
#define EBHSCR_MHDR_FLEXRAY_SID_MASK                    0x07FF000000000000ULL
#define EBHSCR_MHDR_FLEXRAY_SID_SHIFT                   48U

/** @brief  Valid Frame Received */
#define EBHSCR_MHDR_FLEXRAY_VFR_MASK                    0x0800000000000000ULL
#define EBHSCR_MHDR_FLEXRAY_VFR_SHIFT                   59U

/** @brief  Syntax Error Detected */
#define EBHSCR_MHDR_FLEXRAY_SED_MASK                    0x1000000000000000ULL
#define EBHSCR_MHDR_FLEXRAY_SED_SHIFT                   60U

/** @brief  Content Error Detected */
#define EBHSCR_MHDR_FLEXRAY_CED_MASK                    0x2000000000000000ULL
#define EBHSCR_MHDR_FLEXRAY_CED_SHIFT                   61U

/** @brief  Additional Communication Indicator */
#define EBHSCR_MHDR_FLEXRAY_ACI_MASK                    0x4000000000000000ULL
#define EBHSCR_MHDR_FLEXRAY_ACI_SHIFT                   62U

/** @brief  Slot Boundary Violation */
#define EBHSCR_MHDR_FLEXRAY_SBV_MASK                    0x8000000000000000ULL
#define EBHSCR_MHDR_FLEXRAY_SBV_SHIFT                   63U


/** @brief  Frame status */
#define EBHSCR_MHDR_FLEXRAY_FRAME_STATUS_MASK           0x0000FFFF00000000ULL
#define EBHSCR_MHDR_FLEXRAY_FRAME_STATUS_SHIFT          32U

/** @brief  Byte Received Counter */
#define EBHSCR_MHDR_FLEXRAY_BRC_MASK                    0x0000000700000000ULL
#define EBHSCR_MHDR_FLEXRAY_BRC_SHIFT                   32U

/** @brief  Communication cycle part */
#define EBHSCR_MHDR_FLEXRAY_CP_MASK                     0x0000001800000000ULL
#define EBHSCR_MHDR_FLEXRAY_CP_SHIFT                    35U
#define EBHSCR_MHDR_FLEXRAY_CP_STATIC_PART              0x0U
#define EBHSCR_MHDR_FLEXRAY_CP_DYNAMIC_PART             0x1U
#define EBHSCR_MHDR_FLEXRAY_CP_SYMBOL_WINDOW            0x2U
#define EBHSCR_MHDR_FLEXRAY_CP_NIT                      0x3U

/** @brief  Sync and/or startup bit wrongly set */
#define EBHSCR_MHDR_FLEXRAY_SYNCERR_MASK                0x0000002000000000ULL
#define EBHSCR_MHDR_FLEXRAY_SYNCERR_SHIFT               37U

/** @brief  Prolonged channel idle detection */
#define EBHSCR_MHDR_FLEXRAY_PCD_MASK                    0x0000004000000000ULL
#define EBHSCR_MHDR_FLEXRAY_PCD_SHIFT                   38U

/** @brief  Boundary violation */
#define EBHSCR_MHDR_FLEXRAY_BVIOL_MASK                  0x0000008000000000ULL
#define EBHSCR_MHDR_FLEXRAY_BVIOL_SHIFT                 39U

/** @brief  NIT violation */
#define EBHSCR_MHDR_FLEXRAY_NITVIOL_MASK                0x0000010000000000ULL
#define EBHSCR_MHDR_FLEXRAY_NITVIOL_SHIFT               40U

/** @brief  Symbol Window violation */
#define EBHSCR_MHDR_FLEXRAY_SWVIOL_MASK                 0x0000020000000000ULL
#define EBHSCR_MHDR_FLEXRAY_SWVIOL_SHIFT                41U

/** @brief  Slot overbooked error */
#define EBHSCR_MHDR_FLEXRAY_SOVERR_MASK                 0x0000040000000000ULL
#define EBHSCR_MHDR_FLEXRAY_SOVERR_SHIFT                42U

/** @brief  Null frame error */
#define EBHSCR_MHDR_FLEXRAY_NERR_MASK                   0x0000080000000000ULL
#define EBHSCR_MHDR_FLEXRAY_NERR_SHIFT                  43U

/** @brief  Sync or startup error */
#define EBHSCR_MHDR_FLEXRAY_SSERR_MASK                  0x0000100000000000ULL
#define EBHSCR_MHDR_FLEXRAY_SSERR_SHIFT                 44U

/** @brief  Frame ID error */
#define EBHSCR_MHDR_FLEXRAY_FIDERR_MASK                 0x0000200000000000ULL
#define EBHSCR_MHDR_FLEXRAY_FIDERR_SHIFT                45U

/** @brief  Cycle counter error */
#define EBHSCR_MHDR_FLEXRAY_CCERR_MASK                  0x0000400000000000ULL
#define EBHSCR_MHDR_FLEXRAY_CCERR_SHIFT                 46U

/** @brief  Static Payload length error */
#define EBHSCR_MHDR_FLEXRAY_SPLERR_MASK                 0x0000800000000000ULL
#define EBHSCR_MHDR_FLEXRAY_SPLERR_SHIFT                47U

/** @brief  The Low Phase was too long  */
#define EBHSCR_MHDR_FLEXRAY_SYERR_MASK                  0x0000000080000000ULL
#define EBHSCR_MHDR_FLEXRAY_SYERR_SHIFT                 31U

/** @brief  Symbol length in units of bit cells */
#define EBHSCR_MHDR_FLEXRAY_SL_MASK                     0x000000007F000000ULL
#define EBHSCR_MHDR_FLEXRAY_SL_SHIFT                    24U

/** @brief  POC-state */
#define EBHSCR_MHDR_FLEXRAY_POC_STATE_MASK              0xFF00000000000000ULL
#define EBHSCR_MHDR_FLEXRAY_POC_STATE_SHIFT             56U

/** @brief  Cycle counter of following cycle */
#define EBHSCR_MHDR_FLEXRAY_CC_FC_MASK                  0x00FF000000000000ULL
#define EBHSCR_MHDR_FLEXRAY_CC_FC_SHIFT                 48U

/** @brief  Supercycle counter */
#define EBHSCR_MHDR_FLEXRAY_SC_MASK                     0x00000000FFFFFFFFULL
#define EBHSCR_MHDR_FLEXRAY_SC_SHIFT                    0U

/**
 * @}
 */

/**
 * @defgroup FLEXRAY_PAYLOAD FlexRay payload bits
 * @ingroup FLEXRAY
 *
 * @{
 */

/** @brief  Frame header */
#define EBHSCR_PAYLOAD_FLEXRAY_FRAME_HDR_MASK              0xFFFFFFFFFF000000ULL
#define EBHSCR_PAYLOAD_FLEXRAY_FRAME_HDR_SHIFT             0U

/** @brief  Payload preamble indicator */
#define EBHSCR_PAYLOAD_FLEXRAY_PPI_MASK                    0x4000000000000000ULL
#define EBHSCR_PAYLOAD_FLEXRAY_PPI_SHIFT                   62U

/** @brief  Null frame indicator */
#define EBHSCR_PAYLOAD_FLEXRAY_NFI_MASK                    0x2000000000000000ULL
#define EBHSCR_PAYLOAD_FLEXRAY_NFI_SHIFT                   61U

/** @brief  Sync frame indicator */
#define EBHSCR_PAYLOAD_FLEXRAY_SFI_MASK                    0x1000000000000000ULL
#define EBHSCR_PAYLOAD_FLEXRAY_SFI_SHIFT                   60U

/** @brief  Startup frame indicator */
#define EBHSCR_PAYLOAD_FLEXRAY_STFI_MASK                   0x0800000000000000ULL
#define EBHSCR_PAYLOAD_FLEXRAY_STFI_SHIFT                  59U

/** @brief  Frame ID */
#define EBHSCR_PAYLOAD_FLEXRAY_FID_MASK                    0x07FF000000000000ULL
#define EBHSCR_PAYLOAD_FLEXRAY_FID_SHIFT                   48U

/** @brief  Payload length in words */
#define EBHSCR_PAYLOAD_FLEXRAY_PL_MASK                     0x0000FE0000000000ULL
#define EBHSCR_PAYLOAD_FLEXRAY_PL_SHIFT                    41U

/** @brief  Header CRC */
#define EBHSCR_PAYLOAD_FLEXRAY_HCRC_MASK                   0x000001FFC0000000ULL
#define EBHSCR_PAYLOAD_FLEXRAY_HCRC_SHIFT                  30U

/** @brief  Cycle count */
#define EBHSCR_PAYLOAD_FLEXRAY_CC_MASK                     0x000000003F000000ULL
#define EBHSCR_PAYLOAD_FLEXRAY_CC_SHIFT                    24U

/* @brief Offset of frame data within payload */
#define EBHSCR_PAYLOAD_FRAME_OFFSET_IN_BYTES               5U

/**
 * @}
 */

/**
 * @}
 */


/*******/
/* LIN */
/*******/
/**
 * @defgroup LIN LIN constants for TAL_BITFIELD macros
 * @ingroup EBHSCR
 *
 * @{
 */

/**
 * @defgroup LIN_STATUS LIN status bits
 * @ingroup LIN
 *
 * @{
 */
/** @brief  Message is LIN-FD message */

/** @brief  Message is LIN 1.3 Classic */
#define EBHSCR_STATUS_LIN_CL_MASK                    0x001U
#define EBHSCR_STATUS_LIN_CL_SHIFT                   0U

/** @brief  Message is LIN 2.0 Enhanced */
#define EBHSCR_STATUS_LIN_EN_MASK                    0x002U
#define EBHSCR_STATUS_LIN_EN_SHIFT                   1U

/** @brief  Message is LIN Wake-Up Packet */
#define EBHSCR_STATUS_LIN_WU_MASK                    0x010U
#define EBHSCR_STATUS_LIN_WU_SHIFT                   4U

/** @brief  Timestamp could only be estimated */
#define EBHSCR_STATUS_LIN_ESTIMATED_TIMESTAMP_MASK   0x400U
#define EBHSCR_STATUS_LIN_ESTIMATED_TIMESTAMP_SHIFT  10U

/**
 * @}
 */

/**
 * @defgroup LIN_MHDR LIN major number specific header bits
 * @ingroup LIN
 *
 * @{
 */

/** @brief Wakeup length - only valid if wakeup bit in status header is set */
#define EBHSCR_MHDR_LIN_WU_LEN_MASK                  0xFFFF000000000000ULL
#define EBHSCR_MHDR_LIN_WU_LEN_SHIFT                 48U

/** @brief Protocol status */
#define EBHSCR_MHDR_LIN_ERR_MASK                     0x0000FFFF00000000ULL
#define EBHSCR_MHDR_LIN_ERR_SHIFT                    32U

/** @brief Received syncronisation field is not 0x55 */
#define EBHSCR_MHDR_LIN_SYN_MASK                     0x0000000200000000ULL
#define EBHSCR_MHDR_LIN_SYN_SHIFT                    33U

/** @brief Received parity does not match calculated parity */
#define EBHSCR_MHDR_LIN_PAR_MASK                     0x0000000400000000ULL
#define EBHSCR_MHDR_LIN_PAR_SHIFT                    34U

/** @brief No response detected after LIN header (payload length field is 1 - i.e. only an identifer
 * but no data was received) */
#define EBHSCR_MHDR_LIN_RES_MASK                     0x0000000800000000ULL
#define EBHSCR_MHDR_LIN_RES_SHIFT                    35U

/** @brief Too many data bytes received (more than 10, 8 data bytes + ID and checksum) */
#define EBHSCR_MHDR_LIN_DAT_MASK                     0x0000001000000000ULL
#define EBHSCR_MHDR_LIN_DAT_SHIFT                    36U

/** @brief Checksum is invalid: Received checksum does not match calculated checksum */
#define EBHSCR_MHDR_LIN_CHK_MASK                     0x0000002000000000ULL
#define EBHSCR_MHDR_LIN_CHK_SHIFT                    37U

/** @brief Expected start bit, but detected recessive bus level */
#define EBHSCR_MHDR_LIN_STA_MASK                     0x0000004000000000ULL
#define EBHSCR_MHDR_LIN_STA_SHIFT                    38U

/** @brief Expected stop bit, but detected recessive bus level */
#define EBHSCR_MHDR_LIN_STO_MASK                     0x0000008000000000ULL
#define EBHSCR_MHDR_LIN_STO_SHIFT                    39U

/** @brief Break and Sync received, but no further data */
#define EBHSCR_MHDR_LIN_EMP_MASK                     0x0000010000000000ULL
#define EBHSCR_MHDR_LIN_EMP_SHIFT                    40U

/**
 * @}
 */
/**
 * @defgroup LIN_HDR LIN message header bits
 * @ingroup LIN
 *
 * @brief LIN ID is the first byte of the EBHSCR payload.
 *
 * @{
 */

/**
 * @brief  LIN id
 * @warning this macro will only work with the full payload of 8 bytes!
 * */
#define EBHSCR_PAYLOAD0_LIN_ID_MASK                  0xFF00000000000000ULL
#define EBHSCR_PAYLOAD0_LIN_ID_SHIFT                 0U

/**
 * @}
 */

/**
 * @}
 */


/*******/
/* CAN */
/*******/
/**
 * @defgroup CAN CAN constants for TAL_BITFIELD macros
 * @ingroup EBHSCR
 *
 * @{
 */

/**
 * @defgroup CAN_STATUS CAN status bits
 * @ingroup CAN
 *
 * @{
 */
/** @brief  Message is CAN-FD message */
#define EBHSCR_STATUS_CAN_IS_CANFD_MASK             0x001U
#define EBHSCR_STATUS_CAN_IS_CANFD_SHIFT            0U

/** @brief  protocol status is available */
#define EBHSCR_STATUS_CAN_PS_AVAIL_MASK             0x002U
#define EBHSCR_STATUS_CAN_PS_AVAIL_SHIFT            1U

/**
 * @}
 */

/**
 * @defgroup CAN_MHDR CAN major number specific header bits
 * @ingroup CAN
 *
 * @{
 */

/** @brief  receive error counter */
#define EBHSCR_MHDR_CAN_REC_MASK                    0xFF00000000000000ULL
#define EBHSCR_MHDR_CAN_REC_SHIFT                   56U

/** @brief  transmit error counter */
#define EBHSCR_MHDR_CAN_TEC_MASK                    0x00FF000000000000ULL
#define EBHSCR_MHDR_CAN_TEC_SHIFT                   48U

/** @brief  data phase last error code */
#define EBHSCR_MHDR_CAN_DLEC_MASK                   0x0000070000000000ULL
#define EBHSCR_MHDR_CAN_DLEC_SHIFT                  40U
/* same coding as LEC - use LEC macros for value comparisons */

/** @brief  bus off - one of the error counters has reached the bus off limit (256) */
#define EBHSCR_MHDR_CAN_BOFF_MASK                   0x0000008000000000ULL
#define EBHSCR_MHDR_CAN_BOFF_SHIFT                  39U

/** @brief  error warning - one of the error counters has reached the error warning limit (96) */
#define EBHSCR_MHDR_CAN_ERRW_MASK                   0x0000004000000000ULL
#define EBHSCR_MHDR_CAN_ERRW_SHIFT                  38U

/** @brief  error passive - one of the error counters has reached the error passive limit (128) */
#define EBHSCR_MHDR_CAN_ERRP_MASK                   0x0000002000000000ULL
#define EBHSCR_MHDR_CAN_ERRP_SHIFT                  37U

/** @brief  last error code */
#define EBHSCR_MHDR_CAN_LEC_MASK                    0x0000000700000000ULL
#define EBHSCR_MHDR_CAN_LEC_SHIFT                   32U
#define EBHSCR_MHDR_CAN_LEC_NO_ERROR                0x0ULL
#define EBHSCR_MHDR_CAN_LEC_STUFF_ERROR             0x1ULL
#define EBHSCR_MHDR_CAN_LEC_FORM_ERROR              0x2ULL
#define EBHSCR_MHDR_CAN_LEC_ACK_ERROR               0x3ULL
#define EBHSCR_MHDR_CAN_LEC_BIT1_ERROR              0x4ULL
#define EBHSCR_MHDR_CAN_LEC_BIT0_ERROR              0x5ULL
#define EBHSCR_MHDR_CAN_LEC_CRC_ERROR               0x6ULL
#define EBHSCR_MHDR_CAN_LEC_NO_CHANGE               0x7ULL

/** @brief  CAN error logging counter */
#define EBHSCR_MHDR_CAN_CEL_MASK                    0x00000000000000FFULL
#define EBHSCR_MHDR_CAN_CEL_SHIFT                   0U

/**
 * @}
 */

/**
 * @defgroup CAN_HDR CAN message header bits
 * @ingroup CAN
 *
 * @brief CAN message header are the first 8 bytes of the EBHSCR payload,
 *        it must be accessed as *little endian* value!
 *
 * @{
 */

/** @brief  extended CAN identifier */
#define EBHSCR_PAYLOAD0_CAN_ID_EXT_MASK             0x000000001FFFFFFFULL
#define EBHSCR_PAYLOAD0_CAN_ID_EXT_SHIFT            0U

/** @brief  standard CAN identifier */
#define EBHSCR_PAYLOAD0_CAN_ID_STD_MASK             0x00000000000007FFULL
#define EBHSCR_PAYLOAD0_CAN_ID_STD_SHIFT            0U

/** @brief  remote transmission request message */
#define EBHSCR_PAYLOAD0_CAN_RTR_MASK                0x0000000040000000ULL
#define EBHSCR_PAYLOAD0_CAN_RTR_SHIFT               30U

/** @brief  Extended CAN identifier used */
#define EBHSCR_PAYLOAD0_CAN_EFF_MASK                0x0000000080000000ULL
#define EBHSCR_PAYLOAD0_CAN_EFF_SHIFT               31U

/** @brief  Frame data length in bytes */
#define EBHSCR_PAYLOAD0_CAN_LEN_MASK                0x0000007F00000000ULL
#define EBHSCR_PAYLOAD0_CAN_LEN_SHIFT               32U

/** @brief  Bit rate switch used in CAN message */
#define EBHSCR_PAYLOAD0_CAN_BRS_MASK                0x0000010000000000ULL
#define EBHSCR_PAYLOAD0_CAN_BRS_SHIFT               40U

/** @brief  Error state indicator */
#define EBHSCR_PAYLOAD0_CAN_ESI_MASK                0x0000020000000000ULL
#define EBHSCR_PAYLOAD0_CAN_ESI_SHIFT               41U

/**
 * @}
 */

/**
 * @}
 */

/*******/
/* PDU */
/*******/
/**
 * @defgroup PDU PDU constants for TAL_BITFIELD macros
 * @ingroup EBHSCR
 *
 * @{
 */

/**
 * @defgroup PDU_STATUS PDU status bits
 * @ingroup PDU
 *
 * @{
 */

/** @brief  PDU is transmitted on IP network */
#define EBHSCR_STATUS_PDU_TRANS_IP_MASK             0x001U
#define EBHSCR_STATUS_PDU_TRANS_IP_SHIFT            0U

/** @brief  Transmission protocol for PDU is IPv4 */
#define EBHSCR_STATUS_PDU_TRANS_PROTO_IPV4_MASK     0x002U
#define EBHSCR_STATUS_PDU_TRANS_PROTO_IPV4_SHIFT    1U

/** @brief  PDU is transmitted on non-IP network: CAN/CAN-FD network */
#define EBHSCR_STATUS_PDU_CANFD_NETWORK_MASK        0x002U
#define EBHSCR_STATUS_PDU_CANFD_NETWORK_SHIFT       1U

/** @brief  Payload starts with 8-byte SoAd header */
#define EBHSCR_STATUS_PDU_PAYLOAD_START_SOAD_MASK   0x004U
#define EBHSCR_STATUS_PDU_PAYLOAD_START_SOAD_SHIFT  2U

/** @brief  PDU is transmitted on non-IP network: FlexRay network */
#define EBHSCR_STATUS_PDU_FLEXRAY_NETWORK_MASK      0x004U
#define EBHSCR_STATUS_PDU_FLEXRAY_NETWORK_SHIFT     2U

/** @brief  Packet is a SOME/IP packet */
#define EBHSCR_STATUS_PDU_IS_SOMEIP_MASK            0x008U
#define EBHSCR_STATUS_PDU_IS_SOMEIP_SHIFT           3U

/** @brief  Transmission protocol for PDU is UDP */
#define EBHSCR_STATUS_PDU_TRANS_PROTO_UDP_MASK      0x010U
#define EBHSCR_STATUS_PDU_TRANS_PROTO_UDP_SHIFT     4U

/** @brief  Source port is contained within first two bytes of major number specific header */
#define EBHSCR_STATUS_PDU_SRC_PORT_MASK             0x020U
#define EBHSCR_STATUS_PDU_SRC_PORT_SHIFT            5U

/** @brief  Destination port is contained within second two bytes of major number specific header */
#define EBHSCR_STATUS_PDU_DST_PORT_MASK             0x040U
#define EBHSCR_STATUS_PDU_DST_PORT_SHIFT            6U

/** @brief  Source IP address is stored on beginning of payload */
#define EBHSCR_STATUS_PDU_SRC_IP_MASK               0x080U
#define EBHSCR_STATUS_PDU_SRC_IP_SHIFT              7U

/** @brief  Destination IP address is stored on beginning of payload */
#define EBHSCR_STATUS_PDU_DST_IP_MASK               0x100U
#define EBHSCR_STATUS_PDU_DST_IP_SHIFT              8U

/** @brief  VLAN TCI is stored in third two bytes of major number specific header */
#define EBHSCR_STATUS_PDU_VLAN_TCI_MASK             0x200U
#define EBHSCR_STATUS_PDU_VLAN_TCI_SHIFT            9U

/** Bit 10 is reserved */

/** @brief  Packet is identified by an application specific PDU handle id in first 4 bytes of major number specific header */
#define EBHSCR_STATUS_PDU_HANDLE_MASK               0x800U
#define EBHSCR_STATUS_PDU_HANDLE_SHIFT              11U

/**
 * @}
 */

/**
 * @defgroup PDU_MHDR PDU major number specific header bits
 * @ingroup PDU
 *
 * @{
 */

/** @brief  Application specific PDU handle id  */
#define EBHSCR_MHDR_PDU_HANDLE_MASK                 0x0000000000ffffffULL
#define EBHSCR_MHDR_PDU_HANDLE_SHIFT                0U

/** @brief  UDP/TCP source port */
#define EBHSCR_MHDR_PDU_SRC_PORT_MASK               0x000000000000ffffULL
#define EBHSCR_MHDR_PDU_SRC_PORT_SHIFT              0U

/** @brief  UDP/TCP destination port */
#define EBHSCR_MHDR_PDU_DST_PORT_MASK               0x00000000ffff0000ULL
#define EBHSCR_MHDR_PDU_DST_PORT_SHIFT              16U

/** @brief  VLAN TCI consisting of VLAN priority and VLAN id */
#define EBHSCR_MHDR_PDU_VLAN_TCI_MASK               0x0000ffff00000000ULL
#define EBHSCR_MHDR_PDU_VLAN_TCI_SHIFT              32U

/* Byte 6 and 7 unused */

/**
 * @}
 */

/**
 * @}
 */

/********/
/* NMEA */
/********/
/**
 * @defgroup NMEA NMEA constants for TAL_BITFIELD macros
 * @ingroup EBHSCR
 *
 * @brief Status and Major number specific header are unused (0). Payload
 * contains ASCII NMEA data so nothing more needed here currently.
 */

/**************/
/* Digital IO */
/**************/
/**
 * @defgroup DIO Digital IO constants for TAL_BITFIELD macros
 * @ingroup EBHSCR
 *
 * @{
 */

/**
 * @defgroup DIO_STATUS Digital IO status bits
 * @ingroup DIO
 *
 * @{
 */

/** @brief  Overflow */
#define EBHSCR_STATUS_DIO_OVERFLOW_MASK             0x001U
#define EBHSCR_STATUS_DIO_OVERFLOW_SHIFT            0U

/** @brief  Timestamp could only be estimated */
#define EBHSCR_STATUS_DIO_ESTIMATED_TIMESTAMP_MASK  0x400U
#define EBHSCR_STATUS_DIO_ESTIMATED_TIMESTAMP_SHIFT 10U

/**
 * @}
 */

/**
 * @defgroup DIO_MHDR Digital IO major number specific header bits
 * @ingroup DIO
 *
 * @{
 */

/** @brief  Value and Type of the Digital IO event */
#define EBHSCR_MHDR_DIO_VALUE_TYPE_MASK             0xff00000000000000ULL
#define EBHSCR_MHDR_DIO_VALUE_TYPE_SHIFT            56U

/**
 * @}
 */

/**
 * @}
 */

/*************/
/* TimeState */
/*************/
/**
 * @defgroup TIME Time state constants for TAL_BITFIELD macros
 * @ingroup EBHSCR
 *
 * @{
 */

/**
 * @defgroup TIME_STATUS Time state status bits
 * @ingroup TIME
 *
 * @{
 */

/** @brief  time offset valid */
#define EBHSCR_STATUS_TIME_OFFSET_VALID_MASK      0x001U
#define EBHSCR_STATUS_TIME_OFFSET_VALID_SHIFT     0U

/** @brief  last offset change valid */
#define EBHSCR_STATUS_TIME_OFFSET_CHG_VALID_MASK  0x002U
#define EBHSCR_STATUS_TIME_OFFSET_CHG_VALID_SHIFT 1U

/** @brief  nano seconds last jump valid */
#define EBHSCR_STATUS_TIME_JUMP_VALID_MASK        0x004U
#define EBHSCR_STATUS_TIME_JUMP_VALID_SHIFT       2U

/** @brief  UTC leap seconds valid */
#define EBHSCR_STATUS_TIME_LEAP_SEC_VALID_MASK    0x008U
#define EBHSCR_STATUS_TIME_LEAP_SEC_VALID_SHIFT   3U

/** @brief  sync state valid */
#define EBHSCR_STATUS_TIME_SYNC_STAT_VALID_MASK   0x010U
#define EBHSCR_STATUS_TIME_SYNC_STAT_VALID_SHIFT  4U

/**
 * @}
 */

/**
 * @defgroup TIME_MHDR time state major number specific header bits
 * @ingroup TIME
 *
 * @{
 */

/** @brief  Time source */
#define EBHSCR_MHDR_TIME_SOURCE_MASK    0x00000000000000ffULL
#define EBHSCR_MHDR_TIME_SOURCE_SHIFT   0U
#define EBHSCR_MHDR_TIME_SOURCE_NONE    0x00ULL
#define EBHSCR_MHDR_TIME_SOURCE_EB_HARD 0x01ULL
#define EBHSCR_MHDR_TIME_SOURCE_XTSS    0x02ULL
#define EBHSCR_MHDR_TIME_SOURCE_PTP_HW  0x03ULL
#define EBHSCR_MHDR_TIME_SOURCE_PTP_SW  0x10ULL
#define EBHSCR_MHDR_TIME_SOURCE_GPS     0x20ULL
#define EBHSCR_MHDR_TIME_SOURCE_EB_SOFT 0x30ULL
#define EBHSCR_MHDR_TIME_SOURCE_CAN     0x40ULL
#define EBHSCR_MHDR_TIME_SOURCE_EB_VIRT 0x50ULL

/**
 * @}
 */

/**
 * @defgroup TIME_PAYLOAD time state payload bytes
 * @ingroup TIME
 *
 * @{
 */

/** @brief  EB time offset in nanoseconds */
#define EBHSCR_PAYLOAD0_TIME_OFFSET_MASK      0xFFFFFFFFFFFFFFFFULL
#define EBHSCR_PAYLOAD0_TIME_OFFSET_SHIFT     0U

/** @brief  last offset change in nanoseconds */
#define EBHSCR_PAYLOAD1_TIME_OFFSET_CHG_MASK  0xFFFFFFFFFFFFFFFFULL
#define EBHSCR_PAYLOAD1_TIME_OFFSET_CHG_SHIFT 0U

/** @brief  nanoseconds last jump */
#define EBHSCR_PAYLOAD2_TIME_JUMP_MASK        0xFFFFFFFFFFFFFFFFULL
#define EBHSCR_PAYLOAD2_TIME_JUMP_SHIFT       0U

/** @brief  UTC leap seconds */
#define EBHSCR_PAYLOAD3_TIME_LEAP_SEC_MASK    0xFFFF000000000000ULL
#define EBHSCR_PAYLOAD3_TIME_LEAP_SEC_SHIFT   48U

/** @brief  sync state */
#define EBHSCR_PAYLOAD3_TIME_SYNC_STAT_MASK   0x0000FFFF00000000ULL
#define EBHSCR_PAYLOAD3_TIME_SYNC_STAT_SHIFT  32U
#define EBHSCR_PAYLOAD3_TIME_SYNC_STAT_FREERUNNING 0x0000ULL
#define EBHSCR_PAYLOAD3_TIME_SYNC_STAT_LOCKED      0x0001ULL

/** @brief  payload length in bytes */
#define EBHSCR_PAYLOAD_TIME_LEN 28U

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

#endif /* end of include guard: _TAL_EBHSCR_H_ */
