/*
 * File    : TAL.h
 *
 * Module  : EB_tresos_TAL
 *
 * Description:
 * Interface header file for TAL.
 *
 * Copyright 2002-2012 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

/**
 *
 * @file TAL.h
 *
 * include this file to get access to the TAL API.
 * If you include this header from C code you have access to the TAL
 * C-API.
 * If you include this header from C++ code you have access to the TAL
 * C-API and to the C++-API.
 * Please see the TAL and the TAL++ API documentation for an overview
 * of the interfaces
 */

#ifndef _TAL_H_
#define _TAL_H_

/* C-Version of API */
#include "TAL_Impl.h"

/* if included from C++ compiler also add a TalInterface C++ class API */
#ifdef __cplusplus
#define TAL_CXX_API
#include "TAL_Impl.h"
#endif

#endif

