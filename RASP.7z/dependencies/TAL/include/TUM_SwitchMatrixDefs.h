/*
 * File    : TAL_TUM_CommandServer.h
 *
 * Module  : TAL_TopHalf
 * Date    : $Date:$
 * Author  : $Author: jore2672 $
 *
 * Description:
 * Interface header file for TUM CommandServer
 *
 * Copyright 2002-2010 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

/**
 *
 * @file TUM_SwitchMatrixDefs.h
 *
 * This file provides the defines for all available commands to control
 * the SwitchMatrix TUM. Not all commands are available on all hardware
 * platforms. If a command is not supported by the hardware platform
 * it is ignored.
 *
 */

#ifndef _TAL_TUM_SWITCHMATRIXDEFS_H_
#define _TAL_TUM_SWITCHMATRIXDEFS_H_

/******************************************************************************
 Include Section
******************************************************************************/

#include "TAL_Std_Types.h"         /* fixed size data types */

/******************************************************************************
 Global Macros
******************************************************************************/

/**
 *
 * @brief ID of SwitchMatrix TUM for communication
 * @def   TUM_ID_SWITCH_MATRIX
 *
 */
#define TUM_ID_SWITCH_MATRIX        1062

/**
 *
 * @brief Instance of SwitchMatrix TUM for communication
 * @def   TUM_INSTANCE_SWITCH_MATRIX
 *
 */
#define TUM_INSTANCE_SWITCH_MATRIX  0

/**
 *
 * @brief Connects the Rx line of the input multiplexer to FlexRay channel #1
 * @def   TUM_SWM_CMD_CONNECT_INPUT_MUX_RX_TO_FR_1
 * @note  Available for EB2100, EB5100, EB6100
 *
 */
#define TUM_SWM_CMD_CONNECT_INPUT_MUX_RX_TO_FR_1   1

/**
 *
 * @brief Connects the Rx line of the input multiplexer to FlexRay channel #2
 * @def   TUM_SWM_CMD_CONNECT_INPUT_MUX_RX_TO_FR_2
 * @note  Available for EB2100, EB5100, EB6100
 *
 */
#define TUM_SWM_CMD_CONNECT_INPUT_MUX_RX_TO_FR_2   2

/**
 *
 * @brief Connects the Rx line of the input multiplexer
                                                      to FlexRay channel #3
 * @def   TUM_SWM_CMD_CONNECT_INPUT_MUX_RX_TO_FR_3
 * @note  Available for EB5100 only if enough FlexRay
                                                      modules are equipped
 *
 */
#define TUM_SWM_CMD_CONNECT_INPUT_MUX_RX_TO_FR_3   3

/**
 *
 * @brief Connects the Rx line of the input multiplexer to FlexRay channel #4
 * @def   TUM_SWM_CMD_CONNECT_INPUT_MUX_RX_TO_FR_4
 * @note  Available for EB5100 only if enough FlexRay modules are equipped
 *
 */
#define TUM_SWM_CMD_CONNECT_INPUT_MUX_RX_TO_FR_4   4

/**
 *
 * @brief Connects the Rx line of the input multiplexer to FlexRay channel #5
 * @def   TUM_SWM_CMD_CONNECT_INPUT_MUX_RX_TO_FR_5
 * @note  Available for EB5100 only if enough FlexRay modules are equipped
 *
 */
#define TUM_SWM_CMD_CONNECT_INPUT_MUX_RX_TO_FR_5   5

/**
 *
 * @brief Connects CAN controller #1 to the CAN High-Speed transeiver
 * @def   TUM_SWM_CMD_CONNECT_CAN1_TO_HS_TRANSEIVER
 * @note  Available for EB2100, EB6100
 *
 */
#define TUM_SWM_CMD_CONNECT_CAN1_TO_HS_TRANSEIVER  20

/**
 *
 * @brief Connects CAN controller #1 to the CAN Low-Speed transceiver
 * @def   TUM_SWM_CMD_CONNECT_CAN1_TO_LS_TRANSEIVER
 * @note  Available for EB2100, EB6100
 *
 */
#define TUM_SWM_CMD_CONNECT_CAN1_TO_LS_TRANSEIVER  21

/**
 *
 * @brief Sets Busmirror defaults for DIGIO
 * @def   TUM_SWM_CMD_BM_CFG_DIO_DEFAULT
 * @note  Available for EB6100
 *
 */
#define TUM_SWM_CMD_BM_CFG_DIO_DEFAULT 30

/**
 *
 * @brief Configures inspector agilent mode for Channel A
 * @def   TUM_SWM_CMD_INSP_CFG_DIO_AGILENT_CH_A
 * @note  Available for EB6100
 *
 */
#define TUM_SWM_CMD_INSP_CFG_DIO_AGILENT_CH_A 31

/**
 *
 * @brief Configures inspector agilent mode for Channel B
 * @def   TUM_SWM_CMD_INSP_CFG_DIO_AGILENT_CH_B
 * @note  Available for EB6100
 *
 */
#define TUM_SWM_CMD_INSP_CFG_DIO_AGILENT_CH_B 32

/**
 *
 * @brief Configures CUST0, DIO1DIR and DIO2DIR for external physical
 * @def   TUM_SWM_CMD_INSP_CFG_DIO_EXPHY
 * @note  Available for EB6100
 *
 */
#define TUM_SWM_CMD_INSP_CFG_DIO_EXPHY 33

/**
 *
 * @brief Configures CUST0, DIO1DIR and DIO2DIR for Inspector mode
 * @def   TUM_SWM_CMD_INSP_CFG_DIO_BD2
 * @note  Available for EB6100
 *
 */
#define TUM_SWM_CMD_INSP_CFG_DIO_BD2 35

/**
 *
 * @brief Configures the X_LINE_TERM pin of the specified slot
 * @def   TUM_SWM_CMD_HANDLE_LINE_TERM
 * @note  Available for EBx200
 *
 */
#define TUM_SWM_CMD_HANDLE_LINE_TERM 40

/**
 *
 * @brief Configures the X_LINE_TERM pin of the specified physical slot
 * @def   TUM_SWM_CMD_HANDLE_LINE_TERM_PHYS
 * @note  Available for EBx200
 *
 */
#define TUM_SWM_CMD_HANDLE_LINE_TERM_PHYS 41

/******************************************************************************
 Global Data Types
******************************************************************************/

/******************************************************************************
 Global Data
******************************************************************************/

/******************************************************************************
 Global Function Declarations
******************************************************************************/

#endif /* _TAL_TUM_SWITCHMATRIXDEFS_H_ */
