/*
 * File    : $RCSfile: TAL_Numbers.h,v $ (cvs $Revision: 1.45 $)
 *
 * Module  : TAL_Numbers
 * Release : $Name: not supported by cvs2svn $
 * Date    : $Date: 2008-10-27 09:24:18 $
 * Author  : $Author: grfe2844 $
 *
 * Description:
 * Interface header file for class TAL_Numbers.
 *
 * Copyright 2002-2010 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifndef _TAL_NUMBERS_H_
#define _TAL_NUMBERS_H_

/******************************************************************************
 Include Section
******************************************************************************/

#include "TAL_Std_Types.h"      /* fixed size data types */

/******************************************************************************
 Global Macros
******************************************************************************/

/******************************************************************************
 Global Data Types
******************************************************************************/

/******************************************************************************
 Global Data
******************************************************************************/

/******************************************************************************
 Global Function Declarations
******************************************************************************/

#ifdef __cplusplus
/******************************************************************************
 Forward Class Declarations
******************************************************************************/

class TAL_DummyFriend;

/******************************************************************************
 Class Declarations
******************************************************************************/

class TAL_Numbers
{
    /*
     * Sometimes you need a friend, even it's only a dummy to prevent the
     * compiler from generating a warning about no public method of this class.
     */
    friend class TAL_DummyFriend;

public:
    /*
     * Public methods:
     */


    /* Public members:
     */

#define DEFINE_CONST(name,value) static const uint8 name = value;

#else /* __cplusplus */

/*
 * define constants as enum members in case of plain C programs, because
 * otherwise the constants cannot be used as real 'constants' (e.g. in struct
 * initializers)
 */
enum TAL_Numbers
{

#define DEFINE_CONST(name,value) name = value,

#endif /* __cplusplus */
    /*************************************************************************
     ** MAJOR Numbers                                                       **
     *************************************************************************/
    /*
     * Inspector Major numbers
     */
    DEFINE_CONST(TAL_Major_First, 0x01U)

    DEFINE_CONST(TAL_Major_Insp_Command_and_FPGA_Packet_FlexRay, TAL_Major_First) /* Inspector string commands */
    DEFINE_CONST(TAL_Major_FPGA_Packet_CAN, 0x02U)
    DEFINE_CONST(TAL_Major_Insp_LogData, 0x03U)       /* Inspector LogData - unused until BM version 4.0 */
    DEFINE_CONST(TAL_Major_Insp_Control_and_FPGA_Packet_ADIO, 0x04U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_DETI, 0x05U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_LIN, 0x06U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_Triggerout, 0x07U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_BitData, 0x08U)

    DEFINE_CONST(TAL_Major_FPGA_Packet_TimestampOverflow, 0x10U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_Alive, 0x11U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_Flowcontrol, 0x12U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_Cyclestart, 0x13U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_FlexRay_ATS, 0x14U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_CAN_ATS, 0x15U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_LIN_ATS, 0x16U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_GPS_ATS, 0x17U)
    DEFINE_CONST(TAL_Major_Insp, 0x18U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_Ethernet_ATS, 0x19U)
    /*
     * Common Major numbers
     */
    DEFINE_CONST(TAL_Major_Common_DeviceDiscovery, 0x20U)
    DEFINE_CONST(TAL_Major_Common_Session, 0x21U)
    DEFINE_CONST(TAL_Major_Common_TargetUserModule, 0x22U)
    DEFINE_CONST(TAL_Major_Common_VersionInfo, 0x23U)
    DEFINE_CONST(TAL_Major_Common_File, 0x24U)
    DEFINE_CONST(TAL_Major_Common_Target, 0x25U)
    DEFINE_CONST(TAL_Major_Common_Padding, 0x26U)

    /*
     * Busmirror Major numbers
     */
    DEFINE_CONST(TAL_Major_BM_Signals, 0x30U)
    DEFINE_CONST(TAL_Major_BM_SignalGroups, 0x31U)
    DEFINE_CONST(TAL_Major_BM_Frames, 0x32U)
    DEFINE_CONST(TAL_Major_BM_ECU, 0x33U)
    DEFINE_CONST(TAL_Major_BM_Target, 0x34U)
    DEFINE_CONST(TAL_Major_BM_DigitalIO, 0x35U)
    DEFINE_CONST(TAL_Major_BM_CANMessages, 0x36U)
    DEFINE_CONST(TAL_Major_BM_PDU, 0x37U)
    DEFINE_CONST(TAL_Major_BM_FRMessages, 0x38U)
    DEFINE_CONST(TAL_Major_Lin, 0x39U)
    DEFINE_CONST(TAL_Major_ServiceDiscovery, 0x3AU)
    DEFINE_CONST(TAL_Major_BM_Ethernet, 0x3BU)
    DEFINE_CONST(TAL_Major_EncapsulatedEBHSCR, 0x3CU)

    /*
     * Virtual FlexRay Major numbers
     */
    DEFINE_CONST(TAL_Major_VirtFrBus, 0x40U)

    /*
     * Virtual CAN Major numbers
     */
    DEFINE_CONST(TAL_Major_VirtCanBus, 0x41U)

    /*
     * Inspector Major numbers (continued)
     */
    DEFINE_CONST(TAL_Major_FPGA_Packet_TriggerMarker, 0x70U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_GeneralMarker, 0x71U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_FlexRay_ATS2, 0x74U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_CAN_ATS2, 0x75U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_LIN_ATS2, 0x76U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_GPS_ATS2, 0x77U)
    DEFINE_CONST(TAL_Major_FPGA_Packet_Ethernet_ATS2, 0x79U)
    DEFINE_CONST(TAL_Major_Device_Option, 0x7AU)

    DEFINE_CONST(TAL_Major_Last, 0x7FU)

    DEFINE_CONST(TAL_Major_Wincore, 0x80U)

    DEFINE_CONST(TAL_Major_Sil, 0x81U) /* deprecated, use TAL_Major_VirtTimeSource */
    DEFINE_CONST(TAL_Major_VirtTimeSource, 0x81U)

    DEFINE_CONST(TAL_Major_Invalid, 0xFFU)


    /*************************************************************************
     ** MINOR Numbers                                                       **
     *************************************************************************/
    /*
     * Inspector Minor numbers
     */

    /* [ 0x01U ] TAL_Major_Insp_Command_and_FPGA_Packet_FlexRay */
    DEFINE_CONST(TAL_Minor_Insp_Command, 0x00U) /* unused */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl0_ChA, 0x01U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl0_ChB, 0x02U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl0_ChAB, 0x03U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl1_ChA, 0x04U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl1_ChB, 0x08U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl1_ChAB, 0x0CU)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl2_ChA, 0x11U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl2_ChB, 0x12U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl2_ChAB, 0x13U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl3_ChA, 0x14U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl3_ChB, 0x18U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameData_Ctrl3_ChAB, 0x1CU)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl0_ChA, 0x41U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl0_ChB, 0x42U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl0_ChAB, 0x43U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl1_ChA, 0x44U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl1_ChB, 0x48U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl1_ChAB, 0x4CU)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl2_ChA, 0x51U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl2_ChB, 0x52U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl2_ChAB, 0x53U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl3_ChA, 0x54U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl3_ChB, 0x58U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatus_Ctrl3_ChAB, 0x5CU)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl0_ChA, 0x81U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl0_ChB, 0x82U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl0_ChAB, 0x83U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl1_ChA, 0x84U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl1_ChB, 0x88U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl1_ChAB, 0x8CU)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl2_ChA, 0x91U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl2_ChB, 0x92U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl2_ChAB, 0x93U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl3_ChA, 0x94U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl3_ChB, 0x98U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_Symbols_Ctrl3_ChAB, 0x9CU)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameDataOverflow_Ctrl0_ChA, 0xF1U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameDataOverflow_Ctrl0_ChB, 0xF2U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameDataOverflow_Ctrl1_ChA, 0xE1U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameDataOverflow_Ctrl1_ChB, 0xE2U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameDataOverflow_Ctrl2_ChA, 0xE3U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameDataOverflow_Ctrl2_ChB, 0xE4U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameDataOverflow_Ctrl3_ChA, 0xE5U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_FrameDataOverflow_Ctrl3_ChB, 0xE6U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatusOverflow_Ctrl0_ChA, 0xF3U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatusOverflow_Ctrl0_ChB, 0xF4U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatusOverflow_Ctrl1_ChA, 0xE7U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatusOverflow_Ctrl1_ChB, 0xE8U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatusOverflow_Ctrl2_ChA, 0xE9U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatusOverflow_Ctrl2_ChB, 0xEAU)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatusOverflow_Ctrl3_ChA, 0xEBU)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_FlexRay_SlotStatusOverflow_Ctrl3_ChB, 0xECU)
    /* [ 0x02U ] TAL_Major_FPGA_Packet_CAN */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Ctrl0, 0x01U) /* CAN controller A */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Ctrl1, 0x02U) /* CAN controller B */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Ctrl2, 0x03U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Ctrl3, 0x04U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Ctrl4, 0x05U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Ctrl5, 0x06U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Ctrl6, 0x07U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Ctrl7, 0x08U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Overflow_Ctrl0, 0xF1U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Overflow_Ctrl1, 0xF2U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Overflow_Ctrl2, 0xF3U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Overflow_Ctrl3, 0xF4U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Overflow_Ctrl4, 0xF5U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Overflow_Ctrl5, 0xF6U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Overflow_Ctrl6, 0xF7U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_CAN_Overflow_Ctrl7, 0xF8U)
    /* [ 0x03U ] TAL_Major_Insp_LogData */
    DEFINE_CONST(TAL_Minor_Insp_ReceiveLogData, 0x00U) /* not used */
    DEFINE_CONST(TAL_Minor_Insp_StartLogDataTransmission, 0x01U) /* not used */
    /* [ 0x04U ] TAL_Major_Insp_Control_and_FPGA_Packet_ADIO */
    DEFINE_CONST(TAL_Minor_Insp_StartMeasurement, 0x00U)
    DEFINE_CONST(TAL_Minor_Insp_StopMeasurement, 0x01U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_ADIO, 0x01U)
    DEFINE_CONST(TAL_Minor_Insp_ConfigureTimebase, 0x02U)
    DEFINE_CONST(TAL_Minor_Insp_ConfigureSyncMaster, 0x03U)
    DEFINE_CONST(TAL_Minor_Insp_ConfigurePacketFormat, 0x04U)
    DEFINE_CONST(TAL_Minor_Insp_ConfigureTimebase_ATS2, 0x05U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Analog, 0x05U) /* patched by TAL_Dispatcher */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Digital, 0x06U) /* patched by TAL_Dispatcher */
    DEFINE_CONST(TAL_Minor_Insp_SetEbhscrMode, 0x07U)
    DEFINE_CONST(TAL_Minor_Insp_SetLineTerm, 0x08U)
    DEFINE_CONST(TAL_Minor_Insp_GetLineTerm, 0x09U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Analog_Overflow, 0xF5U) /* patched by TAL_Dispatcher */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Digital_Overflow, 0xF6U) /* patched by TAL_Dispatcher */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_ADIO_Overflow, 0xFFU)
    /* [ 0x05U ] TAL_Major_FPGA_Packet_DETI */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_DETI, 0x00U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_DETI_Overflow, 0xFFU)
    /* [ 0x06U ] TAL_Major_FPGA_Packet_LIN */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Ctrl0, 0x01U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Ctrl1, 0x02U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Ctrl2, 0x03U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Ctrl3, 0x04U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Wakeup_Ctrl0, 0x81U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Wakeup_Ctrl1, 0x82U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Wakeup_Ctrl2, 0x83U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Wakeup_Ctrl3, 0x84U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Overflow_Ctrl1, 0xF2U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Overflow_Ctrl2, 0xF3U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Overflow_Ctrl3, 0xF4U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_LIN_Overflow_Ctrl0, 0xFFU)
    /* [ 0x07U ] TAL_Major_FPGA_Packet_Triggerout */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Triggerout_Ctrl0, 0x01U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Triggerout_Ctrl1, 0x02U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Triggerout_Ctrl2, 0x03U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Triggerout_Ctrl3, 0x04U)

    /* [ 0x10U ] TAL_Major_FPGA_Packet_TimestampOverflow */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_TimestampOverflow, 0x00U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_TimestampOverflow_ATS2, 0x01U)
    /* [ 0x11U ] TAL_Major_FPGA_Packet_Alive */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Alive, 0x00U)
    /* [ 0x12U ] TAL_Major_FPGA_Packet_Flowcontrol */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Flowcontrol_StopMonitoring, 0x01U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Flowcontrol_StartMonitoring, 0x02U)
    /* [ 0x13U ] TAL_Major_FPGA_Packet_Cyclestart */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Cyclestart_Ctrl0, 0x01U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Cyclestart_Ctrl1, 0x04U)

    /* [ 0x14U ] TAL_Major_FPGA_Packet_FlexRay_ATS */
    /*
     * For minor numbers see TAL_Major_Insp_Command_and_FPGA_Packet_FlexRay
     * since it is handled the same way.
     * ATS means Appended Time Stamp
     */

    /* [ 0x15U ] TAL_Major_FPGA_Packet_CAN_ATS */
    /*
     * For minor numbers see TAL_Major_FPGA_Packet_CAN
     * since it is handled the same way.
     * ATS means Appended Time Stamp
     */

    /* [ 0x16U ] TAL_Major_FPGA_Packet_LIN_ATS */
    /*
     * For minor numbers see TAL_Major_FPGA_Packet_LIN
     * since it is handled the same way.
     * ATS means Appended Time Stamp
     */

    /* [ 0x17U ] TAL_Major_FPGA_Packet_GPS_ATS */
    /*
     * Minor IDs for GPS packets are defined equal to field 'Msg' in
     * NMEA message 'PSRF103' (see SiRF NMEA Reference Manual, Ref2.1, p. 2-5)
     */
    /* GPGGA: Global Positioning System Fixed Data */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_GGA, 0x00U)
    /* GPGLL: Geographic Position - Latitude/Longitude */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_GLL, 0x01U)
    /* GPGSA: GNSS DOP and Active Satellites */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_GSA, 0x02U)
    /* GPGSV: GNSS Satellites in View */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_GSV, 0x03U)
    /* GPRMC: Recommended Minimum Specific GNSS Data */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_RMC, 0x04U)
    /* GPVTG: Course Over Ground and Ground Speed */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_VTG, 0x05U)
    /* GPMSS: MSK Receiver Signal */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_MSS, 0x06U)
    /* undefined (reserved) */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_Res07, 0x07U)
    /* GPZDA: SiRF Timing Message */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_ZDA, 0x08U)
    /* undefined (reserved) */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_Res09, 0x09U)
    /* 1PPS status packet from FPGA */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_1PPS, 0x80U)
    /* new (internal) UTC second */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_UTC_Overflow, 0x81U)
    /* status of the GPS UTC synchronization gained */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_UTC_SyncOK, 0x82U)
    /* status of the GPS UTC synchronization lost */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_UTC_SyncLost, 0x83U)
    /* unknown, generic NMEA message */
    DEFINE_CONST(TAL_Minor_FPGA_GPS_NMEA_Unknown, 0xffU)

    /* [ 0x18U ] TAL_Major_Insp */
    DEFINE_CONST(TAL_Minor_ConfigureFlexRayAsync, 0x00U)
    DEFINE_CONST(TAL_Minor_ConfigureFlexRaySync, 0x01U)
    DEFINE_CONST(TAL_Minor_ConfigureFlexRayFilter, 0x02U)
    DEFINE_CONST(TAL_Minor_ConfigureCan, 0x03U)
    DEFINE_CONST(TAL_Minor_ConfigureCanFilter, 0x04U)
    DEFINE_CONST(TAL_Minor_ConfigureCanFilterTable, 0x05U)
    DEFINE_CONST(TAL_Minor_ConfigureIoConnector, 0x06U)
    DEFINE_CONST(TAL_Minor_ConfigureAdio, 0x07U)

    DEFINE_CONST(TAL_Minor_ConfigureDeti, 0x09U)
    DEFINE_CONST(TAL_Minor_ConfigureLin, 0x0AU)
    DEFINE_CONST(TAL_Minor_ConfigureFlexRayTriggerOutPin, 0x0BU)
    DEFINE_CONST(TAL_Minor_ArmTriggerOutPin, 0x0CU)
    DEFINE_CONST(TAL_Minor_ConfigureCanFD, 0x0DU)
    DEFINE_CONST(TAL_Minor_ConfigureEth, 0x0EU)
    DEFINE_CONST(TAL_Minor_FanStatus, 0x0FU)

    /* [ 0x19U ] TAL_Major_FPGA_Packet_Ethernet_ATS */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Ethernet_FrameDataFF, 0x00U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Ethernet_FrameDataCF, 0x01U)
    DEFINE_CONST(TAL_Minor_FPGA_Packet_Ethernet_FrameDataFF2, 0x02U)

    /*
     * Common Minor numbers
     */

    /* [ 0x20U ] TAL_Major_Common_DeviceDiscovery */
    DEFINE_CONST(TAL_Minor_Common_GetUSBDeviceInfoReq, 0x00U)
    DEFINE_CONST(TAL_Minor_Common_GetPCIDeviceInfoReq, 0x01U)
    /* [ 0x21U ] TAL_Major_Common_Session */
    DEFINE_CONST(TAL_Minor_Common_CreateTCPSessionReq, 0x00U)
    DEFINE_CONST(TAL_Minor_Common_CreateUSBSessionReq, 0x01U)
    DEFINE_CONST(TAL_Minor_Common_CreatePCISessionReq, 0x02U)
    DEFINE_CONST(TAL_Minor_Common_DeleteSessionReq, 0x03U)
    /* [ 0x22U ] TAL_Major_Common_TargetUserModule */
    DEFINE_CONST(TAL_Minor_Common_TUM_UploadReq, 0x00U)
    DEFINE_CONST(TAL_Minor_Common_TUM_ActivateReq, 0x01U)
    DEFINE_CONST(TAL_Minor_Common_TUM_DeactivateReq, 0x02U)
    DEFINE_CONST(TAL_Minor_Common_TUM_RegisterForRxDataReq, 0x03U)
    DEFINE_CONST(TAL_Minor_Common_TUM_UnregisterForRxDataReq, 0x04U)
    DEFINE_CONST(TAL_Minor_Common_TUM_Data, 0x05U)
    /* [ 0x23U ] TAL_Major_Common_VersionInfo */
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_TargetLibraryVersionReq, 0x00U) */
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_TargetLibraryVersionResp, 0x00U) */
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_TargetFirmwareVersionReq, 0x01U) */
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_TargetFirmwareVersionResp, 0x01U) */
    /* [ 0x24U ] TAL_Major_Common_File */
    DEFINE_CONST(TAL_Minor_Common_StartExecDownloadReq, 0x00U)
    DEFINE_CONST(TAL_Minor_Common_ExecDownloadData, 0x01U)
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_StreamData, 0x02U) */
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_StreamOpen, 0x03U) */
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_StreamClose, 0x04U) */
    /* [ 0x25U ] TAL_Major_Common_Target */
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_TargetCPUUtilisationReq, 0x00U) */
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_TargetCPUUtilisationResp, 0x00U) */
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_TargetRAMUtilisationReq, 0x01U) */
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_Common_TargetRAMUtilisationResp, 0x01U) */
    DEFINE_CONST(TAL_Minor_Common_TargetStatusInd, 0x02U)
    DEFINE_CONST(TAL_Minor_Common_TargetResetReq, 0x03U)
    DEFINE_CONST(TAL_Minor_Common_TargetErrorInd, 0x04U)
    DEFINE_CONST(TAL_Minor_Common_TargetCPULoadReq, 0x05U)
    DEFINE_CONST(TAL_Minor_Common_TargetCPULoadResp, 0x05U)
    DEFINE_CONST(TAL_Minor_Common_TargetRAMUsageReq, 0x06U)
    DEFINE_CONST(TAL_Minor_Common_TargetRAMUsageResp, 0x06U)
    DEFINE_CONST(TAL_Minor_Common_TargetAliveReq, 0x07U)
    DEFINE_CONST(TAL_Minor_Common_TargetAliveResp, 0x07U)
    DEFINE_CONST(TAL_Minor_Common_TargetLicenseInfo, 0x08U)
    DEFINE_CONST(TAL_Minor_Common_TargetMD5Info, 0x09U)
    DEFINE_CONST(TAL_Minor_Common_StartFileDownloadReq, 0x0aU)
    DEFINE_CONST(TAL_Minor_Common_FileDownloadData, 0x0bU)
    DEFINE_CONST(TAL_Minor_Common_CurrentTargetTime, 0x0cU)
    DEFINE_CONST(TAL_Minor_Common_TargetModuleInfo, 0x0dU)
    /* [ 0x26U ] TAL_Major_Common_Padding */
    DEFINE_CONST(TAL_Minor_Common_Padding, 0x00U)


    /*
     * Busmirror Minor numbers
     */

    /* [ 0x30U ] TAL_Major_BM_Signals */
    DEFINE_CONST(TAL_Minor_BM_LoadSignalConversionParametersReq, 0x00U)
    DEFINE_CONST(TAL_Minor_BM_SendSignalPhysicalReq, 0x01U)
    DEFINE_CONST(TAL_Minor_BM_SendSignalInvalidReq, 0x02U)
    DEFINE_CONST(TAL_Minor_BM_SendSignalCodedReq, 0x03U)

    DEFINE_CONST(TAL_Minor_BM_CommitSendFrameReq, 0x04U)
    DEFINE_CONST(TAL_Minor_BM_WaveformCreateStorageReq, 0x05U)
    DEFINE_CONST(TAL_Minor_BM_WaveformDeleteStorageReq, 0x06U)
    DEFINE_CONST(TAL_Minor_BM_WaveformInsertSignalCodedReq, 0x07U)
    DEFINE_CONST(TAL_Minor_BM_WaveformInsertSignalPhysicalReq, 0x08U)
    DEFINE_CONST(TAL_Minor_BM_WaveformInsertSignalInvalidReq, 0x09U)
    DEFINE_CONST(TAL_Minor_BM_WaveformActivateReplayReq, 0x0AU)
    DEFINE_CONST(TAL_Minor_BM_WaveformStartReplayReq, 0x0BU)
    DEFINE_CONST(TAL_Minor_BM_WaveformStartActivatedReplaysReq, 0x0CU)
    DEFINE_CONST(TAL_Minor_BM_WaveformStopReplayReq, 0x0DU)
    DEFINE_CONST(TAL_Minor_BM_WaveformStopAllReplaysReq, 0x0EU)
    DEFINE_CONST(TAL_Minor_BM_ReceiveSignalPhysicalReq, 0x0FU)
    DEFINE_CONST(TAL_Minor_BM_ReceiveSignalCodedReq, 0x10U)
    DEFINE_CONST(TAL_Minor_BM_ReceiveRemoteSignalPhysicalReq, 0x11U)
    DEFINE_CONST(TAL_Minor_BM_ReceiveRemoteSignalCodedReq, 0x12U)

    DEFINE_CONST(TAL_Minor_BM_RegisterForRecvSignalReq, 0x13U)
    DEFINE_CONST(TAL_Minor_BM_RegisterForRecvSignalResp, 0x13U) /* unused */
    DEFINE_CONST(TAL_Minor_BM_ReceiveSignalData, 0x14U)

    DEFINE_CONST(TAL_Minor_BM_UnregisterForRecvSignalReq, 0x15U)
    DEFINE_CONST(TAL_Minor_BM_UnregisterForRecvSignalResp, 0x15U) /* unused */

    DEFINE_CONST(TAL_Minor_BM_RegisterForAllRecvSignalReq, 0x16U)
    DEFINE_CONST(TAL_Minor_BM_RegisterForAllRecvSignalResp, 0x16U) /* unused */

    DEFINE_CONST(TAL_Minor_BM_UnregisterForAllRecvSignalReq, 0x17U)
    DEFINE_CONST(TAL_Minor_BM_UnregisterForAllRecvSignalResp, 0x17U) /* unused */

    DEFINE_CONST(TAL_Minor_BM_ReceiveSignalInvalidInd, 0x18U)
    DEFINE_CONST(TAL_Minor_BM_ReceiveSignalErrorInd, 0x19U)

    DEFINE_CONST(TAL_Minor_BM_SendSignalCodedArrayReqFF, 0x20U)
    DEFINE_CONST(TAL_Minor_BM_ReceiveSignalCodedArrayResFF, 0x21U)
    DEFINE_CONST(TAL_Minor_BM_SendSignalCodedArrayReqCF, 0x22U)
    DEFINE_CONST(TAL_Minor_BM_ReceiveSignalCodedArrayResCF, 0x23U)

    /* [ 0x31U ] TAL_Major_BM_SignalGroups */
    DEFINE_CONST(TAL_Minor_BM_StartRecvSignalGroupInd, 0x00U)
    DEFINE_CONST(TAL_Minor_BM_StopRecvSignalGroupInd, 0x01U)
    DEFINE_CONST(TAL_Minor_BM_StartSendSignalGroupReq, 0x02U)
    DEFINE_CONST(TAL_Minor_BM_StopSendSignalGroupReq, 0x03U)
    DEFINE_CONST(TAL_Minor_BM_SignalGroupMappingReq, 0x04U)
    DEFINE_CONST(TAL_Minor_BM_StartSignalGroupMappingInd, 0x05U)
    DEFINE_CONST(TAL_Minor_BM_StopSignalGroupMappingInd, 0x06U)
    DEFINE_CONST(TAL_Minor_BM_ReceiveSignalGroupMappingData, 0x07U)

    /* [ 0x32U ] TAL_Major_BM_Frames */
    DEFINE_CONST(TAL_Minor_BM_EnableSendFrameReq, 0x00U)
    DEFINE_CONST(TAL_Minor_BM_DisableSendFrameReq, 0x01U)
    /* Removed - do not use anymore! DEFINE_CONST(TAL_Minor_BM_SendFrameReq, 0x02U) */

    DEFINE_CONST(TAL_Minor_BM_ReceiveRemoteFrameReq, 0x03U)

    DEFINE_CONST(TAL_Minor_BM_RegisterForRecvFrameReq, 0x04U)
    DEFINE_CONST(TAL_Minor_BM_RegisterForRecvFrameResp, 0x04U) /* unused */
    DEFINE_CONST(TAL_Minor_BM_ReceiveFrameData, 0x05U)

    DEFINE_CONST(TAL_Minor_BM_UnregisterForRecvFrameReq, 0x06U)
    DEFINE_CONST(TAL_Minor_BM_UnregisterForRecvFrameResp, 0x06U) /* unused */
    DEFINE_CONST(TAL_Minor_BM_RegisterForAllRecvFrameReq, 0x07U)
    DEFINE_CONST(TAL_Minor_BM_RegisterForAllRecvFrameResp, 0x07U) /* unused */
    DEFINE_CONST(TAL_Minor_BM_UnregisterForAllRecvFrameReq, 0x08U)
    DEFINE_CONST(TAL_Minor_BM_UnregisterForAllRecvFrameResp, 0x08U) /* unused */

    DEFINE_CONST(TAL_Minor_BM_ReceiveFrameError, 0x09U)

    DEFINE_CONST(TAL_Minor_BM_SendFrameCondReq, 0x0AU)

    DEFINE_CONST(TAL_Minor_BM_InitTimedFrameReq, 0x0BU)
    DEFINE_CONST(TAL_Minor_BM_SendTimedFrameReq, 0x0CU)

    /* [ 0x33U ] TAL_Major_BM_ECU */
    DEFINE_CONST(TAL_Minor_BM_EnableECUReq, 0x00U)
    DEFINE_CONST(TAL_Minor_BM_DisableECUReq, 0x01U)

    /* [ 0x34U ] TAL_Major_BM_Target */
    DEFINE_CONST(TAL_Minor_BM_StartCommunicationReq, 0x00U)
    DEFINE_CONST(TAL_Minor_BM_StopCommunicationReq, 0x01U)
    DEFINE_CONST(TAL_Minor_BM_RegisterForStartOfCommCycleReq, 0x02U)
    DEFINE_CONST(TAL_Minor_BM_UnregisterForStartOfCommCycleReq, 0x03U)
    DEFINE_CONST(TAL_Minor_BM_GetRemoteControllerStatusReq, 0x04U)
    DEFINE_CONST(TAL_Minor_BM_GetRemoteControllerStatusResp, 0x04U)
    DEFINE_CONST(TAL_Minor_BM_RegisterForChangeOfControllerStatusReq, 0x05U)
    DEFINE_CONST(TAL_Minor_BM_UnregisterForChangeOfControllerStatusReq, 0x06U)
    DEFINE_CONST(TAL_Minor_BM_GetRemoteSlotStatusReq, 0x07U)
    DEFINE_CONST(TAL_Minor_BM_GetNumberOfTasksReq, 0x08U)
    DEFINE_CONST(TAL_Minor_BM_GetTaskInfoReq, 0x09U)
    DEFINE_CONST(TAL_Minor_BM_FlexRayStatusInd, 0x0AU)
    DEFINE_CONST(TAL_Minor_BM_SetConditionReq, 0x0BU)

    DEFINE_CONST(TAL_Minor_BM_InitDataReq, 0x0CU)
    DEFINE_CONST(TAL_Minor_BM_InitDataResp, 0x0DU)

    /* [ 0x35U ] TAL_Major_BM_DigitalIO */
    DEFINE_CONST(TAL_Minor_BM_PPRegisterForDioReq, 0x00U)
    DEFINE_CONST(TAL_Minor_BM_PPDioSetChannelDirection, 0x01U)
    DEFINE_CONST(TAL_Minor_BM_PPSendDioValues, 0x02U)
    DEFINE_CONST(TAL_Minor_BM_PPRequestDioData, 0x03U)

    /* [ 0x36U ] TAL_Major_BM_CANMessages */
    DEFINE_CONST(TAL_Minor_BM_InitCANReq, 0x01U)
    DEFINE_CONST(TAL_Minor_BM_InitCANResp, 0x01U) /* unused */

    DEFINE_CONST(TAL_Minor_BM_SendCANMessageReq, 0x02U)

    DEFINE_CONST(TAL_Minor_BM_RegisterForRecvCANMessageFilterReq, 0x03U)
    DEFINE_CONST(TAL_Minor_BM_RegisterForRecvCANMessageFilterResp, 0x03U) /* unused */

    DEFINE_CONST(TAL_Minor_BM_RegisterForRecvCANMessageReq, 0x04U)
    DEFINE_CONST(TAL_Minor_BM_RegisterForRecvCANMessageResp, 0x04U) /* unused */

    DEFINE_CONST(TAL_Minor_BM_ReceiveCANMessageData, 0x05U)

    DEFINE_CONST(TAL_Minor_BM_UnregisterForRecvCANMessageReq, 0x06U)
    DEFINE_CONST(TAL_Minor_BM_UnregisterForRecvCANMessageResp, 0x06U) /* unused */

    DEFINE_CONST(TAL_Minor_BM_SetHostGlobalEventMask, 0x07U)

    DEFINE_CONST(TAL_Minor_BM_ConfigureTimedSendReq, 0x08U)

    DEFINE_CONST(TAL_Minor_BM_InitCANFDReq, 0x09U)

    DEFINE_CONST(TAL_Minor_BM_SetCANSamplingPoint, 0x0AU)

    /* [ 0x37U ] TAL_Major_BM_PDU */
    DEFINE_CONST(TAL_Minor_BM_CommitPDUReq, 0x01U)
    DEFINE_CONST(TAL_Minor_BM_SendPDUReqFF, 0x02U)
    DEFINE_CONST(TAL_Minor_BM_RegisterForRecvPDUReq, 0x04U)
    DEFINE_CONST(TAL_Minor_BM_ReceivePDUDataFF, 0x05U)
    DEFINE_CONST(TAL_Minor_BM_UnregisterForRecvPDUReq, 0x06U)
    DEFINE_CONST(TAL_Minor_BM_UnregisterForAllRecvPDUReq, 0x08U)
    DEFINE_CONST(TAL_Minor_BM_ReceivePDUError, 0x09U)
    DEFINE_CONST(TAL_Minor_BM_SendPDUReqCF, 0x0AU)
    DEFINE_CONST(TAL_Minor_BM_ReceivePDUDataCF, 0x0BU)

    /* [ 0x38U ] TAL_Major_BM_FRMessages */
    DEFINE_CONST(TAL_Minor_BM_FRControlTxComOps, 0x06U)

    /* [ 0x39U ] TAL_Major_Lin */
    DEFINE_CONST(TAL_Minor_LinConfigureChannel, 0x01U)
    DEFINE_CONST(TAL_Minor_LinSetScheduleTableEntry, 0x02U)
    DEFINE_CONST(TAL_Minor_LinReceiveData, 0x03U)
    DEFINE_CONST(TAL_Minor_LinCreateScheduleTable, 0x04U)
    DEFINE_CONST(TAL_Minor_LinStopScheduleTable, 0x05U)
    DEFINE_CONST(TAL_Minor_LinExecuteScheduleTable, 0x06U)
    DEFINE_CONST(TAL_Minor_LinUpdateData, 0x07U)
    DEFINE_CONST(TAL_Minor_LinPrintScheduleTable, 0x08U)
    DEFINE_CONST(TAL_Minor_LinUpdateFrameResponseType, 0x09U)

    /* [ 0x3AU ] TAL_Major_ServiceDiscovery */
    DEFINE_CONST(TAL_Minor_ServiceDiscoverySetState, 0x01U)
    DEFINE_CONST(TAL_Minor_ServiceDiscoveryGetState, 0x02U)

    /* [ 0x3BU ] TAL_Major_BM_Ethernet */
    DEFINE_CONST(TAL_Minor_BM_SendEthMessageReqFF2, 0x00U)
    DEFINE_CONST(TAL_Minor_BM_SendEthMessageReqFF, 0x01U) /* deprecated, use TAL_Minor_BM_SendEthMessageReqFF2 instead (better aligned) */
    DEFINE_CONST(TAL_Minor_BM_SendEthMessageReqCF, 0x02U)

    /* [ 0x3CU ] TAL_Major_EncapsulatedEBHSCR */
    DEFINE_CONST(TAL_Minor_EncapsulatedEBHSCR_FF, 0x01U)
    DEFINE_CONST(TAL_Minor_EncapsulatedEBHSCR_CF, 0x02U)

    /* [ 0x40U ] TAL_Major_VirtFrBus */
    DEFINE_CONST(TAL_Minor_VirtFrBuf, 0x01U)
    DEFINE_CONST(TAL_Minor_VirtFrTxAck, 0x02U)
    DEFINE_CONST(TAL_Minor_VirtFrPOCStatus, 0x03U)
    DEFINE_CONST(TAL_Minor_VirtFrConfig, 0x04U)
    DEFINE_CONST(TAL_Minor_VirtFrConfigLPDU, 0x05U)
    DEFINE_CONST(TAL_Minor_VirtFrSetWakeupChannel, 0x06U)
    DEFINE_CONST(TAL_Minor_CHICommon, 0x07U)
    DEFINE_CONST(TAL_Minor_VirtFrGlobalTime, 0x08U)
    DEFINE_CONST(TAL_Minor_VirtFrSetAbsoluteTimer, 0x09U)
    DEFINE_CONST(TAL_Minor_VirtFrAbsoluteTimerIRQ, 0x0AU)
    DEFINE_CONST(TAL_Minor_VirtFrOnOffLPdu, 0x0BU)
    DEFINE_CONST(TAL_Minor_VirtFrCycleStartIRQ, 0x0CU)

    /* [ 0x41U ] TAL_Major_VirtCanBus */
    DEFINE_CONST(TAL_Minor_VirtCanSetBaudrate, 0x01U)
    DEFINE_CONST(TAL_Minor_VirtCanSetControllerMode, 0x02U)
    DEFINE_CONST(TAL_Minor_VirtCanMsg, 0x03U)
    DEFINE_CONST(TAL_Minor_VirtCanTimedMsg, 0x04U)

    /* [ 0x43U] TAL_Major_EB7200 */
    DEFINE_CONST(TAL_Minor_Channel0, 0x00U)
    DEFINE_CONST(TAL_Minor_Channel1, 0x01U)
    DEFINE_CONST(TAL_Minor_Channel2, 0x02U)
    DEFINE_CONST(TAL_Minor_Channel3, 0x03U)
    DEFINE_CONST(TAL_Minor_Channel4, 0x04U)
    DEFINE_CONST(TAL_Minor_Channel5, 0x05U)
    DEFINE_CONST(TAL_Minor_Channel6, 0x06U)
    DEFINE_CONST(TAL_Minor_Channel7, 0x07U)
    DEFINE_CONST(TAL_Minor_Channel8, 0x08U)
    DEFINE_CONST(TAL_Minor_Channel9, 0x09U)
    DEFINE_CONST(TAL_Minor_Channel10, 0x0aU)
    DEFINE_CONST(TAL_Minor_Channel11, 0x0bU)
    DEFINE_CONST(TAL_Minor_Channel12, 0x0cU)
    DEFINE_CONST(TAL_Minor_Channel13, 0x0dU)
    DEFINE_CONST(TAL_Minor_Channel14, 0x0eU)
    DEFINE_CONST(TAL_Minor_Channel15, 0x0fU)
    DEFINE_CONST(TAL_Minor_Channel16, 0x10U)
    DEFINE_CONST(TAL_Minor_Channel17, 0x11U)
    DEFINE_CONST(TAL_Minor_Channel18, 0x12U)
    DEFINE_CONST(TAL_Minor_Channel19, 0x13U)
    DEFINE_CONST(TAL_Minor_Channel20, 0x14U)
    DEFINE_CONST(TAL_Minor_Channel21, 0x15U)
    DEFINE_CONST(TAL_Minor_Channel22, 0x16U)
    DEFINE_CONST(TAL_Minor_Channel23, 0x17U)
    DEFINE_CONST(TAL_Minor_Channel24, 0x18U)
    DEFINE_CONST(TAL_Minor_Channel25, 0x19U)
    DEFINE_CONST(TAL_Minor_Channel26, 0x1aU)
    DEFINE_CONST(TAL_Minor_Channel27, 0x1bU)
    DEFINE_CONST(TAL_Minor_Channel28, 0x1cU)
    DEFINE_CONST(TAL_Minor_Channel29, 0x1dU)
    DEFINE_CONST(TAL_Minor_Channel30, 0x1eU)
    DEFINE_CONST(TAL_Minor_Channel31, 0x1fU)
    DEFINE_CONST(TAL_Minor_Channel32, 0x20U)
    DEFINE_CONST(TAL_Minor_Channel33, 0x21U)
    DEFINE_CONST(TAL_Minor_Channel34, 0x22U)
    DEFINE_CONST(TAL_Minor_Channel35, 0x23U)
    DEFINE_CONST(TAL_Minor_Channel36, 0x24U)
    DEFINE_CONST(TAL_Minor_Channel37, 0x25U)
    DEFINE_CONST(TAL_Minor_Channel38, 0x26U)
    DEFINE_CONST(TAL_Minor_Channel39, 0x27U)
    DEFINE_CONST(TAL_Minor_Channel40, 0x28U)
    DEFINE_CONST(TAL_Minor_Channel41, 0x29U)
    DEFINE_CONST(TAL_Minor_Channel42, 0x2aU)
    DEFINE_CONST(TAL_Minor_Channel43, 0x2bU)
    DEFINE_CONST(TAL_Minor_Channel44, 0x2cU)
    DEFINE_CONST(TAL_Minor_Channel45, 0x2dU)
    DEFINE_CONST(TAL_Minor_Channel46, 0x2eU)
    DEFINE_CONST(TAL_Minor_Channel47, 0x2fU)

    /*
     * Inspector Minor numbers (continued)
     */
    /* [ 0x70U ] TAL_Major_FPGA_Packet_TriggerMarker */
    /*
     * +-----+------+------+------+------+-----+-----+-----+-------+
     * | Bit |  7   |  6   |  5   |  4   |  3  |  2  |  1  |  0    |
     * +-----+------+------+------+------+-----+-----+-----+-------+
     *       | SRC3 | SRC2 | SRC1 | SRC0 | TT2 | TT1 | TT0 | CLASS |
     *       +------+------+------+------+-----+-----+-----+-------+
     *
     * CLASS     - '0': Start trigger data packet
     *             '1': Stop trigger or single trigger data packet
     * TT[0..2]  - '0': Trigger type concerns to header or data (FlexRay or CAN)
     *             '1': Trigger type concerns to status (FlexRay only)
     * SRC[0..3] - '0': Trigger source was FlexRay
     *             '1': Trigger source was CAN
     *             '2': Trigger source was Button
     *             '3': Trigger source was Pin
     */

    /* [ 0x71U ] TAL_Major_FPGA_Packet_GeneralMarker */
    DEFINE_CONST(TAL_Minor_FPGA_Packet_GeneralMarker, 0x00U)

    /* [ 0x7AU ] TAL_Major_Device_Option */
    DEFINE_CONST(TAL_Minor_Device_Option_Response, 0x00U)

    /* [ 0x81U ] TAL_Major_VirtTimeSource */
    DEFINE_CONST(TAL_Minor_Sil_Tick, 0x01U) /* deprecated, use TAL_Minor_SilTick */
    DEFINE_CONST(TAL_Minor_SilTick, 0x01U)
    DEFINE_CONST(TAL_Minor_Sil_Tock, 0x02U) /* deprecated, use TAL_Minor_SilTock */
    DEFINE_CONST(TAL_Minor_SilTock, 0x02U)

#ifdef __cplusplus
private:

    /*
     * Private methods:
     */

    /*
     * Private members:
     */

    /*
     * Constructor(s)
     */
    TAL_Numbers();

    /*
     * Destructor
     */
    ~TAL_Numbers();

    /*
     * Prevent assignment operator and copy constructor
     */
    TAL_Numbers & operator = (const TAL_Numbers & rhs);

    TAL_Numbers(const TAL_Numbers & rhs);
#endif /* __cplusplus */

};

#endif /* _TAL_NUMBERS_H_ */
