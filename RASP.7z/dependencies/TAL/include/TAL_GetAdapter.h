/*
 * File    : $RCSfile: TAL_GetAdapter.h,v $
 *
 * Module  : TAL_GetAdapter
 * Release : $Name: not supported by cvs2svn $
 * Date    : $Date: 2020-06-10 10:59:51 $
 * Author  : $Author: Shrief Rizkalla $
 *
 * Description:
 * Implementation of function to get local interfaces
 *
 * Copyright 2002-2020 Elektrobit Austria GmbH, http://www.elektrobit.com
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 *
 * PLATFORM DEPENDANT [yes/no]: yes
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifndef _TAL_GETADAPTER_H_
#define _TAL_GETADAPTER_H_

/******************************************************************************
 Include Section
******************************************************************************/

#include <TAL_Std_Types.h>  /* fixed size data types */
#include <stdlib.h>

/******************************************************************************
 Global Macros
******************************************************************************/

/*---------------------------------------------------------------------------*/
static inline void append(TAL_AdapterListIterator* Head, const TAL_AdapterInfoType& AdapterInfo)
{
    TAL_AdapterListEntryType* Element = (TAL_AdapterListEntryType*)malloc(sizeof(TAL_AdapterListEntryType));
    if (Element != NULL)
    {
        Element->AdapterInfo = AdapterInfo;
        Element->Next = NULL;
    }
    if (*Head == NULL)
    {
        *Head = Element;
    }
    else
    {
        TAL_AdapterListEntryType* cursor = *Head;
        while (cursor->Next != NULL)
        {
            cursor = cursor->Next;
        }
        cursor->Next = Element;
    }
}
/******************************************************************************
 Global Data Types
******************************************************************************/

/******************************************************************************
 Global Data
******************************************************************************/

/******************************************************************************
 Global Function Declarations
******************************************************************************/

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     *
     * @brief Retrieves all adapter information for the local computer
     *
     * @param Adapters_Head     A linked structure containing all information on local network adpaters.
     *
     * @retval TAL_SUCCESS      Network adapter information are correctly extracted.
     * @retval TAL_FAILED       The function call failed to execute
     *
     * @remarks  None.
     *
     */
    extern TAL_ReturnType TAL_GetAdapter(TAL_AdapterListIterator* Adapters_Head);

    /**
     *
     * @brief deletes the allocated memory for the struct holding the network adapter information
     *
     * @param Adapters_Head     A linked structure containing all information on local network adpaters.
     *
     * @retval None.
     *
     * @remarks  The input struct must be referring to the head of the structure, in order to delete all linked structs.
     *
     */
    extern void TAL_FreeAdapter(TAL_AdapterListIterator Adapters_Head);

#ifdef __cplusplus
}
#endif

/******************************************************************************
 Class Declarations
******************************************************************************/

#endif /* _TAL_GETADAPTER_H_ */
