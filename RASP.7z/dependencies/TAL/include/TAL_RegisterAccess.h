#ifndef TAL_REGISTER_ACCESS_H
#define TAL_REGISTER_ACCESS_H

#include <TAL_Std_Types.h>                /* fixed size data types */
#include <TAL_Types.h>                    /* Common TAL types */
#include "OneWireTypes.h"

class TAL_RegisterAccess
{
public:
    TAL_RegisterAccess() : m_isOpened(false) {}
    virtual ~TAL_RegisterAccess() {}
    virtual TAL_ReturnType OpenIp(uint32 srcIpAddress, uint32 destIpAddress, uint32 nTimeoutMsArg); /* for IP BottomHalves */
    virtual TAL_ReturnType OpenPci(TAL_DeviceIndexType device_index); /* for PCI BottomHalves */
    virtual void Close() = 0;
    virtual TAL_ReturnType ReadRegisterU32(uint32 address, uint32* value) = 0;
    virtual TAL_ReturnType WriteRegisterU32(uint32 address, uint32 value) = 0;
    virtual TAL_ReturnType ReadBlock(uint32 address, uint8* data, uint32 length) = 0;
    virtual TAL_ReturnType WriteBlock(uint32 address, const uint8* data, uint32 length, bool IsFirmware) = 0;
    virtual TAL_ReturnType GetModuleConfig(uint8 nSlot, OW_ModuleDescType* pModuleList) = 0;
    bool IsOpened() const
    {
        return m_isOpened;
    }

protected:
    bool m_isOpened;
};

#endif //TAL_REGISTER_ACCESS_H
