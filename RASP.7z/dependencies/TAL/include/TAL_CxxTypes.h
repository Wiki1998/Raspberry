/*
 * File    : TAL_CxxTypes.h
 *
 * Module  : EB_tresos_TAL
 *
 * Description:
 * Interface header file for TAL.
 *
 * Copyright 2002-2012 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifdef TAL_CXX_API

#ifndef TAL_CXX_TYPES_GUARD
#define TAL_CXX_TYPES_GUARD

#include "TAL_Types.h" /* TAL types */
#include "TAL_CompileTimeAssert.h" /* TAL_CompileTimeAssert */
#include <string.h>


class TalCpuLoad
{
public:
    TalCpuLoad()
        : averagePoint1s(0)
        , average1s(0)
        , average10s(0)
    {
    }

    /**
     * @return Average CPU load over the last 0.1s
     */
    uint32 getAveragePoint1s() const
    {
        return averagePoint1s;
    }

    /**
     * @return Average CPU load over the last 1s
     */
    uint32 getAverage1s() const
    {
        return average1s;
    }

    /**
     * @return Average CPU load over the last 10s
     */
    uint32 getAverage10s() const
    {
        return average10s;
    }
protected:
    uint32 averagePoint1s;
    uint32 average1s;
    uint32 average10s;

    friend class TalInterface;
    friend class TalImpl;
};

class TalRamUsage
{
public:
    TalRamUsage()
        : memorySize(0)
        , usedMemory(0)
        , freeMemory(0)
    {
        memset(freeQueueSpace, -1, TAL_COMM_RAM_USAGE_MAX_QUEUECNT);
    }

    /**
     * @return Full size of the target memory in bytes
     */
    uint32 getMemorySize() const
    {
        return memorySize;
    }

    /**
     * @return Size of used memory on the target in bytes
     */
    uint32 getUsedMemory() const
    {
        return usedMemory;
    }

    /**
     * @return Avaliable free memory on the target in bytes
     */
    uint32 getFreeMemory() const
    {
        return freeMemory;
    }

    /** @return Free space in FIFO from target to host (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceOutputFifo() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_OUTPUT_FIFO]; }
    /** @return Free space in FIFO from host to target (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceInputFifo() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_INPUT_FIFO]; }
    /** @return Free space in 2nd FIFO from target to host (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceOutputFifo2() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_OUTPUT_FIFO2]; }
    /** @return Free space in 2nd FIFO from host to target (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceInputFifo2() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_INPUT_FIFO2]; }
    /** @return Free space in FlexRay timed frame send queue (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceFrQueue0() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_FR_QUEUE0]; }
    /** @return Free space in FlexRay timed frame send queue (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceFrQueue1() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_FR_QUEUE1]; }
    /** @return Free space in FlexRay timed frame send queue (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceFrQueue2() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_FR_QUEUE2]; }
    /** @return Free space in CAN timed frame send queue (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceCanQueue0() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_CAN_QUEUE0]; }
    /** @return Free space in CAN timed frame send queue (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceCanQueue1() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_CAN_QUEUE1]; }
    /** @return Free space in CAN timed frame send queue (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceCanQueue2() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_CAN_QUEUE2]; }
    /** @return Free space in CAN timed frame send queue (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceCanQueue3() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_CAN_QUEUE3]; }
    /** @return Free space in CAN timed frame send queue (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceCanQueue4() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_CAN_QUEUE4]; }
    /** @return Free space in CAN timed frame send queue (percentage) */
    /*          (0xff .. value not available) */
    sint8 getFreeSpaceCanQueue5() const { return freeQueueSpace[TAL_COMM_RAM_USAGE_CAN_QUEUE5]; }
    /** @return Free space in queue selected by queue id (percentage) */
    /*          (-1 .. value not available) */
    sint8 getFreeQueueSpaceByID(TAL_CommRAMUsageQueueType nQueueID) const 
    {
        if (nQueueID < TAL_COMM_RAM_USAGE_MAX_QUEUECNT)
        {
            return freeQueueSpace[nQueueID];
        }
        else
        {
            return -1;
        }
    }

protected:
    uint32 memorySize;
    uint32 usedMemory;
    uint32 freeMemory;
    sint8 freeQueueSpace[TAL_COMM_RAM_USAGE_MAX_QUEUECNT];

    friend class TalInterface;
    friend class TalImpl;
};

class TalTargetHardwareInfo
{
public:
    TalTargetHardwareInfo()
        :  serialNr(0)
        ,  ramSizeInBytes(0)
        ,  flashSizeInBytes(0)
        ,  sramSizeInBytes(0)
        ,  compactFlashSizeInBytes(0)
    {
        boardID[0] = '\0';
        macAddr[0] = '\0';
        compactFlashType[0] = '\0';
        hwVariantName[0] = '\0';
    }

    /**
     * @return the serial number of the target hardware
     */
    uint16 getSerialNr() const
    {
        return serialNr;
    }

    /**
    * @return the RAM size of the target hardware in megabytes
    */
    uint32 getRamSizeInMegaBytes() const
    {
        return ramSizeInBytes / (1024 * 1024);
    }

    /**
    * @return the flash size of the target hardware in megabytes
    */
    uint32 getFlashSizeInMegaBytes() const
    {
        return flashSizeInBytes  / (1024 * 1024);
    }

    /**
    * @return the SRAM size of the target hardware in bytes
    */
    uint32 getSramSizeInBytes() const
    {
        return sramSizeInBytes;
    }

    /**
    * @return the Compact Flash size of the target hardwre in megabytes
    */
    uint32 getCompactFlashSizeInMegaBytes() const
    {
        return static_cast<uint32>(compactFlashSizeInBytes  / (1024 * 1024));
    }

    /**
    * @return the board ID of the target hardware as zero terminated string
    */
    const char * getBoardID() const 
    {
        return boardID;
    }

    /**
    * @return the Mac-Address of the target hardware as zero terminated string
    */
    const char * getMacAddr() const 
    {
        return macAddr;
    }

    /**
    * @return the Compact Flash type of the target hardware as zero terminated string
    */
    const char * getCompactFlashType() const
    {
        return compactFlashType;
    }

    /**
    * @return the hardware variant name of the target hardware as zero terminated string
    */
    const char * getHwVariantName() const 
    {
        return hwVariantName;
    }

protected:
    uint16 serialNr;
    uint32 ramSizeInBytes;
    uint32 flashSizeInBytes;
    uint32 sramSizeInBytes;
    uint64 compactFlashSizeInBytes;

    char boardID[HW_INFO_BOARD_ID_LENGTH];
    char macAddr[HW_INFO_MAC_ADDR_LENGTH];
    char compactFlashType[HW_INFO_COMPACTFLASH_TYPE_LENGTH];
    char hwVariantName[HW_INFO_VARIANT_NAME_LENGTH];

    friend class TalInterface;
    friend class TalImpl;
};

class TalInt
{
public:
    TalInt()
        : value(0)
    {
    }

    /**
     * @return integer value
     */
    int get() const
    {
        return value;
    }

    /**
     * @param val integer value
     */
    void set(int val)
    {
        value = val;
    }

protected:
    int value;

    friend class TalInterface;
    friend class TalImpl;
};

class TalUInt
{
public:
    TalUInt()
        : value(0)
    {
    }

    /**
     * @return integer value
     */
    unsigned int get() const
    {
        return value;
    }

    /**
     * @param val integer value
     */
    void set(unsigned int val)
    {
        value = val;
    }

protected:
    unsigned int value;

    friend class TalInterface;
    friend class TalImpl;
};

class TalUInt64
{
public:
    TalUInt64()
        : value(0)
    {
    }

    /**
     * @return long value
     */
    uint64 get() const
    {
        return value;
    }

    /**
     * @param val long integer value
     */
    void set(uint64 val)
    {
        value = val;
    }

protected:
    uint64 value;

    friend class TalInterface;
    friend class TalImpl;
};

class TalLicense
{
public:
    TalLicense()
        : name(0)
        , num(0)
        , validityEndYear(0)
        , validityEndMonth(0)
    {
    }

    /**
     * @return license feature as a zero-terminated string
     */
    const char *getName() const
    {
        if (name == 0)
        {
            return "";
        }
        else
        {
            return name;
        }
    }

    /**
     * @return number of the license feature
     */
    int getNumber() const
    {
        return num;
    }

    /**
     * @return year of the end of the validity time of the license
     */
    int getValidityEndYear() const
    {
        return validityEndYear;
    }

    /**
     * @return month of the end of the validity time of the license
     */
    int getValidityEndMonth() const
    {
        return validityEndMonth;
    }

protected:
    const char *name;
    int num;
    int validityEndYear;
    int validityEndMonth;

    friend class TalInterface;
    friend class TalImpl;
};

class TalModule
{
public:
    TalModule()
        : moduleType(TAL_TYPE_UNKNOWN)
        , slot(0)
        , revision(0)
        , boardID(0)
    {
    }

    /**
     * @return module feature as a zero-terminated string
     */
    TAL_ModuleType getType() const
    {
        return moduleType;
    }

    /**
     * @return number of the module feature
     */
    uint8 getSlot() const
    {
        return slot;
    }

    /**
     * @return year of the end of the validity time of the module
     */
    uint8 getRevision() const
    {
        return revision;
    }

    /**
     * @return month of the end of the validity time of the module
     */
    uint64 getBoardID() const
    {

        return boardID;
    }

protected:
    TAL_ModuleType moduleType;
    uint8 slot;
    uint8 revision;
    uint64 boardID;

    friend class TalInterface;
    friend class TalImpl;
};

class TalTargetTime
{
public:
    TalTargetTime()
        : timestamp(0)
        , timestampType(TAL_FPGA_TIMEBASE_FREE_RUNNING_LEGACY)
        , microPerMacro(40)
        , macroPerCycle(5000)
        , cyclePerSupercycle(64)
    {
    }

    TalTargetTime(uint64 timestampArg,
                  TAL_TimebaseSelectType timestampTypeArg,
                  uint8 microPerMacroArg,
                  uint16 macroPerCycleArg,
                  uint8 cyclePerSupercycleArg)
        : timestamp(timestampArg)
        , timestampType(timestampTypeArg)
        , microPerMacro(microPerMacroArg)
        , macroPerCycle(macroPerCycleArg)
        , cyclePerSupercycle(cyclePerSupercycleArg)
    {
    }

    /**
     * @return raw value of timestamp
     */
    uint64 getTimestampRaw() const
    {
        return timestamp;
    }

    /**
     * @return timestamp in units of microticks (25ns)
     */
    uint64 getTimestampMicrotick() const
    {
        switch(timestampType)
        {
            case TAL_FPGA_TIMEBASE_FREE_RUNNING_LEGACY:
            case TAL_FPGA_TIMEBASE_GPS:
            case TAL_FPGA_TIMEBASE_FREE_RUNNING:
                return timestamp;

            case TAL_FPGA_TIMEBASE_FR_MACROTICK_MASTER:     /* fallthrough */
            case TAL_FPGA_TIMEBASE_FR_MACROTICK_SLAVE:
            case TAL_FPGA_TIMEBASE_FR_MACROTICK_SLAVE_CH1:
            case TAL_FPGA_TIMEBASE_FR_MACROTICK_SLAVE_CH2:
            {
                /* Layout of macrotick timestamp 
                 *
                 * Bit  7 ..  0 Microtick
                 * Bit 24 ..  8 Macrotick
                 * Bit 25       if set --> fallback timestamp if not sync
                 * Bit 31 .. 26 Cycle
                 * Bit 63 .. 32 Supercycle
                 */
                uint64 nMicroticks  =  timestamp & 0x000000ffULL;
                uint64 nMacroticks  = (timestamp & 0x01ffff00ULL) >> 8;
                uint64 nCycles      = (timestamp & 0xfc000000ULL) >> 26;
                uint64 nSupercycles =  timestamp                  >> 32;
                return nMicroticks +
                       ( nMacroticks +
                         ( nCycles +
                           nSupercycles * cyclePerSupercycle
                         ) * macroPerCycle
                       ) * microPerMacro;
            }
            case TAL_FPGA_TIMEBASE_BPLUS_SLAVE_CH1: /* fallthrough */
            case TAL_FPGA_TIMEBASE_BPLUS_SLAVE_CH2: /* fallthrough */
            case TAL_FPGA_TIMEBASE_EB_TIME_MASTER:
                return timestamp;

            default:
                /* should not happen */
                return timestamp;
        }
    }

    /**
     * @return type of timestamp
     */
    TAL_TimebaseSelectType getTimestampType() const
    {
        return timestampType;
    }

    /**
     * @return microticks per macrotick
     */
    int getMicroPerMacro() const
    {
        return microPerMacro;
    }

    /**
     * @return macroticks per cycle
     */
    int getMacroPerCycle() const
    {
        return macroPerCycle;
    }

    /**
     * @return cycles per supercycle
     */
    int getCyclePerSupercycle() const
    {
        return cyclePerSupercycle;
    }

protected:
    uint64 timestamp;
    TAL_TimebaseSelectType timestampType;
    uint8 microPerMacro;
    uint16 macroPerCycle;
    uint8 cyclePerSupercycle;

    friend class TalInterface;
    friend class TalImpl;
};

class TalEventType
{
public:
    TalEventType()
        : type(TAL_EVENT_UNKNOWN)
    {
    }

    /**
     * @return type of the event.
     */
    TAL_EventType getType() const
    {
        return type;
    }

protected:
    TAL_EventType type;

    friend class TalInterface;
    friend class TalImpl;
};

class TalEvent
{
public:
    TalEvent()
        : id(0)
        , data(0)
    {
    }

    /**
     * @return id of the event. Optional, depending on the type.
     */
    int getId() const
    {
        return id;
    }

    /**
     * @return data of the event. Optional, depending on the type.
     */
    unsigned int getData() const
    {
        return data;
    }

protected:
    int id;
    unsigned int data;

    friend class TalInterface;
    friend class TalImpl;
    friend class TAL_EventBase;
};

class TalVersion
{
public:
    TalVersion()
        : majorVersion(0)
        , minorVersion(0)
        , patchVersion(0)
    {
        variant[0] = '\0';
        description[0] = '\0';
    }

    /**
     * Returns major number
     *
     * @return major number
     */
    uint16 getMajor() const
    {
        return majorVersion;
    }

    /**
     * Returns minor number
     *
     * @return minor number
     */
    uint16 getMinor() const
    {
        return minorVersion;
    }

    /**
     * Returns patch number
     *
     * @return patch number
     */
    uint16 getPatch() const
    {
        return patchVersion;
    }

    /**
     * Returns variant name
     *
     * @return variant name
     */
    const char * getVariant() const
    {
        return variant;
    }

    /**
     * Returns description
     *
     * @return description
     */
    const char * getDescription() const
    {
        return description;
    }

protected:
    uint16 majorVersion;
    uint16 minorVersion;
    uint16 patchVersion;
    char variant[BUSMIRROR_VERSION_VARIANT_NAME_LENGTH];
    char description[BUSMIRROR_VERSION_DESCRIPTION_LENGTH];

    friend class TalInterface;
    friend class TalImpl;
};

class TalFifoUsage
{
public:
    TalFifoUsage()
        : txFreeBytes(0)
        , txTotalBytes(0)
        , rxFreeBytes(0)
        , rxTotalBytes(0)
    {
    }

    /**
     * Returns free bytes for transmit FIFO
     *
     * @return free bytes for transmit FIFO
     */
    uint32 getTxFreeBytes() const
    {
        return txFreeBytes;
    }

    /**
     * Returns total bytes for transmit FIFO
     *
     * @return total bytes for transmit FIFO
     */
    uint32 getTxTotalBytes() const
    {
        return txTotalBytes;
    }

    /**
     * Returns free bytes for receive FIFO
     *
     * @return free bytes for receive FIFO
     */
    uint32 getRxFreeBytes() const
    {
        return rxFreeBytes;
    }

    /**
     * Returns total bytes for receive FIFO
     *
     * @return total bytes for receive FIFO
     */
    uint32 getRxTotalBytes() const
    {
        return rxTotalBytes;
    }


protected:
    uint32 txFreeBytes;
    uint32 txTotalBytes;
    uint32 rxFreeBytes;
    uint32 rxTotalBytes;

    friend class TalInterface;
    friend class TalImpl;
};

class TalByteArray
{
public:
    /**
     * @brief Allocates a byte array of size nArrayLength on the heap
     *
     * The size of the byte array is fixed and must be known during object
     * creation. It can not be changed afterwards.
     *
     * @param nArrayLength Size of the array in bytes
     */
    TalByteArray(uint32 nArrayLength)
        /* new uint8[0] does not return 0 in MSVC Debug configuration */
        : array((nArrayLength == 0) ? 0 : new uint8[nArrayLength])
        , arrayLength(nArrayLength)
        , arrayLengthReceived(0)
    {
    }

    virtual ~TalByteArray()
    {
        if (array != 0)
        {
            delete [] array;
        }
    }

    /**
     * Sets the value of the array at index. Use getArrayLength() to get the
     * length of the array.
     *
     * @param nIndex Index of the byte which shall be set
     * @param nValue Value the byte shall be set to
     *
     * @return TAL_SUCCESS index is in bounds
     * @return TAL_INVALID_INDEX index is out of bounds
     */
    TAL_ReturnType setArrayValue(uint32 nIndex, uint8 nValue)
    {
        if (nIndex >= arrayLength)
        {
            return TAL_INVALID_INDEX;
        }

        array[nIndex] = nValue;
        return TAL_SUCCESS;
    }

    /**
     * Gets the value of the array at index. Use getArrayLengthReceived() to
     * get the length of the received array.
     *
     * @param nIndex Index of the byte which shall be get
     *
     * @return array value at index
     */
    uint8 getArrayValue(uint32 nIndex) const
    {
        if (nIndex < arrayLength)
        {
            return array[nIndex];
        }
        else
        {
            return 0;
        }
    }

    /**
     * @brief Gets the real length of the last received array
     *
     * If the array is received from the target the received length can differ
     * from the allocated length. Therfore use the getArrayLengthReceived()
     * method to check the valid area of the array.
     *
     * @return last array length received.
     */
    uint32 getArrayLengthReceived() const
    {
        return arrayLengthReceived;
    }

    /**
     * @brief Gets the length of the array
     *
     * The array length is fixed during calling the constructor of
     * TalByteArray. This method can be used to get the array length at a
     * later time.
     *
     * @return array length
     */
    uint32 getArrayLength() const
    {
        return arrayLength;
    }

#ifndef SWIG
    /**
     * Copy a given buffer to the array
     *
     * @param pBuffer array
     * @param nBufferSize length of array in pBuffer
     *
     * @return TAL_SUCCESS index is in bounds
     * @return TAL_BUFFER_TOO_SMALL given buffer is to large to fit into array
     */
    TAL_ReturnType setArray(const uint8* pBuffer, uint32 nBufferSize)
    {
        if (nBufferSize > arrayLength)
        {
            return TAL_BUFFER_TOO_SMALL;
        }

        memcpy(array, pBuffer, nBufferSize);
        return TAL_SUCCESS;
    }

    /**
     * Gets the pointer of the array at index.
     *
     * @return Pointer to array at nIndex
     */
    uint8 *getArray() const
    {
        return array;
    }
#endif /* SWIG */
protected:
    uint8 * const array;
    const uint32 arrayLength;
    uint32 arrayLengthReceived;

    friend class TalInterface;
    friend class TalImpl;
    friend class TalSignal;
    friend class TalPdu;
    friend class TalCanMsg;
    friend class TalUserData;
    friend class TalMeasureData;

    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalByteArray & operator = (const TalByteArray & rhs);
#endif /* SWIG */

    TalByteArray(const TalByteArray & rhs);
};

/**
 * This class is derived from TalByteArray so please have a look at the
 * methods of the superclass.
 *
 * @sa TalByteArray
 */
class TalUserData : public TalByteArray
{
public:
    /**
     * Creates a Tal User Data Object with size nArrayLength.
     *
     * @param nArrayLength length of message. Size must not be larger than 1014.
     * If larger packets shall be transmitted TalUserDataLarge shall be used.
     */
    TalUserData(uint16 nArrayLength)
        : TalByteArray(nArrayLength)
    {
    }
protected:
    friend class TalInterface;
    friend class TalImpl;

    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalUserData & operator = (const TalUserData & rhs);
#endif /* SWIG */

    TalUserData(const TalUserData & rhs);
};

/**
 * This class is derived from TalByteArray so please have a look at the
 * methods of the superclass.
 *
 * @sa TalByteArray
 */
class TalUserDataLarge : public TalByteArray
{
public:
    /**
     * Creates a large Tal User Data Object with size nArrayLength.
     */
    TalUserDataLarge(uint32 nArrayLength)
        : TalByteArray(nArrayLength)
        , muxVal(0)
        , maxChunkSize(0)
        , handle()
        , isCompleted(true)
        , tmp_length(0)
        , next(0)
    {
    }

    /**
     * @brief chain together large data packets for multiplexed reception
     *
     * Chain user data packets together to allow muxed user packets over the
     * same tum id and the same tum instance. For advanced users. Use is optional.
     * Only use this function if you want to multiplex large user data packets
     * which is sent from one tum instance of one tum!
     *
     * @param pUserData user data to chain
     */
    void chainTo(TalUserDataLarge * pUserData)
    {
        /* avoid endless loops later on in receive function by checking if we
           are already in the chain */
        TalUserDataLarge *u = pUserData;
        do
        {
            if (u->next == this)
            {
                return;
            }
            u = u->next;
        } while (u != 0);

        next = pUserData;
    }

    /**
     * @brief check if large data packet reception is finished
     *
     * When large data packets are chained together this function can be used
     * to identify which user data packet in the chain is finished. Use is
     * optional. Only use this function if you want to multiplex large user
     * data packets which is sent from one tum instance of one tum!
     *
     * For unchained large data packets it suffices to check the return value
     * of receiveUserData().
     *
     * @return true if finished, false if transfer is ongoing. true after
     * object creation until first receiveUserData() is called.
     */
    bool isFinished() const
    {
        return isCompleted;
    }

    /**
     * @brief Set the multiplexer value for large data packets.
     *
     * Use is optional. Only use this function if you want to multiplex large
     * user data packets which is sent from one tum instance of one tum!
     *
     * @param nMuxVal This value is written into the first byte of each data
     * chunk transmitted to the target. It may be used either to distinguish
     * between several DataPacket connections which are open concurrently or
     * to intermix 'normal' data transmission (via 'sendUserData()') with
     * chunked data transmission. Default: 0.
     */
    void setMuxVal(uint8 nMuxVal)
    {
        muxVal = nMuxVal;
    }

    /**
     * @brief Sets the chunk size for large data packets in send direction.
     *
     * Use is optional. Default value is perfectly fine for most environments.
     * A smaller size is only advisable if very hard latency requirements
     * shall be met over interfaces which cant send 1010 bytes in one block.
     * This function only sets the chunk size in the send direction (from the
     * host to the target).
     *
     * @param nMaxChunkSize Maximum size of a single chunk (excluding chunk
     * header) in bytes. The maximum supported size is 1010 currently. If set to
     * 0 or a value larger than the maximum supported size, it is set to the
     * maximum supported size. Default: 1010.
     */
    void setMaxChunkSize(uint16 nMaxChunkSize)
    {
        maxChunkSize = nMaxChunkSize;
    }
protected:
    static const uint32 PAYLOAD_SIZE_MAX = 1014;

    uint8 muxVal;
    uint16 maxChunkSize;
    TAL_TUM_RxDataPacketHandle handle;
    bool isCompleted;
    uint8 tmp[PAYLOAD_SIZE_MAX];
    uint16 tmp_length;
    TalUserDataLarge *next;

    friend class TalInterface;
    friend class TalImpl;

    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalUserDataLarge & operator = (const TalUserDataLarge & rhs);
#endif /* SWIG */

    TalUserDataLarge(const TalUserDataLarge & rhs);
};

/**
 * This class is derived from TalByteArray so please have a look at the
 * methods of the superclass.
 *
 * @sa TalByteArray
 */
class TalSomeIpMsg: public TalByteArray
{
public:
    /**
     * Creates a Tal FlexRay Message Object with size nArrayLength.
     *
     * @param nArrayLength length of message
     */
    TalSomeIpMsg(uint16 nArrayLength)
        : TalByteArray(nArrayLength)
        , id(0)
    {
    }

    /**
     * @return Id of the FlexRay message.
     */
    uint32 getMessageId() const
    {
        return id;
    }

    void setMessageId(uint32 someip_msg_id)
    {
        id = someip_msg_id;
    }

protected:

    uint32 id;

    friend class TalInterface;
    friend class TalImpl;

    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalSomeIpMsg & operator = (const TalSomeIpMsg & rhs);
#endif /* SWIG */

    TalSomeIpMsg(const TalSomeIpMsg & rhs);
};

/**
 * This class is derived from TalByteArray so please have a look at the
 * methods of the superclass.
 *
 * @sa TalByteArray
 */
class TalFrMsg: public TalByteArray
{
public:
    /**
     * Creates a Tal FlexRay Message Object with size nArrayLength.
     *
     * @param nArrayLength length of message
     */
    TalFrMsg(uint16 nArrayLength)
        : TalByteArray(nArrayLength)
        , status(TAL_BM_FRAME_STATUS_NO_MSG)
    {
    }

    /**
     * @return Status of the FlexRay message of type TAL_BM_FrameStatusType.
     */
    TAL_BM_FrameStatusType getStatus() const
    {
        return status;
    }

protected:

    TAL_BM_FrameStatusType status;

    friend class TalInterface;
    friend class TalImpl;

    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalFrMsg & operator = (const TalFrMsg & rhs);
#endif /* SWIG */

    TalFrMsg(const TalFrMsg & rhs);
};

/**
 * This class is derived from TalByteArray so please have a look at the
 * methods of the superclass.
 *
 * @sa TalByteArray
 */
class TalCanMsg: public TalByteArray
{
public:
    /**
     * Creates a Tal CAN Message Object with size nArrayLength.
     *
     * @param nArrayLength length of message
     */
    TalCanMsg(uint16 nArrayLength)
        : TalByteArray(nArrayLength)
        , id(0)
        , transactionId(0)
        , type(TAL_BM_CANMSGTYPE_DATA)
        , timestamp(0)
        , status(TAL_BM_CAN_MSG_STAT_UNKNOWN)
        , extended(false)
        , timestamp64(0)
    {
    }

    /**
     * @param messageId the CAN message ID (11 or 29 bit).
     */
    void setMessageId(TAL_BM_CANMessageIDType messageId)
    {
        id = messageId;
    }

    /**
     * @return ID of received CAN message (11 or 29 bit).
     */
    TAL_BM_CANMessageIDType getMessageId() const
    {
        return id;
    }

    /**
     * @return Timestamp of the received CAN message. The resolution of the
     * timestamp is 1us/tick.
     */
    uint32 getTimestamp() const
    {
        return timestamp;
    }

    /**
     * @param bIsExtended Defines if the CAN message ID is a standard
     * (false) or extended (true) one.
     */
    void setExtended(bool bIsExtended)
    {
        extended = bIsExtended;
    }

    /**
     * @return false for a standard, true for an extended CAN message ID.
     */
    bool isExtended() const
    {
        return extended ? true : false;
    }

    /**
     * @param messageType Type of the CAN message. Use TAL_BM_CANMESSAGE_DATA
     * to define a CAN data message or TAL_BM_CANMESSAGE_REMOTE to define a
     * CAN remote message.
     */
    void setMessageType(TAL_BM_CANMsgTypeType messageType)
    {
        type = messageType;
    }

    /**
     * @return Type of the CAN message. Is either TAL_BM_CANMESSAGE_DATA or
     * TAL_BM_CANMESSAGE_REMOTE.
     */
    TAL_BM_CANMsgTypeType getMessageType() const
    {
        return type;
    }

    /**
     * @return Transaction ID assigned to this CAN message by the driver.  A
     * Transaction ID is always assigned to a CAN message even if
     * TAL_BM_SendCANMessage returns TAL_COMM_ERROR. Can be used in combination
     * with functions TAL_BM_GetCANEvent or TAL_BM_PeekCANEvent to realize a
     * flow-control check of sent CAN messages.
     */
    TAL_TransactionIDType getTransactionId() const
    {
        return transactionId;
    }

    /**
     * @return Status of the CAN message of type TAL_BM_CANMessageStatusType.
     */
    TAL_BM_CANMessageStatusType getStatus() const
    {
        return status;
    }
    
    /**
     * @param ntimestamp    64 bit timestamp of the CAN message.
     */
    void setTimestamp64(uint64 ntimestamp)
    {
        timestamp64 = ntimestamp;
    }

    /**
     * @return 64 bit timestamp of the CAN message..
     */
    uint64 getTimestamp64() const
    {
        return timestamp64;
    }
    
protected:
    TAL_BM_CANMessageIDType id;
    TAL_TransactionIDType transactionId;
    TAL_BM_CANMsgTypeType type;
    uint32 timestamp;
    TAL_BM_CANMessageStatusType status;
    TAL_Boolean extended;
    uint64 timestamp64;

    friend class TalInterface;
    friend class TalImpl;

    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalCanMsg & operator = (const TalCanMsg & rhs);
#endif /* SWIG */

    TalCanMsg(const TalCanMsg & rhs);
};

/**
 * This class is derived from TalByteArray so please have a look at the
 * methods of the superclass.
 *
 * @sa TalByteArray
 */
class TalEthMsg: public TalByteArray
{
public:
    /**
     * Creates a raw TAL Ethernet Message Object with size nArrayLength.
     *
     * @param nArrayLength length of raw Ethernet message
     */
    TalEthMsg(uint16 nArrayLength)
        : TalByteArray(nArrayLength)
        , nPayloadOffs(14u)
    {
    }
    
    /**
     * Creates a TAL Ethernet Message Object from header elements with payload size nArrayLength.
     *
     * @param nArrayLength length of Ethernet message payload
     * @param nDestMAC     Destination MAC address of the Ethernet packet (Id in TalMeasureData)
     * @param nSrcMAC      Source MAC address of the Ethernet packet (Slot in TalMeasureData)
     * @param nVlanID      VLAN ID of Ethernet packet or -1 if not set (Channel in TalMeasureData)
     * @param nVlanPrio    VLAN Priority of Ethernet packet or -1 if not set (SlotStatus in TalMeasureData)
     * @param nEtherType   EtherType of Ethernet packet (Header in TalMeasureData)
     */
    TalEthMsg(uint16 nArrayLength,
        sint64 nDestMAC,
        sint64 nSrcMAC,
        sint32 nVlanID,
        sint32 nVlanPrio,
        uint16 nEtherType)
        : TalByteArray(nVlanID == -1 ? nArrayLength + 14u : nArrayLength + 18u)
        , nPayloadOffs(nVlanID == -1 ? 14u : 18u)
    {
        (void) setDestMAC(nDestMAC);
        (void) setSrcMAC(nSrcMAC);
        (void) setVlanID_Prio(nVlanID, nVlanPrio);
        (void) setEtherType(nEtherType);
    }
    
    /**
     * Set Destination MAC address of the Ethernet packet.
     *
     * @param nDestMAC     Destination MAC address of the Ethernet packet (Id in TalMeasureData)
     *
     * @return TAL_SUCCESS index is in bounds
     * @return TAL_INVALID_INDEX index is out of bounds (allocated packet length too short)
     */
    TAL_ReturnType setDestMAC(sint64 nDestMAC)
    {
        uint32 i;
        TAL_ReturnType ret = TAL_SUCCESS;

        for (i = 0u; (i < 6u) && (ret == TAL_SUCCESS); i++)
        {
            ret = setArrayValue((5u - i), (uint8) (nDestMAC & 0x00000000000000ff));
            nDestMAC >>= 8;
        }

        return ret;
    }

    /**
     * Set Source MAC address of the Ethernet packet.
     *
     * @param nSrcMAC      Source MAC address of the Ethernet packet (Slot in TalMeasureData)
     *
     * @return TAL_SUCCESS index is in bounds
     * @return TAL_INVALID_INDEX index is out of bounds (allocated packet length too short)
     */
    TAL_ReturnType setSrcMAC(sint64 nSrcMAC)
    {
        uint32 i;
        TAL_ReturnType ret = TAL_SUCCESS;

        for (i = 0u; (i < 6u) && (ret == TAL_SUCCESS); i++)
        {
            ret = setArrayValue(6u + (5u - i), (uint8) (nSrcMAC & 0x00000000000000ff));
            nSrcMAC >>= 8;
        }

        return ret;
    }

    /**
     * Set VLAN fields of the Ethernet packet.
     *
     * Note: This method should be called before setting the EtherType / adding payload data.
     *
     * @param nVlanID      VLAN ID of Ethernet packet or -1 if not set (Channel in TalMeasureData)
     * @param nVlanPrio    VLAN Priority of Ethernet packet or -1 if not set (SlotStatus in TalMeasureData)
     *
     * @return TAL_SUCCESS index is in bounds
     * @return TAL_INVALID_INDEX index is out of bounds (allocated packet length too short)
     */
    TAL_ReturnType setVlanID_Prio(sint32 nVlanID, sint32 nVlanPrio)
    {
        TAL_ReturnType ret = TAL_SUCCESS;
        if (nVlanID == -1)
        {
            nPayloadOffs = 14u;
        }
        else
        {
            uint32 nVlanTag = ((uint32) nVlanID & 0x0ffful) | (((uint32) nVlanPrio & 0x000ful) << 12u);
            nPayloadOffs = 18u;
            ret = setArrayValue(12u, 0x81u);
            if (ret == TAL_SUCCESS)
            {
                ret = setArrayValue(13u, 0x00u);
            }
            if (ret == TAL_SUCCESS)
            {
                ret = setArrayValue(13u, 0x00u);
            }
            if (ret == TAL_SUCCESS)
            {
                ret = setArrayValue(14u, (uint8) ((nVlanTag >> 8u) & 0xfful));
            }
            if (ret == TAL_SUCCESS)
            {
                ret = setArrayValue(15u, (uint8) (nVlanTag & 0xfful));
            }
        }
        return ret;
    }

    /**
     * Set EtherType field of the Ethernet packet.
     *
     * @param nEtherType   EtherType of Ethernet packet (Header in TalMeasureData)
     *
     * @return TAL_SUCCESS index is in bounds
     * @return TAL_INVALID_INDEX index is out of bounds (allocated packet length too short)
     */
    TAL_ReturnType setEtherType(uint16 nEtherType)
    {
        TAL_ReturnType ret = setArrayValue(nPayloadOffs - 2u, (uint8) ((nEtherType >> 8u) & 0xffu));
        if (ret == TAL_SUCCESS)
        {
            ret = setArrayValue(nPayloadOffs - 1u, (uint8) (nEtherType & 0xffu));
        }
        return ret;
    }

    /**
     * Sets the value of the Ethernet packet payload at index. Use getPayloadLength() to get the
     * payload length of the Ethernet packet.
     *
     * @param nIndex Index of the byte which shall be set
     * @param nValue Value the byte shall be set to
     *
     * @return TAL_SUCCESS index is in bounds
     * @return TAL_INVALID_INDEX index is out of bounds
     */
    TAL_ReturnType setPayloadValue(uint32 nIndex, uint8 nValue)
    {
        if (nIndex >= (arrayLength - nPayloadOffs))
        {
            return TAL_INVALID_INDEX;
        }

        array[nIndex + nPayloadOffs] = nValue;
        return TAL_SUCCESS;
    }

    /**
     * Gets the value of the the Ethernet packet payload at index. Use getPayloadLength() to get the
     * payload length of the Ethernet packet.
     *
     * @param nIndex Index of the byte which shall be get
     *
     * @return array value at index
     */
    uint8 getPayloadValue(uint32 nIndex) const
    {
        if (nIndex < (arrayLength - nPayloadOffs))
        {
            return array[nIndex + nPayloadOffs];
        }
        else
        {
            return 0;
        }
    }

    /**
     * @brief Gets the payload length of the Ethernet packet
     *
     * The array length is fixed during calling the constructor of
     * TalByteArray. This method can be used to get the array length at a
     * later time.
     *
     * @return array length
     */
    uint32 getPayloadLength() const
    {
        return arrayLength - nPayloadOffs;
    }

#ifndef SWIG
    /**
     * Copy a given buffer payload of the Ethernet packet
     *
     * @param pBuffer array
     * @param nBufferSize length of array in pBuffer
     *
     * @return TAL_SUCCESS index is in bounds
     * @return TAL_BUFFER_TOO_SMALL given buffer is to large to fit into array
     */
    TAL_ReturnType setPayload(const uint8* pBuffer, uint32 nBufferSize)
    {
        if (nBufferSize > (arrayLength - nPayloadOffs))
        {
            return TAL_BUFFER_TOO_SMALL;
        }

        memcpy((array + nPayloadOffs), pBuffer, nBufferSize);
        return TAL_SUCCESS;
    }
#endif /* SWIG */

protected:

    friend class TalInterface;
    friend class TalImpl;

    uint16 nPayloadOffs;

    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalEthMsg & operator = (const TalEthMsg & rhs);
#endif /* SWIG */

    TalEthMsg(const TalEthMsg & rhs);
};

/**
 * This class is derived from TalByteArray so please have a look at the
 * methods of the superclass.
 *
 * @sa TalByteArray
 */
class TalPdu: public TalByteArray
{
public:
    /**
     * Creates a Tal Pdu Object with size nArrayLength.
     *
     * @param nArrayLength length of message
     */
    TalPdu(uint16 nArrayLength)
        : TalByteArray(nArrayLength)
        , codedStatus(TAL_BM_PDU_STATUS_NO_MSG)
    {
    }

    /**
     * @brief Get the Pdu status
     *
     * Gets all status flags for this Pdu. Use the following macros if the PduTimingChecker
     * is used
     * @sa TAL_BM_GET_PDU_STATUS_REPETITION_TRUE_INVALID
     * @sa TAL_BM_GET_PDU_STATUS_TIMEPERIOD_TRUE_INVALID 
     * @sa TAL_BM_GET_PDU_STATUS_REPETITION_FALSE_INVALID 
     * @sa TAL_BM_GET_PDU_STATUS_TIMEPERIOD_FALSE_INVALID 
     * @sa TAL_BM_GET_PDU_STATUS_MINIMUMDELAY_INVALID 
     * @sa TAL_BM_GET_PDU_STATUS_STARTTIME_INVALID 
     *
     * @return codedStatus all status flags for this Pdu
     */
    TAL_BM_PDUStatusType getCodedStatus() const
    {
        return codedStatus;
    }

    /**
     * @brief Check if the PDU violated the Repetition True Timing 
     *
     * The PDU has a repetition counter greater than zero. The repetition was received
     * too early/late. This error flag is valid for the TRUE timing only!
     * This flag is only set if the PduTimingChecker is used and enabled!
     *
     * @return true  The repetition time was violated
     * @return false No repetition timing error occured
     */
    bool isRepetitionTimeTrueInvalid() const
    {
        return TAL_BM_GET_PDU_STATUS_REPETITION_TRUE_INVALID(codedStatus) ? true : false;
    }
    
    /**
     * @brief Check if the PDU violated the Time Period True Timing 
     *
     * The PDU is periodic or mixed. The interval was violated, 
     * the PDU was received too late/early. This error flag is valid for the TRUE timing only!
     * This flag is only set if the PduTimingChecker is used and enabled!
     * 
     * @return true  The time period was violated
     * @return false No time period timing error occured
     */
    bool isTimePeriodTrueInvalid() const
    {
        return TAL_BM_GET_PDU_STATUS_TIMEPERIOD_TRUE_INVALID(codedStatus) ? true : false;
    }

    /**
     * @brief Check if the PDU violated the Repetition False Timing 
     *
     * The PDU has a repetition counter greater than zero. The repetition was received
     * too early/late. This error flag is valid for the FALSE timing only!
     * This flag is only set if the PduTimingChecker is used and enabled!
     *
     * @return true  The repetition time was violated
     * @return false No repetition timing error occured
     */
    bool isRepetitionTimeFalseInvalid() const
    {
        return TAL_BM_GET_PDU_STATUS_REPETITION_FALSE_INVALID(codedStatus) ? true : false;
    }

    /**
     * @brief Check if the PDU violated the Time Period False Timing 
     *
     * The PDU is periodic or mixed. The interval was violated, 
     * the PDU was received too late/early. This error flag is valid for the FALSE timing only!
     * This flag is only set if the PduTimingChecker is used and enabled!
     *
     * @return true  The time period was violated
     * @return false No time period timing error occured
     */
    bool isTimePeriodFalseInvalid() const
    {
        return TAL_BM_GET_PDU_STATUS_TIMEPERIOD_FALSE_INVALID(codedStatus) ? true : false;
    }

    /**
     * @brief Check if the PDU violated its minimum delay. 
     *
     * A subsequent PDU was received too early and violated the configured minimum delay.
     * This flag is only set if the PduTimingChecker is used and enabled!
     *
     * @return true  The minimum delay was violated
     * @return false No minimum delay timing error occured
     */
    bool isMinimumDelayInvalid() const
    {
        return TAL_BM_GET_PDU_STATUS_MINIMUMDELAY_INVALID(codedStatus) ? true : false;
    }

    /**
     * @brief Check if the PDU its starting time window. 
     *
     * The PDU was not received within its starting time window.
     * This flag is only set if the PduTimingChecker is used and enabled!
     *
     * @return true  The minimum delay was violated
     * @return false No minimum delay timing error occured
     */
    bool isStartingTimeInvalid() const
    {
        return TAL_BM_GET_PDU_STATUS_STARTTIME_INVALID(codedStatus) ? true : false;
    }

protected:
    friend class TalInterface;
    friend class TalImpl;

    uint8 codedStatus;
    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalPdu & operator = (const TalPdu & rhs);
#endif /* SWIG */

    TalPdu(const TalPdu & rhs);
};

/**
 * This class is derived from TalByteArray so please have a look at the
 * methods of the superclass.
 *
 * @sa TalByteArray
 */
class TalLinMsg: public TalByteArray
{
public:

    /**
     * Creates a Tal Lin Message Object.
     */
    TalLinMsg(uint16 nArrayLength)
        : TalByteArray(nArrayLength),
          nId(0),
          checksumType(TAL_LIN_CLASSIC_CS),
          responseType(TAL_LIN_MASTER_RESPONSE),
          nTimeMs(0),
          nCtrlIdx(0),
          statusType(TAL_LIN_NOT_OK)
    {
    }
    
    void setMessageId(uint8 id)
    {
        nId = id;
    }
    
    void setChecksumType(TAL_Lin_FrameCsModelType ct)
    {
        checksumType = ct;
    }
    
    void setResponseType(TAL_Lin_FrameResponseType rt)
    {
        responseType = rt;
    }
    
    void setScheduleTime(uint32 timeMs)
    {
        nTimeMs = timeMs;
    }
    
    void setCtrlIdx(uint8 ctrl)
    {
        nCtrlIdx = ctrl;
    }
    
    void setStatus(TAL_Lin_StatusType status)
    {
        statusType = status;
    }

    uint8 getMessageId() const
    {
        return nId;
    }
    
    uint8 getCtrlIdx() const
    {
        return nCtrlIdx;
    }

    TAL_Lin_FrameCsModelType getChecksumType() const
    {
        return checksumType;
    }

    TAL_Lin_FrameResponseType getResponseType() const
    {
        return responseType;
    }

    TAL_Lin_StatusType getStatus() const
    {
        return statusType;
    }

    uint32 getScheduleTime() const
    {
        return nTimeMs;
    }

protected:
    uint8 nId;
    TAL_Lin_FrameCsModelType checksumType;
    TAL_Lin_FrameResponseType responseType;
    uint32 nTimeMs;
    uint8 nCtrlIdx;
    TAL_Lin_StatusType statusType;

    friend class TalInterface;
    friend class TalImpl;

    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalLinMsg & operator = (const TalLinMsg & rhs);
#endif /* SWIG */

    TalLinMsg(const TalLinMsg & rhs);
};

class TalError
{
public:
    TalError()
        : errorNumber(0)
        , errorDataLengthReceived(0)
    {
        errorString[0] = 0;
        for (int i = 0; i < ERROR_DATA_LENGTH; i++)
        {
            errorData[i] = 0;
        }
    }

    /**
     * @return number decribing the error
     */
    TAL_ErrnoType getErrorNumber() const
    {
        return errorNumber;
    }

    /**
     * @return number of additional error arguments received.  If the
     * corresponding error does not have additional arguments then 0 is
     * returned.
     */
    uint8 getErrorDataLengthReceived() const
    {
        return errorDataLengthReceived;
    }

    /**
     * Gets the additional error argument array at index. Use
     * getErrorDataLengthReceived() to get the number of error arguments
     * received.
     *
     * @param i Index of error argument which shall be get
     *
     * @return Value of the error argument
     */
    uint32 getErrorData(uint8 i) const
    {
        if (i < ERROR_DATA_LENGTH)
        {
            return errorData[i];
        }
        else
        {
            return 0;
        }
    }

    /**
     * @return Stringification of error number and error arguments in human
     * readable form.
     * The message starts with (II) for informational messages, (WW) for
     * warning messages and (EE) for error messages. If the message is not
     * prefixed its also an error message.
     */
    const char * getErrorString()
    {
        if (TAL_ConvertErrorDataToString(errorNumber,
                                         errorData,
                                         errorDataLengthReceived,
                                         errorString,
                                         ERROR_STRING_LENGTH) == TAL_SUCCESS)
        {
            return errorString;
        }
        else
        {
            return "";
        }
    }
protected:
    static const uint8 ERROR_DATA_LENGTH = 254;
    static const uint16 ERROR_STRING_LENGTH = 1024;
    uint32 errorData[ERROR_DATA_LENGTH];
    char errorString[ERROR_STRING_LENGTH];

    TAL_ErrnoType errorNumber;
    uint8 errorDataLengthReceived;

    friend class TalInterface;
    friend class TalImpl;

    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalError & operator = (const TalError & rhs);
#endif /* SWIG */

    TalError(const TalError & rhs);
};

class TalFrPocStatus
{
public:
    TalFrPocStatus()
        : pocState(TAL_POCSTATE_CONFIG)
        , freeze(false)
        , chiHaltRequest(false)
        , coldstartNoise(false)
        , slotMode(TAL_SLOTMODE_SINGLE)
        , errorMode(TAL_ERRORMODE_ACTIVE)
        , wakeupStatus(TAL_WAKEUP_UNDEFINED)
        , startupState(TAL_STARTUP_UNDEFINED)
    {
    }

    /**
     * @return FlexRay controller POC-state.
     */
    TAL_POCStateType getPocState() const
    {
        return pocState;
    }

    /**
     * @return FlexRay controller freeze bit
     */
    bool getFreeze() const
    {
        return freeze;
    }

    /**
     * @return FlexRay controller CHI halt request bit
     */
    bool getChiHaltRequest() const
    {
        return chiHaltRequest;
    }

    /**
     * @return FlexRay controller coldstart noise bit
     */
    bool getColdstartNoise() const
    {
        return coldstartNoise;
    }

    /**
     * @return FlexRay controller slot mode
     */
    TAL_SlotModeType getSlotMode() const
    {
        return slotMode;
    }

    /**
     * @return FlexRay controller error mode
     */
    TAL_ErrorModeType getErrorMode() const
    {
        return errorMode;
    }

    /**
     * @return FlexRay controller wakeup status
     */
    TAL_WakeupStatusType getWakeupStatus() const
    {
        return wakeupStatus;
    }

    /**
     * @return FlexRay controller startup state
     */
    TAL_StartupStateType getStartupState() const
    {
        return startupState;
    }
protected:
    TAL_POCStateType pocState;
    bool freeze;
    bool chiHaltRequest;
    bool coldstartNoise;
    TAL_SlotModeType slotMode;
    TAL_ErrorModeType errorMode;
    TAL_WakeupStatusType wakeupStatus;
    TAL_StartupStateType startupState;

    friend class TalInterface;
    friend class TalImpl;
};

/**
 * This class is derived from TalByteArray so please have a look at the
 * methods of the superclass.
 *
 * @sa TalByteArray
 */
class TalSignal : public TalByteArray
{
public:
    /**
     * Creates a Tal Signal Data Object
     */
    TalSignal()
        : TalByteArray(0)
        , codedStatus(TAL_BM_SIGNAL_STATUS_NO_MSG)
        , codedValue()
        , physicalValue(0)
        , physicalStatus(TAL_NO_CONV_FUNC)
        , type(TAL_SIGNAL_CODED)
    {
        codedValue = 0;
        symbol[0] = 0;

        /* sorry for this, but casts are necessary because TAL C-Interface
           used uint8 instead of char */
        TAL_CompileTimeAssert(sizeof(char) == sizeof(uint8));
    }

    /**
     * Creates a Tal Signal Array Data Object. Signal Arrays where introduced
     * in AUTOSAR and provides possibility to access byte arrays via the
     * signal API.
     *
     * @param nArrayLength length of the signal array in bytes
     */
    TalSignal(uint16 nArrayLength)
        : TalByteArray(nArrayLength)
        , codedStatus(TAL_BM_SIGNAL_STATUS_NO_MSG)
        , codedValue()
        , physicalValue(0)
        , physicalStatus(TAL_NO_CONV_FUNC)
        , type(TAL_SIGNAL_ARRAY)
    {
        codedValue = 0;
        symbol[0] = 0;
    }

    /**
     * @param val physical value of the signal (e.g. 3.3333). Always make sure to
     * check the return value of the next bmSendSignal call to check if a
     * conversion was even possibe.
     */
    void setPhysicalValue(TAL_BM_PhysicalSignalValueType val)
    {
        physicalValue = val;
        type = TAL_SIGNAL_PHYSICAL;
    }

/* disable warning about strcpy in windows */
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable:4996)
#endif /* _MSC_VER */
    /**
     * @param name symbol name of the physical signal. If a value corresponds to
     * an enum this enum can be set with a string. Always make sure to check
     * the return value of the next bmSendSignal call to check if a conversion
     * was even possibe.
     */
    void setSymbolName(const char *name)
    {
        if (strlen(name) < SYMBOL_LENGTH)
        {
            strcpy(symbol, name);
            type = TAL_SIGNAL_SYMBOL;
        }
    }
#ifdef _MSC_VER
#pragma warning(pop)
#endif /* _MSC_VER */

    /**
     * @param val unsigned (>0) coded value of the signal
     */
    void setCodedValueUnsigned(uint32 val)
    {
        codedValue = val;
        type = TAL_SIGNAL_CODED;
    }

    /**
     * @param val signed (<0) coded value of the signal
     */
    void setCodedValueSigned(sint32 val)
    {
        codedValue = val;
        type = TAL_SIGNAL_CODED;
    }

    /**
     * @return unsigned (>0) coded value of the signal
     */
    uint32 getCodedValueUnsigned() const
    {
        return static_cast<uint32>(codedValue);
    }

    /**
     * @return signed (<0) coded value of the signal
     */
    sint32 getCodedValueSigned() const
    {
        return static_cast<sint32>(codedValue);
    }
    /**
     * @param val unsigned (>0) coded value of the signal
     * @note used only with conversion funtions TAL_BM_PhysicalToCoded64 and TAL_BM_CodedToPhysical64,
     * not to be used with send/receive functions
     */
    void setCodedValueUnsigned64(uint64 val)
    {
        codedValue = val;
    }

    /**
     * @param val signed (<0) coded value of the signal
     */
    void setCodedValueSigned64(sint64 val)
    {
        codedValue = val;
    }

    /**
     * @return unsigned (>0) coded value of the signal
     */
    uint64 getCodedValueUnsigned64() const
    {
        return codedValue;
    }

    /**
     * @return signed (<0) coded value of the signal
     */
    sint64 getCodedValueSigned64() const
    {
        return static_cast<sint64>(codedValue);
    }
    /**
     * @return physical status of the signal. This value must be checked by
     * the user to know if underlying conversion functions even exist in the
     * configuration.
     */
    TAL_BM_PhysicalSignalStatusType getPhysicalStatus() const
    {
        return physicalStatus;
    }

    /**
     * @return symbol name of the physical signal. If a value corresponds to
     * an enum this enum is returned in human readable form. Always make sure
     * to call getPhysicalStatus() before to check if a enum is even available
     * for the actual received value.
     */
    const char * getSymbolName() const
    {
        return symbol;
    }

    /**
     * @return physical value of the signal (e.g. 3.3333). Always make sure to
     * call getPhysicalStatus() before to check if a conversion is even
     * available for the actual received value.
     */
    TAL_BM_PhysicalSignalValueType getPhysicalValue() const
    {
        return physicalValue;
    }

    /**
     * @brief Check if element was updated since the last read
     *
     * Check is a signal/frame/pdu was updated since the last retrieval with
     * the according function. Can be used to e.g. only carry on with
     * calculation if a new value was received from the target.
     *
     * @return true The element was updated since last read
     * @return false The element was not updated since last read
     */
    bool isUpdated() const
    {
        return TAL_BM_GET_SIGNAL_STATUS_UPDATED(codedStatus) ? true : false;
    }

    /**
     * @brief Check if a signal is invalid
     *
     * This call is only supported for FlexRay RBS. If a invalid value is
     * received this function returns true and the signal value corresponds to
     * the last valid signal value which was received.
     *
     * @return true The invalid value was received. However as signal value
     * the last valid signal value is returned.
     *
     * @return false The invalid value was not received.
     */
    bool isInvalid() const
    {
        return TAL_BM_GET_SIGNAL_STATUS_INVALID(codedStatus) ? true : false;
    }

    /**
     * @brief Check if the protecting crc signal was invalid
              Only valid if E2EChecker is active
     *
     * @return true The CRC check failed.
     *
     * @return false The CRC check was successful.
     */
    bool isCrcInvalid() const
    {
        return TAL_BM_GET_SIGNAL_STATUS_CRC_INVALID(codedStatus) ? true : false;
    }

    /**
     * @brief Check if the protecting counter signal was invalid
              Only valid if E2EChecker is active
     *
     * @return true The counter check failed.
     *
     * @return false The counter check was successful.
     */
    bool isCounterInvalid() const
    {
        return TAL_BM_GET_SIGNAL_STATUS_COUNTER_INVALID(codedStatus) ? true : false;
    }

    /**
     * @brief Check if the protecting signal is checked by the E2EChecker.
     *
     * @return true The checks are active.
     *
     * @return false The checks are disabled.
     */
    bool isE2eCheckActive() const
    {
        return TAL_BM_GET_SIGNAL_STATUS_CHECK_ACTIVE(codedStatus) ? true : false;
    }

protected:
    static const uint32 SYMBOL_LENGTH = 255;

    char symbol[SYMBOL_LENGTH];
    TAL_BM_SignalStatusType codedStatus;
    uint64 codedValue;
    TAL_BM_PhysicalSignalValueType physicalValue;
    TAL_BM_PhysicalSignalStatusType physicalStatus;
    TAL_SignalType type;

    friend class TalInterface;
    friend class TalImpl;

    /*
     * Prevent assignment operator and copy constructor
     */
#ifndef SWIG
    TalSignal & operator = (const TalSignal & rhs);
#endif /* SWIG */

    TalSignal(const TalSignal & rhs);
};

#endif /* TAL_CXX_TYPES_GUARD */
#endif /* TAL_CXX_API */
