/*
 * File    : TAL_Endian.h
 *
 * Description:
 * Define functions to access data structures of defined endianess
 *
 * Copyright 2002-2021 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Note: For TAL, don't use this file directly; instead include TAL_Helper.h
 * (because of there defined macros defining platform endianess)
 */

#ifndef _TAL_ENDIAN_H_
#define _TAL_ENDIAN_H_

/******************************************************************************
 Include Section
******************************************************************************/

#include <stdint.h>
#include <stdio.h>

/******************************************************************************
 Global Macros
******************************************************************************/

#define TAL_GCC_VERSION (__GNUC__ * 10000 \
                         + __GNUC_MINOR__ * 100 \
                         + __GNUC_PATCHLEVEL__)

#if (TAL_GCC_VERSION > 40300) || defined (__clang__)
#define PLATFORM_SWAPU64 __builtin_bswap64
#define PLATFORM_SWAPU32 __builtin_bswap32
#define PLATFORM_SWAPU16 __builtin_bswap16
#elif defined(_MSC_VER)
#include <stdlib.h>
#define PLATFORM_SWAPU64 _byteswap_uint64
#define PLATFORM_SWAPU32 _byteswap_ulong
#define PLATFORM_SWAPU16 _byteswap_ushort
#else
#define PLATFORM_SWAPU64 TAL_CONSTANT_SWAPU64
#define PLATFORM_SWAPU32 TAL_CONSTANT_SWAPU32
#define PLATFORM_SWAPU16 TAL_CONSTANT_SWAPU16
#endif

#define TAL_CONSTANT_SWAPU64(x) \
    ((uint64_t)((((uint64_t)(x) & 0x00000000000000ffULL) << 56) | \
               (((uint64_t)(x) & 0x000000000000ff00ULL) << 40) | \
               (((uint64_t)(x) & 0x0000000000ff0000ULL) << 24) | \
               (((uint64_t)(x) & 0x00000000ff000000ULL) <<  8) | \
               (((uint64_t)(x) & 0x000000ff00000000ULL) >>  8) | \
               (((uint64_t)(x) & 0x0000ff0000000000ULL) >> 24) | \
               (((uint64_t)(x) & 0x00ff000000000000ULL) >> 40) | \
               (((uint64_t)(x) & 0xff00000000000000ULL) >> 56)))

#define TAL_CONSTANT_SWAPU32(x) \
    ((uint32_t)((((uint32_t)(x) & 0x000000ffU) << 24) | \
               (((uint32_t)(x) & 0x0000ff00U) <<  8) | \
               (((uint32_t)(x) & 0x00ff0000U) >>  8) | \
               (((uint32_t)(x) & 0xff000000U) >> 24)))

#define TAL_CONSTANT_SWAPU16(x) \
    ((uint16_t)((((uint16_t)(x) & 0x00ffU) << 8) | \
               (((uint16_t)(x) & 0xff00U) >> 8)))

/* try hard to detect endianess */
#if (defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__) || \
    (defined(CPU_BYTE_ORDER) && CPU_BYTE_ORDER == HIGH_BYTE_FIRST) || \
    (defined(__BIG_ENDIAN__))

static inline uint64_t CpuToBigEndianU64(uint64_t x)
{
    return x;
}

static inline uint32_t CpuToBigEndianU32(uint32_t x)
{
    return x;
}

static inline uint16_t CpuToBigEndianU16(uint16_t x)
{
    return x;
}

static inline uint64_t BigEndianU64ToCpu(uint64_t x)
{
    return x;
}

static inline uint32_t BigEndianU32ToCpu(uint32_t x)
{
    return x;
}

static inline uint16_t BigEndianU16ToCpu(uint16_t x)
{
    return x;
}

static inline uint64_t CpuToLittleEndianU64(uint64_t x)
{
    return PLATFORM_SWAPU64(x);
}

static inline uint32_t CpuToLittleEndianU32(uint32_t x)
{
    return PLATFORM_SWAPU32(x);
}

static inline uint16_t CpuToLittleEndianU16(uint16_t x)
{
    return PLATFORM_SWAPU16(x);
}

static inline uint64_t LittleEndianU64ToCpu(uint64_t x)
{
    return PLATFORM_SWAPU64(x);
}

static inline uint32_t LittleEndianU32ToCpu(uint32_t x)
{
    return PLATFORM_SWAPU32(x);
}

static inline uint16_t LittleEndianU16ToCpu(uint16_t x)
{
    return PLATFORM_SWAPU16(x);
}

#elif (defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__) || \
    (defined(CPU_BYTE_ORDER) && CPU_BYTE_ORDER == LOW_BYTE_FIRST) || \
    (defined(__LITTLE_ENDIAN__))

static inline uint64_t CpuToBigEndianU64(uint64_t x)
{
    return PLATFORM_SWAPU64(x);
}

static inline uint32_t CpuToBigEndianU32(uint32_t x)
{
    return PLATFORM_SWAPU32(x);
}

static inline uint16_t CpuToBigEndianU16(uint16_t x)
{
    return PLATFORM_SWAPU16(x);
}

static inline uint64_t BigEndianU64ToCpu(uint64_t x)
{
    return PLATFORM_SWAPU64(x);
}

static inline uint32_t BigEndianU32ToCpu(uint32_t x)
{
    return PLATFORM_SWAPU32(x);
}

static inline uint16_t BigEndianU16ToCpu(uint16_t x)
{
    return PLATFORM_SWAPU16(x);
}

static inline uint64_t CpuToLittleEndianU64(uint64_t x)
{
    return x;
}

static inline uint32_t CpuToLittleEndianU32(uint32_t x)
{
    return x;
}

static inline uint16_t CpuToLittleEndianU16(uint16_t x)
{
    return x;
}

static inline uint64_t LittleEndianU64ToCpu(uint64_t x)
{
    return x;
}

static inline uint32_t LittleEndianU32ToCpu(uint32_t x)
{
    return x;
}

static inline uint16_t LittleEndianU16ToCpu(uint16_t x)
{
    return x;
}

#else

/* cannot detect endianess at preprocessing time, try to detect it at compile time */

static const union { unsigned char bytes[4]; uint32_t value; } tal_endian_check = { { 0, 1, 2, 3} };
#define TAL_IS_BIG_ENDIAN (tal_endian_check.value == 0x00010203UL)

static inline uint64_t CpuToBigEndianU64(uint64_t x)
{
    return TAL_IS_BIG_ENDIAN ? x : PLATFORM_SWAPU64(x);
}

static inline uint32_t CpuToBigEndianU32(uint32_t x)
{
    return TAL_IS_BIG_ENDIAN ? x : PLATFORM_SWAPU32(x);
}

static inline uint16_t CpuToBigEndianU16(uint16_t x)
{
    return TAL_IS_BIG_ENDIAN ? x : PLATFORM_SWAPU16(x);
}

static inline uint64_t BigEndianU64ToCpu(uint64_t x)
{
    return TAL_IS_BIG_ENDIAN ? x : PLATFORM_SWAPU64(x);
}

static inline uint32_t BigEndianU32ToCpu(uint32_t x)
{
    return TAL_IS_BIG_ENDIAN ? x : PLATFORM_SWAPU32(x);
}

static inline uint16_t BigEndianU16ToCpu(uint16_t x)
{
    return TAL_IS_BIG_ENDIAN ? x : PLATFORM_SWAPU16(x);
}

static inline uint64_t CpuToLittleEndianU64(uint64_t x)
{
    return TAL_IS_BIG_ENDIAN ? PLATFORM_SWAPU64(x) : x;
}

static inline uint32_t CpuToLittleEndianU32(uint32_t x)
{
    return TAL_IS_BIG_ENDIAN ? PLATFORM_SWAPU32(x) : x;
}

static inline uint16_t CpuToLittleEndianU16(uint16_t x)
{
    return TAL_IS_BIG_ENDIAN ? PLATFORM_SWAPU16(x) : x;
}

static inline uint64_t LittleEndianU64ToCpu(uint64_t x)
{
    return TAL_IS_BIG_ENDIAN ? PLATFORM_SWAPU64(x) : x;
}

static inline uint32_t LittleEndianU32ToCpu(uint32_t x)
{
    return TAL_IS_BIG_ENDIAN ? PLATFORM_SWAPU32(x) : x;
}

static inline uint16_t LittleEndianU16ToCpu(uint16_t x)
{
    return TAL_IS_BIG_ENDIAN ? PLATFORM_SWAPU16(x) : x;
}

#endif

static inline uint64_t SwapU64(uint64_t data)
{
    return PLATFORM_SWAPU64(data);
}

static inline uint32_t SwapU32(uint32_t data)
{
    return PLATFORM_SWAPU32(data);
}

static inline uint16_t SwapU16(uint16_t data)
{
    return PLATFORM_SWAPU16(data);
}

/* so that nobody uses these macros - please use the inline functions instead */
#undef PLATFORM_SWAPU64
#undef PLATFORM_SWAPU32
#undef PLATFORM_SWAPU16

/*---------------------------------------------------------------------------*/

static inline void WriteBigEndianU64( uint64_t nVal, void *p64 )
{
    uint8_t *p8 = (uint8_t*)p64;

    p8[0] = (uint8_t) ((nVal >> 56U) & 0xffU);
    p8[1] = (uint8_t) ((nVal >> 48U) & 0xffU);
    p8[2] = (uint8_t) ((nVal >> 40U) & 0xffU);
    p8[3] = (uint8_t) ((nVal >> 32U) & 0xffU);
    p8[4] = (uint8_t) ((nVal >> 24U) & 0xffU);
    p8[5] = (uint8_t) ((nVal >> 16U) & 0xffU);
    p8[6] = (uint8_t) ((nVal >>  8U) & 0xffU);
    p8[7] = (uint8_t) ((nVal >>  0U) & 0xffU);
}

/*---------------------------------------------------------------------------*/

static inline void WriteBigEndianU48( uint64_t nVal, void *p48 )
{
    uint8_t *p8 = (uint8_t*)p48;

    p8[0] = (uint8_t) ((nVal >> 40U) & 0xffU);
    p8[1] = (uint8_t) ((nVal >> 32U) & 0xffU);
    p8[2] = (uint8_t) ((nVal >> 24U) & 0xffU);
    p8[3] = (uint8_t) ((nVal >> 16U) & 0xffU);
    p8[4] = (uint8_t) ((nVal >>  8U) & 0xffU);
    p8[5] = (uint8_t) ((nVal >>  0U) & 0xffU);
}

/*---------------------------------------------------------------------------*/

static inline void WriteBigEndianU32( uint32_t nVal, void *p32 )
{
    uint8_t *p8 = (uint8_t*)p32;

    p8[0] = (uint8_t) ((nVal >> 24U) & 0xffU);
    p8[1] = (uint8_t) ((nVal >> 16U) & 0xffU);
    p8[2] = (uint8_t) ((nVal >>  8U) & 0xffU);
    p8[3] = (uint8_t) ((nVal >>  0U) & 0xffU);
}

/*---------------------------------------------------------------------------*/

static inline void WriteBigEndianU24( uint32_t nVal, void *p24 )
{
    uint8_t *p8 = (uint8_t*)p24;

    p8[0] = (uint8_t) ((nVal >> 16U) & 0xffU);
    p8[1] = (uint8_t) ((nVal >>  8U) & 0xffU);
    p8[2] = (uint8_t) ((nVal >>  0U) & 0xffU);
}

/*---------------------------------------------------------------------------*/

static inline void WriteBigEndianU16( uint16_t nVal, void *p16 )
{
    uint8_t *p8 = (uint8_t*)p16;

    p8[0] = (uint8_t) ((nVal >> 8U) & 0xffU);
    p8[1] = (uint8_t) ((nVal >> 0U) & 0xffU);
}

/*---------------------------------------------------------------------------*/

/* Use with care - usually its simpler to not use this function */
static inline void WriteU8( uint8_t nVal, void *p8 )
{
    uint8_t *p = (uint8_t*)p8;

    p[0] = (uint8_t) ((nVal >> 0U) & 0xffU);
}

/*---------------------------------------------------------------------------*/

static inline void WriteBigEndianU32ToFile( uint32_t nVal, FILE *h )
{
    fputc((nVal >> 24U) & 0xffU, h);
    fputc((nVal >> 16U) & 0xffU, h);
    fputc((nVal >>  8U) & 0xffU, h);
    fputc((nVal >>  0U) & 0xffU, h);
}

/*---------------------------------------------------------------------------*/

static inline void WriteLittleEndianU64( uint64_t nVal, void *p64 )
{
    uint8_t *p8 = (uint8_t*)p64;

    p8[0] = (uint8_t) ((nVal >>  0U) & 0xffU);
    p8[1] = (uint8_t) ((nVal >>  8U) & 0xffU);
    p8[2] = (uint8_t) ((nVal >> 16U) & 0xffU);
    p8[3] = (uint8_t) ((nVal >> 24U) & 0xffU);
    p8[4] = (uint8_t) ((nVal >> 32U) & 0xffU);
    p8[5] = (uint8_t) ((nVal >> 40U) & 0xffU);
    p8[6] = (uint8_t) ((nVal >> 48U) & 0xffU);
    p8[7] = (uint8_t) ((nVal >> 56U) & 0xffU);
}

/*---------------------------------------------------------------------------*/

static inline void WriteLittleEndianU48( uint64_t nVal, void *p48 )
{
    uint8_t *p8 = (uint8_t*)p48;

    p8[0] = (uint8_t) ((nVal >>  0U) & 0xffU);
    p8[1] = (uint8_t) ((nVal >>  8U) & 0xffU);
    p8[2] = (uint8_t) ((nVal >> 16U) & 0xffU);
    p8[3] = (uint8_t) ((nVal >> 24U) & 0xffU);
    p8[4] = (uint8_t) ((nVal >> 32U) & 0xffU);
    p8[5] = (uint8_t) ((nVal >> 40U) & 0xffU);
}

/*---------------------------------------------------------------------------*/

static inline void WriteLittleEndianU32( uint32_t nVal, void *p32 )
{
    uint8_t *p8 = (uint8_t*)p32;

    p8[0] = (uint8_t) ((nVal >>  0U) & 0xffU);
    p8[1] = (uint8_t) ((nVal >>  8U) & 0xffU);
    p8[2] = (uint8_t) ((nVal >> 16U) & 0xffU);
    p8[3] = (uint8_t) ((nVal >> 24U) & 0xffU);

}

/*---------------------------------------------------------------------------*/

static inline void WriteLittleEndianU24( uint32_t nVal, void *p24 )
{
    uint8_t *p8 = (uint8_t*)p24;

    p8[0] = (uint8_t) ((nVal >>  0U) & 0xffU);
    p8[1] = (uint8_t) ((nVal >>  8U) & 0xffU);
    p8[2] = (uint8_t) ((nVal >> 16U) & 0xffU);

}

/*---------------------------------------------------------------------------*/

static inline void WriteLittleEndianU16( uint16_t nVal, void *p16 )
{
    uint8_t *p8 = (uint8_t*)p16;

    p8[0] = (uint8_t) ((nVal >>  0U) & 0xffU);
    p8[1] = (uint8_t) ((nVal >>  8U) & 0xffU);
}

/*---------------------------------------------------------------------------*/

static inline uint64_t ReadBigEndianU64( const void *p64 )
{
    const uint8_t *p8 = (const uint8_t*)p64;

    return (((uint64_t) p8[0]) << 56) | (((uint64_t) p8[1]) << 48) |
           (((uint64_t) p8[2]) << 40) | (((uint64_t) p8[3]) << 32) |
           (((uint64_t) p8[4]) << 24) | (((uint64_t) p8[5]) << 16) |
           (((uint64_t) p8[6]) << 8)  | ((uint64_t) p8[7]);
}

/*---------------------------------------------------------------------------*/

static inline uint64_t ReadBigEndianU48( const void *p48 )
{
    const uint8_t *p8 = (const uint8_t*)p48;

    return (((uint64_t) p8[0]) << 40) | (((uint64_t) p8[1]) << 32) |
           (((uint64_t) p8[2]) << 24) | (((uint64_t) p8[3]) << 16) |
           (((uint64_t) p8[4]) << 8)  | ((uint64_t) p8[5]);
}

/*---------------------------------------------------------------------------*/

static inline uint32_t ReadBigEndianU32( const void *p32 )
{
    const uint8_t *p8 = (const uint8_t*)p32;

    return (p8[0] << 24) | (p8[1] << 16) | (p8[2] << 8) | p8[3];
}

/*---------------------------------------------------------------------------*/

static inline uint32_t ReadBigEndianU24( const void *p24 )
{
    const uint8_t *p8 = (const uint8_t*)p24;

    return (p8[0] << 16) | (p8[1] << 8) | p8[2];
}

/*---------------------------------------------------------------------------*/

static inline uint16_t ReadBigEndianU16( const void *p16 )
{
    const uint8_t *p8 = (const uint8_t*)p16;

    return (p8[0] << 8) | p8[1];
}

/*---------------------------------------------------------------------------*/

/* Use with care - usually its simpler to not use this function */
static inline uint8_t ReadU8( const void *p8 )
{
    const uint8_t *_p8 = (const uint8_t*)p8;

    return _p8[0];
}

/*---------------------------------------------------------------------------*/

static inline uint32_t ReadBigEndianU32FromFile( FILE* h )
{
    uint8_t c0 = (uint8_t)fgetc(h);
    uint8_t c1 = (uint8_t)fgetc(h);
    uint8_t c2 = (uint8_t)fgetc(h);
    uint8_t c3 = (uint8_t)fgetc(h);

    return (c0 << 24) | (c1 << 16) | (c2 << 8) | c3;
}

/*---------------------------------------------------------------------------*/

static inline uint64_t ReadLittleEndianU64( const void *p64 )
{
    const uint8_t *p8 = (const uint8_t*)p64;

    return (((uint64_t) p8[7]) << 56) | (((uint64_t) p8[6]) << 48) |
           (((uint64_t) p8[5]) << 40) | (((uint64_t) p8[4]) << 32) |
           (((uint64_t) p8[3]) << 24) | (((uint64_t) p8[2]) << 16) |
           (((uint64_t) p8[1]) << 8)  | ((uint64_t) p8[0]);
}

/*---------------------------------------------------------------------------*/

static inline uint64_t ReadLittleEndianU48( const void *p48 )
{
    const uint8_t *p8 = (const uint8_t*)p48;

    return (((uint64_t) p8[5]) << 40) | (((uint64_t) p8[4]) << 32) |
           (((uint64_t) p8[3]) << 24) | (((uint64_t) p8[2]) << 16) |
           (((uint64_t) p8[1]) << 8)  | ((uint64_t) p8[0]);
}

/*---------------------------------------------------------------------------*/

static inline uint32_t ReadLittleEndianU32( const void *p32 )
{
    const uint8_t *p8 = (const uint8_t*)p32;

    return (p8[3] << 24) | (p8[2] << 16) | (p8[1] << 8) | p8[0];
}

/*---------------------------------------------------------------------------*/

static inline uint32_t ReadLittleEndianU24( const void *p24 )
{
    const uint8_t *p8 = (const uint8_t*)p24;

    return (p8[2] << 16) | (p8[1] << 8) | p8[0];
}

/*---------------------------------------------------------------------------*/

static inline uint16_t ReadLittleEndianU16( const void *p16 )
{
    const uint8_t *p8 = (const uint8_t*)p16;

    return (p8[1] << 8) | p8[0];
}

/*---------------------------------------------------------------------------*/

#endif /* _TAL_ENDIAN_H_ */
