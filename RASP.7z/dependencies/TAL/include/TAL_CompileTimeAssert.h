/*
 * File    : $RCSfile: TAL_CompileTimeAssert.h,v $ (cvs $Revision: 1.6 $)
 *
 * Module  : TAL_Coder
 * Release : $Name: not supported by cvs2svn $
 * Date    : $Date: 2008-06-16 09:51:00 $
 * Author  : $Author: gebe $
 *
 * Description:
 * Macro for a compile time assert statement
 *
 * Copyright 2002-2007 DECOMSYS GmbH, http://www.decomsys.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of DECOMSYS GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * DECOMSYS GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifndef _TAL_COMPILETIMEASSERT_H_
#define _TAL_COMPILETIMEASSERT_H_

#include <assert.h>
#ifdef static_assert
/* C11 feature */
#define TAL_CompileTimeAssert(e) static_assert(e)
#else
/**
 * This macro generates invalid code (division by zero) if the given expression
 * does not evaluates to the boolean value true.
 */
#define TAL_CompileTimeAssert(e)                             \
    do                                                       \
    {                                                        \
        enum { assert_static_ = 1/((int)(e)) };              \
    } while(0)
#endif

#endif /* _TAL_COMPILETIMEASSERT_H_ */
