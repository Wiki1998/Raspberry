/*
 * File    : TAL_Bitfield.h
 *
 * Description:
 * Interface header file defining bitfield extraction and construction macros
 *
 * Copyright 2002-2021 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 */

#ifndef _TAL_BITFIELD_H_
#define _TAL_BITFIELD_H_

/******************************************************************************
 Global Macros
******************************************************************************/

/**
 * @addtogroup EBHSCR
 * @{
 */

/**
 * @brief Extract a bit field out of a scalar value
 *
 * You have to define constants named 'XXX_MASK' (the bits of the bit field
 * within the given value) and 'XXX_SHIFT' (the number of bits to shift the
 * masked-out value to the right in order to get the bit field value within
 * the LSB of the result). 'XXX' is referred as base name of the bit field
 *
 * @param name  Base name of bit field
 * @param reg   Scalar value from which the bit field is extracted
 *
 * @retval      Extracted bit field
 */
#define TAL_GET_BITFIELD(name, reg) \
            TAL_GET_BITFIELD_HLP(name ## _MASK, name ## _SHIFT, reg)

/**
 * @brief Set a range of bits in the given register to the specified value
 *
 * You have to define constants named 'XXX_MASK' (the bits of the bit field
 * within the given value) and 'XXX_SHIFT' (the number of bits to shift the
 * masked-out value to the right in order to get the bit field value within
 * the LSB of the result). 'XXX' is referred as base name of the bit field
 *
 * @param name  Base name of bit field
 * @param reg   Scalar value into which to write the given bit field
 * @param val   Value of bit field to set (add ULL suffix to avoid warnings)
 *
 * @retval      None
 */
#define TAL_SET_BITFIELD(name, reg, val) \
            TAL_SET_BITFIELD_HLP(name ## _MASK, name ## _SHIFT, reg, val)

/**
 * @brief Set a range of bits in the given register to a specified constant
 *
 * You have to define constants named 'XXX_MASK' (the bits of the bit field
 * within the given value) and 'XXX_SHIFT' (the number of bits to shift the
 * masked-out value to the right in order to get the bit field value within
 * the LSB of the result). 'XXX' is referred as base name of the bit field.
 * The constant has to be defined as 'XXX_constant'
 *
 * @param name  Base name of bit field
 * @param reg   Scalar value into which to write the given bit field
 * @param constant Name of constant to set
 *
 * @retval      None
 */
#define TAL_SET_BITFIELD_CONST(name, reg, constant) \
            TAL_SET_BITFIELD_HLP(name ## _MASK, name ## _SHIFT, reg, name ## _ ## constant)

/**
 * @brief Create a bitfield
 *
 * Create a bitfield which can be directly 'or'ed with other bits/bitfields
 * in order to create the full value for a register.
 * You have to define constants named 'XXX_MASK' (the bits of the bit field
 * within the given value) and 'XXX_SHIFT' (the number of bits to shift the
 * masked-out value to the right in order to get the bit field value within
 * the LSB of the result). 'XXX' is referred as base name of the bit field
 *
 * @param name  Base name of bit field
 * @param val   Value of bit field to set
 *
 * @retval      Bitfield value to be 'or'ed with other ones
 */
#define TAL_BITFIELD(name, val) \
            TAL_BITFIELD_HLP(name ## _SHIFT, val)

/**
 * @brief Create a bitfield for a constant
 *
 * Create a bitfield which can be directly 'or'ed with other bits/bitfields
 * in order to create the full value for a register.
 * You have to define constants named 'XXX_MASK' (the bits of the bit field
 * within the given value) and 'XXX_SHIFT' (the number of bits to shift the
 * masked-out value to the right in order to get the bit field value within
 * the LSB of the result). 'XXX' is referred as base name of the bit field
 * The constant has to be defined as 'XXX_constant'
 *
 * @param name  Base name of bit field
 * @param constant Name of constant to set
 *
 * @retval      Bitfield value to be 'or'ed with other ones
 */
#define TAL_BITFIELD_CONST(name, constant) \
            TAL_BITFIELD_HLP(name ## _SHIFT, name ## _ ## constant)

/** @cond EXCLUDE_FROM_DOCU */
#define TAL_GET_BITFIELD_HLP(mask, shift, reg) (((reg)&(mask))>>(shift))
#define TAL_SET_BITFIELD_HLP(mask, shift, reg, val) reg = ((reg)&~(mask))|((((uint64_t)(val))<<(shift))&(mask))
#define TAL_BITFIELD_HLP(shift, val) (((uint64_t)(val))<<(shift))
/** @endcond */

/**
 * @}
 */

#endif /* _TAL_BITFIELD_H_ */
