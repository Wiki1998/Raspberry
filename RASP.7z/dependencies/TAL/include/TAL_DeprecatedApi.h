/*
 * File    : TAL_DeprecatedApi.h
 *
 * Module  : EB_tresos_TAL
 *
 * Description:
 * Interface header file for TAL.
 *
 * Copyright 2002-2012 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

/**
 *
 * @file TAL_DeprecatedApi.h
 *
 * Deprecated (backward compatibility) API and deprecated types
 *
 */

#ifndef _TAL_DEPRECATED_API_H_
#define _TAL_DEPRECATED_API_H_

#include "TAL_Std_Types.h"         /* TAL_API macro */
#include "TAL_Cfg.h"
#include "TAL_DeprecatedTypes.h"
#include "TAL_Deprecated.h"

#ifndef TAL_TH_BM_PHYSICAL_ENABLED
#error macro TAL_TH_BM_PHYSICAL_ENABLED not defined
#endif /* TAL_TH_BM_PHYSICAL_ENABLED */

#ifdef __cplusplus
extern "C"
{
#endif

#if (TAL_TH_BM_PHYSICAL_ENABLED == TAL_ON)
#ifndef TAL_CXX_API
/**
 * @deprecated please use TAL_BM_PhysicalToCoded64 instead. Deprecated in 21.05.
 * @brief Converts a Physical Value into a Coded one
 *
 * This function converts a Physical value into a Coded value.
 * Using this function together with TAL_BM_SendSignalCoded has the same
 * effect as calling TAL_BM_SendSignalPhys directly. As a side effect the
 * coded representation can be used for other purposes (e.g. displaying it in
 * a GUI) too. Cannot be used to convert a symbol (enumerated constant name).
 * For converting a symbol use TAL_BM_SymbolToCoded.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle   handle of the established session
 * @param signalIndex     unique identifier for the signal
 * @param pPhysical       Pointer to the Physical value that should be
 *                        converted
 * @param pCoded          Pointer to where the Coded value should be stored
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_CONVERSION   The function call failed, unable to find
 *                             conversion
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 *
 * @invariant None.
 *
 * @pre A session has to be established before calling this function.
 *
 * @post None.
 *
 * @remarks None.
 *
 */
TAL_DEPRECATED TAL_API extern TAL_ReturnType
TAL_BM_PhysicalToCoded(TAL_SessionHandleType sessionHandle,
                       TAL_BM_SignalIndexType signalIndex,
                       TAL_BM_PhysicalSignalValueType * pPhysical,
                       TAL_BM_CodedSignalValueType * pCoded);
#endif /* TAL_CXX_API */
#endif /* (TAL_TH_BM_PHYSICAL_ENABLED == TAL_ON) */

#if (TAL_TH_BM_PHYSICAL_ENABLED == TAL_ON)
#ifndef TAL_CXX_API
/**
 * @deprecated please use TAL_BM_CodedToPhysical64 instead. Deprecated in 21.05.
 *
 * @brief Converts a Coded value into a Physical one
 *
 * This function converts a Coded value into a Physical value
 * Using this function together with TAL_BM_ReceiveSignalCodedWithStatus has the same
 * effect as calling TAL_BM_ReceiveSignalPhys directly. As a side
 * effect the coded representation can be used for other purposes (e.g.
 * displaying it in a GUI) too.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle   handle of the established session
 * @param signalIndex     unique identifier for the signal
 * @param pCoded          Pointer to the Coded value that should be converted
 * @param pPhysical       Pointer to the location where the Physical Value
 *                        should be stored. (if NULL, no value is provided)
 *                        Only valid if the physical status is TAL_VALUE or TAL_MIXED.
 * @param pStatusPhysical pointer to a data structure for storing the signal
 *                        status of the physical signal. (if NULL, no value is provided)
 * @param pSymbolName     pointer to store the symbol name (coded in
 *                        utf8) in (0 .. symbol name is not stored).
 *                        The string gets zero terminated.
 *                        Only valid if the physical status is TAL_SYMBOL or TAL_MIXED.
 *                        (if NULL, no value is provided)
 * @param nSymbolNameLength size of the provided (user) buffer (pSymbolName)
 *                          in bytes for storing the symbol name
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_CONVERSION    The function call failed, unable to find
 *                              conversion
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed
 * @retval TAL_NO_SESSION       The function call failed, no valid session
 * @retval TAL_BUFFER_TOO_SMALL The buffer for the symbol name is too small,
 *                              thus the symbol was not copied. The remaining
 *                              functionality of the call succeeded
 *
 * @invariant None.
 *
 * @pre A session has to be established before calling this function.
 *
 * @post None.
 *
 * @remarks None.
 *
 */
TAL_DEPRECATED TAL_API extern TAL_ReturnType
TAL_BM_CodedToPhysical(TAL_SessionHandleType sessionHandle,
                      TAL_BM_SignalIndexType signalIndex,
                      TAL_BM_CodedSignalValueType * pCoded,
                      TAL_BM_PhysicalSignalValueType * pPhysical,
                      TAL_BM_PhysicalSignalStatusType * pStatusPhysical,
                      uint8 * pSymbolName,
                      uint32 nSymbolNameLength);
#endif /* TAL_CXX_API */
#endif /* (TAL_TH_BM_PHYSICAL_ENABLED == TAL_ON) */

#ifdef __cplusplus
}
#endif

#endif /* _TAL_DEPRECATED_API_H_ */
