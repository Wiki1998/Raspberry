/*
 * File    : TAL_CommandServer.h
 *
 * Module  : EB_tresos_TAL
 *
 * Description:
 * Interface header file for TAL.
 *
 * Copyright 2002-2012 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifndef _TAL_COMMANDSERVER_H_
#define _TAL_COMMANDSERVER_H_

/******************************************************************************
 Include Section
******************************************************************************/

#include <string>                /* class std::string */

#include "TAL_Types.h"           /* TAL_SessionHandleType */

/******************************************************************************
 Global Macros
******************************************************************************/
#ifndef NOTE
    #define STR(x)  #x
    #define STR2(x) STR(x)
    #define NOTE(x) message (__FILE__ "(" STR2(__LINE__) ") : NOTE: " #x) 
#endif

/******************************************************************************
 Global Data Types
******************************************************************************/

/******************************************************************************
 Global Data Declarations
******************************************************************************/

/******************************************************************************
 Global Function Declarations
******************************************************************************/

/******************************************************************************
 Forward Class Declarations
******************************************************************************/

/******************************************************************************
 Class Declarations
******************************************************************************/

/**
 * @defgroup commandserver Command server related functions
 * @{
 */

class TAL_API TAL_CommandServer
{
public: 
    /**
     * @brief Function prototype, to specify the type of housekeeping function
     *
     * @typedef *TAL_HousekeepingFunc
     *  This function prototype define the signature of a user provided
     *  function for TAL housekeeping.
     *
     * @param TAL_SessionHandleType handle of the established session
     */
    typedef void (*TAL_HousekeepingFunc)(TAL_SessionHandleType);

    /**
     * @brief Constructor
     *
     * Creates the TAL Command Server object. Must be called once prior
     * all other TAL Command Server functions.
     *
     * @param TAL_SessionHandleArg TAL Session Handle
     * @ifnot SWIG
     * @param pHousekeeping Use this parameter only when the TAL Command 
     *                      Server runs in a single threaded environment.
     *                      Single threaded environment: Points to TAL_ProcessTargetData()
     *                      function.
     *                      Multi threaded: Not needed. TAL_ProcessTargetData() is called 
     *                      periodically in another thread.
     * @endif
     */
    TAL_CommandServer(TAL_SessionHandleType TAL_SessionHandleArg
#ifndef SWIG
                      , TAL_HousekeepingFunc pHousekeeping = 0
#endif
                      );

#ifndef SWIG
    /**
     * @brief Constructor for using TAL_ProcessTargetData as housekeeping function
     *
     * Creates the TAL Command Server object. Must be called once prior
     * all other TAL Command Server functions.
     *
     * @param TAL_SessionHandleArg TAL Session Handle
     * @param pHousekeeping Use this parameter only when the TAL Command 
     *                      Server runs in a single threaded environment.
     *                      Points to TAL_ProcessTargetData() function.
     */
    TAL_CommandServer(TAL_SessionHandleType TAL_SessionHandleArg
                      , void (*pHousekeeping)(TAL_SessionHandleType,sint16)
                      );
#endif

    /**
     * @brief Destructor
     */
    ~TAL_CommandServer();

    /*
     * Public Methods
     */

    /*********** JFFS2 filesystem manipulating **********/
    
#ifndef SWIG /* overload std::string with char* will generate SWIG warning 516 */
    /**
     * @brief Writes a license file to the target
     *
     * Writes either a plain license file or a license file contained within
     * a zip-file to the target. In case of a zip-file, only license files
     * with matching Board-Ids are sent to the target
     *
     * @param LicenseFileName Path to license file in the hosts filesystem
     *
     * @retval TAL_SUCCESS             The license was transferred successfully
     * @retval TAL_FAILED              An error occured
     * @retval TAL_INVALID_ARGUMENT    At least one parameter contains an invalid value
     * @retval TAL_FILE_NOT_FOUND      Unable to open provided filename
     * @retval TAL_FILE_ACCESS_FAILED  Unalbe to access provided filename
     * @retval TAL_NO_SESSION          Session handle is invalid
     * @retval TAL_INVALID_INDEX       The function call failed, index out of bounds
     * @retval TAL_ENCODING_ERROR      The function call failed due to an error when
     *                                 encoding a package
     * @retval TAL_COMM_ERROR          The function call failed due to an error in the
     *                                 communication
     * @retval TAL_OUT_OF_MEMORY       Failed to allocate memory
     * @retval TAL_NULL_POINTER        The function call failed cause a null pointer is
     *                                 supplied where it is not allowed
     * @retval TAL_INVALID_FILE_FORMAT Input file is not a valid license file
     * @retval TAL_LICENSE_NOT_FOUND   Input file does not contain a license for
     *                                 the connected device
     */
    TAL_ReturnType WriteLicenseFile(
                        std::string LicenseFileName);// DEPRECATED! Use following function:
    TAL_ReturnType WriteLicenseFile(
                        const char* LicenseFileName);
                        


    /**
     * @brief Writes a file to the JFFS2 filesystem on the target
     *
     * Writes a file to the JFFS2 filesystem on the connected target.
     * Maximal file size supported is 2^23 - 1 bytes (approx. 7.9MB).
     *
     * @param LocalFileName Path to file in the hosts filesystem
     * @param Jffs2FileName Name the file gets in the targets JFFS2 filesystem
     *
     * @retval TAL_SUCCESS            The file was written successfully to JFFS2 filesystem
     * @retval TAL_FAILED             An error occured while writing file to JFFS2 filesystem
     * @retval TAL_INVALID_ARGUMENT   At least one parameter contains an invalid value
     * @retval TAL_FILE_NOT_FOUND     Unable to open provided filename
     * @retval TAL_FILE_ACCESS_FAILED Unalbe to access provided filename
     * @retval TAL_NO_SESSION         Session handle is invalid
     * @retval TAL_INVALID_INDEX      The function call failed, index out of bounds
     * @retval TAL_ENCODING_ERROR     The function call failed due to an error when
     *                                encoding a package
     * @retval TAL_COMM_ERROR         The function call failed due to an error in the
     *                                communication
     * @retval TAL_OUT_OF_MEMORY      Failed to allocate memory
     * @retval TAL_NULL_POINTER       The function call failed cause a null pointer is
     *                                supplied where it is not allowed
     */    
    TAL_ReturnType WriteFileToJffs2(
                        std::string LocalFileName,
                        std::string Jffs2FileName);// DEPRECATED! Use following function:                        
    TAL_ReturnType WriteFileToJffs2(
                        const char* LocalFileName,
                        const char* Jffs2FileName);

    /**
     * @brief Reads a file from the JFFS2 filesystem on the target
     *
     * Reads a file from the JFFS2 filesystem on the connected target.
     *
     * @param LocalFileName Path to file in the hosts filesystem
     * @param Jffs2FileName Name the file has in the targets JFFS2 filesystem
     *
     * @retval TAL_SUCCESS            The file was read successfully from JFFS2 filesystem
     * @retval TAL_FAILED             An error occured while reading file from JFFS2 filesystem
     * @retval TAL_INVALID_ARGUMENT   At least one parameter contains an invalid value
     * @retval TAL_FILE_NOT_FOUND     Unable to open provided filename
     * @retval TAL_FILE_ACCESS_FAILED Unalbe to access provided filename
     * @retval TAL_NO_SESSION         Session handle is invalid
     * @retval TAL_INVALID_INDEX      The function call failed, index out of bounds
     * @retval TAL_ENCODING_ERROR     The function call failed due to an error when
     *                                encoding a package
     * @retval TAL_COMM_ERROR         The function call failed due to an error in the
     *                                communication
     * @retval TAL_OUT_OF_MEMORY      Failed to allocate memory
     * @retval TAL_NULL_POINTER       The function call failed cause a null pointer is
     *                                supplied where it is not allowed
     */
    TAL_ReturnType ReadFileFromJffs2(
                        std::string LocalFileName,
                        std::string Jffs2FileName);// DEPRECATED! Use following function:                        
    TAL_ReturnType ReadFileFromJffs2(
                        const char* LocalFileName,
                        const char* Jffs2FileName);

    /**
     * @brief Calculates the MD5 checksum of a file in the JFFS2 filesystem
     *        on the target
     *
     * Calculates the MD5 checksum of a file in the JFFS2 filesystem
     * on the connected target.
     *
     * @param Jffs2FileName Name the file has in the targets JFFS2 filesystem
     * @param sChksum Reference to string where the MD5 checksum gets stored.
     *
     * @retval TAL_SUCCESS          The MD5 checksum was calculated successfully
     * @retval TAL_FAILED           An error occured while calculating the MD5 checksum
     * @retval TAL_INVALID_ARGUMENT At least one parameter contains an invalid value
     * @retval TAL_FILE_NOT_FOUND   Unable to open provided filename
     * @retval TAL_NO_SESSION       Session handle is invalid
     * @retval TAL_INVALID_INDEX    The function call failed, index out of bounds
     * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
     *                              encoding a package
     * @retval TAL_COMM_ERROR       The function call failed due to an error in the
     *                              communication
     * @retval TAL_OUT_OF_MEMORY    Failed to allocate memory
     * @retval TAL_NULL_POINTER     The function call failed cause a null pointer is
     *                              supplied where it is not allowed
     */
    TAL_ReturnType GetMD5ChkSumFromFileInJffs2(
                        std::string Jffs2FileName,
                        std::string& sChksum);// DEPRECATED! Use following function:                        
    TAL_ReturnType GetMD5ChkSumFromFileInJffs2(
                        const char* Jffs2FileName,
                        char* sChksum);

    /**
     * @brief Deletes a file from the JFFS2 filesystem on the target
     *
     * Deletes a file from the JFFS2 filesystem on the connected target.
     *
     * @param Jffs2FileName Name the file has in the targets JFFS2 filesystem
     *
     * @retval TAL_SUCCESS          The file was deleted successfully from JFFS2 filesystem
     * @retval TAL_FAILED           An error occured while deleting file from JFFS2 filesystem
     * @retval TAL_INVALID_ARGUMENT At least one parameter contains an invalid value
     * @retval TAL_FILE_NOT_FOUND   Unable to open provided filename
     * @retval TAL_NO_SESSION       Session handle is invalid
     * @retval TAL_INVALID_INDEX    The function call failed, index out of bounds
     * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
     *                              encoding a package
     * @retval TAL_COMM_ERROR       The function call failed due to an error in the
     *                              communication
     * @retval TAL_OUT_OF_MEMORY    Failed to allocate memory
     * @retval TAL_NULL_POINTER     The function call failed cause a null pointer is
     *                              supplied where it is not allowed
     */
    TAL_ReturnType DeleteFileFromJffs2(std::string Jffs2FileName);// DEPRECATED! Use following function:
    TAL_ReturnType DeleteFileFromJffs2(const char* Jffs2FileName);
    
#endif

    /*********** RealTimeClock functions **********/
    /**
     * @brief Sets the Real-Time-Clock (RTC) on the target
     *
     * Sets the Real-Time-Clock (RTC) on the connected target.
     * Also sets the UTC timestamp on EBx200 targets if no GPS module is present
     * or the UTC timestamp is not synchronized. If the UTC timestamp is already
     * synchronized to the GPS signal, the update is silently ignored.
     *
     * @param nTime nTime is in UNIX time format. This means seconds since 1970.
     *              If nTime != 0: Sets the target time to nTime.
     *              If nTime == 0: Default, sets the target time to the actual 
     *              system time of the host.
     *
     * @retval TAL_SUCCESS          The time was set successfully
     * @retval TAL_FAILED           An error occured while setting the time
     * @retval TAL_INVALID_ARGUMENT At least one parameter contains an invalid value
     * @retval TAL_NO_SESSION       Session handle is invalid
     * @retval TAL_INVALID_INDEX    The function call failed, index out of bounds
     * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
     *                              encoding a package
     * @retval TAL_COMM_ERROR       The function call failed due to an error in the
     *                              communication
     * @retval TAL_OUT_OF_MEMORY    Failed to allocate memory
     * @retval TAL_NULL_POINTER     The function call failed cause a null pointer is
     *                              supplied where it is not allowed
     *
     * @note This method should not be used during an active measurement since doing so
     *       will result in a step of the measured UTC timestamp.
     */
    TAL_ReturnType SetRTC(uint32 nTime = 0);

    /*
     * Public Members
     */

private:
    /*
     * Private Methods
     */
    void initCommandServer( void );

    /* get m_sCmdRespHandle */
    TAL_TUM_RxDataPacketHandle* GetCmdRespHandle( void )
    {
        return &m_sCmdRespHandle;
    }

    /* set m_nResponseStatus */
    void SetResponseStatus( TAL_ReturnType nStatus )
    {
        m_nResponseStatus = nStatus;
    }

    TAL_ReturnType SendCommand(const uint8 *buf, uint32 size) const;
    TAL_ReturnType GetTargetResponse(uint32 size, uint32 &nRespCmd);
    TAL_ReturnType WaitForTargetResponse();

    /*
     * only one of 'pFileToSend' or 'pBufToSend' shall be non-zero
     */
    struct BufList
    {
        const char *pBuf;
        uint32 nSize;
        BufList *pNext;
    };

    TAL_ReturnType WriteFileToJffs2(
                        FILE * const pFileToSend,
                        const BufList * pBufListToSend,
                        std::string Jffs2FileName);
    /* 
     * Callback function of type TAL_TUM_RecvUserDataCallbackFunctionPointerType
     * for receiving status (return value) notifications about sent commands
     */
    static void RecvUserDataCallback(TAL_SessionHandleType pSessionHandle,
                                     TAL_TUM_IDType nTUM_ID,
                                     TAL_TUM_InstanceIDType nTUM_InstanceID,
                                     const uint8 *pUserData,
                                     uint16 nUserDataLength);

    /*
     * Private Members
     */
    
    /* TAL_SessionHandle */
    TAL_SessionHandleType m_TAL_SessionHandle;

    /* struct for receiveing TUM DataPackets */
    TAL_TUM_RxDataPacketHandle m_sCmdRespHandle;

    /* Response status */
    TAL_ReturnType m_nResponseStatus;

    /* pointer to housekeeping function */
    TAL_HousekeepingFunc m_pHousekeeping;

    /* pointer to alternative housekeeping function */
    void (*m_pHousekeeping2)(TAL_SessionHandleType,sint16);

    /*
     * Prevent assignment operator and copy constructor
     */
     TAL_CommandServer & operator = (const TAL_CommandServer & rhs);

     TAL_CommandServer(const TAL_CommandServer & rhs);
};




/*---------------------------------------------------------------------------*/

#ifndef SWIG
/** 
 * @cond EXCLUDE_FROM_DOCU
 *
 * @deprecated Use TAL_CommandServer class directly instead
 *
 * Class for source backward compatibility to older TAL releases. This class is
 * not needed any more!
 */
class TAL_API TAL_CommandServerGuard
{
public:
    /**
     * @brief Creates the TAL Command Server object
     *
     * @param SessionHandle TAL Session Handle
     * @param pHousekeeping Use this parameter only when the TAL Command 
     *                      Server runs in a single threaded environment.
     *                      Single threaded environment: Points to TAL_ProcessTargetData()
     *                      function.
     *                      Multi threaded: Not needed. TAL_ProcessTargetData() is called 
     *                      periodically in another thread.
     */
    TAL_CommandServerGuard(
                    TAL_SessionHandleType SessionHandle,
                    TAL_CommandServer::TAL_HousekeepingFunc pHousekeeping = 0)
        : m_CmdServer(SessionHandle, pHousekeeping)
    {
    }

    /**
     * @brief Creates the TAL Command Server object
     *
     * @param SessionHandle TAL Session Handle
     * @param pHousekeeping Use this parameter only when the TAL Command 
     *                      Server runs in a single threaded environment.
     *                      Single threaded environment: Points to TAL_ProcessTargetData()
     *                      function.
     */
    TAL_CommandServerGuard(
                    TAL_SessionHandleType SessionHandle,
                    void (*pHousekeeping)(TAL_SessionHandleType,sint16))
        : m_CmdServer(SessionHandle, pHousekeeping)
    {
    }

    /**
     * @brief Deletes the TAL Command Server object.
     *
     * Deletes the TAL Command Server object.
     */
    ~TAL_CommandServerGuard()
    {
    }

    /**
     * @brief Get TAL Command Server interface
     *
     * @retval Pointer to TAL_CommandServer object.
     */
    TAL_CommandServer* GetTalCommandServer()
    {
        return &m_CmdServer;
    }

private:
    TAL_CommandServer m_CmdServer;

    /*
     * Prevent assignment operator and copy constructor
     */
     TAL_CommandServerGuard & operator = (const TAL_CommandServerGuard & rhs);

     TAL_CommandServerGuard(const TAL_CommandServerGuard & rhs);
};
/* @endcond */
#endif

/**
 * @}
 */

#endif /* _TAL_COMMANDSERVER_H_ */

/*=============================== End of File ===============================*/

