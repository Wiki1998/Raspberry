/*
 * File    : $RCSfile: BitVector.h,v $ (cvs $Revision: 1.4 $)
 *
 * Module  : CommonHostTarget
 * Release : $Name: not supported by cvs2svn $
 * Date    : $Date: 2007-11-09 12:32:07 $
 * Author  : $Author: gernot $
 *
 * Description: Macro to set deprecated argument for compilers
 * where it is supported
 *
 * Copyright 2002-2007 DECOMSYS GmbH, http://www.decomsys.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of DECOMSYS GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * DECOMSYS GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifndef _TAL_DEPRECATED_H_
#define _TAL_DEPRECATED_H_

#ifndef TAL_NO_DEPRECATED
#if (__GNUC__ > 3 || (__GNUC__ == 3 && __GNUC_MINOR__ >= 1))
/* gcc */
#define TAL_DEPRECATED __attribute__((__deprecated__))
#else
#ifdef _MSC_VER
/* MSVC */
#define TAL_DEPRECATED __declspec(deprecated)
#else
/* unknown */
#define TAL_DEPRECATED
#endif
#endif
#else
/* deprecation warning disabled */
#define TAL_DEPRECATED
#endif

#endif /* _TAL_DEPRECATED_H_ */
