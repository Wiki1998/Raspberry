/*
 * File    : TAL_Cfg.h
 *
 * Module  : EB_tresos_TAL
 *
 * Description:
 * Pre-compile time parameters of TAL.
 * Can be used to disable/enable features.
 *
 * Copyright 2002-2012 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifndef _TAL_CFG_H_
#define _TAL_CFG_H_

/******************************************************************************
 Include Section
******************************************************************************/

#include "TAL_Types.h" /* get TAL types defined */

/******************************************************************************
 Global Macros
******************************************************************************/

/*
 * Feature set definition
 */

#ifdef EBX2XX
#define TAL_PCI_ENABLED TAL_OFF
#endif

#ifndef TAL_PCI_ENABLED
#define TAL_PCI_ENABLED TAL_ON
#endif

#ifndef TAL_PCI_WIN_ENABLED
#define TAL_PCI_WIN_ENABLED TAL_OFF
#endif

#ifndef TAL_PCI_VISA_ENABLED
#define TAL_PCI_VISA_ENABLED TAL_OFF
#endif

#ifndef TAL_PCI_EB_ENABLED
#define TAL_PCI_EB_ENABLED TAL_ON
#endif

#ifndef TAL_TCP_ENABLED
#define TAL_TCP_ENABLED TAL_ON
#endif

#ifdef EBX2XX
#define TAL_UDP_ENABLED TAL_OFF
#endif

#ifndef TAL_UDP_ENABLED
#define TAL_UDP_ENABLED TAL_ON
#endif

/* enable ProcessTargetDataThread */
#ifndef TAL_TH_PROCESS_TARGET_DATA_THREAD_ENABLED
#define TAL_TH_PROCESS_TARGET_DATA_THREAD_ENABLED TAL_ON
#endif

/* enable/disable embedding of 'Generic' Firmware.ttc files into TAL library */
#ifndef TAL_TH_EMBEDDED_TTC_ENABLED
#define TAL_TH_EMBEDDED_TTC_ENABLED TAL_ON
#endif

/* enable/disable the dummy bottom half */
#ifndef TAL_DUMMY_ENABLED
#define TAL_DUMMY_ENABLED TAL_ON
#endif

/* enable/disable the deprecated blocking TAL API */
#ifndef TAL_TH_BM_BL_ENABLED
#define TAL_TH_BM_BL_ENABLED TAL_ON
#endif

/* enable/disable the physical signal and TCS file support */
#ifndef TAL_TH_BM_PHYSICAL_ENABLED
#define TAL_TH_BM_PHYSICAL_ENABLED TAL_ON
#endif

/* enable/disable the sqlite file support.
 * Sqlite file support is an optional feature used for querying the tresosDB.
 * Additionally you must not compile files from TopHalf/src/sqlite. */
#ifndef TAL_SQLITE_ENABLED
#define TAL_SQLITE_ENABLED TAL_ON
#endif

/*
 * enable/disable the Hostbased RBS feature.
 * The Hostbased RBS is a fast Ethernet based RBS alternative to current EB hardware based RBSes.
 * The Hostbased RBS is per default off and is not compiled for any _x2xx_lx platform.
 */
#ifndef TAL_HBR_ENABLED
#define TAL_HBR_ENABLED TAL_OFF
#endif

/*
 * Configuration parameters
 */
/*
 * Defines the maximum number of packets read within on
 * invocation of the background function.
 */
#define TAL_BH_BGHANDLER_MAX_ITERATIONS 10000UL

/******************************************************************************
 Global Data Types
******************************************************************************/

/******************************************************************************
 Global Data
******************************************************************************/

/******************************************************************************
 Global Function Declarations
******************************************************************************/

#endif /* _TAL_CFG_H_ */
