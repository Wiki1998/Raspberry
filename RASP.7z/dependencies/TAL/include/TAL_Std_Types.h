/*
 * File    : $RCSfile: TAL_Std_Types.h,v $ (cvs $Revision: 1.5 $)
 *
 * Module  : TAL_Std_Types
 * Release : $Name: not supported by cvs2svn $
 * Date    : $Date: 2008-03-28 12:57:11 $
 * Author  : $Author: gebe $
 *
 * Description:
 * Interface header file for definition of std types
 *
 * Copyright 2002-2019 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

/**
 * 
 * @file TAL_Std_Types.h
 *
 */

#ifndef _TAL_STD_TYPES_H_
#define _TAL_STD_TYPES_H_

/******************************************************************************
 Include Section
******************************************************************************/

#include <stddef.h>             /* for size_t */

#include <Platform_Types.h>

/******************************************************************************
 Global Macros
******************************************************************************/

/* For use with TAL_Boolean */
#define TAL_FALSE 0
#define TAL_TRUE 1

/**
 *
 * @brief Transparent type for pointer values
 *
 * @def TAL_UNUSED_PARAMETER
 *  This macro is used to suppress warnings concerning unused arguments of
 *  a function.
 *  It shall only be used during the development of new code or if a
 *  specific function prototype has to be used (e.g. callback functions),
 *  but the arguments are not evaluated by the function.
 *
 */
#define TAL_UNUSED_PARAMETER(parameter) ((void)parameter)

/**
 *
 * @brief Constant for invalid handles
 *
 * @def TAL_INVALID_HANDLE
 *  This macro is used to define an invalid value for a handle.
 *
 */
#define TAL_INVALID_HANDLE 0

/* @cond EXCLUDE_FROM_DOCU */
/*
 * Default: use deprecated enums in API for backward compatibility.
 * Swig: Do not export deprecated enums.
 * Deprecated enum constants are not exported if the user compiles his
 * programs using TAL_DONT_USE_DEPRECATED_ENUMS.
 */
#if (!defined TAL_DONT_USE_DEPRECATED_ENUMS) && (!defined SWIG)
#define TAL_USE_DEPRECATED_ENUMS
#endif
/* @endcond */

/* @cond EXCLUDE_FROM_DOCU */
#ifdef _WIN32
#ifdef TAL_API_EXPORTS
#ifndef TAL_API
#define TAL_API __declspec(dllexport)
#endif
#else
#ifndef TAL_API
#define TAL_API __declspec(dllimport)
#endif
#endif
#else
#if __GNUC__ >= 4
#define TAL_API __attribute__ ((visibility ("default")))
#else
#define TAL_API
#endif
#endif
/* @endcond */

/******************************************************************************
 Global Data Types
******************************************************************************/

/**
 *
 * @brief TAL type used for boolean values in C-API
 *
 * @typedef TAL_Boolean
 *  For use with TAL_TRUE/TAL_FALSE macros.
 */
typedef unsigned int TAL_Boolean;

/**
 *
 * @brief Transparent type for pointer values
 *
 * @typedef TAL_PointerIntType
 *  Definition of an integer, big enough to keep a pointer (address) value.
 *  The type is used to anonymize a pointer from its concrete (C++)
 *  implementation.
 */
typedef size_t TAL_PointerIntType;

/**
 *
 * @brief Status value, returned by any TAL_* function.
 *
 * @enum TAL_ReturnType
 *  This enum type defines the possible values, each TAL_* function
 *  may return.
 *
 * @sa TAL_ReturnType2Str
 * @sa TAL_ReturnType2Text
 *
 */
typedef enum {
     TAL_SUCCESS = 0 /**< The function call executed successfully */
    ,TAL_FAILED = 1 /**< The function call failed to execute */
    ,TAL_NOT_SUPPORTED = 2 /**< The function is not supported */
    ,TAL_NO_CONVERSION = 3 /**< No Conversion function found or conversion value out of range */
    ,TAL_BUFFER_TOO_SMALL = 4 /**< User provided Buffer too small for the content */
    ,TAL_INVALID_INDEX = 5 /**< index not within bounds or no element available for the specified index */
    ,TAL_NULL_POINTER = 6 /**< error: a null pointer is supplied where it is not allowed */
    ,TAL_INVALID_ARGUMENT = 7 /**< One or more arguments contains invalid values */
    ,TAL_OUT_OF_MEMORY = 8 /**< Memory Allocation failed */
    ,TAL_NO_SESSION = 9 /**< No active Session available */
    ,TAL_ENCODING_ERROR = 10 /**< Error Encoding Buffer */
    ,TAL_COMM_ERROR = 11 /**< Communication attempted failed */
    ,TAL_FILE_NOT_FOUND = 12 /**< unable to open provided filename */
    ,TAL_DONT_MATCH = 13 /**< Packet don't match selection criteria */
    ,TAL_OUT_OF_SEQUENCE = 14 /**< Packet is out of sequence */
    ,TAL_NOT_FINISHED = 15 /**< Current action was not finished */
    ,TAL_OVERFLOW = 16 /**< Overflow of some sort happened */
    ,TAL_TIMEOUT = 17 /**< a timeout in a TAL operation occurred */
    ,TAL_NO_DATA = 18 /**< no new data is present */
    ,TAL_BYTE_ARRAY_ERROR = 19 /**< byte array signal is used with functions where it is not allowed. Use special byte array functions for these signals instead */
    ,TAL_HIGH_LOAD = 20 /**< High load on communication channel detected */
    ,TAL_FILE_ACCESS_FAILED = 21 /**< Accessing file failed */
    ,TAL_MODIFIED = 22 /**< Operation modified state */
    ,TAL_NOT_REGISTERED = 23 /**< please call the according register function first */
    ,TAL_INCOMPATIBLE_HARDWARE = 24 /**< hardware does not match to ttc file */
    ,TAL_LICENSE_NOT_FOUND = 25 /**< necessary license not found */
    ,TAL_INVALID_FILE_FORMAT = 26 /**< format of given file is incorrect */
    ,TAL_EOF = 27 /**< end of file reached */
    ,TAL_NO_DEVICE = 28 /**< no device was found */ 
    ,TAL_SUCCESS_AGAIN = 29 /**< another additional call of something that should only be called once */
    ,TAL_ALREADY_REGISTERED = 30 /** < TUM instance is already registered for user data notification */
    ,TAL_NO_BUFFER_AVAILABLE = 31 /**< No buffer provided by user or in case of replay data, tx buffer is full */
    ,TAL_REGISTER_ACCESS_FAILED = 32 /**< Read or write of the specified register address failed */
    ,TAL_INVALID_MODULE_SLOT = 33 /**< No module available for the specified slot number */
    ,TAL_DAQ_STATE_INVALID = 34 /**< Error when changing the daq state or daq state change was not recognized by the fpga */
    ,TAL_MODULE_NOT_INIT = 35 /**< Measurement is not initialized (only a maintenance session is established) */
    ,TAL_FIRMWARE_OUTDATED = 36 /**< Firmware is outdated, please perform a firmware upgrade! */
    ,TAL_FIRMWARE_IDENTICAL = 37 /**< Firmware file's version is identical to running firmware */
    ,TAL_NO_CONNECTION = 38 /**< No active connection to target device available */
    ,TAL_INVALID_DATA = 39 /**< Invalid data received */
    ,TAL_RETURNTYPE_MAX_VALUE = 39 /**< For type safe conversion into a scalar type */

/* @cond EXCLUDE_FROM_DOCU */
#ifdef TAL_USE_DEPRECATED_ENUMS
    ,TAL_Success = TAL_SUCCESS
    ,TAL_Failed = TAL_FAILED
    ,TAL_NotSupported = TAL_NOT_SUPPORTED
    ,TAL_NoConversion = TAL_NO_CONVERSION
    ,TAL_BufferTooSmall = TAL_BUFFER_TOO_SMALL
    ,TAL_InvalidIndex = TAL_INVALID_INDEX
    ,TAL_NullPointer = TAL_NULL_POINTER
    ,TAL_InvalidArgument = TAL_INVALID_ARGUMENT
    ,TAL_OutOfMemory = TAL_OUT_OF_MEMORY
    ,TAL_NoSession = TAL_NO_SESSION
    ,TAL_EncodingError = TAL_ENCODING_ERROR
    ,TAL_CommError = TAL_COMM_ERROR
    ,TAL_FileNotFound = TAL_FILE_NOT_FOUND
    ,TAL_DontMatch = TAL_DONT_MATCH
    ,TAL_OutOfSequence = TAL_OUT_OF_SEQUENCE
    ,TAL_NotFinished = TAL_NOT_FINISHED
    ,TAL_Overflow = TAL_OVERFLOW
    ,TAL_Timeout = TAL_TIMEOUT
    ,TAL_NoData = TAL_NO_DATA
    ,TAL_ByteArrayError = TAL_BYTE_ARRAY_ERROR
    ,TAL_HighLoad = TAL_HIGH_LOAD
    ,TAL_FileAccessFailed = TAL_FILE_ACCESS_FAILED
    ,TAL_Modified = TAL_MODIFIED
    ,TAL_NotRegistered = TAL_NOT_REGISTERED
    ,TAL_IncompatibleHardware = TAL_INCOMPATIBLE_HARDWARE
    ,TAL_LicenseNotFound = TAL_LICENSE_NOT_FOUND
    ,TAL_InvalidFileFormat = TAL_INVALID_FILE_FORMAT
    ,TAL_EndOfFile = TAL_EOF
    ,TAL_NoDevice = TAL_NO_DEVICE
    ,TAL_ReturnTypeMaxValue = TAL_RETURNTYPE_MAX_VALUE
#endif
/* @endcond */
} TAL_ReturnType;
/* @cond EXCLUDE_FROM_DOCU */
typedef uint8 TAL_ScalarReturnType;
/* @endcond */

#ifndef SWIG
/* Workaround for failed PDF doku build: */
/* @cond EXCLUDE_FROM_DOCU */
/**
 * @brief Convert a TAL return code to its string representation
 *
 * @param ret Code returned by any TAL function
 *
 * @retval String representation of TAL return code
 */
#define TAL_ReturnType2Str(ret) (\
            (ret)==TAL_SUCCESS?"TAL_Success":\
            (ret)==TAL_FAILED?"TAL_Failed":\
            (ret)==TAL_NOT_SUPPORTED?"TAL_NotSupported":\
            (ret)==TAL_NO_CONVERSION?"TAL_NoConversion":\
            (ret)==TAL_BUFFER_TOO_SMALL?"TAL_BufferTooSmall":\
            (ret)==TAL_INVALID_INDEX?"TAL_InvalidIndex":\
            (ret)==TAL_NULL_POINTER?"TAL_NullPointer":\
            (ret)==TAL_INVALID_ARGUMENT?"TAL_InvalidArgument":\
            (ret)==TAL_OUT_OF_MEMORY?"TAL_OutOfMemory":\
            (ret)==TAL_NO_SESSION?"TAL_NoSession":\
            (ret)==TAL_ENCODING_ERROR?"TAL_EncodingError":\
            (ret)==TAL_COMM_ERROR?"TAL_CommError":\
            (ret)==TAL_FILE_NOT_FOUND?"TAL_FileNotFound":\
            (ret)==TAL_DONT_MATCH?"TAL_DontMatch":\
            (ret)==TAL_OUT_OF_SEQUENCE?"TAL_OutOfSequence":\
            (ret)==TAL_NOT_FINISHED?"TAL_NotFinished":\
            (ret)==TAL_OVERFLOW?"TAL_Overflow":\
            (ret)==TAL_TIMEOUT?"TAL_Timeout":\
            (ret)==TAL_NO_DATA?"TAL_NoData":\
            (ret)==TAL_BYTE_ARRAY_ERROR?"TAL_ByteArrayError":\
            (ret)==TAL_HIGH_LOAD?"TAL_HighLoad":\
            (ret)==TAL_FILE_ACCESS_FAILED?"TAL_FileAccessFailed":\
            (ret)==TAL_MODIFIED?"TAL_Modified":\
            (ret)==TAL_NOT_REGISTERED?"TAL_NotRegistered":\
            (ret)==TAL_INCOMPATIBLE_HARDWARE?"TAL_IncompatibleHardware":\
            (ret)==TAL_LICENSE_NOT_FOUND?"TAL_LicenseNotFound":\
            (ret)==TAL_INVALID_FILE_FORMAT?"TAL_InvalidFileFormat":\
            (ret)==TAL_EOF?"TAL_EndOfFile":\
            (ret)==TAL_NO_DEVICE?"TAL_NoDevice":\
            (ret)==TAL_NO_BUFFER_AVAILABLE?"TAL_NoBufferAvailable":\
            (ret)==TAL_REGISTER_ACCESS_FAILED?"TAL_RegisterAccessFailed":\
            (ret)==TAL_INVALID_MODULE_SLOT?"TAL_InvalidModuleSlot":\
            (ret)==TAL_DAQ_STATE_INVALID?"TAL_DaqStateInvalid":\
            (ret)==TAL_MODULE_NOT_INIT?"TAL_ModuleNotInit":\
            (ret)==TAL_FIRMWARE_OUTDATED?"TAL_FirmwareOutdated":\
            (ret)==TAL_FIRMWARE_IDENTICAL?"TAL_FirmwareIdentical":\
            (ret)==TAL_NO_CONNECTION?"TAL_NoConnection":\
            (ret)==TAL_INVALID_DATA?"TAL_Invalid_Data":\
            "TAL_Unknown")
/* @endcond */

/* Workaround for failed PDF doku build: */
/* @cond EXCLUDE_FROM_DOCU */
/**
 * @brief Convert a TAL return code to a descriptive text
 *
 * @param ret Code returned by any TAL function
 *
 * @retval String containing descriptive text for TAL return code
 */
#define TAL_ReturnType2Text(ret) (\
            (ret)==TAL_SUCCESS?"The function call executed successfully":\
            (ret)==TAL_FAILED?"The function call failed to execute":\
            (ret)==TAL_NOT_SUPPORTED?"The function is not supported":\
            (ret)==TAL_NO_CONVERSION?"No Conversion function found or conversion value out of range":\
            (ret)==TAL_BUFFER_TOO_SMALL?"User provided Buffer too small for the content":\
            (ret)==TAL_INVALID_INDEX?"index not within bounds or no element available for the specified index":\
            (ret)==TAL_NULL_POINTER?"error: a null pointer is supplied where it is not allowed":\
            (ret)==TAL_INVALID_ARGUMENT?"One or more arguments contains invalid values":\
            (ret)==TAL_OUT_OF_MEMORY?"Memory Allocation failed":\
            (ret)==TAL_NO_SESSION?"No active Session available":\
            (ret)==TAL_ENCODING_ERROR?"Error Encoding Buffer":\
            (ret)==TAL_COMM_ERROR?"Communication attempted failed":\
            (ret)==TAL_FILE_NOT_FOUND?"unable to open provided filename":\
            (ret)==TAL_DONT_MATCH?"Packet don't match selection criteria":\
            (ret)==TAL_OUT_OF_SEQUENCE?"Packet is out of sequence":\
            (ret)==TAL_NOT_FINISHED?"Current action was not finished":\
            (ret)==TAL_OVERFLOW?"Overflow of some sort happened":\
            (ret)==TAL_TIMEOUT?"a timeout in a TAL operation occurred":\
            (ret)==TAL_NO_DATA?"no new data is present":\
            (ret)==TAL_BYTE_ARRAY_ERROR?"byte array signal is used with functions where it is not allowed. Use special byte array functions for these signals instead":\
            (ret)==TAL_HIGH_LOAD?"High load on communication channel detected":\
            (ret)==TAL_FILE_ACCESS_FAILED?"Accessing file failed":\
            (ret)==TAL_MODIFIED?"Operation modified state":\
            (ret)==TAL_NOT_REGISTERED?"please call the according register function first":\
            (ret)==TAL_INCOMPATIBLE_HARDWARE?"hardware does not match to ttc file":\
            (ret)==TAL_LICENSE_NOT_FOUND?"necessary license not found":\
            (ret)==TAL_INVALID_FILE_FORMAT?"format of given file is incorrect":\
            (ret)==TAL_EOF?"end of file is reached":\
            (ret)==TAL_NO_DEVICE?"no device was found":\
            (ret)==TAL_NO_BUFFER_AVAILABLE?"No buffer provided by user":\
            (ret)==TAL_REGISTER_ACCESS_FAILED?"Read or write of the specified register address failed":\
            (ret)==TAL_INVALID_MODULE_SLOT?"No module available for the specified slot number":\
            (ret)==TAL_DAQ_STATE_INVALID?"Error when changing the daq state or daq state change was not recognized by the fpga":\
            (ret)==TAL_MODULE_NOT_INIT?"Modules are not initialized (Only a maintenance session is established)":\
            (ret)==TAL_FIRMWARE_OUTDATED?"Firmware outdated - please perform a firmware update":\
            (ret)==TAL_FIRMWARE_IDENTICAL?"Firmware file's version is identical to running firmware":\
            (ret)==TAL_NO_CONNECTION?"No active connection to target device available":\
            (ret)==TAL_INVALID_DATA?"Invalid data received":\
            "unknown TAL error code")
/* @endcond */
#endif /* SWIG */

/* Supported Modules Types */
typedef enum
{
    TAL_TYPE_UNKNOWN                  =  0,
    TAL_TYPE_EB5100_FR_TJA1080        =  1,
    TAL_TYPE_EB5100_FR_N1D4           =  1,
    TAL_TYPE_EB5100_CAN_HS            =  2,
    TAL_TYPE_EB5100_CAN_LS            =  3,
    TAL_TYPE_EB5100_DIGIO             =  4,
    TAL_TYPE_EB5100_TRANSPARENT       =  5,
    TAL_TYPE_EB5100_GALISO_FR_TJA1080 =  6,
    TAL_TYPE_EB5100_GALISO_FR_N1D4    =  6,
    TAL_TYPE_EB6100_IO_EXTENSION      =  7,
    TAL_TYPE_EB6100_VCXO_EXTENSION    =  8,
    TAL_TYPE_EB0211_SYSTEM            =  9,
    TAL_TYPE_EB0212_ISOPULSE          = 10,
/*  TAL_TYPE_EB0213_ISOPULSE_BRIDGED has no OneWire chip */
    TAL_TYPE_EB0214_MICRO_SDHC        = 11,
    TAL_TYPE_EB0215_RS232_DSUB        = 12,
    TAL_TYPE_EB0216_JTAGCOP           = 13,
    TAL_TYPE_EB0217_HWTEST_SLOT       = 14,
    TAL_TYPE_EB0218_HWTEST_EXPANSION  = 15,
    TAL_TYPE_EB0219_SYSTEM_ODU        = 16,
    TAL_TYPE_EB0220_FR_ODU            = 17,
    TAL_TYPE_EB0223_CAN_FD_ODU_REV1   = 18,
    TAL_TYPE_EB0221_CAN_HS_ODU_REV0   = 18,
    TAL_TYPE_EB0221_CAN_HS_ODU        = 18,
    TAL_TYPE_EB0270_GPS_REV1          = 19,
    TAL_TYPE_EB0230_GPS_REV0          = 19,
    TAL_TYPE_EB0230_GPS               = 19,
    TAL_TYPE_EB0244_DIGIO_GAL_ODU     = 20,
    TAL_TYPE_EB0260_FR_DSUB           = 21,
    TAL_TYPE_EB0263_CAN_FD_DSUB_REV1  = 22,
    TAL_TYPE_EB0261_CAN_HS_DSUB_REV0  = 22,
    TAL_TYPE_EB0261_CAN_HS_DSUB       = 22,
    TAL_TYPE_EB0284_DIGIO_GAL_DSUB    = 23,
    TAL_TYPE_EB02XX_TRANSPARENT       = 24,
    TAL_TYPE_EB0222_LIN_ODU           = 25,
    TAL_TYPE_EB0262_LIN_DSUB          = 26,
    TAL_TYPE_EB5100_LIN               = 27,
    TAL_TYPE_EB0224_DIGIO_ODU         = 28,
    TAL_TYPE_EB0264_DIGIO_DSUB        = 29,
    TAL_TYPE_EB0207_ETHERCAT          = 30,
    TAL_TYPE_EB0225_HWSYNC_ODU        = 31,
    TAL_TYPE_EB0223_CAN_FD_ODU        = 32, /* legacy: only used during prototyping; DO NEVER EVER program new Chips using this number! */
    TAL_TYPE_EB0263_CAN_FD_DSUB       = 33, /* legacy: only used during prototyping; DO NEVER EVER program new Chips using this number! */
    TAL_TYPE_EB0226_CAN_LS_ODU        = 34,
    TAL_TYPE_EB0227_Dual_CAN_FD_ODU   = 35,
    TAL_TYPE_EB0266_CAN_LS_DSUB       = 36,
    TAL_TYPE_EB0267_Dual_CAN_FD_DSUB  = 37,
    TAL_TYPE_EB7200_BASE_BOARD         = 38,
    TAL_TYPE_EB1220_EB1221_LVDS160_320 = 39,
    TAL_TYPE_EB7200_LVDS_MI5           = 39, /* deprecated */
    TAL_TYPE_EB7200_LVDS160_320        = 39, /* deprecated */
    TAL_TYPE_EB1227_EB1228_LVDS3G      = 40,
    TAL_TYPE_EB7200_LVDS3G             = 40, /* deprecated */
    TAL_TYPE_EB0200_BASE_BOARD         = 41,
    TAL_TYPE_EB1234_BROADR_REACH       = 42,
    TAL_TYPE_EB1235_1000BASET1         = 43,
    TAL_TYPE_EB1230_LVDS3G_TX          = 44,
    TAL_TYPE_EB1213_CARRIER_BOARD      = 45,
    TAL_TYPE_EB1224_LVD160_320_TX      = 46,
    TAL_TYPE_EB0294_1000BASE_EXT       = 47,
    TAL_TYPE_EB0228_HWSYNC_ODU         = 48,
    TAL_TYPE_EB0268_HWSYNC_DSUB        = 49,
    TAL_TYPE_EB1237_FPD_LINK           = 50,
    TAL_TYPE_EB7210_BASE_BOARD         = 51,

    /* 
     * add new Module Types here ... 
     * don't forget to add an identification string in function
     * OW_GetModuleTypeString in file OneWireGeneric.cpp
     * don't forget to extend config file parser in function readModulesConfig
     * in file HAL_SessionLinux.cpp
     * 
     */

    TAL_TYPE_LAST, /* This is always the last entry - used for array sizes and
                     loop counters */
    TAL_TYPE_EMPTY = 0xFFFF /* This is always 0xFFFF to do not break binary
                              compatibility between linux HAL and autocore HAL */ 
} TAL_ModuleType;

/******************************************************************************
 Global Data
******************************************************************************/

/******************************************************************************
 Global Function Declarations
******************************************************************************/

#endif /* _TAL_STD_TYPES_H_ */

