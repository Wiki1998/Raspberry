/*
 * File    : TAL_Sleep.h
 *
 * Module  : EB_tresos_TAL
 *
 * Description:
 * Interface header file for TAL.
 *
 * Copyright 2002-2012 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifndef _TAL_SLEEP_H_
#define _TAL_SLEEP_H_

/******************************************************************************
 Include Section
******************************************************************************/

#include "TAL_Std_Types.h"  /* fixed size data types */

/******************************************************************************
 Global Macros
******************************************************************************/

/******************************************************************************
 Global Data Types
******************************************************************************/

/******************************************************************************
 Global Data
******************************************************************************/

/******************************************************************************
 Global Function Declarations
******************************************************************************/

#ifdef __cplusplus
extern "C"
{
#endif

/**
 *
 * @brief Sleep for the given number of micro seconds
 *
 * @param nMicroSeconds   time in micro seconds
 *
 * @retval None.
 *
 * @remarks  Please be aware that although the time can be specified in
 * microseconds the real time after this function returns will have a much
 * bigger granularity under most operating systems (sometimes around 10
 * milliseconds and more). Usually this depends on the system timer.
 *
 * Below you can find a few tips how to increase the accuracy of the sleep
 * function under various operating systems. If in doubt look at your
 * operating systems documentation. Please note that if you change the period
 * of the system timer by any means this will probably result in a higher
 * overall system load because of more interrupts. We do not encourage this.
 * Furthermore we believe that most programs which depends on the accuracy
 * of sleep are poorly designed.
 *
 * Linux with xenomai: Here we use rt_task_sleep, the xenomai real time native
 * API sleep function, so the time will be pretty accurate.
 *
 * On standard POSIX platforms (e.g. standard Linux) we use usleep. On such
 * systems you possibly can use the Pseudo-POSIX function clock_setres to
 * change the resolution of the system timer.
 *
 * On Microsoft Windows we use Sleep. On such systems you can use the function
 * timeBeginPeriod and timeEndPeriod in your application to request a minimal
 * resolution for periodic timers.
 */
TAL_API extern void TAL_Sleep(uint32 nMicroSeconds);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* _TAL_SLEEP_H_ */
