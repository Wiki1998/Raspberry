/*
 * File    : $RCSfile: TAL_Types.h,v $ (cvs $Revision: 1.19 $)
 *
 * Module  : TAL_Types
 * Release : $Name: not supported by cvs2svn $
 * Date    : $Date: 2008-12-12 10:59:51 $
 * Author  : $Author: grfe2844 $
 *
 * Description:
 * Interface header file for externally visible TAL API Types.
 *
 * Copyright 2002-2010 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

/**
 *
 * @file TAL_Types.h
 *
 * Interface header file for externally visible TAL API Types.
 *
 */

#ifndef _TAL_TYPES_H_
#define _TAL_TYPES_H_

#include "TAL_Std_Types.h"
#include "TAL_Numbers.h"
#include "TAL_EBHSCR.h"

#ifdef __cplusplus
/* forward class declarations */
class TalMeasureData;
#endif

#ifndef _MSC_VER
/* use C99-Standard keyword per default */
#define TAL_INLINE inline
#else
/* for MSVC compiler we need a fall-back */
#define TAL_INLINE __inline
#endif

/**
 * @brief Constant, defining an identifier for all instances of a target
 *        user module
 *
 * @sa TAL_TUM_InstanceIDType
 *
 * @def TAL_TUM_ALL_INSTANCES_IDENTIFIER
 *  This value is used as a special value, identifying all instances of a
 *  target user module.
 */
#define TAL_TUM_ALL_INSTANCES_IDENTIFIER 0xFFFF

/**
 * @brief Constant, defining an identifier for all digital in channels
 *
 * @sa TAL_BM_DigitalIOPinIDType
 *
 * @def DIO_READ_ALL_IN_CHANNELS
 *  This value is used as a special value, identifying all digital in channels
 *  of the hardware.
 */
#define DIO_READ_ALL_IN_CHANNELS 0xFF

/*
 * Do not wrap with SWIG because these macros shall only be used in the C and
 * C++ implementation of the TAL
 */
#ifndef SWIG

/**
 * @brief Constant, defining the maximal number of FlexRay controllers used by
 *        Busmirror
 *
 * @def TAL_BM_MAX_NR_FLEXRAY_CTRL
 */
#define TAL_BM_MAX_NR_FLEXRAY_CTRL 3

/**
 * @brief Constant, defining the maximal number of Ethernet controllers used by
 *        Busmirror
 *
 * @def TAL_BM_MAX_NR_ETH_CTRL
 */
#define TAL_BM_MAX_NR_ETH_CTRL 2

/**
 * @brief Constant, defining the maximal number of CAN networks used by
 *        Busmirror
 *
 * @def TAL_BM_MAX_NR_CAN_CTRL
 */
#define TAL_BM_MAX_NR_CAN_CTRL 8

/**
 * @brief Constant, defining the minimum value for the baudrate which is supported
 * by a CAN controler
 *
 * @def TAL_BM_MIN_BAUDRATE_CAN_CTRL
 */
#define TAL_BM_MIN_BAUDRATE_CAN_CTRL 40000

/**
 * @brief Constant, defining the maximum value for the baudrate which is supported
 * by a CAN controler
 *
 * @def TAL_BM_MAX_BAUDRATE_CAN_CTRL
 */
#define TAL_BM_MAX_BAUDRATE_CAN_CTRL 1000000

/**
 * @brief Constant, defining the maximum value for the baudrate which is supported
 * by a CANFD controler
 *
 * @def TAL_BM_MAX_BAUDRATE_CANFD_CTRL
 */

#define TAL_BM_MAX_BAUDRATE_CANFD_CTRL 10000000

/**
 * @brief Constant, defining the maximal number of virtual CAN networks used by
 *        Busmirror
 *
 * @def TAL_BM_MAX_NR_VIRT_CAN_CTRL
 */
#define TAL_BM_MAX_NR_VIRT_CAN_CTRL 8

/**
 *
 * @brief Macros for CAN message type
 *
 * @def TAL_BM_CANMESSAGE_DATA
 * @def TAL_BM_CANMESSAGE_REMOTE
 *
 * @note Defines the specific type of a CAN message
 *
 */
#define TAL_BM_CANMESSAGE_DATA 0U
#define TAL_BM_CANMESSAGE_REMOTE 1U

/*
 * Macros to read/write the specific information of the QueueID
 * See class description of class TAL_CANMessageBase for details
 */

/* Shift and mask defines to access specific parts of the QueueID */
#define TAL_BM_CAN_SUBSCRIBE_HASHQUEUE (0x0U)
#define TAL_BM_CAN_SUBSCRIBE_FILTERQUEUE (0x1U)
#define TAL_BM_CAN_SUBSCRIBE_GLOBALQUEUE (0x2U)

#define TAL_BM_CAN_EXTENDED_ID_SHIFT (29U)
#define TAL_BM_CAN_SUBSCRIBE_ID_SHIFT (30U)

#define TAL_BM_CAN_MESSAGE_ID_MASK (0x1FFFFFFFUL)
#define TAL_BM_CAN_MESSAGE_INDEX_MASK (0x3FFFFFFFUL)
#define TAL_BM_CAN_FILTER_ID_MASK (0x000000FFUL)

/**
 * @brief Macro to create a QueueID for a single CAN message hash queue.
 *
 * @param msg_id    A CAN message ID (11 or 29 bit)
 * @param bExtended Boolean to set the message to a standard (TAL_FALSE)
 *                  or extended (TAL_TRUE) CAN ID.
 *
 * @retval QueueID for the single CAN message hash queue.
 *
 * @note Use this macro in the context of registering/unregistering
 *       a single CAN message hash queue
 *       or for sending a single CAN message
 *       or for receiving from a single CAN message hash queue
 *       in polling mode.
 *
 * @remark Use instead of deprecated macro CAN_GET_QUEUE_ID and CAN_GET_SEND_ID
 */
#define TAL_BM_CAN_QUEUE_ID(msg_id, bExtended)                                                                       \
    ((bExtended)                                                                                                     \
         ? (((msg_id)&TAL_BM_CAN_MESSAGE_ID_MASK) |                                                                  \
            (TAL_BM_CAN_SUBSCRIBE_HASHQUEUE << TAL_BM_CAN_SUBSCRIBE_ID_SHIFT) | (1 << TAL_BM_CAN_EXTENDED_ID_SHIFT)) \
         : (((msg_id)&TAL_BM_CAN_MESSAGE_ID_MASK) |                                                                  \
            (TAL_BM_CAN_SUBSCRIBE_HASHQUEUE << TAL_BM_CAN_SUBSCRIBE_ID_SHIFT)))

/**
 * @brief Macro to create a QueueID for a filter queue
 *
 * @param FilterNum Number of filter table which should be used.
 *                  The number must be smaller than the maximum number
 *                  of filter tables defined during initialization.
 *
 * @retval QueueID for the selected filter queue
 *
 * @note Use this macro only in the context of receiving from a CAN message
 *       filter queue in polling mode.
 *
 * @remark Use instead of deprecated macro CAN_GET_FILTER_QUEUE_ID
 */
#define TAL_BM_CAN_FILTER_QUEUE_ID(FilterNum) \
    (((FilterNum)&TAL_BM_CAN_FILTER_ID_MASK) | (TAL_BM_CAN_SUBSCRIBE_FILTERQUEUE << TAL_BM_CAN_SUBSCRIBE_ID_SHIFT))

/**
 * @brief Macro to create a QueueID for a CAN message when reading from
 *        the global queue (if global queue is activated).
 *
 * @retval QueueID for reading from the global queue.
 *
 * @note Use this macro only in the context of receiving from the CAN message
 *       global queue in polling mode.
 *
 * @remark Use instead of deprecated macro CAN_GET_GLOBAL_QUEUE_ID
 */
#define TAL_BM_CAN_GLOBAL_QUEUE_ID() (TAL_BM_CAN_SUBSCRIBE_GLOBALQUEUE << TAL_BM_CAN_SUBSCRIBE_ID_SHIFT)

/**
 * @brief Constant, defining the maximal number of LIN controllers used by
 *        Busmirror
 *
 * @def TAL_BM_MAX_NR_LIN_CTRL
 */
#define TAL_BM_MAX_NR_LIN_CTRL 4

/**
 * @brief The signal has not been received since power up.
 *
 * @note Do not use these macros directly, instead use #TAL_BM_GET_SIGNAL_STATUS_NO_MSG
 *
 * @sa TAL_BM_SignalStatusType
 */
#define TAL_BM_SIGNAL_STATUS_NO_MSG (1U << 2U)

/**
 *
 * @brief Macro for signal status information masking
 *
 * @note Do not use these macros directly, instead use #TAL_BM_GET_SIGNAL_STATUS_UPDATED
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_SIGNAL_STATUS_UPDATED (1U << 8U)

/**
 *
 * @brief Macro for signal status information masking
 *
 * @note Do not use these macros directly, instead use #TAL_BM_GET_SIGNAL_STATUS_SUBSCRIBED
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_SIGNAL_STATUS_SUBSCRIBED (1U << 9U)

/**
 *
 * @brief Macro for signal status information masking
 *
 * @note Do not use these macros directly, instead use #TAL_BM_GET_SIGNAL_STATUS_CRC_INVALID
 * @note Only valid if E2EChecker TUM is active
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_SIGNAL_STATUS_CRC_INVALID (1U << 11U)

/**
 *
 * @brief Macro for signal status information masking
 *
 * @note Do not use these macros directly, instead use #TAL_BM_GET_SIGNAL_STATUS_COUNTER_INVALID
 * @note Only valid if E2EChecker TUM is active
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_SIGNAL_STATUS_COUNTER_INVALID (1U << 12U)

/**
 *
 * @brief Macro for signal status information masking
 *
 * @note Do not use these macros directly, instead use #TAL_BM_GET_SIGNAL_STATUS_CHECK_ACTIVE
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_SIGNAL_STATUS_CHECK_ACTIVE (1U << 13U)

/**
 *
 * @brief Check if there is a valid value of the signal
 *
 * This macro returns 1 if the signal was never received
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_GET_SIGNAL_STATUS_NO_MSG(signalStatus) (((signalStatus)&TAL_BM_SIGNAL_STATUS_NO_MSG) >> 2U)

/**
 *
 * @brief Check if the signal was updated since the last reception
 *
 * This macro returns 1 if the signal was updated since it was last read
 * by the user
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_GET_SIGNAL_STATUS_UPDATED(signalStatus) (((signalStatus)&TAL_BM_SIGNAL_STATUS_UPDATED) >> 8U)

/**
 *
 * @brief Check if the user has subscribed the reception of the signal
 *
 * This macro returns 1 if the user has subscribed to the signal
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_GET_SIGNAL_STATUS_SUBSCRIBED(signalStatus) (((signalStatus)&TAL_BM_SIGNAL_STATUS_SUBSCRIBED) >> 9U)

/**
 *
 * @brief Check if a signals crc is invalid
 *
 * This macro returns 1 if the protecting e2e crc value was invalid
 *
 * @note Only valid if E2EChecker TUM is active
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_GET_SIGNAL_STATUS_CRC_INVALID(signalStatus) (((signalStatus)&TAL_BM_SIGNAL_STATUS_CRC_INVALID) >> 11U)

/**
 *
 * @brief Check if a signals counter is invalid
 *
 * This macro returns 1 if the protecting e2e counter value was invalid
 *
 * @note Only valid if E2EChecker TUM is active
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_GET_SIGNAL_STATUS_COUNTER_INVALID(signalStatus) \
    (((signalStatus)&TAL_BM_SIGNAL_STATUS_COUNTER_INVALID) >> 12U)

/**
 *
 * @brief Check if this signal is verified by the E2EChecker TUM
 *
 * This macro returns 1 if the E2EChecker TUM is enabled for this signal
 *
 * @sa TAL_BM_SignalStatusType
 *
 */
#define TAL_BM_GET_SIGNAL_STATUS_CHECK_ACTIVE(signalStatus) (((signalStatus)&TAL_BM_SIGNAL_STATUS_CHECK_ACTIVE) >> 13U)

/**
 *
 * @brief Macro for pdu status information masking
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note Do not use this macro directly, instead use #TAL_BM_GET_PDU_STATUS_REPETITION_TRUE_INVALID
 *
 * @sa TAL_BM_GET_PDU_STATUS_REPETITION_TRUE_INVALID
 */
#define TAL_BM_PDU_STATUS_REPETITION_TRUE_INVALID (1U)

/**
 *
 * @brief Macro for pdu status information masking
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note Do not use this macro directly, instead use #TAL_BM_GET_PDU_STATUS_TIMEPERIOD_TRUE_INVALID
 *
 * @sa TAL_BM_GET_PDU_STATUS_TIMEPERIOD_TRUE_INVALID
 */
#define TAL_BM_PDU_STATUS_TIMEPERIOD_TRUE_INVALID (1U << 1U)

/**
 *
 * @brief Macro for pdu status information masking
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note Do not use this macro directly, instead use #TAL_BM_GET_PDU_STATUS_REPETITION_FALSE_INVALID
 *
 * @sa TAL_BM_GET_PDU_STATUS_REPETITION_FALSE_INVALID
 */
#define TAL_BM_PDU_STATUS_REPETITION_FALSE_INVALID (1U << 2U)

/**
 *
 * @brief Macro for pdu status information masking
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note Do not use this macro directly, instead use #TAL_BM_GET_PDU_STATUS_TIMEPERIOD_FALSE_INVALID
 *
 * @sa TAL_BM_GET_PDU_STATUS_TIMEPERIOD_FALSE_INVALID
 */
#define TAL_BM_PDU_STATUS_TIMEPERIOD_FALSE_INVALID (1U << 3U)

/**
 *
 * @brief Macro for pdu status information masking
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note Do not use this macro directly, instead use #TAL_BM_GET_PDU_STATUS_MINIMUMDELAY_INVALID
 *
 * @sa TAL_BM_GET_PDU_STATUS_MINIMUMDELAY_INVALID
 */
#define TAL_BM_PDU_STATUS_MINDELAY_INVALID (1U << 4U)

/**
 *
 * @brief Macro for pdu status information masking
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note Do not use this macro directly, instead use #TAL_BM_GET_PDU_STATUS_STARTTIME_INVALID
 *
 * @sa TAL_BM_GET_PDU_STATUS_STARTTIME_INVALID
 */
#define TAL_BM_PDU_STATUS_STARTTIME_INVALID (1U << 5U)

/**
 *
 * @brief The PDU has not been received since power up.
 *
 * @note Do not use these macros directly, instead use #TAL_BM_GET_PDU_STATUS_NO_MSG
 *
 * @sa TAL_BM_PDUStatusType
 */
#define TAL_BM_PDU_STATUS_NO_MSG (1U << 6U)

/**
 *
 * @brief Macro for pdu status information masking
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note Do not use this macro directly, instead use #TAL_BM_GET_PDU_STATUS_CHECK_ACTIVE
 *
 * @sa TAL_BM_GET_PDU_STATUS_CHECK_ACTIVE
 */
#define TAL_BM_PDU_STATUS_CHECK_ACTIVE (1U << 7U)

/**
 *
 * @brief Check if the PDUs number of repetitions were violated (True timing).
 *
 * This macro returns 1 if the number of repetitions (True timing) were violated.
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note The PduTimingChecker TUM can not determine whether true or false timings
 * are active. Therefore false positives may occur.
 *
 * @sa TAL_BM_PDUStatusType
 * @sa TAL_BM_GET_PDU_STATUS_REPETITION_FALSE_INVALID
 *
 */
#define TAL_BM_GET_PDU_STATUS_REPETITION_TRUE_INVALID(pduStatus) ((pduStatus)&TAL_BM_PDU_STATUS_REPETITION_TRUE_INVALID)

/**
 *
 * @brief Check if the PDUs time period was violated (True timing).
 *
 * This macro returns 1 if the PDUs time period was violated (True timing).
 * This only applies to periodic or mixed PDUs.
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note The PduTimingChecker TUM can not determine whether true or false timings
 * are active. Therefore false positives may occur.
 *
 * @sa TAL_BM_PDUStatusType
 * @sa TAL_BM_GET_PDU_STATUS_TIMEPERIOD_FALSE_INVALID
 *
 */
#define TAL_BM_GET_PDU_STATUS_TIMEPERIOD_TRUE_INVALID(pduStatus) \
    (((pduStatus)&TAL_BM_PDU_STATUS_TIMEPERIOD_TRUE_INVALID) >> 1U)

/**
 *
 * @brief Check if the PDUs number of repetitions were violated (False timing).
 *
 * This macro returns 1 if the number of repetitions (False timing) were violated.
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note The PduTimingChecker TUM can not determine whether true or false timings
 * are active. Therefore false positives may occur.
 *
 * @sa TAL_BM_PDUStatusType
 * @sa TAL_BM_GET_PDU_STATUS_REPETITION_TRUE_INVALID
 *
 */
#define TAL_BM_GET_PDU_STATUS_REPETITION_FALSE_INVALID(pduStatus) \
    (((pduStatus)&TAL_BM_PDU_STATUS_REPETITION_FALSE_INVALID) >> 2U)

/**
 *
 * @brief Check if the PDUs time period was violated (False timing).
 *
 * This macro returns 1 if the PDUs time period was violated (False timing).
 * This only applies to periodic or mixed PDUs.
 *
 * @note Only supported if the PduTimingChecker TUM is used.
 * @note The PduTimingChecker TUM can not determine whether true or false timings
 * are active. Therefore false positives may occur.
 *
 * @sa TAL_BM_PDUStatusType
 * @sa TAL_BM_GET_PDU_STATUS_TIMEPERIOD_TRUE_INVALID
 *
 */
#define TAL_BM_GET_PDU_STATUS_TIMEPERIOD_FALSE_INVALID(pduStatus) \
    (((pduStatus)&TAL_BM_PDU_STATUS_TIMEPERIOD_FALSE_INVALID) >> 3U)

/**
 *
 * @brief Check if the PDUs violated its minimum delay.
 *
 * This macro returns 1 if the PDU violated its minimum delay.
 *
 * @sa TAL_BM_PDUStatusType
 * @note Only supported if the PduTimingChecker TUM is used.
 *
 */
#define TAL_BM_GET_PDU_STATUS_MINIMUMDELAY_INVALID(pduStatus) (((pduStatus)&TAL_BM_PDU_STATUS_MINDELAY_INVALID) >> 4U)

/**
 *
 * @brief The PDU was not received within its configured starting
 * time window
 *
 * This macro returns 1 if the PDU was not received within its
 * configured starting time window. See PduTimingChecker TUM
 * documentation for more details.
 *
 * @sa TAL_BM_PDUStatusType
 * @note Only supported if the PduTimingChecker TUM is used.
 *
 */
#define TAL_BM_GET_PDU_STATUS_STARTTIME_INVALID(pduStatus) (((pduStatus)&TAL_BM_PDU_STATUS_STARTTIME_INVALID) >> 5U)

/**
 *
 * @brief Check if there is a valid value of the PDU
 *
 * This macro returns 1 if the PDU was never received
 *
 * @sa TAL_BM_PDUStatusType
 *
 */
#define TAL_BM_GET_PDU_STATUS_NO_MSG(pduStatus) (((pduStatus)&TAL_BM_PDU_STATUS_NO_MSG) >> 6U)

/**
 *
 * @brief
 *
 * This macro returns 1 if the PDuTimingChecker verified the PDUs timing
 *
 * @sa TAL_BM_PDUStatusType
 * @note Only supported if the PduTimingChecker TUM is used.
 *
 */
#define TAL_BM_GET_PDU_STATUS_CHECK_ACTIVE(pduStatus) (((pduStatus)&TAL_BM_PDU_STATUS_CHECK_ACTIVE) >> 7U)

/**
 *
 * @brief The FlexRay frame was not received in time
 *
 * @note Do not use these macros directly, instead use #TAL_BM_GET_FRAME_STATUS_RX_TIMEOUT
 *
 * @sa TAL_BM_FrameStatusType
 */
#define TAL_BM_FRAME_STATUS_RX_TIMEOUT (1U << 1U)

/**
 *
 * @brief The FlexRay frame has not been received since power up.
 *
 * @note Do not use these macros directly, instead use #TAL_BM_GET_FRAME_STATUS_NO_MSG
 *
 * @sa TAL_BM_FrameStatusType
 */
#define TAL_BM_FRAME_STATUS_NO_MSG (1U << 2U)

/**
 *
 * @brief Check if there was a timeout receiving a FlexRay frame
 *
 * If this macro returns 1 a timeout on reception of a FlexRay frame occurred
 *
 * @sa TAL_BM_FrameStatusType
 *
 */
#define TAL_BM_GET_FRAME_STATUS_RX_TIMEOUT(frameStatus) (((frameStatus)&TAL_BM_FRAME_STATUS_RX_TIMEOUT) >> 1U)

/**
 *
 * @brief Check if there is a valid value of the FlexRay frame
 *
 * If this macro returns 1 the FlexRay frame was never received
 *
 * @sa TAL_BM_FrameStatusType
 *
 */
#define TAL_BM_GET_FRAME_STATUS_NO_MSG(frameStatus) (((frameStatus)&TAL_BM_FRAME_STATUS_NO_MSG) >> 2U)

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @brief Macros for compile time parametrisation of code
 *
 * Define for enabling and disabling of features on
 *  @li C-preprocessor level or
 *  @li C++ template explicit specialisation level
 * but both are evaluated at compile time.
 *
 */

/**
 * @def TAL_ON
 */
#define TAL_ON 1

/**
 * @def TAL_OFF
 */
#define TAL_OFF 0
/* @endcond */

/**
 *
 * @brief Maximum length of the version description text
 *
 * This macro defines the maximum length of the text phrase, describing a
 * specific version of a TAL software module.
 *
 * @sa TAL_VersionInfoType
 *
 */
#define BUSMIRROR_VERSION_DESCRIPTION_LENGTH 32

/**
 *
 * @brief Maximum length of the version variant description text
 *
 * This macro defines the maximum length of the text phrase, describing a
 * specific version variant of a TAL software module.
 *
 * @sa TAL_VersionInfoType
 *
 */
#define BUSMIRROR_VERSION_VARIANT_NAME_LENGTH 32

/**
 *
 * @brief Maximum length of the target hardware 'BoardID' description text
 *
 * This macro defines the maximum length of the text phrase, describing the
 * 'BoardID' of the target hardware
 *
 * @sa TAL_TargetHWInfoType
 *
 */
#define HW_INFO_BOARD_ID_LENGTH 16

/**
 *
 * @brief Maximum length of the target hardware 'MAC address' description text
 *
 * This macro defines the maximum length of the text phrase, describing the
 * 'MAC address' of the target hardware
 *
 * @sa TAL_TargetHWInfoType
 *
 */
#define HW_INFO_MAC_ADDR_LENGTH 20

/**
 *
 * @brief Maximum length of the target hardware 'Compact Flash Type'
 *        description text
 *
 * This macro defines the maximum length of the text phrase, describing the
 * 'Compact Flash Type' of the target hardware
 *
 * @sa TAL_TargetHWInfoType
 *
 */
#define HW_INFO_COMPACTFLASH_TYPE_LENGTH 128

/**
 *
 * @brief Maximum length of the target hardware 'Variant Name'
 *        description text
 *
 * This macro defines the maximum length of the text phrase, describing the
 * 'Variant Name' of the target hardware
 *
 * @sa TAL_TargetHWInfoType
 *
 */
#define HW_INFO_VARIANT_NAME_LENGTH 16

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @brief Type to store a communication cycle value
 *
 *  This scalar type defines a type for storing a communication cycle value.
 *  This type is only needed for labview rt API.
 *
 */
typedef uint8 TAL_CycleType;

/**
 *
 * @brief Enables a bulk erase for FPGA
 *
 * This macro enables bulk erasing an FPGA design
 *
 * @sa TAL_FirmwareUpdate
 *
 */
#define TAL_FWUP_BULKERASE (0x00000001UL)

/**
 *
 * @brief Disables reconfiguration after updating FPGA design
 *
 * This macro disables reconfiguration after updating FPGA design
 *
 * @sa TAL_FirmwareUpdate
 *
 */
#define TAL_FWUP_DISABLE_RECONFIGURATION (0x00000002UL)

/**
 *
 * @brief Force flag to bypass module configuration check for flashing
 * of FPGA designs
 *
 * This macro defines a force flag that bypasses the module configuration
 * check for flashing of FPGA designs
 *
 * @sa TAL_FirmwareUpdate
 *
 */
#define TAL_FWUP_FORCE (0x80000000UL)

/* @endcond */

#endif /* SWIG */

#define TAL_TDB_MAX_LABEL_LENGTH 255

/**
 * @cond INCLUDE_INTERNAL_CODE
 */

/*
 * Never use these macros directly. Use TAL_GetFrameIndex() instead.
 * Max. number of supported frame indices
 *
 * 2 Controllers
 * Message RAM per Controller: 4096 bytes
 * Minimal payload per frame-triggering: 8 bytes (worst-case assumption)
 * => 4096/8 = 512 Frame Triggerings per Controller
 *
 * A AUDI mlbevo schedule with local communication has ~50 Frame-triggerings
 * per controller (due to buffer optimizations).
 *
 * Dont change one parameter without the other!
 */
#define TAL_FRAME_INDEX_CC_SHIFT 9
#define TAL_FRAME_INDEX_FT_MASK 0x1FF
#define TAL_FRAME_INDEX_MAX 1024

/**
 * @endcond
 */

/**
 * @brief SOME/IP Message Type (8 bit) as coded in the message header
 */
#define TAL_SOMEIP_REQUEST 0x00
#define TAL_SOMEIP_REQUEST_NO_RETURN 0x01
#define TAL_SOMEIP_REQUEST_NOTIFICATION 0x02
#define TAL_SOMEIP_RESPONSE 0x80
#define TAL_SOMEIP_ERROR 0x81

/**
 * @brief SOME/IP Protocol version as coded in the message header
 */
#define TAL_SOMEIP_PROTOCOL_VERSION 0x01

/**
 * @brief SOME/IP Interface version as coded in the message header
 */
#define TAL_SOMEIP_INTERFACE_VERSION 0x01

/**
 *
 * @brief Macros for SOME/IP message type
 *
 */
/**
 * @brief SOME/IP number of nested elements supported, elements which
 * increase nesting level are: union, struct, fixed-array, var-array
 */
#define TAL_SOMEIP_MAX_NESTING_LEVEL 64

/**
 * @return returns a value of type TAL_SomeIpDataType
 */
#define TAL_SOMEIP_GET_DATA_TYPE(x) (((x)&0xF0000000UL) >> 28)

/**
 * @brief Only used for structs, fixed-arrays, var-arrays and unions. 0 for all other
 * types. For var-arrays this parameter is mandatory, which means that this
 * value must be greater than 0!
 *
 * @return returns either 0 (disabled), 1, 2, 3. 3 means 4 bytes length field!
 */
#define TAL_SOMEIP_GET_SIZE_LENGTH_FIELD(x) (((x)&0x00C00000UL) >> 22)

/**
 * @brief Only used for unions. 0 for all other types. For unions this parameter is
 * mandatory, which means that this value must be greater than 0.
 *
 * @return returns either 0 (disabled), 1, 2, 3. 3 means 4 bytes length field!
 */
#define TAL_SOMEIP_GET_SIZE_TYPE_FIELD(x) (((x)&0x00300000UL) >> 20)

/**
 * @brief Only used for basic types, determines endianess.
 *
 * @return returns 0x40000UL for big endian, 0 otherwise
 */
#define TAL_SOMEIP_IS_BIG_ENDIAN(x) ((x)&0x00040000UL)

/**
 * @brief Only used for basic types. If this bit is set either one, or two uint32's
 * with contains the invalid value follows.
 *
 * @return returns 0x20000UL if invalid value exists, 0 otherwise
 */
#define TAL_SOMEIP_HAS_INVALID_VALUE(x) ((x)&0x00020000UL)

/**
 * @brief Only set for last element of a root message. This shall be used to stop
 * parsing SOME/IP data elements at the right point.
 *
 * @return returns 0x10000UL, if it's a last element, 0 otherwise
 */
#define TAL_SOMEIP_IS_LAST_ELEMENT(x) ((x)&0x00010000UL)

/**
 * @brief Number of SOME/IP elements or bytes, depending on an element type.
 * For a string this means number of bytes.
 * For a struct this is the number of struct elements.
 * For a fixed-array this is the number of array elements.
 */
#define TAL_SOMEIP_GET_NELEMENTS(x) ((x)&0x0000FFFFUL)

/**
 *
 * @brief Creates the device option code for generic EBX2XX device option
 * Takes major and minor number of the protocol primitive to be sent as argument
 *
 */
#ifdef __cplusplus
#define DEVICE_OPTION_CODE(major, minor) \
    (((uint32)(TAL_Numbers::major) << 8U) | (uint32)(TAL_Numbers::minor))
#else /* __cplusplus */
#define DEVICE_OPTION_CODE(major, minor) \
    (((uint32)(major) << 8U) | (uint32)(minor))
#endif

/**
 *
 * @brief Type to store the index of a digital input/output pin
 *
 *  This scalar type defines a type to represent the index of a digital
 *  input/output pin.
 *
 */
typedef uint8 TAL_BM_DigitalIOPinIDType;

/**
 *
 * @brief Type to store the value of a digital input/output pin
 *
 *  This scalar type defines a type for represent the status of a digital
 *  input or output pin.
 *
 */
typedef uint8 TAL_BM_DigitalValueType;

/**
 *
 * @brief Index for EBxxxx devices.
 *
 * This type defines an index type for identifying EBxxxx devices.
 *
 */
typedef uint8 TAL_DeviceIndexType;

/**
 *
 * @brief Type to store a signal value in its physical presentation domain
 *
 *  This type is used to store a signal value in its physical presentation
 *  domain
 *
 */
typedef double TAL_BM_PhysicalSignalValueType;

/**
 *
 * @brief Transparent identifier for sessions.
 *
 *  This scalar type defines a transparent type for identifying sessions.
 *
 */
typedef TAL_PointerIntType TAL_SessionHandleType;

/**
 *
 * @brief Type to store an identifier for a specific user request
 *
 *  This scalar type defines a type for identifying a specific user request.
 *  The number is generated by the TAL and is used during the whole processing
 *  of the user request to identify the request.
 *
 */
typedef uint16 TAL_TransactionIDType;

/**
 *
 * @brief Type to store an error number
 *
 *  This scalar type defines a type for identifying an error.
 *  Values to use with this type can be found in file TAL_Errors.h.
 *
 */
typedef uint16 TAL_ErrnoType;

/**
 *
 * @brief Target Condition
 *
 *  This type holds the value of a specific target condition.
 *
 */
typedef uint8 TAL_ConditionType;

/**
 *
 * @brief Type to store an identifier for a specific target user module
 *
 *  This scalar type defines a type for identifying a specific target user
 *  module.
 *
 */
typedef uint16 TAL_TUM_IDType;

/**
 *
 * @brief Type to store an identifier for a specific instance of a target
 *        user module
 *
 * @sa TAL_TUM_ALL_INSTANCES_IDENTIFIER
 *
 *  This scalar type defines a type for identifying a specific instance
 *  of a target user module.
 *
 */
typedef uint16 TAL_TUM_InstanceIDType;

/**
 *
 * @brief Type to store an identifier for a specific signal
 *
 *  This scalar type defines a type for identifying a signal uniquely.
 *  The values are generated by the BUSMIRROR<CONFIG> tool.
 *
 */
typedef uint32 TAL_BM_SignalIndexType;

typedef uint8 TAL_BM_PDUUpdateBitType;

/**
 *
 * @brief Type to store status information of a signal
 *
 *  This scalar type defines a type for keeping status information of a signal.
 *  Different attributes are coded in distinct bit(s) and have to be
 *  checked by applying specific bit masks.
 *  Use the macros
 *  #TAL_BM_GET_SIGNAL_STATUS_NO_MSG ,
 *  #TAL_BM_GET_SIGNAL_STATUS_UPDATED ,
 *  #TAL_BM_GET_SIGNAL_STATUS_SUBSCRIBED ,
 *  #TAL_BM_GET_SIGNAL_STATUS_CRC_INVALID ,
 *  #TAL_BM_GET_SIGNAL_STATUS_COUNTER_INVALID and
 *  #TAL_BM_GET_SIGNAL_STATUS_CHECK_ACTIVE
 *  to gather the corresponding status
 *  information encoded into a value of this type.
 *
 */
typedef uint32 TAL_BM_SignalStatusType;

/**
 *
 * @brief Type to store status information of a PDU
 *
 *  This scalar type defines a type for keeping status information of a PDU.
 *  Different attributes are coded in distinct bit(s) and have to be
 *  checked by applying specific bit masks.
 *  Use the macros
 *  #TAL_BM_GET_PDU_STATUS_NO_MSG ,
 *  #TAL_BM_GET_PDU_STATUS_REPETITION_TRUE_INVALID ,
 *  #TAL_BM_GET_PDU_STATUS_TIMEPERIOD_TRUE_INVALID ,
 *  #TAL_BM_GET_PDU_STATUS_REPETITION_FALSE_INVALID ,
 *  #TAL_BM_GET_PDU_STATUS_TIMEPERIOD_FALSE_INVALID ,
 *  #TAL_BM_GET_PDU_STATUS_MINIMUMDELAY_INVALID ,
 *  #TAL_BM_GET_PDU_STATUS_STARTTIME_INVALID and
 *  #TAL_BM_GET_PDU_STATUS_CHECK_ACTIVE
 *  to gather the corresponding status
 *  information encoded into a value of this type.
 *
 */
typedef uint8 TAL_BM_PDUStatusType;

/**
 *
 * @brief Type to store status information of a FlexRay frame
 *
 *  This scalar type defines a type for keeping status information of a
 *  FlexRay frame.
 *  Different attributes are coded in distinct bit(s) and have to be
 *  checked by applying specific bit masks.
 *  Use the macros
 *  #TAL_BM_GET_FRAME_STATUS_NO_MSG and
 *  #TAL_BM_GET_FRAME_STATUS_RX_TIMEOUT
 *  to gather the corresponding status
 *  information encoded into a value of this type.
 *
 */
typedef uint8 TAL_BM_FrameStatusType;

/**
 *
 * @brief Type to store an identifier for a specific signal group
 *
 *  This scalar type defines a type for identifying a signal group uniquely.
 *  The values are generated by the BUSMIRROR<CONFIG> tool.
 *
 */
typedef uint32 TAL_BM_SignalGroupIndexType;

/**
 *
 * @brief Type to store an identifier for a frame
 *
 *  This scalar type defines a type for identifying a frame uniquely.
 *  The values are generated by the BUSMIRROR<CONFIG> tool.
 *
 * @remark use inline function @sa TAL_GetFrameIndex to assemble a frame index
 * out of controller index and frame triggering id (LPduIdx).
 *
 */
typedef uint16 TAL_BM_FrameIndexType;

/**
 *
 * @brief Type to store an identifier for a frame
 *
 *  This scalar type defines a type for identifying a service uniquely.
 *  The values are generated by the BUSMIRROR<CONFIG> tool.
 *
 */
typedef uint32 TAL_BM_ServiceIndexType;

/**
 *
 * @brief Assemble a frame index out of a controller index and a frame
 * triggering index (LPduIdx)
 *
 * To calculate the other way around use @sa TAL_GetFrameTriggering
 *
 * @param nCtrlIdx controller index of the FlexRay controller (busmirror has
 * 2 with default FPGA). The index is 0-based.
 *
 * @param nLPduIdx frame triggering index of AUTOSAR. It is also 0-based.
 * Use BMCfg.tdb to read out this parameter depending on your cluster.
 *
 * @return frame index
 *
 */
static TAL_INLINE TAL_BM_FrameIndexType TAL_GetFrameIndex(uint8 nCtrlIdx, uint16 nLPduIdx)

{
    return (nCtrlIdx << TAL_FRAME_INDEX_CC_SHIFT) | (nLPduIdx & TAL_FRAME_INDEX_FT_MASK);
}

#ifndef SWIG /* uint8* and uint16* problematic in swig wrapper */
/**
 *
 * @brief Assemble a controller index and a frame triggering index (LPduIdx)
 * to a frame index
 *
 * To calculate the other way around use @sa TAL_GetFrameIndex
 *
 * @param nFrameIndex frame index
 *
 * @param pCtrlIdx controller index of the FlexRay controller (busmirror has
 * 2 with default FPGA). The index is 0-based.
 *
 * @param pLPduIdx frame triggering index of AUTOSAR. It is also 0-based.
 * Use BMCfg.tdb to read out this parameter depending on your cluster.
 *
 */
static TAL_INLINE void TAL_GetFrameTriggering(TAL_BM_FrameIndexType nFrameIndex, uint8* pCtrlIdx, uint16* pLPduIdx)
{
    *pCtrlIdx = nFrameIndex >> TAL_FRAME_INDEX_CC_SHIFT;
    *pLPduIdx = nFrameIndex & TAL_FRAME_INDEX_FT_MASK;
}
#endif

/**
 *
 * @brief Type to store an identifier for a PDU
 *
 *  This scalar type defines a type for identifying a PDU uniquely.
 *  The values are generated by the BUSMIRROR<CONFIG> tool.
 *
 */
typedef uint16 TAL_BM_PDUIndexType;

/**
 *
 * @brief Type to store a CAN QueueID
 *
 *  This scalar type defines the CAN QueueID identifier.
 *
 */
typedef uint32 TAL_BM_CANMessageIDType;

/*
 * @cond EXCLUDE_FROM_DOCU
 */

/* Default: use deprecated enums in API for backward compatibility */
#define TAL_USE_DEPRECATED_ENUMS

/*
 * deprecated enum constants are not exported if the user compiles his
 * programs using TAL_DONT_USE_DEPRECATED_ENUMS
 */
#ifdef TAL_DONT_USE_DEPRECATED_ENUMS
#undef TAL_USE_DEPRECATED_ENUMS
#endif

/* Simplify the task for swig */
#ifdef SWIG
#undef TAL_USE_DEPRECATED_ENUMS
#endif

/*
 * @endcond
 */

/**
 *
 * @brief Type to store parameter for the digital IO sampling task on the target
 *
 *  This scalar type defines a type for represent the digital IO sampling mode
 *  of the target.
 *
 */
typedef enum
{
    TAL_DIO_SEND_EACH_SAMPLE = 0,
    TAL_DIO_SEND_WHEN_NEW_VALUE = 1,
    TAL_DIO_NO_AUTOMATIC_SAMPLING = 2
} TAL_BM_DigitalIOSampleParameterType;

/**
 *
 * @brief Identifiers for the data directions digital pins.
 *
 *  This enum type defines identifiers to specify the directions, how a
 *  digital pin can be used.
 *
 */
typedef enum
{
    TAL_DIO_IN = 0,
    TAL_DIO_OUT = 1
} TAL_BM_DigitalIODirectionType;

/**
 *
 * @brief This enumerator type is used for the FlexRay controller POC-state.
 *
 *  This enum type defines identifiers to specify the possible values of the
 *  Flexray controller POC state.
 */
typedef enum
{
    TAL_POCSTATE_CONFIG = 0
    /**< FlexRay Ctrl is in POC-state "config" */
    ,
    TAL_POCSTATE_DEFAULT_CONFIG = 1
    /**< FlexRay Ctrl is in POC-state "default" */
    ,
    TAL_POCSTATE_HALT = 2
    /**< FlexRay Ctrl is in POC-state "halt" */
    ,
    TAL_POCSTATE_NORMAL_ACTIVE = 3
    /**< FlexRay Ctrl is in POC-state "normal active" */
    ,
    TAL_POCSTATE_NORMAL_PASSIVE = 4
    /**< FlexRay Ctrl is in POC-state "normal passive" */
    ,
    TAL_POCSTATE_READY = 5
    /**< FlexRay Ctrl is in POC-state "ready" */
    ,
    TAL_POCSTATE_STARTUP = 6
    /**< FlexRay Ctrl is in POC-state "startup" */
    ,
    TAL_POCSTATE_WAKEUP = 7
    /**< FlexRay Ctrl is in POC-state "wakeup" */
    ,
    TAL_POCSTATE_MAX_VALUE = TAL_POCSTATE_WAKEUP
    /**< Used internally for asserting save casts. */
} TAL_POCStateType;

/**
 * @brief This enumerator type is used for the FlexRay controller slotmode.
 *
 *  This enum type defines identifiers to specify the possible values of the
 *  Flexray controller slot mode.
 */
typedef enum
{
    TAL_SLOTMODE_SINGLE = 0
    /**< FlexRay Ctrl is in "single-slot-mode" */
    ,
    TAL_SLOTMODE_ALL_PENDING = 1
    /**< FlexRay Ctrl is in "all-pending-slot-mode"*/
    ,
    TAL_SLOTMODE_ALL = 2
    /**< FlexRay Ctrl is in "all-slot-mode" */
    ,
    TAL_SLOTMODE_MAX_VALUE = TAL_SLOTMODE_ALL
    /**< Used internally for assertig save casts. */
} TAL_SlotModeType;

/**
 * @brief This enumerator type is used for the FlexRay controller errormode.
 *
 *  This enum type defines identifiers to specify the possible values of the
 *  Flexray controller error mode.
 */
typedef enum
{
    TAL_ERRORMODE_ACTIVE = 0
    /**< FlexRay Ctrl is in "active" errormode */
    ,
    TAL_ERRORMODE_PASSIVE = 1
    /**< FlexRay CtrAl is in "passive" errormode */
    ,
    TAL_ERRORMODE_COMM_HALT = 2
    /**< FlexRay Ctrl is in "comm halt" errormode */
    ,
    TAL_ERRORMODE_MAX_VALUE = TAL_ERRORMODE_COMM_HALT
    /**< Used internally for assertig save casts. */
} TAL_ErrorModeType;

/**
 * @brief This enumerator type is used for the FlexRay controller wakeup status.
 *
 *  This enum type defines identifiers to specify the possible values of the
 *  Flexray controller wakeupt status.
 */
typedef enum
{
    TAL_WAKEUP_UNDEFINED = 0
    /**< FlexRay Ctrl wakeup status is "undefined" */
    ,
    TAL_WAKEUP_RECEIVED_HEADER = 1
    /**< FlexRay Ctrl wakeup status is "received header" */
    ,
    TAL_WAKEUP_RECEIVED_WUP = 2
    /**< FlexRay Ctrl wakeup status is "received WUP" */
    ,
    TAL_WAKEUP_COLLISION_HEADER = 3
    /**< FlexRay Ctrl wakeup status is "collision header" */
    ,
    TAL_WAKEUP_COLLISION_WUP = 4
    /**< FlexRay Ctrl wakeup status is "collision WUP" */
    ,
    TAL_WAKEUP_COLLISION_UNKNOWN = 5
    /**< FlexRay Ctrl wakeup status is "collision unknown" */
    ,
    TAL_WAKEUP_TRANSMITTED = 6
    /**< FlexRay Ctrl wakeup status is "transmitted" */
    ,
    TAL_WAKEUP_MAX_VALUE = TAL_WAKEUP_TRANSMITTED
    /**< Used internally for assertig save casts. */
} TAL_WakeupStatusType;

/**
 * @brief This enumerator type is used for the FlexRay controller startup state.
 *
 *  This enum type defines identifiers to specify the possible values of the
 *  Flexray controller startup state.
 */
typedef enum
{
    TAL_STARTUP_UNDEFINED = 0
    /**< FlexRay Ctrl startup state is "undefined". */
    ,
    TAL_STARTUP_COLDSTART_LISTEN = 1
    /**< FlexRay Ctrl startup state is "coldstart listen". */
    ,
    TAL_STARTUP_INEGRATION_COLDSTART_CHECK = 2
    /**< FlexRay Ctrl startup state is "coldstart check". */
    ,
    TAL_STARTUP_COLDSTART_JOIN = 3
    /**< FlexRay Ctrl startup state is "coldstart join". */
    ,
    TAL_STARTUP_COLDSTART_COLLISION_RESOLUTION = 4
    /**< FlexRay Ctrl startup state is "coldstart collision resolution". */
    ,
    TAL_STARTUP_COLDSTART_CONSISTENCY_CHECK = 5
    /**< FlexRay Ctrl startup state is "coldstart consistency check". */
    ,
    TAL_STARTUP_INEGRATION_LISTEN = 6
    /**< FlexRay Ctrl startup state is "integration listen". */
    ,
    TAL_STARTUP_INITIALIZE_SCHEDULE = 7
    /**< FlexRay Ctrl startup state is "initialize schedule". */
    ,
    TAL_STARTUP_INEGRATION_CONSISTENCY_CHECK = 8
    /**< FlexRay Ctrl startup state is "integration consistency check". */
    ,
    TAL_STARTUP_COLDSTART_GAP = 9
    /**< FlexRay Ctrl startup state is "coldstart gap". */
    ,
    TAL_STARTUP_MAX_VALUE = TAL_STARTUP_COLDSTART_GAP
    /**< Used internally for assertig save casts. */
} TAL_StartupStateType;

/**
 *
 * @brief Enum for all known connections types
 *
 *    This enum defines all supported connections for hardware devices
 *    supported by the TAL. It is preferred that you use either TAL_USB,
 *    TAL_PCI or TAL_TCP.
 *
 */
typedef enum
{
    TAL_USB = 0 /**< USB connection to target device */
    ,
    TAL_PCI = 3 /**< PCI connection to target device */
    ,
    TAL_TCP = 4 /**<TCP connection to target device */
    ,
    TAL_UDP = 5 /**<UDP connection to target device */
    ,
    TAL_DUMMY = 6 /**< connection to dummy device */
    ,
    TAL_UNKNOWN = 7 /**< unknown connection type */
} TAL_ConnectionType;

/**
 *
 * @brief Synonym for TAL_ConnectionType, primarily needed for
 *        backward compatibility
 *
 */
typedef TAL_ConnectionType TAL_DeviceHardwareType;

/**
 *
 * @brief Enum for all known hardware devices
 *
 *    This enum defines all supported hardware types.
 */
typedef enum
{
    TAL_HW_UNKNOWN = 0 /**< hardware type unknown */
    ,
    TAL_EBX200 = 4 /**< EBX200; preferred type for all EBX200 devices */
    ,
    TAL_EB2200 = 5 /**< EB2200 device */
    ,
    TAL_EB5200 = 6 /**< EB5200 PCIe card */
    ,
    TAL_EB72XX = 8 /**< EB72XX; used for both EB7200 and EB7210 */
    ,
    TAL_EB82XX = 9 /**< EB82XX; used for both EB8200 and EB8210 */
/* @cond EXCLUDE_FROM_DOCU */
#ifdef TAL_USE_DEPRECATED_ENUMS
    ,
    TAL_EB7200 = TAL_EB72XX /**< deprecated: used for EB7200 PCIe card */
    ,
    TAL_EB8200 = TAL_EB82XX /**< deprecated: used for EB8200 PCIe card */
#endif
    /* @endcond */
    ,
    TAL_EBVIRT = 10 /**< EB Virtual Bus */
    ,
    TAL_EBX3 = 11 /**< EBX3 device */
} TAL_HardwareType;

/**
 *
 * @brief Identifiers for physical signal status.
 *
 *  This enum type defines identifiers to interpret physical signals.
 *
 */
typedef enum
{
    TAL_INVALID = 0
    /**< the invalid value was received */
    ,
    TAL_SYMBOL = 1
    /**< a symbol was received */
    ,
    TAL_VALUE = 2
    /**< a value was received */
    ,
    TAL_MIXED = 3
    /**< a symbol and a value was received */
    ,
    TAL_NO_CONV_FUNC = 4
    /**< no conversion function is defined */
    ,
    TAL_OUT_OF_RANGE = 5
    /**< value not covered by conversion function */
} TAL_BM_PhysicalSignalStatusType;

/**
 *
 * @brief Type to store network types
 *
 * This enum defines identifiers of the available networks
 *
 */
typedef enum
{
    TAL_BM_NW_RBS = 0
    /**< the complete busmirror residual bus simulation */
    ,
    TAL_BM_NW_CAN_0_MSGIF = 3
    /**< the message based CAN interface for controller 0. Don't use this for
     **  CAN controllers used by RBS. Use TAL_BM_NW_RBS! */
    ,
    TAL_BM_NW_CAN_1_MSGIF = 4
    /**< the message based CAN interface for controller 1. Don't use this for
     **  CAN controllers used by RBS. Use TAL_BM_NW_RBS! */
    ,
    TAL_BM_NW_CAN_2_MSGIF = 5
    /**< the message based CAN interface for controller 2. Don't use this for
     **  CAN controllers used by RBS. Use TAL_BM_NW_RBS! */
    ,
    TAL_BM_NW_CAN_3_MSGIF = 6
    /**< the message based CAN interface for controller 3. Don't use this for
     **  CAN controllers used by RBS. Use TAL_BM_NW_RBS! */
    ,
    TAL_BM_NW_CAN_4_MSGIF = 10
    /**< the message based CAN interface for controller 4. Don't use this for
     **  CAN controllers used by RBS. Use TAL_BM_NW_RBS! */
    ,
    TAL_BM_NW_CAN_5_MSGIF = 11
    /**< the message based CAN interface for controller 5. Don't use this for
     **  CAN controllers used by RBS. Use TAL_BM_NW_RBS! */
    ,
    TAL_BM_NW_UNKNOWN = 100
    /**< Unknown network - used for variable initialisation */
} TAL_BM_NetworkType;

/**
 *
 * @brief Identifiers for notification types upon signal reception
 *
 *  This enum type defines identifiers to specify the sort of notifications
 *  which has to be triggered after receiving a signal.
 *
 */
typedef enum
{
    TAL_SIGNAL_RECEIVED = 0
    /**< New signal value present. Callback (if one is registered) is called
     * for valid and invalid signal values. */
    ,
    TAL_SIGNAL_CHANGED = 1
    /**< New and old signal value are different. Not supported any more. Can
     * easily be made within application. */
} TAL_BM_RecvSignalNotificationType;

/**
 *
 * @brief Identifiers for the receive type of the PDU
 *
 *  This enum type defines identifiers for the type of how the PDU should be updated
 *  within the TAL
 *
 */
typedef enum
{
    TAL_PDU_ALWAYS = 0
    /**< PDU is always sent to the host after reception from the BUS.
     *   This option is only supported for Firmware Revisions prior to 4.x.
     *   As of Busmirror Firmware Revision 4.x please use TAL_PDU_UPDATED
     *   instead. */
    ,
    TAL_PDU_UPDATED = 1
    /**< PDU is only sent when Updatebit is set */
    ,
    TAL_PDU_STATUS = 2
    /**< If Updatebit is not set, the Data of the PDU is ignored, but the
     * Status is updated at the host.
     * This option is only supported for Firmware Revisions prior to 4.x.
     * As of Busmirror Firmware Revision 4.x please use TAL_PDU_UPDATED
     * instead. */
} TAL_BM_RecvPduNotificationType;

/**
 *
 * @brief Identifiers for the send behavior type of the PDU
 *
 *  This enum type defines identifiers for the type of how the PDU should be updated
 *  on the Bus when sent.
 *
 */
typedef enum
{
    TAL_SEND_PDU_ONCE = 0
    /**< PDU is sent once with set Updatebit, later the PDU is assembled from
     * signals again. Additionally triggers the sending of the PDU once - i.e.
     * to trigger the sending of event based timings */
    ,
    TAL_SEND_PDU_ALWAYS = 1
    /**< PDU is sent continuously with set Updatebit until TAL_STOP_PDU is
     * used. */
    /* @cond EXCLUDE_FROM_DOCU */
    /** @deprecated use TAL_SEND_PDU_ONCE **/
    ,
    TAL_UPDATE_PDU_ONCE = 2
    /**< PDU is sent once with set Updatebit, later the PDU is assembled from
     * signals again. */
    /* @endcond */
    ,
    TAL_STOP_PDU = 3
    /**< Stops the continuously sending of PDUs after a call to
     * TAL_SEND_PDU_ALWAYS. Pdus are packed from signals again after this
     * call. */

    /*
     * ATTENTION: see TAL_BM_SendPduUpdateInternalType if you want to add enum
     * values. A cast is used to hide internal implementation details from API
     */
} TAL_BM_SendPduUpdateType;

/**
 *
 * @brief Identifiers for methods, how to represent a disabled frame
 *
 *  This enum type defines identifiers to specify the methods, how a disabled
 *  shall be represented on the bus.
 *
 */
typedef enum
{
    TAL_NULL_FRAME = 0
    /**< Generate a "null frame" */
    ,
    TAL_DISAPPEAR = 1
    /**< The frame disappears from the bus */
    ,
    TAL_DISABLE_FRAME_MAX_VALUE = TAL_DISAPPEAR
    /**< Used internally for asserting save casts. */
} TAL_BM_DisabledFrameMethodType;

/**
 *
 * @brief Identifiers for selection of FlexRay bus channels
 *
 * This enum type defines identifiers to specify the channels of a FlexRay bus.
 *
 */
typedef enum
{
    TAL_CHANNEL_A = 0 /**< Channel A */
    ,
    TAL_CHANNEL_B = 1 /**< Channel B */
    ,
    TAL_CHANNEL_AB = 2 /**< Channel A and B */
    ,
    TAL_CHANNEL_NONE = 3 /**< all channels disabled */
    ,
    TAL_CHANNEL_AA = 4 /**< Channel A and A (dual single channel monitoring) */
} TAL_FRChannelType;
/* @cond EXCLUDE_FROM_DOCU */
typedef uint8 TAL_ScalarFRChannelType;
/* @endcond */

/**
 *
 * @brief Identifiers for selection of transfer direction
 *
 * This enum type defines identifiers to specify the transfer
 * direction of a buffer.
 *
 */
typedef enum
{
    TAL_BUF_RECV = 0
    /**< Transfer direction of FlexRay Buffer is receive */
    ,
    TAL_BUF_SEND = 1
    /**< Transfer direction of FlexRay Buffer is send */
} TAL_FRTransferDirectionType;
/* @cond EXCLUDE_FROM_DOCU */
typedef uint8 TAL_ScalarFRTransferDirectionType;
/* @endcond */

/**
 *
 * @brief Identifiers for selection of the transmission mode
 *        of a FlexRay buffer.
 *
 * This enum type defines identifiers to specify the transmission
 * mode of a FlexRay buffer.
 *
 */
typedef enum
{
    TAL_BUF_SINGLE_SHOT = 0
    /**< Single shot buffer mode (EVENT) */
    ,
    TAL_BUF_CONTINUOUS = 1
    /**< Continuous buffer mode (STATE) */
} TAL_FRTransmissionModeType;
/* @cond EXCLUDE_FROM_DOCU */
typedef uint8 TAL_ScalarFRTransmissionModeType;
/* @endcond */

/**
 *
 * @brief Identifiers for selection of the Key-Slot mode
 *        of a FlexRay controller.
 *
 * This enum type defines identifiers to specify the Key-Slot
 * mode of a FlexRay controller.
 *
 */
typedef enum
{
    TAL_KEYSLOT_NOCOLDSTART_NOSYNC = 1
    /**< Node is neither sync or coldstart node */
    ,
    TAL_KEYSLOT_NOCOLDSTART_SYNC = 2
    /**< Node is only a sync node */
    ,
    TAL_KEYSLOT_COLDSTARTLEADING_SYNC = 3
    /**< Node is leading coldstarter and sync node */
    ,
    TAL_KEYSLOT_COLDSTARTFOLLOWING_SYNC = 4
    /**< Node is following coldstarter and sync node */
} TAL_FRKeySlotModeType;
/* @cond EXCLUDE_FROM_DOCU */
typedef uint8 TAL_ScalarFRKeySlotModeType;
/* @endcond */

/**
 * @brief Enumeration for received CAN events
 *
 * Event types for received CAN events.
 * A combination of the event type values is allowed.
 */
typedef enum
{
    TAL_BM_CAN_EVENT_RX = 0x00000001
    /**< message received */
    ,
    TAL_BM_CAN_EVENT_TX = 0x00000002
    /**< message transmitted */
    ,
    TAL_BM_CAN_EVENT_WARNING_RX = 0x00000004
    /**< tx error counter reached warning level (>96) */
    ,
    TAL_BM_CAN_EVENT_WARNING_TX = 0x00000008
    /**< rx error counter reached warning level (>96) */
    ,
    TAL_BM_CAN_EVENT_ERR_PASSIVE = 0x00000010
    /**< CAN "error passive" occurred */
    ,
    TAL_BM_CAN_EVENT_BUS_OFF = 0x00000020
    /**< CAN "bus off" error occurred */
    ,
    TAL_BM_CAN_EVENT_OVERRUN_RX = 0x00000040
    /**< overrun in RX queue or hardware occurred */
    ,
    TAL_BM_CAN_EVENT_OVERRUN_TX = 0x00000080
    /**< overrun in TX queue occurred */
    ,
    TAL_BM_CAN_EVENT_CAN_ERR = 0x00000100
    /**< a CAN bit or frame error occurred */
    ,
    TAL_BM_CAN_EVENT_LEAVING_STANDBY = 0x00000200
    /**< CAN hardware leaves standby power down mode or is waked up */
    ,
    TAL_BM_CAN_EVENT_ENTERING_STANDBY = 0x00000400
    /**< CAN hardware enters standby / power down mode */
    ,
    TAL_BM_CAN_EVENT_ARBITRATION_LOST = 0x00000800
    /**< arbitration lost */
    ,
    TAL_BM_CAN_EVENT_DEVICE_CHANGED = 0x00001000
    /**< device changed event */
    ,
    TAL_BM_CAN_EVENT_PHY_FAULT = 0x00002000
    /**< General failure of physical layer detected */
    ,
    TAL_BM_CAN_EVENT_PHY_H = 0x00004000
    /**< Fault on CAN-H detected (Low Speed CAN) */
    ,
    TAL_BM_CAN_EVENT_PHY_L = 0x00008000
    /**< Fault on CAN-L detected (Low Speed CAN) */
    ,
    TAL_BM_CAN_EVENT_TX_ABORT = 0x00010000
    /**< message transmission aborted */
    ,
    TAL_BM_CAN_EVENT_ACTIVE = 0x00020000
    /**< all OK on CAN bus no errors detected */
    ,
    TAL_BM_CAN_EVENT_TX_TIMED_ERR_DELAY = 0x00040000
    /**< time triggered send: buffer was enabled after the configured timestamp */
    ,
    TAL_BM_CAN_EVENT_TX_TIMED_ERR_BLOCKED = 0x00080000
    /**< time triggered send: CAN bus blocked or arbitration lost */
    ,
    TAL_BM_CAN_EVENT_TX_TIMED_ERR_BUSY = 0x00100000
    /**< time triggered send: CAN controller was busy */
    ,
    TAL_BM_CAN_EVENT_TX_TIMED_ERR_WINDOW = 0x00200000
    /**< time triggered send: transmission time window violated */
    ,
    TAL_BM_CAN_EVENT_TX_TIMED_BUF_ALMOST_FULL = 0x00400000
    /**< time triggered send: Buffer almost full (Filllevel > 7168) */
    ,
    TAL_BM_CAN_EVENT_TX_TIMED_BUF_FREE = 0x00800000
    /**< time triggered send: Buffer space available (Filllevel < 6144) */
} TAL_BM_CANEventFlagsType;
/* @cond EXCLUDE_FROM_DOCU */
typedef uint16 TAL_BM_ScalarCANEventFlagsType;
/* @endcond */

/**
 *
 * @brief Enumeration for CAN event (message) status
 *
 *  This enum type defines the possible status of CAN events (messages).
 *
 */
typedef enum
{
    TAL_BM_CAN_MSG_STAT_UNKNOWN = 0
    /**< no status known about CAN message */
    ,
    TAL_BM_CAN_MSG_STAT_RX = 1
    /**< is a received CAN message */
    ,
    TAL_BM_CAN_MSG_STAT_TX_INTERNAL_ERROR = 2
    /**< is a CAN Tx confirmation - internal CANLIB error occurred during CAN
     * message transmission */
    ,
    TAL_BM_CAN_MSG_STAT_TX_QUEUE_FULL = 3
    /**< is a CAN Tx confirmation - Low-level Tx FIFO is full CAN Tx message
     * not written to FIFO */
    ,
    TAL_BM_CAN_MSG_STAT_TX_SENT = 4
    /**< is a CAN Tx confirmation CAN Tx message was sent successfully on the
     * CAN bus */
} TAL_BM_CANMessageStatusType;
/* @cond EXCLUDE_FROM_DOCU */
typedef uint8 TAL_BM_ScalarCANMessageStatusType;
/* @endcond */

/**
 *
 * @brief Enumeration for CAN message type
 *
 *  This enum type defines the CAN message type.
 *
 */
typedef enum
{
    TAL_BM_CANMSGTYPE_DATA = 0
    /**< defines a CAN data message */
    ,
    TAL_BM_CANMSGTYPE_REMOTE = 1
    /**< defines a CAN remote message */
    ,
    TAL_BM_CANMSGTYPE_FD_DATA = 2
    /**< defines a CAN-FD message without bit rate switching */
    ,
    TAL_BM_CANMSGTYPE_FD_DATA_BRS = 3
    /**< defines a CAN-FD message with bit rate switching */
    ,
    TAL_BM_CANMSGTYPE_UNKNOWN = 4
    /**< CAN message type unknown */
} TAL_BM_CANMsgTypeType;
/* @cond EXCLUDE_FROM_DOCU */
typedef uint8 TAL_BM_ScalarCANMsgTypeType;
/* @endcond */

/**
 *
 * @brief Enumeration for speed of Ethernet network (controller)
 *
 *  This enum type defines identifiers to select the speed of an Ethernet
 *  network (controller).
 */
typedef enum
{
    TAL_BM_ETH_SPEED_10_MBPS = 0
    /**< 10 MBit/sec */
    ,
    TAL_BM_ETH_SPEED_100_MBPS = 1
    /**< 100 MBit/sec */
    ,
    TAL_BM_ETH_SPEED_1000_MBPS = 2
    /**< 1 GBit/sec */
    ,
    TAL_BM_ETH_SPEED_AN = 255
    /** speed (and duplex mode) shall be determined using auto negotiation (if possible) */
} TAL_BM_EthBaudRateType;

/**
 *
 * @brief Enumeration for duplex mode of Ethernet network (controller)
 *
 *  This enum type defines identifiers to select the duplex mode of an Ethernet
 *  network (controller).
 */
typedef enum
{
    TAL_BM_ETH_DUPLEX_HALF = 0
    /**< half duplex mode */
    ,
    TAL_BM_ETH_DUPLEX_FULL = 1
    /**< full duplex mode */
} TAL_BM_EthDuplexType;

/**
 *
 * @brief Enumeration for flags of Ethernet network (controller)
 *
 *  Flags for configuration of an Ethernet
 *  network (controller).
 */
typedef enum
{
    TAL_BM_ETH_FLAG_DEFAULT_MODE = 0x00000000
    /**< Default mode (determine from transceiver revision / link partner) */
    ,
    TAL_BM_ETH_FLAG_A0_MODE = 0x00000001
    /**< A0 compatibility mode */
    ,
    TAL_BM_ETH_FLAG_A2_MODE = 0x00000002
    /**<Force A2 mode */
    ,
    /* @cond EXCLUDE_FROM_DOCU */
    TAL_BM_ETH_FLAG_DISABLE_PASSTHROUGH = 0x00000004
    /**<Disable pass-through to other port (only for EB1235).
     * Note: Versions < 4.19.3 have pass-through enabled by default. */
    /** @deprecated use bBack2Back of TAL_InspConfigureEth **/
    /* @endcond */
    ,
    TAL_BM_ETH_FLAG_DISABLE_CAPTURE = 0x00000008
    /**<Disable capture to host on given port (only for EB1235) */
    ,
    /* @cond EXCLUDE_FROM_DOCU */
    TAL_BM_ETH_FLAG_ENABLE_PASSTHROUGH = 0x00000010
    /**<Enable pass-through to other port (only for EB1235).
     * Note: Since 4.19.3 pass-through is disabled by default. */
    /** @deprecated use bBack2Back of TAL_InspConfigureEth **/
    /* @endcond */
    ,
    TAL_BM_ETH_FLAG_DISABLE_TX_LOGGING = 0x00000020
    /**< Disable TX logging, otherwise TX logging is enabled by default. */
} TAL_BM_EthFlags;

/**
 * @brief Enumeration for TAL events
 *
 *  This enum type defines a TAL event type.
 */
typedef enum
{
    TAL_EVENT_SIGNAL = 0,
    TAL_EVENT_SIGNAL_GROUP = 1,
    TAL_EVENT_PDU = 2,
    TAL_EVENT_CAN = 3,
    TAL_EVENT_DIO = 4,
    TAL_EVENT_TUM = 5,
    TAL_EVENT_POC = 6,
    TAL_EVENT_CPU = 7,
    TAL_EVENT_RAM = 8,
    TAL_EVENT_LIN = 9,
    TAL_EVENT_UNKNOWN = 10,
    TAL_EVENT_FRAME = 11,
    TAL_EVENT_SD = 12,
    TAL_EVENT_MAX_VALUE = 13
} TAL_EventType;

/**
 * @brief Enumeration for the FlexRay physical layer types
 *
 *  This enum type defines the possible FlexRay physical layer
 *  which can be used
 */
typedef enum
{
    TAL_PHYSICAL_LAYER_TYPE_UNKNOWN = 0 /**< Physical Layer type Unknown    */
    ,
    TAL_PHYSICAL_LAYER_TYPE_TJA1080 = 1 /**< Physical Layer type is TJA1080 */
    ,
    TAL_PHYSICAL_LAYER_TYPE_RS485 = 2 /**< Physical Layer type is RS485   */
} TAL_PhysicalLayerType;

/**
 *
 * @brief Identifiers for the sent behavior type of the Frame
 *
 *  This enum type defines identifiers for the type of how the Frame should be updated
 *  on the Bus when sent.
 *
 */
typedef enum
{
    TAL_SEND_FRAME_ONCE = 0
    /**< Frame is sent once */
    ,
    TAL_SEND_FRAME_ALWAYS = 1
    /**< Frame is sent continuously */
    ,
    TAL_STOP_FRAME = 3
    /**< Stops the continuously sending of the Frame */
} TAL_BM_SendFrameConditionType;

/**
 * @brief Option bitfield for initialisation of FlexRay timed send functionality
 *
 * @note Set options by OR-ing a subset of the following values:
 *       - TAL_FRAME_TIMED_SEND_ONLY
 *
 * @sa TAL_FRAME_TIMED_SEND_ONLY
 */
typedef uint32 TAL_FrameTimedOptionType;

/**
 * @cond EXCLUDE_FROM_DOCU
 *
 * @brief Enumeration for Inspector measurement timebase
 *
 *  This enum type defines the different timebases which
 *  can be selected as input for the measurement controller.
 */
typedef enum
{
    TAL_FPGA_TIMEBASE_FREE_RUNNING_LEGACY = 0
    /**< Uses the measurement controller (MCTRL) internal 32 bit free running 25ns timer; deprecated use TAL_FPGA_TIMEBASE_FREE_RUNNING instead */
    ,
    TAL_FPGA_TIMEBASE_FR_MACROTICK_MASTER = 1
    /**< Uses the FlexRay Macrotick Master */
    ,
    TAL_FPGA_TIMEBASE_FR_MACROTICK_SLAVE = 2
    /**< Uses the first channel slave timestamp; deprecated use either TAL_FPGA_TIMEBASE_FR_MACROTICK_SLAVE_CH1 or TAL_FPGA_TIMEBASE_FR_MACROTICK_SLAVE_CH2 instead */
    ,
    TAL_FPGA_TIMEBASE_GPS = 3
    /**< Uses the GPS timebase (continuous corrected 25ns); deprecated use TAL_FPGA_TIMEBASE_GPS_UTC_MASTER instead */
    ,
    TAL_FPGA_TIMEBASE_FREE_RUNNING = 4
    /**< Uses a free running 64 bit 25ns timer */
    ,
    TAL_FPGA_TIMEBASE_GPS_UTC_MASTER = 5
    /**< Uses the GPS Master timebase (UTC sec., usec., ticks) */
    ,
    TAL_FPGA_TIMEBASE_GPS_UTC_SLAVE = 6
    /**< Uses the GPS Slave timebase (UTC sec., usec., ticks) */
    ,
    TAL_FPGA_TIMEBASE_FR_MACROTICK_SLAVE_CH1 = 7
    /**< Use the FlexRay Macrotick slave timestamp from channel 1 */
    ,
    TAL_FPGA_TIMEBASE_FR_MACROTICK_SLAVE_CH2 = 8
    /**< Use the FlexRay Macrotick slave timestamp from channel 2 */
    ,
    TAL_FPGA_TIMEBASE_GPS_UTC_SLAVE_CH1 = 9
    /**< Use the GPS timestamp (UTC sec, usec. ticks) slave timestamp from channel 1 */
    ,
    TAL_FPGA_TIMEBASE_GPS_UTC_SLAVE_CH2 = 10
    /**< Use the GPS timestamp (UTC sec, usec. ticks) slave timestamp from channel 2 */
    ,
    TAL_FPGA_TIMEBASE_BPLUS_SLAVE_CH1 = 11
    /**< Uses the b-plus slave ns timebase received from eb7200 from channel 1*/
    ,
    TAL_FPGA_TIMEBASE_BPLUS_SLAVE_CH2 = 12
    /**< Uses the b-plus slave ns timebase received from eb7200 from channel 2*/
    ,
    TAL_FPGA_TIMEBASE_EB_TIME_MASTER = 13
    /**< Uses the eb time master ns timebase (most significant 3 bits: 100) */
    ,
    TAL_FPGA_TIMEBASE_UNKNOWN = 14
    /**< Timebase is unknown */
} TAL_TimebaseSelectType;

typedef uint8 TAL_ScalarTimebaseSelectType;

typedef TAL_TimebaseSelectType TAL_InspTimebaseSelectType;
/* @endcond */

/**
 * @cond EXCLUDE_FROM_DOCU
 * @brief Option bitfield for selecting the inspector TAL packet format
 *
 * @note Set options by OR-ing a subset of the following values:
 *       - TAL_INSP_PACKET_FORMAT_DUAL_TIMESTAMP
 *       - TAL_INSP_PACKET_FORMAT_ATS2_TIMESTAMP
 *
 * @sa TAL_INSP_PACKET_FORMAT_DUAL_TIMESTAMP
 * @sa TAL_INSP_PACKET_FORMAT_ATS2_TIMESTAMP
 */
/* Note: don't use unsigned constants since otherwise Java wrapper fails to build */
typedef uint32 TAL_ScalarInspPacketFormatMaskType;

/**
 * @brief Set dual timestamp format (start + end) for inspector packets
 *
 * @sa TAL_ScalarInspPacketFormatMaskType
 */
#define TAL_INSP_PACKET_FORMAT_DUAL_TIMESTAMP 0x00000001

/**
 * @brief Set ATS2 timestamp format (second timestamp pair) for inspector packets
 *
 * @sa TAL_ScalarInspPacketFormatMaskType
 */
#define TAL_INSP_PACKET_FORMAT_ATS2_TIMESTAMP 0x00000002
/* @endcond */

/**
 * @cond EXCLUDE_FROM_DOCU
 * @brief Inspector timestamp format
 *
 * @note Use one of the following values:
 *       - TAL_INSP_TIMESTAMP_FORMAT_25NS
 *       - TAL_INSP_TIMESTAMP_FORMAT_FR_MACROTICK
 *       - TAL_INSP_TIMESTAMP_FORMAT_GPS_UTC
 *       - TAL_INSP_TIMESTAMP_FORMAT_UNKNOWN
 *       - TAL_INSP_TIMESTAMP_FORMAT_NS
 *
 * @sa TAL_INSP_TIMESTAMP_FORMAT_25NS
 * @sa TAL_INSP_TIMESTAMP_FORMAT_FR_MACROTICK
 * @sa TAL_INSP_TIMESTAMP_FORMAT_GPS_UTC
 * @sa TAL_INSP_TIMESTAMP_FORMAT_UNKNOWN
 * @sa TAL_INSP_TIMESTAMP_FORMAT_NS
 */
typedef uint8 TAL_ScalarInspTimestampFormat;

/**
 * @brief Timestamp format is a continuous 25ns counter
 *
 * @sa TAL_ScalarInspTimestampFormat
 */
#define TAL_INSP_TIMESTAMP_FORMAT_25NS 0x00

/**
 * @brief Timestamp format is FlexRay macrotick based
 *
 * @sa TAL_ScalarInspTimestampFormat
 */
#define TAL_INSP_TIMESTAMP_FORMAT_FR_MACROTICK 0x01

/**
 * @brief Timestamp format is GPS UTC
 *
 * @sa TAL_ScalarInspTimestampFormat
 */
#define TAL_INSP_TIMESTAMP_FORMAT_GPS_UTC 0x02

/**
 * @brief Timestamp format is unknown
 *
 * @sa TAL_ScalarInspTimestampFormat
 */
#define TAL_INSP_TIMESTAMP_FORMAT_UNKNOWN 0x03

/**
 * @brief Timestamp format is a ns counter
 *
 * @sa TAL_ScalarInspTimestampFormat
 */
#define TAL_INSP_TIMESTAMP_FORMAT_NS 0x04
/* @endcond */

/*
 * Typedefs and structs which should be hidden from scripting API goes in
 * here. They are used during C++ compilation but not needed in scripting
 * code. So they are hidden to avoid confusing the user.
 */
#ifndef SWIG

/**
 * @brief Enumeration for various CAN related options
 *
 *  This enum type defines various options to control the
 *  behaviour of related CAN functions.
 */
typedef enum
{
    TAL_BM_CAN_OPT_UNUSED = 0
    /**< option has no effect - does nothing */
} TAL_BM_CANOptionType;
/* @cond EXCLUDE_FROM_DOCU */
typedef uint16 TAL_BM_ScalarCANOptionType;
/* @endcond */

/*
 * @cond EXCLUDE_FROM_DOCU
 * Only used internally in TAL_Impl.h.
 * Not exported to docu and scripting wrappers
 */
typedef enum
{
    TAL_SIGNAL_ARRAY = 0,
    TAL_SIGNAL_CODED = 1,
    TAL_SIGNAL_PHYSICAL = 2,
    TAL_SIGNAL_SYMBOL = 3
} TAL_SignalType;
/* @endcond */

/*
 * (partially) opaque data structure for reception of large data packets
 */
typedef struct
{
    uint8* pBuffer;
    uint32 nBufferSize;
    uint32 nDataLength;
    uint32 nBytesAlreadyReceived;
    uint8 nMuxVal;
} TAL_TUM_RxDataPacketHandle;

/**
 *
 * @brief Structure to encapsulate version information about a
 *        TAL software module
 *
 * @struct TAL_VersionInfoType
 *  This struct holds version information; where scalar values and some
 *  natural speech text is enclosed.
 *
 */
typedef struct
{
    uint8 majorVersion;                                      /**< Major version number */
    uint8 minorVersion;                                      /**< Minor version number */
    uint8 patchVersion;                                      /**< Patch version number */
    char variantName[BUSMIRROR_VERSION_VARIANT_NAME_LENGTH]; /**< Variant text */
    char description[BUSMIRROR_VERSION_DESCRIPTION_LENGTH];  /**< Textual description */
} TAL_VersionInfoType;

/**
 * @brief Enumeration for GPS sync states
 *
 *  This enum type defines the state of the GPS receiver (if present).
 */
typedef enum
{
    TAL_GPS_RCVR_STATE_UNKNOWN = 0
    /**< GPS receiver not present / state unknown */
    ,
    TAL_GPS_RCVR_STATE_FAILED = 1
    /**< GPS receiver failed */
    ,
    TAL_GPS_RCVR_STATE_STARTUP = 2
    /**< GPS receiver is in startup */
    ,
    TAL_GPS_RCVR_STATE_ASYNC = 3
    /**< GPS receiver is running but is not yet synchronized */
    ,
    TAL_GPS_RCVR_STATE_SYNC = 4
    /**< GPS receiver is running and produces 1PPS signal */
} TAL_GPSReceiverStateType;

/**
 * @brief Option bitfield for inspector synchronisation master
 *
 * @note Set options by OR-ing a subset of the following values:
 *       - TAL_INSP_CONF_SYNC_MASTER_ENABLE
 *       - TAL_INSP_CONF_SYNC_MASTER_ENABLE_OUTPUT
 *
 * @sa TAL_INSP_CONF_SYNC_MASTER_ENABLE
 * @sa TAL_INSP_CONF_SYNC_MASTER_ENABLE_OUTPUT
 */
typedef uint32 TAL_ScalarInspSyncMasterOptionsMaskType;

/**
 * @brief Enable inspector sync master
 *
 * @sa TAL_ScalarInspSyncMasterOptionsMaskType
 */
#define TAL_INSP_CONF_SYNC_MASTER_ENABLE 0x00000001U

/**
 * @brief Enable digital output signal lines for inspector sync master
 *
 * @sa TAL_ScalarInspSyncMasterOptionsMaskType
 */
#define TAL_INSP_CONF_SYNC_MASTER_ENABLE_OUTPUT 0x00000002U

/**
 * @brief Default delay compensation for TAL_InspConfigureSyncMaster
 *
 * @sa TAL_InspConfigureSyncMaster
 */
#define TAL_INSP_CONF_SYNC_MASTER_DEFAULT_DELAY_COMP 1

/**
 * @brief If this option is set only FlexRay frames from the FlexRay Timed Send
 *        interface are sent on the FlexRay bus. If for a scheduled FlexRay
 *        frame no data is present a NULL Frame will be sent (in the static
 *        segment). When unset, frames from the FlexRay RBS will be sent if there
 *        are no frames scheduled from the FlexRay timed send interface.
 *
 * @sa TAL_FrameTimedOptionType
 */
#define TAL_FRAME_TIMED_SEND_ONLY 0x00000001

#define TAL_EB_TIME_ID_MASK 0xE000000000000000ULL

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @brief Structure to encapsulate information about a USB device
 *
 * @struct TAL_USBDeviceInfoType
 *  This struct holds information about a specific USB device.
 *
 */
typedef struct
{
    TAL_DeviceHardwareType HwType; /**< deprecated: use hardwareType instead */
    uint32 serialNumber;           /**< Serial number of the device given by EB e.g. 22 */
    TAL_HardwareType hardwareType; /**< Type of board */
} TAL_USBDeviceInfoType;
/* @endcond */

#endif /* SWIG */

/**
 * @brief Enumeration for the PCI Connection types
 *
 *  This enum type defines the possible connections for PCI dependend
 *  depending on the respective driver
 */
typedef enum
{
    TAL_PCI_INVALID = -1,
    /**< connection type unknown / not present */
    TAL_PCI_CONNECTION_VISA = 0,
    /**< connection type for EB5200 VISA */
    TAL_PCI_CONNECTION = 1,
    /**< connection type for EB5200 */
    TAL_PCI_CONNECTION_XILLY_LEGACY = 2,
    /**< not supported anymore, kept due to backward compatibility */
    TAL_PCI_CONNECTION_XILLY = 3,
    /**< connection type for EB7200 XILLYBUS*/
    TAL_PCI_CONNECTION_XDMA = 4
    /**< connection type for EB7200 XDMA*/
} TAL_PCIConnectionType;

/**
 *
 * @brief Structure to encapsulate information about a PCI device
 *
 * @struct TAL_PCIDeviceInfoType
 *  This struct holds information about a specific PCI device.
 *
 */
typedef struct
{
    uint32 serialNumber; /**< Serial number of the device, if supported by the device, otherwise device index */
    char* pDeviceName;   /**< currently unused: NULL */
    TAL_HardwareType hardwareType;           /**< Type of board */
    TAL_PCIConnectionType pciConnectionType; /**< PCI connection type */
} TAL_PCIDeviceInfoType;

#ifndef SWIG
/**
 *
 * @brief Invalid Device Serial Number.
 *
 */
#define TAL_SERIALNUMBER_INVALID (0xFFFFFFFFU)
#endif /* SWIG */

#ifndef TAL_CXX_API
/**
 *
 * @brief Type to store a signal value in its coded presentation domain
 *
 * @union TAL_BM_CodedSignalValueType
 *  This union defines the possible variants, how a coded representation
 *  of a signal value can be stored.
 *  The union elements can also be used for signal value ranges,
 *  which need less than 32 bit and do only differ in their "sign-ness"
 *  and are only used handle such 32 bit values transparently.
 *
 */
typedef union
{
    uint32 value_uint32; /**< unsigned signal representation */
    sint32 value_sint32; /**< signed signal representation */
} TAL_BM_CodedSignalValueType;
#endif

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to handle a received
 *        CAN Message (Event) from the target
 *
 *  This function prototype defines the signature of a user provided
 *  function for notifications (from TAL to the user) about the reception
 *  of a CAN Message (Event) from the target.
 *
 * @param sessionHandle Handle of the established session
 *                      (not used in TUM context)
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param event         The received CAN event.
 */
typedef void (*TAL_BM_CANEventCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    uint8 CANCC,
    TAL_BM_CANEventFlagsType event);

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to handle a received
 *        signal value from the target
 *
 *  This function prototype defines the signature of a user provided
 *  functions for notifications (from TAL to the user) about the reception
 *  of data from the target.
 *
 * @param sessionHandle handle of the established session
 * @param signalIndex   unique identifier for the signal
 *
 */
typedef void (*TAL_BM_RecvSignalCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    TAL_BM_SignalIndexType signalIndex);

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to handle a received
 *        signal group from the target
 *
 *  This function prototype defines the signature of a user provided
 *  functions for notifications (from TAL to the user) about the reception
 *  of a signal group from the target.
 *
 * @param sessionHandle handle of the established session
 * @param signalGroupIndex unique identifier for the signal group
 *
 */
typedef void (*TAL_BM_RecvSignalGroupCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    TAL_BM_SignalGroupIndexType signalGroupIndex);

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method for notification
 *        about a transmitted controller status
 *
 *  This function prototype defines the signature of a user provided
 *  functions for notifications (from TAL to the user) about a transmitted
 *  controller status from a the target.
 *
 * @param sessionHandle handle of the established session
 * @param nFRCtrlIdx Index of the FlexRay network (controller).
 *                   Valid values are 0 up to 1.
 *
 */
typedef void (
    *TAL_BM_ControllerStatusCallbackFunctionPointerType)(TAL_SessionHandleType sessionHandle, uint8 nFRCtrlIdx);

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to notify the
 *        receiving of user data from a target user module
 *
 *  This function prototype definitions the signature of a user provided
 *  functions for notifications (from TAL to the user) about receiving
 *  user data from a target user module.
 *
 * @param sessionHandle identifier for the session, used to receive user data
 * @param nTUM_ID       unique identifier for the target user module
 * @param nTUM_InstanceID unique identifier for the instance of a target
 *                      user module
 * @param pUserData     pointer to the received user data
 * @param nUserDataLength size in number of bytes of the received user data
 *
 */
typedef void (*TAL_TUM_RecvUserDataCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    TAL_TUM_IDType nTUM_ID,
    TAL_TUM_InstanceIDType nTUM_InstanceID,
    const uint8* pUserData,
    uint16 nUserDataLength);

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to read out the
 *        target CPU load when received.
 *
 *  This function prototype defines the signature of a user provided
 *  functions for notifications (from TAL to the user) that a new
 *  value of CPU load was measured on the target.
 *
 * @param sessionHandle      handle of the established session
 * @param nAverage_point1s   average CPU load over the last 0.1s
 * @param nAverage_1s        average CPU load over the last 1s
 * @param nAverage_10s       average CPU load over the last 10s
 *
 */
typedef void (*TAL_CPULoadFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    uint32 nAverage_point1s,
    uint32 nAverage_1s,
    uint32 nAverage_10s);

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to read out the
 *        target RAM Usage when received.
 *
 *  This function prototype defines the signature of a user provided
 *  functions for notifications (from TAL to the user) that a new
 *  value of RAM usage was measured on the target.
 *
 * @param sessionHandle      handle of the established session
 * @param nMemorySize        Size of the memory on the target
 * @param nUsedMemory        memory used on the target
 * @param nFreeMemory        free memory available on the target
 *
 */
typedef void (*TAL_RAMUsageFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    uint32 nMemorySize,
    uint32 nUsedMemory,
    uint32 nFreeMemory);

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to read out the
 *        target Communication RAM Usage when received.
 *
 *  This function prototype defines the signature of a user provided
 *  functions for notifications (from TAL to the user) that a new
 *  value of Communication RAM usage was measured on the target.
 *
 * @param sessionHandle      handle of the established session
 * @param nFreeSpaceOutputFifo  percentage of free space in output
 *                              queue from target to host
 *                              (-1 ... value not available)
 * @param nFreeSpaceInputFifo   percentage of free space in input
 *                              queue from host to target
 *                              (-1 ... value not available)
 * @param nFreeSpaceOutputFifo2 percentage of free space in 2nd
 *                              output queue from target to host
 *                              (-1 ... value not available)
 * @param nFreeSpaceInputFifo2  percentage of free space in 2nd
 *                              input queue from target to host
 *                              (-1 ... value not available)
 * @param nFreeSpaceFrQueue0    percentage of free space in queue containing
 *                              timed FlexRay frames to send
 *                              (-1 ... value not available)
 * @param nFreeSpaceFrQueue1    percentage of free space in queue containing
 *                              timed FlexRay frames to send
 *                              (-1 ... value not available)
 * @param nFreeSpaceFrQueue2    percentage of free space in queue containing
 *                              timed FlexRay frames to send
 *                              (-1 ... value not available)
 * @param nFreeSpaceCanQueue0   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 * @param nFreeSpaceCanQueue1   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 * @param nFreeSpaceCanQueue2   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 * @param nFreeSpaceCanQueue3   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 * @param nFreeSpaceCanQueue4   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 * @param nFreeSpaceCanQueue5   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 *
 */
typedef void (*TAL_CommRAMUsageFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    sint8 nFreeSpaceOutputFifo,
    sint8 nFreeSpaceInputFifo,
    sint8 nFreeSpaceOutputFifo2,
    sint8 nFreeSpaceInputFifo2,
    sint8 nFreeSpaceFrQueue0,
    sint8 nFreeSpaceFrQueue1,
    sint8 nFreeSpaceFrQueue2,
    sint8 nFreeSpaceCanQueue0,
    sint8 nFreeSpaceCanQueue1,
    sint8 nFreeSpaceCanQueue2,
    sint8 nFreeSpaceCanQueue3,
    sint8 nFreeSpaceCanQueue4,
    sint8 nFreeSpaceCanQueue5);

/**
 *
 * @brief Queue IDs for various communication queues on the target
 *
 *  This enum type defines identifiers for the target communication queues for usage
 *  in calls to TAL_GetTargetCommRAMUsageByID() / TalRamUsage::getFreeQueueSpaceByID().
 *
 */
typedef enum
{
    TAL_COMM_RAM_USAGE_OUTPUT_FIFO = 0,
    /**< percentage of free space in output queue from target to host */
    TAL_COMM_RAM_USAGE_INPUT_FIFO = 1,
    /**< percentage of free space in input queue from host to target */
    TAL_COMM_RAM_USAGE_OUTPUT_FIFO2 = 2,
    /**< percentage of free space in 2nd output queue from target to host */
    TAL_COMM_RAM_USAGE_INPUT_FIFO2 = 3,
    /**< percentage of free space in 2nd input queue from target to host */
    TAL_COMM_RAM_USAGE_FR_QUEUE0 = 4,
    /**< percentage of free space in queue containing timed FlexRay frames to send (Ctrl. 0) */
    TAL_COMM_RAM_USAGE_FR_QUEUE1 = 5,
    /**< percentage of free space in queue containing timed FlexRay frames to send (Ctrl. 1) */
    TAL_COMM_RAM_USAGE_FR_QUEUE2 = 6,
    /**< percentage of free space in queue containing timed FlexRay frames to send (Ctrl. 2) */
    /* 7: reserved  */
    TAL_COMM_RAM_USAGE_CAN_QUEUE0 = 8,
    /**< percentage of free space in queue containing timed CAN frames to send (Ctrl. 0) */
    TAL_COMM_RAM_USAGE_CAN_QUEUE1 = 9,
    /**< percentage of free space in queue containing timed CAN frames to send (Ctrl. 1) */
    TAL_COMM_RAM_USAGE_CAN_QUEUE2 = 10,
    /**< percentage of free space in queue containing timed CAN frames to send (Ctrl. 2) */
    TAL_COMM_RAM_USAGE_CAN_QUEUE3 = 11,
    /**< percentage of free space in queue containing timed CAN frames to send (Ctrl. 3) */
    TAL_COMM_RAM_USAGE_CAN_QUEUE4 = 12,
    /**< percentage of free space in queue containing timed CAN frames to send (Ctrl. 4) */
    TAL_COMM_RAM_USAGE_CAN_QUEUE5 = 13,
    /**< percentage of free space in queue containing timed CAN frames to send (Ctrl. 5) */
    TAL_COMM_RAM_USAGE_ETH_TX0QUEUE0 = 14,
    /**< percentage of free space in transmit queue containing timed Ethernet frames to send (Ctrl. 0) */
    TAL_COMM_RAM_USAGE_ETH_TX0QUEUE1 = 15,
    /**< percentage of free space in transmit queue containing timed Ethernet frames to send (Ctrl. 1) */
    TAL_COMM_RAM_USAGE_ETH_TX1QUEUE0 = 16,
    /**< percentage of free space in transmit queue containing normal Ethernet frames to send (Ctrl. 0) */
    TAL_COMM_RAM_USAGE_ETH_TX1QUEUE1 = 17,
    /**< percentage of free space in transmit queue containing normal Ethernet frames to send (Ctrl. 1) */
    TAL_COMM_RAM_USAGE_ETH_RXQUEUE0 = 18,
    /**< percentage of free space in Ethernet receive queue(Ctrl. 0) */
    TAL_COMM_RAM_USAGE_ETH_RXQUEUE1 = 19,
    /**< percentage of free space in Ethernet receive queue(Ctrl. 1) */
    TAL_COMM_RAM_USAGE_MAX_QUEUECNT = 20
    /**< number of supported queues */
} TAL_CommRAMUsageQueueType;

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to handle a received
 *        PDU from the target
 *
 *  This function prototype defines the signature of a user provided
 *  functions for notifications (from TAL to the user) about the reception
 *  of a PDU from a the target.
 *
 * @param sessionHandle handle of the established session
 * @param pduID       unique identifier for the PDU
 *
 */
typedef void (
    *TAL_BM_RecvPDUCallbackFunctionPointerType)(TAL_SessionHandleType sessionHandle, TAL_BM_PDUIndexType pduID);

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to handle a received
 *        CAN Message (Event) from the target
 *
 *  This function prototype defines the signature of a user provided
 *  function for notifications (from TAL to the user) about the reception
 *  of a CAN Message (Event) from the target.
 *
 * @param sessionHandle Handle of the established session
 *                      (not used in TUM context)
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param QueueID       The Queue ID addresses one specific queue in the
 *                      CAN message base.
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 *
 * @note Pass the QueueID (without any macros) to any function called in
 *       the callback which takes the QueueID as argument.
 *
 */
typedef void (*TAL_BM_RecvCANMessageCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    uint8 CANCC,
    TAL_BM_CANMessageIDType QueueID);

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to handle a received
 *        digital I/O event from the target.
 *
 *  This function prototype defines the signature of a user provided
 *  function for notifications (from TAL to the user) about the reception
 *  of a digital I/O event from the target.
 *
 *  @param sessionHandle Handle of the established session
 *  @param digitalPinID  Index (starts with 0) of the digital pin the event
 *                       was triggered.
 *  @param digitalValue  Value of the digital pin.
 *
 *  @note None.
 *
 */
typedef void (*TAL_BM_RecvDioValuesCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    TAL_BM_DigitalIOPinIDType digitalPinID,
    TAL_BM_DigitalValueType digitalValue);

/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to notify the
 *        receiving of a measurement data from the target
 *
 *  This function prototype definitions the signature of a user provided
 *  functions for notifications (from TAL to the user) about receiving
 *  measurement data from the target.
 *
 * @param sessionHandle identifier for the session, used to receive
 * measurement data. Can be used to differ measurement data if one callback is
 * used to handle several sessions.
 * @param pMeasurementData pointer to the received measurement data. The
 * layout of the payload comes uninterpreted from the measurement controller
 * and therefore is subject of change in future versions.
 * @param nMeasurementDataLength size in number of bytes of the received
 * measurement data
 *
 */
typedef void (*TAL_MeasurementCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    const uint8* pMeasurementData,
    uint32 nMeasurementDataLength);


/**
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to notify the
 *        receiving of ebhscr data from the target
 *
 *  This function prototype definitions the signature of a user provided
 *  functions for notifications (from TAL to the user) about receiving
 *  ebhscr data from the target.
 *
 * @param sessionHandle identifier for the session, used to receive
 * measurement data. Can be used to differ measurement data if one callback is
 * used to handle several sessions.
 * @param ebhscr_packet pointer to the received ebhscr data.
 * @param context User defined context which is set when registering this callback
 *
 */
typedef void (*TAL_EBHSCRCallbackType)(
    TAL_SessionHandleType sessionHandle,
    const struct ebhscr* ebhscr_packet,
    void* context);


#ifdef __cplusplus
/**
 *
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to notify the
 *        receiving of already processed measurement data from the target
 *
 *  This function prototype definitions the signature of a user provided
 *  functions for notifications (from TAL to the user) about receiving
 *  already processed measurement data from the target.
 *
 * @param pContext User defined context which is set when registering this callback
 * @param sessionHandle identifier for the session, used to receive
 * measurement data. Can be used to differ measurement data if one callback is
 * used to handle several sessions.
 * @param pMeasurementData Pointer to class which holds the already processed
 * measurement data received from the target.
 *
 */
typedef void (*TAL_MeasurementClassCallbackFunctionPointerType)(
    void* pContext,
    TAL_SessionHandleType sessionHandle,
    TalMeasureData* pMeasurementData);
#endif

/*
 * Callbacks which are not needed in Public API are hidden from user and docu
 * generation. This is done to avoid confusing the user.
 */
#ifndef SWIG

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to handle a received
 *        frame from the target
 *
 *  This function prototype defines the signature of a user provided
 *  functions for notifications (from TAL to the user) about the reception
 *  of a frame from a the target.
 *
 * @param sessionHandle handle of the established session
 * @param frameID       unique identifier for the frame
 *
 */
typedef void (
    *TAL_BM_RecvFrameCallbackFunctionPointerType)(TAL_SessionHandleType sessionHandle, TAL_BM_FrameIndexType frameID);
/* @endcond */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method to handle a received
 *        FPGA Alive Packet from the target.
 *
 *  This function prototype defines the signature of a user provided
 *  function for notifications (from TAL to the user) about the reception
 *  of a FPGA Alive packet from the target
 *
 *  @param sessionHandle Handle of the established session
 *  @param pContext  User defined context which is set when registering
 *                   this callback
 *  @param nLastTimestamp  Last logged timestamp stored to LOG database
 *  @param nPrimaryKey     Primary key of LOG database
 *
 *  @note Former TReceiveCallback
 *
 */
typedef void (*TAL_FpgaAlivePacketRecvCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    void* pContext,
    long long int nLastTimestamp,
    long long int nPrimaryKey);
/* @endcond */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback method to notify the
 *        receiving of download data from an established session.
 *
 *  This function prototype defines the signature of a user provided
 *  function (from TAL to the user) about receiving
 *  download data from an established session.
 *
 * @note If pExecDownloadData is 0; nExecDownloadDataLength is the whole
 *       filesize the target will transfer in the following.
 *
 * @param sessionHandle identifier for the session, used to receive diagnostic
 *                      data
 * @param pExecDownloadData         pointer to the received download data
 * @param nExecDownloadDataLength   size in number of bytes of the received
 *                                  download data
 *
 */
typedef void (*TAL_RecvExecDownloadDataCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    const uint8* pExecDownloadData,
    uint32 nExecDownloadDataLength);
/* @endcond */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @brief Function prototype, to specify the type of function, provided
 *        by the user as callback/notification method about communication
 *        cycle start from the target
 *
 *  This function prototype defines the signature of a user provided
 *  functions for notifications (from TAL to the user) about the start
 *  of a communication cycle from a the target.
 *  This type is only used in labiew rt API.
 *
 * @param sessionHandle      handle of the established session
 * @param communicationCycle started communication cycle
 *
 */
typedef void (*TAL_CommCycleStartCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    TAL_CycleType communicationCycle);
/* @endcond */

#endif /* SWIG */

/**
 * @brief Available execution modes for schedule tables
 */
typedef enum
{
    /** Schedule table is disabled */
    TAL_LIN_SCHEDULE_DISABLED = 0,
    /** LIN Master Mode: Schedule table is executed only once */
    TAL_LIN_SCHEDULE_MASTER_ONCE = 1,
    /** LIN Master Mode: Schedule table is executed continuously */
    TAL_LIN_SCHEDULE_MASTER_CONTINUOUS = 2,
    /** LIN Slave mode: Schedule table is not executed */
    TAL_LIN_SCHEDULE_SLAVE = 3
} TAL_Lin_ScheduleTableExecModeType;

/* @brief Various status flags for received frames
 * */
typedef enum
{
    /** */
    TAL_LIN_NOT_OK = 0,
    /** Frame transmission successful */
    TAL_LIN_TX_OK = 1,
    /** Ongoing transmission */
    TAL_LIN_TX_BUSY = 2,
    /** Mismatch between sent and read back data
     *  Identifier parity error or
     *  physical bus error */
    TAL_LIN_TX_HEADER_ERROR = 3,
    /** Mismatch between sent and read back data
     *  physical bus error */
    TAL_LIN_TX_ERROR = 4,
    /** LIN Controller received a correct frame */
    TAL_LIN_RX_OK = 5,
    /** Ongoing reception */
    TAL_LIN_RX_BUSY = 6,
    /** LIN Controller detected an error:
     *  Buffer overrun
     *  Missing bytes
     *  Checksum error
     *  Framing error */
    TAL_LIN_RX_ERROR = 7,
    /** Missing response */
    TAL_LIN_RX_NO_RESPONSE = 8,
    /** */
    TAL_LIN_CH_UNINIT = 9,
    /** LIN Controller is ready to transmit the next frame */
    TAL_LIN_CH_OPERATIONAL = 10,
    /** LIN Controller is in sleep state */
    TAL_LIN_CH_SLEEP = 11,
} TAL_Lin_StatusType;

/**
 * @brief Indicates the checksum model for a frame
 * */
typedef enum
{
    /** Enhanced checksum model */
    TAL_LIN_ENHANCED_CS = 0,
    /** Classic checksum model */
    TAL_LIN_CLASSIC_CS = 1
} TAL_Lin_FrameCsModelType;

/**
 * @brief Defines which node generates the response
 */
typedef enum
{
    /** The response is generated by the master node */
    TAL_LIN_MASTER_RESPONSE = 0,
    /** The response is generated from a slave node */
    TAL_LIN_SLAVE_RESPONSE = 1,
    /** The response is generated from one slave to another slave,
     * the master does not receive this response. */
    TAL_LIN_SLAVE_TO_SLAVE = 2,
    /** This frame is disabled. It will be ignored */
    TAL_LIN_FRAME_DISABLED = 3,
} TAL_Lin_FrameResponseType;

/**
 * @brief Prototype for TAL lin callback function
 *
 * This function prototype defines the signature of a user provided
 * functions for notifications (from TAL to the user) about the reception
 * of a Lin Frame from the target.
 *
 * @param sessionHandle handle of the established session
 * @param pLinFrame the received LIN frame
 *
 */
typedef void (*TAL_LinCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    uint8 nCtrlIdx,
    TAL_Lin_StatusType status,
    TAL_Lin_FrameCsModelType checksumModel,
    uint8 nMessageId,
    const uint8* pData,
    uint8 nPayloadLength);

/**
 *
 * @brief Identifiers for target status
 *
 * @enum TAL_TargetStatusType
 *  This enum type defines identifiers for the status of the target.
 *
 */
typedef enum
{
    TAL_TargetUndefined = 0 /**< No state information about the target
                             *   available */
    ,
    TAL_TargetApplInitialized = 1 /**< Sent after connecting to target application
                                   *   when it is finished with initialisation */
    /* 2 was used for 'TAL_RedBootInitialized' in previous versions */
    /* 3 was used for 'TAL_SoftDeviceInitialized' in previous versions */
    ,
    TAL_TargetSystemInitialized = 4 /**< Sent after connecting to target system
                                     *  when it is finished with initialisation */
    ,
    TAL_ErrorStatusStart = 16 /**< all states above this report an error */
    ,
    TAL_FirmwareOutdated = 16 /**< indicate that the target firmware need to be
                               * updated in order to execute this ttc */
    ,
    TAL_TargetStatusMaxValue = 16 /**< Internal use only: maximum value
                                   *   within this enum */
} TAL_TargetStatusType;

/**
 * @brief Wireshark options
 */
typedef enum
{
    TAL_PCAP_OPTION_NONE = 0 /**< No specific option is set */
    ,
    TAL_PCAP_OPTION_SERVER = 1 /**< Write to server pipe (only supported on Windows).
                                * This is for traditional wireshark pcap named
                                * pipes. After calling this function you may open a named pipe in
                                * wireshark: open menu Capture, Options. The Capture Options windows
                                * will open. Click the Button ManageInterfaces inside. Now click the
                                * Button New in the Pipes Tab and set the pipe name (e.g.:
                                * \\\\\.\\pipe\\wireshark). */
    ,
    TAL_PCAP_OPTION_CLIENT = 2 /**< Write to client pipe (only supported on Windows).
                                * This is for the new wireshark extcap (external
                                * capture) plugins. With this new plugin system wireshark opens the
                                * server end of the pipe first. This function will then connect
                                * to the already opened server pipe. */
    ,
    TAL_PCAP_OPTION_FILE = 4 /**<  Use this for writing pcap data to a file */
    ,
    TAL_PCAP_OPTION_DLT_EBHSCR = 8 /**< In the pcap global header, set the network
                                    * parameter (data link type) to DLT_EBHSCR. Please use this option for EB7200
                                    * and EB8200.
                                    * If this options is not specified, writer uses the default DLT_PPI.
                                    * EB2200 and EB5200 use DLT_PPI.
                                    * More info http://www.tcpdump.org/linktypes.html */
    ,
    TAL_PCAP_OPTION_REGISTER_EBX200 = 256 /**< This option internally installs
                                           * a callback using registerForMeasurementDataClass to write captured data of
                                           * the EB2200 and EB5200 directly to the pcap stream. It does work with pipe
                                           * or file option. Please use this option only on EB2200 or EB5200. */
    ,
    TAL_PCAP_OPTION_REGISTER_EBHSCR = 512 /**< This option internally installs
                                           * a callback using registerForMeasurementData to write captured EBHSCR data
                                           * directly to the pcap stream. It does work with pipe
                                           * and file options. */
/* @cond EXCLUDE_FROM_DOCU */
#ifdef TAL_USE_DEPRECATED_ENUMS
    ,
    TAL_PCAP_OPTION_REGISTER_EB7200 = TAL_PCAP_OPTION_REGISTER_EBHSCR
/**< Deprecated, replaced by TAL_PCAP_OPTION_REGISTER_EBHSCR because this feature
 *   is now also available for other boards than EB7200  */
#endif
    /* @endcond */
} TAL_PcapOptionType;

typedef enum
{
    TAL_BM_SERVER_SERVICE_DOWN = 0,
    TAL_BM_SERVER_SERVICE_AVAILABLE = 1,
    TAL_BM_CLIENT_SERVICE_RELEASED = 2,
    TAL_BM_CLIENT_SERVICE_REQUESTED = 3,
    TAL_BM_CONSUMED_EVENTGROUP_RELEASED = 4,
    TAL_BM_CONSUMED_EVENTGROUP_REQUESTED = 5,
} TAL_BM_SdSetStateType;

typedef enum
{
    TAL_BM_SD_CLIENT_SERVICE = 0,
    TAL_BM_SD_CONSUMED_EVENTGROUP = 1,
    TAL_BM_SD_EVENT_HANDLER = 2,
} TAL_BM_SdGetStateServiceType;

typedef enum
{
    TAL_BM_SD_UNDEFINED = 0,
    TAL_BM_CLIENT_SERVICE_DOWN = 1,
    TAL_BM_CLIENT_SERVICE_AVAILABLE = 2,
    TAL_BM_CONSUMED_EVENTGROUP_DOWN = 3,
    TAL_BM_CONSUMED_EVENTGROUP_AVAILABLE = 4,
    TAL_BM_EVENT_HANDLER_RELEASED = 5,
    TAL_BM_EVENT_HANDLER_REQUESTED = 6,
} TAL_BM_SdCurrentStateType;

typedef void (*TAL_SdCurrentStateEventCallbackFunctionPointerType)(
    TAL_SessionHandleType sessionHandle,
    uint32 nId,
    TAL_BM_SdCurrentStateType state);

/**
 *
 * @brief Identifiers SomeIp data types
 *
 * @enum TAL_SomeIpDataType
 *
 */
typedef enum
{
    TAL_SOMEIP_TYPE_BOOLEAN = 0,
    TAL_SOMEIP_TYPE_UINT8 = 1,
    TAL_SOMEIP_TYPE_UINT16 = 2,
    TAL_SOMEIP_TYPE_UINT32 = 3,
    TAL_SOMEIP_TYPE_UINT64 = 4,
    TAL_SOMEIP_TYPE_SINT8 = 5,
    TAL_SOMEIP_TYPE_SINT16 = 6,
    TAL_SOMEIP_TYPE_SINT32 = 7,
    TAL_SOMEIP_TYPE_SINT64 = 8,
    TAL_SOMEIP_TYPE_FLOAT32 = 9,
    TAL_SOMEIP_TYPE_FLOAT64 = 10,
    TAL_SOMEIP_TYPE_STRUCT = 11,
    TAL_SOMEIP_TYPE_ARRAY = 12,
    TAL_SOMEIP_TYPE_VARARRAY = 13,
    TAL_SOMEIP_TYPE_STRING = 14,
    TAL_SOMEIP_TYPE_UNION = 15
} TAL_SomeIpDataType;

typedef union
{
    /** unsigned signal representation, used for boolean, uint8, uint16,
     * uint32, uint64 and for the value of the type field of a union
     */
    uint64 value_uint64;

    /** signed signal representation, used for sint8, sint16, sint32 and sint64 */
    sint64 value_sint64;

    /** single precision floating point, used for float32 */
    float32 value_float32;

    /** double precision floating point, used for float64 */
    float64 value_float64;

    /** points to first byte of the data, used for string, fixed-array, var-array and struct */
    const uint8* data;
} TAL_SomeIpValueType;

typedef struct
{
    TAL_SomeIpDataType type; /**< data-type of the data element */
    const char* const* name; /**< name of the data element; points to constant string table inside library */
    uint32 flags;            /**< packed config flags; used TAL_SOMEIP_GET_ macros to decode. Implementation
                              *   note: this is simply a copy of the uint32 config data element! */
    uint32 nelements;        /**< only used for string, struct and fixed-array, 0 for
                              *   all other. For a string this means number of bytes. For a struct this is the
                              *   number of struct elements. For a fixed-array this is the number of array
                              *   elements. */
    sint32 elemLvl;          /**< -1: init value, >=0 actual level we are in dim array */
    TAL_BM_SignalIndexType
        codingSignalIndex; /**< Optional id of the computational method required for
                            * coded/physical value conversion. If a data conversion is defined
                            * then the value is >=0 else it is set to -1. Pass this id
                            * as signalIndex argument value when calling either
                            * TAL_BM_PhysicalToCoded64, TAL_BM_CodedToPhysical64, or TAL_BM_SymbolToCoded. */
    sint64 props_id;       /**< optional id of the SwDataDefProps assigned to the data element. If no data conversion
                                is defined then the value is set to -1. */
    TAL_SomeIpValueType invalid_value; /**< only used for basic data types, invalid value of the basic
                                        *   data element. Use TAL_SOMEIP_HAS_INVALID_VALUE(flags) to
                                        *   determine if this value is defined. */
} TAL_SomeIpConfigType;

/* @cond EXCLUDE_FROM_DOCU */
typedef struct
{
    sint32 cnt;           /**< decrement counter of not processed messages, if 0 all messages are processed */
    void* pMessageConfig; /**< pointer to TAL_SomeIpMessageConfig */
    void* pMessage;       /**< pointer to next message */
} TAL_SomeIpMessageIterator;
/* @endcond */

/* @cond EXCLUDE_FROM_DOCU */
typedef struct
{
    sint32
        udp_payload_to_proccess; /**< length of processed payload, decreased every time data is successfully parsed */
    const uint8* pWholeMessage;  /**< pointer to next message */
} TAL_SomeIpUdpMessageIterator;
/* @endcond */

/* @cond EXCLUDE_FROM_DOCU */
typedef struct
{
    uint8* length_field;     /**< points to the first byte where the length field is written to as
                              * soon as nesting level ends */
    uint32 cfg;              /**< copied configuration data of the element which created the nesting level,
                              * this is used to determine the size of the length field and the type of the element we
                              * are in */
    uint32 length;           /**< how may bytes are contained in this nesting level; starts with 0 when the
                              * nesting element is created; is increased every time a new element is added; when the
                              * nesting level closes this size is written to the length_field _and_ this size is copied to
                              * the previous nesting level! length field is maintained even if sizeof length field is 0! */
    uint32 var_array_length; /**< length of var-array in bytes */
    uint32 n;                /**< number of elements already written on this nesting level; starts with nelements;
                              * decreased by 1 every time a new element is written; used to check if additional elements
                              * are allowed to be written to this level, or if the nesting level shall be closed */
    const uint32* first_array_elem; /**< first element of array */
} TAL_SomeIpNestingType;
/* @endcond */
/* @cond EXCLUDE_FROM_DOCU */
typedef struct
{
    uint8 last; /**< TRUE if last config element is reached */

    const uint32* pRawConfig; /**< pointer to next config element in format flags, nameIdx, valid */
    const char* const* pName; /**< pointer to name array */
    sint32 lvl;               /**< -1: init value, >=0 actual level we are in dim array */
    sint32 elemLvl;           /**< -1: init value, >=0 actual level of the element are in dim array */
    TAL_SomeIpNestingType dim
        [TAL_SOMEIP_MAX_NESTING_LEVEL]; /**< used to keep track of
                                         * different nesting levels; element is added as soon as struct, union, fixed-array or
                                         * var-array occurs; */
} TAL_SomeIpConfigIterator;
/* @endcond */
/* @cond EXCLUDE_FROM_DOCU */
typedef struct
{
    sint32 payloadToProcess;  /**< non processed payload */
    const uint8* pElement;    /**< pointer to next element in SomeIp payload */
    const uint32* pRawConfig; /**< pointer to next config element in format flags, nameIdx, valid */
    sint32 lvl;               /**< -1: init value, >=0 actual level we are in dim array */
    sint32 elemLvl;           /**< -1: init value, >=0 actual level of the element in dim array */
    TAL_SomeIpNestingType dim
        [TAL_SOMEIP_MAX_NESTING_LEVEL]; /**< used to keep track of
                                         * different nesting levels; element is added as soon as struct, union, fixed-array or
                                         * var-array occurs; */
    sint8 unionHandling;                /**< indicator of the union processing state */
    sint32 unionTypeField;              /**< value of the union type field */
    const char* const* pName;           /**< pointer to name array */
    uint8 last;                         /**< TRUE if last config element is reached */
} TAL_SomeIpElementIterator;
/* @endcond */

/* @cond EXCLUDE_FROM_DOCU */
typedef struct
{
    const uint32* cfg;        /**< points to actual cfg element */
    const char* const* pName; /**< points to the name of the actual cfg element */
    uint8* dst;           /**< points to the actual write position inside the SOME/IP message user supplied buffer */
    uint32 dst_remaining; /**< length of dst, decreased every time data is written to dst */
    TAL_SomeIpNestingType dim
        [TAL_SOMEIP_MAX_NESTING_LEVEL]; /**< used to keep track of
                                         * different nesting levels; element is added as soon as struct, union, fixed-array or
                                         * var-array occurs; */
    uint8 writeArrayHandling;
    sint8 unionHandling;                                  /**< indicator of the union processing state */
    sint8 varArrayHandling[TAL_SOMEIP_MAX_NESTING_LEVEL]; /**< indicator of the var array processing state */
    sint32 unionTypeField;                                /**< value of the union type field */
    sint32 varArraySize[TAL_SOMEIP_MAX_NESTING_LEVEL];    /**< var array size in bytes*/
    sint32 lvl;                                           /**< -1: init value, >=0 actual level we are in dim array */
    sint32 varArrayLvl;                                   /**< -1: init value, >=0 actual level we are in dim array */
    sint32 elemLvl;     /**< -1: init value, >=0 actual level of the element in dim array */
    uint8* wdst;        /**< user byte buffer, taken from previous dst */
    uint32 wcfg;        /**< used by write function, taken from previous config */
    TAL_ReturnType err; /**< used to remember stream errors */
} TAL_SomeIpWriterIterator;
/* @endcond */

///@brief Identifiers of E2E Profile 5, 6 and 7 data types

///@brief Status of the reception on one single Data in one cycle, protected with E2E Profile 5, 6 or 7
typedef enum
{
    ///@brief OK: the checks of the Data in this cycle were successful (including counter check, which was incremented by 1).
    TAL_E2E_OK = 0x00,
    ///@brief Error: the checks of the Data in this cycle were successful, with the exception of the repetition.
    TAL_E2E_REPEATED = 0x01,
    ///@brief Error: The checks of the Data in this cycle were successful, with the exception of counter jump,
    /// which changed more than the allowed delta.
    TAL_E2E_WRONGSEQUENCE = 0x02,
    ///@brief Error: Error not related to counters occurred (e.g. wrong crc, wrong length, wrong Data ID) or the return
    /// of the check function was not OK.
    TAL_E2E_ERROR = 0x03,
    ///@brief Error: No value has been received yet (e.g. during initialization). This is used as the initialization value for the buffer,
    /// it is not returned by any E2E profile.
    TAL_E2E_NOTAVAILABLE = 0x04,
    ///@brief Error: the Check function has been invoked but no new Data is not available since the last call.
    TAL_E2E_NONEWDATA = 0x05
} TAL_E2E_CheckStatusType;

///@brief Configuration of transmitted Data for E2E Profile's 4, 5, 6 or 7. For each transmitted Data, there is an instance of this typedef.
typedef struct
{
    ///@brief E2E Profile in the configuration
    uint32 profile;
    ///@brief A system-unique identifier of the Data
    uint32 dataID;
    ///@brief Byte offset of the E2E header from the beginning of the Data
    uint32 hdrOffset;
    ///@brief Minimal length of Data, in bytes. E2E checks that Length is >= MinDataLength.
    /// The value shall be >= (E2E header size + SOME/IP header size) and <= MaxDataLength.
    uint32 minDataLength;
    ///@brief   Maximal length of Data, in bytes. E2E checks that DataLength is <= MaxDataLength.
    /// The value shall be >= MinDataLength
    uint32 maxDataLength;
    ///@brief Maximum allowed gap between two counter values of two consecutively received valid Data.
    /// For example, if the receiver gets Data with counter 1 and MaxDeltaCounter is 3, then at the next
    /// reception the receiver can accept Counters with values 2, 3 or 4.
    uint32 maxDeltaCounter;
} TAL_E2E_ConfigType;

///@brief State of the sender for a Data protected with E2E Profile 4, 5, 6 or 7.
typedef struct
{
    ///@brief Counter to be used for protecting the next Data. The initial value is 0, which
    /// means that in the first cycle, Counter is 0. Each time E2E_PXXProtect() is called,
    /// it increments the counter up to the maximum counter value depending on the Profile.\n
    /// Profile 4: Maximum counter value: 0xFFFFU\n
    /// Profile 5: Maximum counter value: 0xFFU\n
    /// Profile 6: Maximum counter value: 0xFFU\n
    /// Profile 7: Maximum counter value: 0xFFFFFFFFU\n
    uint32 counter;
} TAL_E2E_ProtectStateType;

///@brief State of the reception on one single Data protected with E2E Profile 5, 6 or 7.
typedef struct
{
    ///@brief Status Result of the verification of the Data in this cycle, determined by the
    /// Check function
    TAL_E2E_CheckStatusType status;
    ///@brief Counter of the data in previous cycle. It is initialized with 0.
    uint32 counter;
} TAL_E2E_CheckStateType;

/**
 * @brief Structure to store status and event register of the associated channel
 *
 * @note This function is currently only supported for EB7200 base projects
 *
 */
typedef struct
{
    /**
     * Status register
     *
     * Bit 0: '1' indicates that there is channel activity\n
     * Bit 1: '1' indicates that there is an MTA frame reception ongoing\n
     */
    uint32 status;

    /**
     * Event register
     *
     * Bit 0: code error\n
     * Bit 1: disparity error\n
     * Bit 2: time out error\n
     * Bit 3: MTA frame oversized error\n
     * Bit 4: data FIFO overflow error\n
     * Bit 5: header FIFO overflow error\n
     * Bit 6: EOF\n
     *
     * for all bits: '1' indicates the occurrence of the event since last call
     * of TAL_GetMeasurementStatus function.
     */
    uint32 events;
} TAL_MeasurementStatusType;

/**
 * @brief Structure to store temperature, fan speed and flag register of the EB5200/EB7200 device
 *
 * @note This function is currently only supported for EB7200
 *
 */
typedef struct
{
    /** actual on-chip temperature in Celsius */
    double temp_on_chip;

    /** actual speed of the fan in rpm*/
    uint32 fan_speed;

#define TAL_TEMP_STATUS_FAN_ON 0x01
#define TAL_TEMP_STATUS_FAN_ON_REQUESTED 0x02
#define TAL_TEMP_STATUS_OVERHEATED 0x04
#define TAL_TEMP_STATUS_FAN_MAX 0x08

    /**
     * Flag register
     *
     * Bit 0 / TAL_TEMP_STATUS_FAN_ON: The fan is currently running
     * Bit 1 / TAL_TEMP_STATUS_FAN_ON_REQUESTED: Fan start is requested because temperature is above its limit
     * Bit 2 / TAL_TEMP_STATUS_OVERHEATED: The board is overheated and shutting * down
     * Bit 3 / TAL_TEMP_STATUS_FAN_MAX: The fan is running at maximum speed
     */
    uint32 flags;
} TAL_TemperatureStatusType;

typedef enum
{
    ///@brief value for BIG Endian
    TAL_MOSTSIGNIFICANTBYTEFIRST = 1
    ///@brief value for LITTLE Endian
    ,
    TAL_MOSTSIGNIFICANTBYTELAST = 2
} TAL_Endianness;

typedef struct
{
    ///@brief Name of the Signal in the configuration DB
    const unsigned char* pSignalName;

    ///@brief Name of the signal unit in the configuration DB
    const unsigned char* pUnitName;

    ///@brief Identifier of the Signal in the configuration DB
    /// A conversion representation may refer to this identifier
    sint64 nSignalPk;

    ///@brief Identifier of PDU in the configuration DB;
    /// PDU this signal is contained in (either a PDU or a Multiplexed-PDU)
    sint64 nPduPk;

    ///@brief Identifier of the SignalGroup in the configuration DB
    /// SignalGroup this signal is contained in
    sint64 nSignalGroupPk;

    ///@brief Invalid value of the signal. Only valid if bHasInvalidValue is
    /// TAL_TRUE
    sint64 nInvalidValue;

    ///@brief Initial value of the signal. Only valid if bHasInitialValue is
    /// TAL_TRUE
    sint64 nInitialValue;

    ///@brief Bit size of the Signal given in bit.
    int nBitSize;

    ///@brief Bit offset of the Signal in the PDU given in bit;
    /// bit counting policy: sawtooth as AUTOSAR;
    int nBitOffset;

    ///@brief Update bit offset of Signal in the PDU given in bit;
    /// bit counting policy: sawtooth as AUTOSAR;
    /// if this value is negative the Signal has no update bit;
    int nUpdateBitOffset;

    ///@brief Signal endianness;
    /// 1: BIG, 2:LITTLE
    TAL_Endianness nEndianness;

    ///@brief Signal signedness;
    /// 0: unsigned; 1: signed
    int bIsSigned;

    ///@brief Invalid value is available;
    /// 0: unavailable; 1: available
    int bHasInvalidValue;

    ///@brief Initial value is available;
    /// 0: unavailable; 1: available
    int bHasInitialValue;
} TAL_SignalConfigType;

typedef struct
{
    ///@brief Name of the SignalGroup in the configuration DB
    const unsigned char* pSignalGroupName;

    ///@brief Identifier of the SignalGroup in the configuration DB
    sint64 nSignalGroupPk;

    ///@brief Size of the SignalGroup given in bytes.
    int nByteSize;

} TAL_SignalGroupConfigType;

typedef struct
{
    ///@brief Name of Multiplexed-PDU in the configuration DB
    const unsigned char* pMuxPduName;

    ///@brief Identifier of the Multiplexed-PDU in the configuration DB;
    /// A Signal may refer to this identifier
    sint64 nPduPk_MuxPart;

    ///@brief Identifier of the Container PDU in the configuration DB;
    /// PDU this Multiplexed-PDU is contained in
    sint64 nPduPk_MuxContainer;

    ///@brief Size of Multiplexed-PDU in byte
    int nByteSize;

    ///@brief Absolute offset of the Multiplexed-PDU in PDU given in byte
    int nByteOffset;

    ///@brief Bitsize of MUX-Value. 0 if this Multiplexed-PDU has no MUX-Value
    /// (a so called static-part).
    int nMuxBitSize;

    ///@brief Bit offset of MUX-Value in the PDU given in bit;
    /// bit counting policy: monotone;
    /// if this value is negative the PDU has no MUX-Value (static part);
    int nMuxBitOffset;

    ///@brief Expected value of MUX-Value
    int nMuxValue;

    ///@brief Multiplexer endianness
    /// 1: BIG, 2:LITTLE
    TAL_Endianness nMuxEndianness;
} TAL_MultiplexedPduConfigType;

typedef enum
{
    TAL_CONTAINER_PDU_HEADERTYPE_LONG = 0,
    TAL_CONTAINER_PDU_HEADERTYPE_SHORT = 1,
} TAL_ContainerPduHeaderType;

typedef struct
{
    ///@brief Container header format;
    TAL_ContainerPduHeaderType nFormat;

    ///@brief Container header endianness;
    /// 1: BIG, 2:LITTLE
    TAL_Endianness nEndianness;
    ///@brief Identifier of PDU in the configuration DB;
    /// A Signal may refer to this identifier
    sint64 nPduPk;
} TAL_ContainerPduConfigType;

typedef struct
{
    ///@brief Name of the contained Pdu in the configuration DB
    const unsigned char* pContainedPduName;
    ///@brief Container pdu id
    sint64 nPduPk_ContainerPdu;

    ///@brief Contained pdu id; 1:n relation with nPduPk_ContainerPdu; a
    //signal refers to this pdu id
    sint64 nPduPk_ContainedPdu;

    ///@brief short Header Id of the contained Pdu; 1:1 relation with
    /// nPduPk_ContainedPdu
    /// note: the same contained pdu may have both a short and a long header id. depending on the container pdu format (long or short) the right one must be used!
    uint32 nPdu_ShortHeaderId;

    ///@brief long Header Id of the contained Pdu; 1:1 relation with
    ///nPduPk_ContainedPdu
    /// note: the same contained pdu may have both a short and a long header id. depending on the container pdu format (long or short) the right one must be used!
    uint32 nPdu_LongHeaderId;

    ///@brief Size of Contained-PDU in byte
    int nByteSize;
} TAL_ContainedPduConfigType;

typedef struct
{
    const uint8* p;                    /**< points to pdu header */
    uint32 remaining;                  /**< remaining bytes in p */
    TAL_ContainerPduConfigType config; /* configuration for decoding */
} TAL_ContainerPduIterator;

typedef struct
{
    ///@brief Name of PDU in the configuration DB
    const unsigned char* pPduName;

    ///@brief Identifier of PDU in the configuration DB;
    /// A Signal may refer to this identifier
    sint64 nPduPk;

    ///@brief Identifier of Frame in the configuration DB;
    /// Frame this PDU is contained in.
    sint64 nFramePk;

    ///@brief Size of PDU in byte
    int nByteSize;

    ///@brief Absolute offset of PDU in frame given in byte
    int nByteOffset;

    ///@brief Update bit offset of PDU in frame given in bit.
    /// bit counting policy: monotone;
    /// if this value is negative the PDU has no update bit;
    int nUpdateBitOffset;
} TAL_PduConfigType;

typedef struct
{
    ///@brief Name of the Frame-Triggering in the configuration DB
    const unsigned char* pFtName;

    ///@brief Name of the Frame in the configuration DB
    const unsigned char* pFrameName;

    ///@brief Identifier of the Frame-Triggering in the configuration DB
    sint64 nFtPk;

    ///@brief Identifier of the Frame in the configuration DB;
    /// A PDU may refer to this identifier
    sint64 nFramePk;

    ///@brief Identifier of the Controller in the configuration DB;
    sint64 nControllerPk;

    ///@brief Size of the FrameTriggering in byte
    int nByteSize;

    ///@brief Bus where the packet was received: CAN/FlexRay/LIN
    /// Possible values:
    /// - FlexRay:      1
    /// - CAN:          2
    /// - LIN:          3
    /// - Ethernet:     4
    /// - Marker:     128
    /// - Analog:     129
    /// - Digital:    130
    /// - Triggerout: 131
    /// - Control:    132
    int nBus;

    ///@brief Channel this packet was sent on. Only used for FlexRay.
    /// Possible values:
    /// - FlexRay:    1 = ChA; 2 = ChB
    int nChannel;

    ///@brief Message-ID of the packet sent. On CAN this is the CAN
    /// message-id. On FlexRay this is the slot-id.
    int nID;

    ///@brief base cycle. Only used for FlexRay.
    int nBC;

    ///@brief cycle repetition. Only used for FlexRay.
    int nCR;
} TAL_FrameTriggeringConfigType;

typedef struct
{
    /// @brief cluster key
    sint64 nClusterPk;

    /// @brief cluster name
    const unsigned char* pClusterName;

    ///@brief baudrate
    int nBaudrate;
} TAL_CanClusterConfigType;

/// @name CAN id
typedef enum
{
    TAL_CAN_UNKNOWN = -1 ///< @brief Unknown CAN identifier
    ,
    TAL_CAN_DATA_OVERFLOW = -7 ///< @brief CAN measurement channel overflow
    ,
    TAL_CAN_STD_MIN = 0x00000000 ///< @brief Lowest CAN standard message identifier
    ,
    TAL_CAN_STD_MAX = 0x000003FF ///< @brief Highest CAN standard message identifier
    ,
    TAL_CAN_STD_MASK = 0x000003FF ///< @brief CAN standard message identifier mask
    ,
    TAL_CAN_EXT_FLAG = 0x40000000 ///< @brief CAN extended message identifier flag
    ,
    TAL_CAN_EXT_MIN = 0x00000000 ///< @brief Lowest CAN extended message identifier
    ,
    TAL_CAN_EXT_MAX = 0x1FFFFFFF ///< @brief Highest CAN extended message identifier
    ,
    TAL_CAN_EXT_MASK = 0x1FFFFFFF ///< @brief CAN extended message identifier mask
} TAL_CanIdType;

/**
 *
 * @brief Constant, defining to use the baudrate(s) already set during CAN controller initialization
 *        of RBS.
 *
 * @def TAL_CAN_USE_RBS_BAUDRATE
 *
 */
#define TAL_CAN_USE_RBS_BAUDRATE 0UL

typedef struct
{
    ///@brief Identifier of the Controller in the configuration DB.
    sint64 nControllerPk;
    ///@brief Identifier of the Cluster in the configuration DB.
    sint64 nClusterPk;
    ///@brief Name of the Controller in the configuration DB
    const unsigned char* pControllerName;
    ///@brief Name of the sending ECU in the configuration DB
    const unsigned char* pTxEcuName;
    ///@brief Maximum payload length for dynamic frames in [16 bit words].
    unsigned int pPayloadLengthDynMax;
    ///@brief Number of the last minislot in which a frame transmission can start in the dynamic segment.
    unsigned int pLatestTx;
    ///@brief ID of the slot used to transmit the startup frame, sync frame, or designated single slot frame.
    unsigned int pKeySlotId;
    ///@brief Flag indicating whether the Key Slot is used to transmit a startup frame.
    unsigned int pKeySlotUsedForStartup;
    ///@brief Flag indicating whether the Key Slot is used to transmit a sync frame.
    unsigned int pKeySlotUsedForSync;
    ///@brief Flag indicating whether or not the node shall enter single slot mode following startup.
    unsigned int pSingleSlotEnabled;
    ///@brief Number of repetitions of the wakeup symbol that are combined to form a wakeup pattern when the node
    /// enters the POC:wakeup send state.
    unsigned int pWakeupPattern;
    ///@brief The node's ability to act as coldstart node.
    unsigned int vColdstartInhibit;
    ///@brief Delay Compensation Channel A in [uT]
    unsigned int pDelayCompensationA;
    ///@brief  Delay Compensation Channel A in [uT]
    unsigned int pDelayCompensationB;
    ///@brief Defines if the controller is a Coldstart and/or/not Sync Node.
    unsigned int KeySlotMode;
} TAL_FlexRayControllerConfigType;

typedef struct
{
    /// @brief Cluster name.
    const unsigned char* pClusterName;
    ///@brief Identifier of the Cluster in the configuration DB.
    sint64 nClusterPk;
    ///@brief Nominal bit time in [us].
    double gdBit;
    ///@brief Number of bits in the Transmission Start Sequence in [gdBit].
    unsigned int gdTSSTransmitter;
    ///@brief Length of the cycle in [us].
    unsigned int gdCycle;
    ///@brief Duration of the cluster wide nominal macrotick in [us].
    double gdMacrotick;
    ///@brief Duration of a static slot in [MT].
    unsigned int gdStaticSlot;
    ///@brief Number of static slots in the static segment.
    unsigned int gNumberOfStaticSlots;
    ///@brief Number of macroticks the action point is offset from the beginning of a static slots or symbol window.
    unsigned int gdActionPointOffset;
    ///@brief Payload length of a static frame in [16 bit words].
    unsigned int gPayloadLengthStatic;
    ///@brief Duration of the idle phase within a dynamic slot in [Minislot].
    unsigned int gdDynamicSlotIdlePhase;
    ///@brief Duration of a minislot in [MT].
    unsigned int gdMinislot;
    ///@brief Number of macroticks the minislot action point is offset from the beginning of a minislot.
    unsigned int gdMinislotActionPointOffset;
    ///@brief Duration of the Network Idle Time in [MT].
    unsigned int gdNIT;
    ///@brief Duration of the symbol window in [MT].
    unsigned int gdSymbolWindow;
    ///@brief Offset correction start in [MT]
    unsigned int gOffsetCorrectionStart;
    ///@brief Offset correction max in [us]
    double gOffsetCorrectionMax;
    ///@brief Upper limit of the CAS acceptance window in [gdBit].
    unsigned int gdCASRxLowMax;
    ///@brief Number of bits used by the node to test the LOW portion of a received wakeup symbol in [gdBit].
    unsigned int gdWakeupSymbolRxLow;
    ///@brief Number of bits used by the node to test the duration of the idle portion of a received wakeup symbol in [gdBit].
    unsigned int gdWakeupSymbolRxIdle;
    ///@brief Number of bits used by the node to transmit the LOW part of a wakeup symbol in [gdBit].
    unsigned int gdWakeupSymbolTxLow;
    ///@brief Number of bits used by the node to transmit the idle part of a wakeup symbol in [gdBit].
    unsigned int gdWakeupSymbolTxIdle;
    ///@brief Number of minislots in the dynamic segment.
    unsigned int gNumberOfMinislots;
    ///@brief Length of the Network Management vector in a cluster in bytes.
    unsigned int gNetworkManagementVectorLength;
    ///@brief The channels that are used by the cluster.
    ///A = 0, B = 1,  A&B = 2
    unsigned int gChannels;
} TAL_FlexRayClusterConfigType;
/**
 * @cond EXCLUDE_FROM_DOCU
 *
 * @note This is an abstract type. Do not depend on its implementation in user
 * code!
 */
typedef struct
{
    TAL_PointerIntType statementHandle;
} TAL_DBIterator;
/* @endcond */

/**
 *
 * @brief Structure for reading/writing an EBY2XX register
 */
typedef struct
{
    /** address of register */
    uint32 reg;

    /** value of register */
    uint32 val;
} TAL_DevOpt_RegAccess;

/**
 *
 * @brief Structure for reading a block of EBY2XX registers
 */
typedef struct
{
    /** address of register block */
    uint32 addr;

    /** size of register block */
    uint32 size;

    /** address of buffer for received data */
    uint8* buf;
} TAL_DevOpt_RegBlockAccessRead;

/**
 *
 * @brief Structure for writing a block of EBY2XX registers
 */
typedef struct
{
    /** address of register block */
    uint32 addr;

    /** size of register block */
    uint32 size;

    /** address of buffer for data to be written */
    const uint8* buf;
} TAL_DevOpt_RegBlockAccessWrite;

/**
 *
 * @brief Structure for specifying a memory area
 */
typedef struct
{
    /** address of buffer (must be aligned to 64bit, if not the data will not be written from the beginning of the buffer.) */
    uint8* buf;

    /** size of buffer */
    uint32 size;
} TAL_DevOpt_Buffer;

/**
 *
 * @brief Structure for specifying a read-only memory area
 */
typedef struct
{
    /** address of buffer */
    const uint8* buf;

    /** size of buffer */
    uint32 size;
} TAL_DevOpt_Buffer_ro;

/**
 *
 * @brief Structure for setting timing option
 */
typedef struct
{
    /** Controller index*/
    uint8 ctrlIdx;

    /** value of grace period in ns */
    uint64 gracePeriodNs;

    /** value of no-report period in ns */
    uint64 noReportPeriodNs;
} TAL_DevOpt_ReplayTimingOptions;

/**
 *
 * @brief Structure for specifying CAN sampling point
 */
typedef struct
{
    /** Controller index */
    uint32 CANCC;

    /** CAN sampling point in percent */
    uint32 samplingPoint;

    /** CANFD sampling point phase in percent */
    uint32 samplingPointFd;

} TAL_DevOpt_CANSamplingPoint;

/**
 * @brief Enum for controller types in line termination
 *
 */
typedef enum
{
    TAL_LINETERM_CAN = 0,
    TAL_LINETERM_FlexRay = 1,
    TAL_LINETERM_LIN = 2
} TAL_LineTerm_ControllerType;

/**
 * @brief Structure for setting/getting line termination on EB2200/EB5200
 *
 */
typedef struct
{
    /** Type of controller (Use TAL_LineTerm_ControllerType as values) */
    uint32 controllerType;

    /** Controller index (zero-based)*/
    uint32 controllerIndex;

    /** Value of line termination (0=OFF, 1=ON, 0xFFFFFFFF=Undefined) */
    uint32 value;
} TAL_DevOpt_LineTerm;


/**
 *
 * @brief Enum for all known device options
 *
 * @typedef TAL_DeviceOptionType
 *  This enum defines all supported device options.
 */
typedef enum
{
    TAL_DEVOPT_UNKNOWN = 0,
    TAL_EB7200_GET_STATUS = 1 /**<Get channel status and event */
    ,
    TAL_EBHSCR_SET_BUFFER = 2 /**<DEPRECATED: Provide RX buffer for EBHSCR packets for EB devices */
    ,
    TAL_GET_TEMP_STATUS = 3 /**<Get temperature status for target device */
    ,
    TAL_EBY2XX_WRITE_BLOCKID = 4 /**<DEPRECATED: Write BLOCK ID message for EB7200 or EB8200 device */
    ,
    TAL_EBY2XX_ENABLE_RAW_CHANNEL = 5 /**<Enable raw data channel (0x01 - enabled; 0x00 - disabled) */
    /* number 6 reserved because of backwards compatibility */
    ,
    TAL_EBY2XX_GET_REGISTER_VALUE =
        7 /**<Get value from register (argument type: TAL_DevOpt_RegAccess) for EB7200 or EB8200 device */
    ,
    TAL_EBY2XX_SET_REGISTER_VALUE =
        8 /**<Set value in register: (argument type: TAL_DevOpt_RegAccess) for EB7200 or EB8200 device */
    ,
    TAL_EBY2XX_READ_BLOCKID = 9 /**<DEPRECATED: Read configuration block for EB7200 device or EB8200 device */
    ,
    TAL_EB8200_ENABLE_JUMBO_FRAME_SUPPORT =
        10 /**<Enable jumbo frame support for EB8200 device (0x01 - enabled; 0x00 - disabled) */
    ,
    TAL_EB8200_GET_ERROR_REPORT = 11 /**<Obsolete: Get error storage for EB8200 device */
    ,
    TAL_EBY2XX_GET_DAQ_TYPE = 12 /**<Get DAQ type for EB7200 or EB8200 device. Possible values ::TAL_ModuleType */
    ,
    TAL_EB8200_GET_EB1213_TEMP = 13 /**<Get temperature for EB8200 device in grad celsius */
    ,
    TAL_EB8200_SET_PTP_MODE = 14 /**<Set PTP mode for EB8200 device */
    ,
    TAL_EBY2XX_WRITE_BLOCK_ID =
        15 /**<write BLOCK ID message for EB 7200 or EB 8200 device (argument type: TAL_DevOpt_Buffer_ro) */
    ,
    TAL_EBY2XX_READ_BLOCK_ID =
        16 /**<read BLOCK ID message for EB 7200 or EB 8200 device (argument type: TAL_DevOpt_Buffer) */
    ,
    TAL_EBY2XX_READ_REGISTER_BLOCK =
        17 /**<read block of registers from EB 7200 or EB 8200 device (argument type: TAL_DevOpt_RegBlockAccessRead) */
    ,
    TAL_EBY2XX_WRITE_REGISTER_BLOCK =
        18 /**<write block of registers to EB 7200 or EB 8200 device (argument type: TAL_DevOpt_RegBlockAccessWrite) */
    ,
    TAL_EBY2XX_WRITE_FWUPD_BLOCK =
        19 /**<write block of registers for firmware update to EB 7200 or EB 8200 device (argument type: TAL_DevOpt_RegBlockAccessWrite) */
    ,
    TAL_EBHSCR_SET_BUF =
        20 /**<provide RX buffer for EBHSCR packets for EB devices (argument type: TAL_DevOpt_Buffer) */
    ,
    TAL_EB8200_SET_TIMESTAMP_BASE =
        22 /**<set the EBHSCR timestamp base for an EB8200 device (argument type: TAL_TimestampBaseType) */
    ,
    TAL_EBY2XX_REPLAY_TIMING_OPTIONS =
        23 /**< set the timing options grace period and no-report period for EB7200 or EB8200, currently only supported for 1000BASET1 modules (argument type: TAL_DevOpt_ReplayTimingOptions) */
    ,
    TAL_SET_PROCESS_TARGET_DATA_THREAD_PRIO =
        24 /**< set the priority of the process target data thread (argument type: uint32, value range: 0 .. 100 (highest)) */
    ,
    TAL_EBX200_SET_CAN_SAMPLING_POINT = DEVICE_OPTION_CODE(
        TAL_Major_BM_CANMessages,
        TAL_Minor_BM_SetCANSamplingPoint) /**<Set CAN Sampling point on EB2200 or EB5200 (argument type: TAL_DevOpt_CANSamplingPoint) */
    ,
    TAL_EBX200_SET_EBHSCR_MODE = DEVICE_OPTION_CODE(
        TAL_Major_Insp_Control_and_FPGA_Packet_ADIO,
        TAL_Minor_Insp_SetEbhscrMode) /**<Set EBHSCR mode on EB2200 or EB5200 (argument type: TAL_DevOpt_EBHSCRMode) */
    ,
    TAL_EBX200_SET_LINE_TERM = DEVICE_OPTION_CODE(
        TAL_Major_Insp_Control_and_FPGA_Packet_ADIO,
        TAL_Minor_Insp_SetLineTerm) /**<Set line termination on EB2200 or EB5200 (argument type: TAL_DevOpt_LineTerm) */
    ,
    TAL_EBX200_GET_LINE_TERM = DEVICE_OPTION_CODE(
        TAL_Major_Insp_Control_and_FPGA_Packet_ADIO,
        TAL_Minor_Insp_GetLineTerm) /**<Get line termination status on EB2200 or EB5200 (argument type: TAL_DevOpt_LineTerm) */
    ,
    TAL_EBX200_CONTROL_FLEXRAY_TX_COM_OPS = DEVICE_OPTION_CODE(
        TAL_Major_BM_FRMessages,
        TAL_Minor_BM_FRControlTxComOps) /**<Control FlexRay Com Ops (argument type: uint32, 0 .. disable, 1 .. enable) */
/* @cond EXCLUDE_FROM_DOCU */
#ifdef TAL_USE_DEPRECATED_ENUMS
    ,
    TAL_EB7200_SET_BUFFER = TAL_EBHSCR_SET_BUFFER,
    TAL_EB8200_SET_BUFFER = TAL_EBHSCR_SET_BUFFER,
    TAL_EBY2XX_SET_BUFFER = TAL_EBHSCR_SET_BUFFER,
    TAL_EBY2XX_GET_TEMP_STATUS = TAL_GET_TEMP_STATUS,
    TAL_EB7200_GET_TEMP_STATUS = TAL_GET_TEMP_STATUS,
    TAL_EBX2XX_GET_TEMP_STATUS = 6,
    TAL_EB5200_GET_TEMP_STATUS = TAL_EBX2XX_GET_TEMP_STATUS,
    TAL_EB7200_WRITE_BLOCKID = TAL_EBY2XX_WRITE_BLOCKID,
    TAL_EB8200_WRITE_BLOCKID = TAL_EBY2XX_WRITE_BLOCKID,
    TAL_EB7200_ENABLE_RAW_CHANNEL = TAL_EBY2XX_ENABLE_RAW_CHANNEL,
    TAL_EB7200_GET_REGISTER_VALUE = TAL_EBY2XX_GET_REGISTER_VALUE,
    TAL_EB7200_SET_REGISTER_VALUE = TAL_EBY2XX_SET_REGISTER_VALUE,
    TAL_EB7200_READ_BLOCKID = TAL_EBY2XX_READ_BLOCKID,
    TAL_EB8200_READ_BLOCKID = TAL_EBY2XX_READ_BLOCKID,
    TAL_EB7200_GET_DAQ_TYPE = TAL_EBY2XX_GET_DAQ_TYPE
#endif
    /* @endcond */
} TAL_DeviceOptionType;

typedef enum
{
    TAL_EB8200_DISABLE_PTP = 0,
    TAL_EB8200_ENABLE_PTP_ETH_0 = 1,
    TAL_EB8200_ENABLE_PTP_ETH_1 = 2,
    TAL_EB8200_ENABLE_PTP_ETH_2 = 3,
    TAL_EB8200_ENABLE_PTP_ETH_3 = 4
} TAL_EB8200PTPMode;

/**
 *
 * @brief Type to define the EBHSCR timestamp base for the EB8200 device.
 *
 *  This enum defines the available options for setting the EBHSCR timestamp
 *  for the EB8200 device.
 */
typedef enum
{
    TAL_EB8200_TIMESTAMP_BASE_DEFAULT = 0,     /**< zero-based timestamp in ns (NS_CNT) */
    TAL_EB8200_TIMESTAMP_BASE_OFFSET = 1,      /**< NS_CNT plus a given NS_OFFSET; approximately political time */
    TAL_EB8200_TIMESTAMP_BASE_OFFSET_LEAP = 2, /**< NS_CNT plus a given NS_OFFSET minus NS_LEAP; exact political time */
    TAL_EB8200_TIMESTAMP_BASE_LEAP = 3         /**< NS_CNT minus NS_LEAP */
} TAL_EB8200TimestampBaseType;

/**
 * @brief Enum for setting EBHSCR mode on EBX200 devices.
 *
 * This enum defines the available options for setting EBHSCR mode on EBX200 devices.
 * It must be used as argument for the device option: TAL_EBX200_SET_EBHSCR_MODE
 *
 */
typedef enum
{
    TAL_EBX200_DISABLE_EBHSCR_MEASUREMENT = 0,
    TAL_EBX200_ENABLE_EBHSCR_RX_MEASUREMENT = 1,
    TAL_EBX200_ENABLE_EBHSCR_TX_MEASUREMENT = 2,
    TAL_EBX200_ENABLE_EBHSCR_RXTX_MEASUREMENT = 3
} TAL_DevOpt_EBHSCRMode;

typedef TAL_DBIterator TAL_SignalConfigIterator;
typedef TAL_DBIterator TAL_SignalGroupConfigIterator;
typedef TAL_DBIterator TAL_PduConfigIterator;
typedef TAL_DBIterator TAL_MultiplexedPduConfigIterator;
typedef TAL_DBIterator TAL_FrameTriggeringConfigIterator;
typedef TAL_DBIterator TAL_CanClusterConfigIterator;
typedef TAL_DBIterator TAL_FlexRayControllerConfigIterator;
typedef TAL_DBIterator TAL_FlexRayClusterConfigIterator;
typedef TAL_DBIterator TAL_ContainerPduConfigIterator;
typedef TAL_DBIterator TAL_ContainedPduConfigIterator;

/**
 *
 * @brief Type to define the possible time sources
 *
 */
typedef enum
{
    TAL_TIMESRC_NONE = 0x00,             /**< free running time */
    TAL_TIMESRC_EB_TIMESYNC_HARD = 0x01, /**< hard syncing to EB timesync line */
    TAL_TIMESRC_XTSS = 0x02,             /**< syncing to b-plus XTSS time server */
    TAL_TIMESRC_PTP_HW_ETH0 = 0x03,      /**< syncing to Ethernet PTP (IEEE 1588) time server on EB8200 ethernet 0 */
    TAL_TIMESRC_PTP_HW_ETH1 = 0x04,      /**< syncing to Ethernet PTP (IEEE 1588) time server on EB8200 ethernet 1 */
    TAL_TIMESRC_PTP_HW_ETH2 = 0x05,      /**< syncing to Ethernet PTP (IEEE 1588) time server on EB8200 ethernet 2 */
    TAL_TIMESRC_PTP_HW_ETH3 = 0x06,      /**< syncing to Ethernet PTP (IEEE 1588) time server on EB8200 ethernet 3 */
    TAL_TIMESRC_PTP = 0x10,              /**< syncing to Ethernet PTP (IEEE 1588) time server */
    TAL_TIMESRC_GPS = 0x20,              /**< syncing with hardware GPS module */
    TAL_TIMESRC_EB_TIMESYNC_SOFT = 0x30, /**< soft synching to EB timesync line */
    TAL_TIMESRC_CAN = 0x40,              /**< syncing to CAN time server */
    TAL_TIMESRC_EB_VIRT = 0x50           /**< synchronized to EB virtual time server */
} TAL_TimeSourceType;

/**
 *
 * @brief Type to define the possible sync states of a time source
 *
 */
typedef enum
{
    TAL_TIMESYNCSTATE_FREERUNNING = 0,
    TAL_TIMESYNCSTATE_LOCKEDTOMASTER = 1
} TAL_TimeSyncStateType;

/**
 *
 * @brief Type which groups information about the time state
 *
 * @note EB7200 and EB8200 devices use only struct member 'ns_cnt'
 *
 */
typedef struct
{
    uint64 ns_cnt;                 /**< For EB2200 and EB5200 devices the 'ns_cnt' parameter is corrected locally,
                                    * considering the time difference between reception of the information and call
                                    * to the function, before the information is handed over to the user,
                                    * EB7200 and EB8200 devices use the 'ns_cnt' as current HW timestamp,
                                    * VirtualBus use only 'ns_cnt' */
    uint64 ns_cnt_last_jump;       /**< Point in time of last hard change/jump of time count after the
                                    * jump. Hard changes in time count indicate an error - this only
                                    * happens if smooth change is not possible. */
    sint64 ns_off;                 /**< The offset is the difference of the zero-based capture counter to TAI
                                    * (1.1.1970 00:00:00, without leap seconds) */
    uint64 ns_cnt_last_off_change; /**< Point in time of last change of time offset. Can be used to
                                    * track changes in time offset. */
    uint16 leap_sec_cnt;           /**< UTC leap-seconds. */
    TAL_TimeSyncStateType sync_state;
    TAL_TimeSourceType time_source;

} TAL_TimeStateType;
/*
 * Do not wrap with SWIG because SWIG does not support such big constants
 */
#ifndef SWIG
/**
 *
 * @brief Constant for invalid/unknown offset in TAL API TAL_SetEBTimeOffset/setEBTimeOffset
 *
 * @def TAL_NS_OFF_UNKNOWN
 *
 */
#define TAL_NS_OFF_UNKNOWN 0x7FFFFFFFFFFFFFFF
#endif
/**
 *
 * @brief Constant for invalid/unknown leap seconds count in TAL API TAL_SetEBTimeOffset/
 *        setEBTimeOffset
 *
 * Set to the largest possible signed long long (because offset is of that type)
 *
 * @def TAL_LEAP_SEC_CNT_UNKNOWN
 *
 */
#define TAL_LEAP_SEC_CNT_UNKNOWN 0xFFFF

/**
 *
 * @brief Structure to encapsulate information about EB2200 devices
 *
 * @struct TAL_DevInfo_SSDP
 *  This struct holds information about EB2200 devices through SSDP protocol.
 *
 */
typedef struct
{
    char TargetIPaddr[16];  /**< IP address of target */
    char HostIPAddr[16];    /**< IP address of host */
    char EthInterface[256]; /**< description of host ethernet interface */
} TAL_EthDeviceInfoType;

/**
 *
 * @brief Structure to encapsulate information about EB2200 devices
 *
 * @struct TAL_DevInfo_SSDP
 *  This struct holds information about EB2200 devices through SSDP protocol.
 *
 */
typedef struct TAL_EthDeviceListEntryType
{
    TAL_EthDeviceInfoType DevInfo; /**< Host and Target IP info */
    struct TAL_EthDeviceListEntryType* Next;
} TAL_EthDeviceListEntryType, *TAL_EthDiscoveryIterator;

/**
 *
 * @brief Enum adapter types
 *
 * @typedef TAL_AdapterType
 *  This enum defines the detected network adapter types.
 */
typedef enum
{
    TAL_ADAPTER_UNKNOWN = 0 /**< Unknown type */
    ,
    TAL_ADAPTER_ETHERNET_WIRED = 1 /**< Wired Ethernet */
    ,
    TAL_ADAPTER_ETHERNET_WIRELESS = 2 /**< Wireless Ethernet */
} TAL_AdapterType;

/**
 *
 * @brief Structure to encapsulate information a network adapter
 *
 * @struct TAL_DevInfo_SSDP
 *  This struct holds information about a local network adapter.
 *
 */
typedef struct
{
    char Name[256];       /**< description of host ethernet interface */
    char IPAddr[16];      /**< IP address of adapter */
    char netmask[16];     /**< netmask of adapter */
    TAL_AdapterType Type; /**< Adapter Type */
} TAL_AdapterInfoType;

/**
 *
 * @brief Structure to encapsulate information all local network interfaces
 *
 * @struct TAL_AdapterListIterator
 *  This struct holds information about all local network interfaces.
 *
 */
typedef struct TAL_AdapterListEntryType
{
    TAL_AdapterInfoType AdapterInfo; /**< Adapter info */
    struct TAL_AdapterListEntryType* Next;
} TAL_AdapterListEntryType, *TAL_AdapterListIterator;


typedef void (*TAL_HBR_ClientSubscribedCallbackType)(TAL_SessionHandleType sessionHandle, uint16 serviceId, uint16 instanceId, uint16 eventGroupId);

typedef void (*TAL_HBR_ServiceAvailableCallbackType)(TAL_SessionHandleType sessionHandle, uint16 serviceId, uint16 instanceId);

typedef void (*TAL_HBR_PduReceivedCallbackType)(TAL_SessionHandleType sessionHandle, const uint64* ebhscrPdu);

typedef struct TAL_HBR_Buffer
{
    uint64* pBuffer;
    uint64 bufferLen;
} TAL_HBR_Buffer;

/**
 *
 * @brief Enum crypto algorithm types
 *
 * @typedef TAL_Crypto_AlgorithmType
 *  This enum defines the supported crypto algorithms.
 */
typedef enum
{
    TAL_CMAC_AES_128 = 0,
    TAL_SIPHASH_24 = 1,
}TAL_Crypto_AlgorithmType;

/**
 *
 * @brief Structure to encapsule SecOC security Profiles
 *
 * @struct TAL_SecOC_ProfileType
 *  This struct holds information about the SecOC configuration for a specific I-PDU.
 *
 */
typedef struct
{
    uint8 HeaderLength;                             /** Length of Secured I-PDU Header in bytes, RANGE 0 .. 4, This header is in front of the Authentic
                                                    I-PDU and if available (>0), contains the length of bytes of the Authentic I-PDU.
                                                    Implementation note: our implementation shall not be limited to the RANGE specified by AUTOSAR currently,
                                                    nor shall it do range checks. For our implementation the possible range shall be 0 .. MAX_UINT8 */

    uint8 FreshnessValueLength;                     /**  number of bits of the freshness value. RANGE: 8 .. 64.Valid values are multiple of bytes bits.
                                                    i.e. 8, 16, 24, ... 64. Implementation note: Our implementation shall _not_ check validity of this value,
                                                    Its a prerequisite of our API that only those values mentioned are used. */

    uint8 FreshnessValueTxLength;                   /**  number of LSB-bits of freshness value transmitted within the Secured I-PDU. 0 means the freshness value
                                                    will not be transmitted within the Secured I-PDU.  >0 means the FreshnessValue will be truncated to the
                                                    given bit length. Maximum value allowed is FreshnessValueLength, which means that no truncation happens.
                                                    RANGE: 0 .. FreshnessValueLength  */

    uint32 SecOCAuthDataFreshnessStartPosition;     /** Starting bit of the freshnessvalue inside the authentic PDU. If not zero specified bitarray will be used as freshness */
    uint32 SecOCAuthDataFreshnessLen;               /** Length in bits */

    uint8 FreshnessValueSyncAttempts;               /** Maximal number of Attempts to reconstruct the freshness value and verify the Secured I-Pdu. */

    uint16 AuthInfoTxLength;                        /** Number of MSB-bits of truncated Authenticator to be transmitted within the Secured I-PDU.
                                                    RANGE 1 .. MaxNumberBitsAuthenticator. MaxNumberBitsAuthenticator depends on the Authentication Algorithm. */

    uint32 MessageLinkerPos;                        /** The bit position of the Meassage Linker in the Authentic I-PDU. */
    uint32 MessageLinkerLen;                        /** The length of the message linker in bits. To disable message linker set to 0 */

    TAL_Crypto_AlgorithmType CryptoAlgorithm;       /** Algorithm used to generate the Message authentication code. */
} TAL_SecOC_ProfileType;

#endif /* _TAL_TYPES_H_ */
