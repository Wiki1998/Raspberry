/* BUSTOOLS-DONT-COMPARE */
/**
 * @file Platform_Types.h
 *
 * @date 2019
 * 
 * @author gueb
 *
 *
 * @copyright Copyright 2019-2020 Elektrobit Austria GmbH,
 *            http://www.elektrobit.com/, All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 *
 */
#ifndef PLATFORM_TYPES_H
#define PLATFORM_TYPES_H

#include <stdint.h>
#include <inttypes.h>
/*
 * If TAL_DO_NOT_USE_STD_TYPES is defined the user has to provide his own type
 * definitions for boolean, sint8, sint16, sint32, sint64, uint8, uint16,
 * uint32, uint64, float32 and float64.
 */
#ifndef TAL_DO_NOT_USE_STD_TYPES

typedef int8_t sint8;
typedef int16_t sint16;
typedef int32_t sint32;
typedef int64_t sint64;
typedef uint8_t uint8;
typedef uint16_t uint16;
typedef uint32_t uint32;
typedef uint64_t uint64;
typedef sint32 sint8_least;
typedef sint32 sint16_least;
typedef sint32 sint32_least;
typedef uint32 uint8_least;
typedef uint32 uint16_least;
typedef uint32 uint32_least;
typedef float float32;
typedef double float64;
typedef unsigned char boolean;

#endif /* TAL_DO_NOT_USE_STD_TYPES */

/* for some architectures the uint64/sint64 print formats may not be defined */
#ifndef PRIu64
#define PRIu64 "llu"
#endif
#ifndef PRId64
#define PRId64 "lld"
#endif
#ifndef PRIx64
#define PRIx64 "llx"
#endif

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif
#ifndef SWIG
#define HIGH_BYTE_FIRST 0U
#define LOW_BYTE_FIRST 1U
#define CPU_TYPE_8   8U
#define CPU_TYPE_16 16U
#define CPU_TYPE_32 32U
#define CPU_TYPE_64 64U
#endif
#ifdef EBX2XX
#define CPU_BYTE_ORDER HIGH_BYTE_FIRST
#define CPU_TYPE CPU_TYPE_32
typedef uint32 usize;
#else
#define CPU_BYTE_ORDER LOW_BYTE_FIRST
#define CPU_TYPE CPU_TYPE_64
typedef uint64 usize;
#endif

#if (!defined HAS_64BIT_TYPES)
#define HAS_64BIT_TYPES
#endif

#if (!defined USIZE_C)
/** \brief Macro to define a constant of platform specific type usize (generated, depending on parameter 'Cpu.Type') */
/* Deviation MISRAC2012-1 <+2> */
#define USIZE_C(x) (x ## UL)
#endif

/* !LINKSTO Base.Properties.OverrideMemCpy,1 */
#if (defined TS_MEMCPY_CUSTOM_OVERRIDE)
#error TS_MEMCPY_CUSTOM_OVERRIDE already defined
#endif

/** \brief Macro for enabling overriding of the memory copy function by a custom implementation
 *
 * Range:
 *  - STD_ON (if configuration parameter 'Base/CustomOverrides/CustomOverride_MemCpy' enabled)
 *  - STD_OFF (if configuration parameter 'Base/CustomOverrides/CustomOverride_MemCpy' disabled)
 */
#define TS_MEMCPY_CUSTOM_OVERRIDE STD_OFF

/* !LINKSTO Base.Properties.OverrideMemSet,1 */
#if (defined TS_MEMSET_CUSTOM_OVERRIDE)
#error TS_MEMSET_CUSTOM_OVERRIDE already defined
#endif

/** \brief Macro for enabling overriding of the memory set function by a custom implementation
 *
 * Range:
 *  - STD_ON (if configuration parameter 'Base/CustomOverrides/CustomOverride_MemSet' enabled)
 *  - STD_OFF (if configuration parameter 'Base/CustomOverrides/CustomOverride_MemSet' disabled)
 */
#define TS_MEMSET_CUSTOM_OVERRIDE STD_OFF

/* !LINKSTO Base.Properties.OverrideMemCmp,1 */
#if (defined TS_MEMCMP_CUSTOM_OVERRIDE)
#error TS_MEMCMP_CUSTOM_OVERRIDE already defined
#endif

/** \brief Macro for enabling overriding of the memory compare function by a custom implementation
 *
 * Range:
 *  - STD_ON (if configuration parameter 'Base/CustomOverrides/CustomOverride_MemCmp' enabled)
 *  - STD_OFF (if configuration parameter 'Base/CustomOverrides/CustomOverride_MemCmp' disabled)
 */
#define TS_MEMCMP_CUSTOM_OVERRIDE STD_OFF

/* !LINKSTO Base.Properties.OverrideMemBZero,1 */
#if (defined TS_MEMBZERO_CUSTOM_OVERRIDE)
#error TS_MEMBZERO_CUSTOM_OVERRIDE already defined
#endif

/** \brief Macro for enabling overriding of the memory zeroing function by a custom implementation
 *
 * Range:
 *  - STD_ON (if configuration parameter 'Base/CustomOverrides/CustomOverride_MemBZero' enabled)
 *  - STD_OFF (if configuration parameter 'Base/CustomOverrides/CustomOverride_MemBZero' disabled)
 */
#define TS_MEMBZERO_CUSTOM_OVERRIDE STD_OFF

#endif
