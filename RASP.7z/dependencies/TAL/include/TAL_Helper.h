/*
 * File    : $RCSfile: TAL_Helper.h,v $ (cvs $Revision: 1.1 $)
 *
 * Module  : TAL_Helpers
 * Release : $Name: not supported by cvs2svn $
 * Date    : $Date: 2007-10-12 12:56:08 $
 * Author  : $Author: gernot $
 *
 * Description:
 * Interface header file for class TAL_Helpers.
 *
 * Copyright 2002-2010 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifndef _TAL_HELPER_H_
#define _TAL_HELPER_H_

/******************************************************************************
 Include Section
******************************************************************************/

#include <stdint.h>
#include "TAL_Std_Types.h"
#include "TAL_Endian.h" /* must be included after TAL_Std_Types.h in order to */
                        /* take advantage from endian macros defined there */
#include "TAL_EBHSCR.h" /* also include after TAL_Std_Types.h */

/******************************************************************************
 Global Macros
******************************************************************************/

#if (!defined ARRAY_SIZE)
#define ARRAY_SIZE(a) (sizeof (a) / sizeof ((a)[0]))
#endif /* if (not defined ARRAY_SIZE) */

/*---------------------------------------------------------------------------*/

static inline unsigned int Sawtooth2monotone(unsigned int nBitOffset)
{
    return (nBitOffset&~7U) | (7U-(nBitOffset&7U));
}

/*---------------------------------------------------------------------------*/

static inline unsigned int Monotone2sawtooth(unsigned int nBitOffset)
{
    return Sawtooth2monotone(nBitOffset); // also works vice-versa
}

/*---------------------------------------------------------------------------*/

static inline uint32_t RoundUpUint32( uint32_t nVal )
{
    return ( nVal + 3 ) / 4 * 4;
}

/*---------------------------------------------------------------------------*/

static inline uint64_t RoundUpUint64( uint64_t nVal )
{
    return ( nVal + 7U ) / 8U * 8U;
}

/*---------------------------------------------------------------------------*/

static inline void tal_set_hdr(uint32_t *tal_hdr, uint8_t major, uint8_t minor, uint32_t len)
{
    uint32 hdr = ((uint32_t)major << 24U) |
                 ((uint32_t)minor << 16U) |
                 (uint8_t)(RoundUpUint32(len)/4U);
    *tal_hdr = CpuToBigEndianU32(hdr);
}

/******************************************************************************
 Global Data Types
******************************************************************************/

/******************************************************************************
 Global Data
******************************************************************************/

/******************************************************************************
 Global Function Declarations
******************************************************************************/
#ifdef __cplusplus
template <class T>
T TAL_Min(const T & rA, const T & rB)
{
    return (rA < rB) ? rA : rB;
}

template <class T>
T TAL_Max(const T & rA, const T & rB)
{
    return (rA > rB) ? rA : rB;
}

template <class T>
void TAL_Swap(T & rA, T & rB)
{
    const T temp = rA;
    rA = rB;
    rB = temp;
}
#endif

/******************************************************************************
 Forward Class Declarations
******************************************************************************/

/******************************************************************************
 Class Declarations
******************************************************************************/

/**
 * @endcond
 */

#endif /* _TAL_HELPER_H_ */
