/*
 * File    : TAL_Impl.h
 *
 * Module  : EB_tresos_TAL
 *
 * Description:
 * Interface header file for TAL. Implements both the C API and a C++ wrapper
 * for the C API. Kept in same file to ease maintenance (only one API docu
 * ...). Keep in mind that this file must be processed by doxygen for API Docu
 * generation and by SWIG to generate Python and Java wrappers. So please keep
 * macro-magic at a minimum level.
 *
 * Please also use the same coding convention in this header file. This eases
 * automatic processing of this header file. Therefore the rule that the
 * textwidth shall be 80 is not applicable to this file.
 *
 * Copyright 2002-2012 Elektrobit Austria GmbH, http://www.elektrobit.com/
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 * Not all active architectures are supported by default.
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

/**
 *
 * @file TAL_Impl.h
 *
 * This file provides the implementation of the TAL header.
 * Do not include this file directly, include TAL.h instead.
 *
 */

#ifndef _TAL_H_
#error "Do not include TAL_Impl.h directly, include TAL.h instead"
#else /* _TAL_H_ */

#include "TAL_Types.h"             /* TAL types */
#include "TAL_EBHSCR.h"
#ifndef SWIG
#include "TAL_Sleep.h"             /* TAL_Sleep */
#include "TAL_DeprecatedTypes.h"   /* TAL deprecated types */
#include "TAL_DeprecatedApi.h"     /* TAL deprecated interface */
#ifdef TAL_CXX_API
#include "TAL_CxxTypes.h"
#include "TAL_MeasureData.h"
#endif /* TAL_CXX_API */
#endif /* SWIG */

#ifdef SWIG
#ifndef TAL_DEPRECATED
#define TAL_DEPRECATED             /* SWIG: empty TAL_DEPRECATED macro */
#endif /* TAL_DEPRECATED */
#endif /* SWIG */

#ifndef TAL_TH_BM_PHYSICAL_ENABLED
#error macro TAL_TH_BM_PHYSICAL_ENABLED not defined
#endif /* TAL_TH_BM_PHYSICAL_ENABLED */

/*
 * ATTENTION: It is by-purpose that no C++ wrappers exists for the following
 * callbacks
 */
#ifdef TAL_CXX_API
#ifndef SWIG
extern "C"
{

/**
 * @brief Can be used as callback parameter for TAL_BM_RegisterForRecvSignal()
 * function to schedule events for TAL_GetEvent().
 */
TAL_API extern void
TAL_SignalCallback(TAL_SessionHandleType sessionHandle,
                   TAL_BM_SignalIndexType signalIndex);

/**
 * @brief Can be used as callback parameter for
 * TAL_BM_RegisterForRecvSignalGroup() function to schedule events for
 * TAL_GetEvent().
 */
TAL_API extern void
TAL_SignalGroupCallback(TAL_SessionHandleType sessionHandle,
                        TAL_BM_SignalGroupIndexType signalGroupIndex);

/**
 * @brief Can be used as callback parameter for
 * TAL_BM_RegisterForRecvPdu() function to schedule events for TAL_GetEvent().
 */
TAL_API extern void
TAL_PDUCallback(TAL_SessionHandleType sessionHandle,
                TAL_BM_PDUIndexType pduID);

/**
 * @brief Can be used as callback parameter for TAL_BM_RegisterForRecvFrame()
 * function to schedule events for TAL_GetEvent().
 */
TAL_API extern void
TAL_FrameCallback(TAL_SessionHandleType sessionHandle,
                  TAL_BM_FrameIndexType frameIndex);

/**
 * @brief Can be used as callback parameter for TAL_BM_CANFDInit(),
 * TAL_BM_RegisterForRecvCANMsg(), TAL_BM_RegisterForRecvCANMsgFilter(),
 * TAL_BM_RegisterForCANTxConfirmation(),
 * TAL_BM_RegisterForCANTxConfirmationFilterRange() and
 * TAL_BM_RegisterForRecvCANMsgFilterRange() functions to schedule events for
 * TAL_GetEvent().
 */
TAL_API extern void
TAL_CANCallback(TAL_SessionHandleType sessionHandle,
                uint8 CANCC,
                TAL_BM_CANMessageIDType QueueID);

/**
 * @brief Can be used as callback parameter for TAL_BM_RegisterForCurrentState()
 * function to schedule events for TAL_GetEvent().
 */
TAL_API extern void
TAL_SdCurrentStateEventCallback(TAL_SessionHandleType sessionHandle,
                                uint32 nId,
                                TAL_BM_SdCurrentStateType state);
/**
 * @brief Can be used as callback parameter for TAL_initLin()
 * function to schedule events for TAL_GetEvent().
 */
TAL_API extern void
TAL_LinCallback(TAL_SessionHandleType sessionHandle,
                uint8 nCtrlIdx,
                TAL_Lin_StatusType status,
                TAL_Lin_FrameCsModelType checksumModel,
                uint8 nMessageId,
                const uint8 *pData,
                uint8 nPayloadLength);
/**
 * @brief Can be used as callback parameter for TAL_BM_RegisterForDigitalIn()
 * function to schedule events for TAL_GetEvent().
 */
TAL_API extern void
TAL_DIOCallback(TAL_SessionHandleType sessionHandle,
                TAL_BM_DigitalIOPinIDType digitalPinID,
                TAL_BM_DigitalValueType digitalValue);

/**
 * @brief Can be used as callback parameter for
 * TAL_TUM_RegisterForRecvUserDataNotification() function to schedule events
 * for TAL_GetEvent().
 */
TAL_API extern void
TAL_TUMCallback(TAL_SessionHandleType sessionHandle,
                TAL_TUM_IDType nTUM_ID,
                TAL_TUM_InstanceIDType nTUM_InstanceID,
                const uint8 * pUserData,
                uint16 nUserDataLength);

/**
 * @brief Can be used as callback parameter for TAL_BM_RegisterForPOCStatus()
 * function to schedule events for TAL_GetEvent().
 */
TAL_API extern void
TAL_POCCallback(TAL_SessionHandleType sessionHandle,
                uint8 nFRCtrlIdx);

/**
 * @brief Can be used as callback parameter for TAL_RegisterForTargetCPULoad()
 * function to schedule events for TAL_GetEvent().
 */
TAL_API extern void
TAL_CPUCallback(TAL_SessionHandleType sessionHandle,
                uint32 nAverage_point1s,
                uint32 nAverage_1s,
                uint32 nAverage_10s);

/**
 * @brief Can be used as callback parameter for
 * TAL_RegisterForTargetRAMUsage() function to schedule events for
 * TAL_GetEvent().
 */
TAL_API extern void
TAL_RAMCallback(TAL_SessionHandleType sessionHandle,
                uint32 nMemorySize,
                uint32 nUsedMemory,
                uint32 nFreeMemory);

} /* extern "C" */
#endif /* SWIG */
#endif /* TAL_CXX_API */

#ifdef TAL_CXX_API
class TAL_API TalInterface
{
private:
    TAL_SessionHandleType m_sessionHandle;
public:
    TalInterface();
    virtual ~TalInterface();
#endif /* TAL_CXX_API */

#if (defined __cplusplus) && (!defined TAL_CXX_API)
extern "C"
{
#endif

/**
 * @defgroup busmirror_session Busmirror session related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_Startup instead.
 * @endif
 * @endif
 *
 * @brief Load and initialize a Busmirror target application
 *
 * This function connects to the given Busmirror hardware device, loads
 * the configuration given within the .ttc file and creates a session
 * with the target device.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param pSessionHandle Generated session handle (out-parameter)
 * @endif
 * @param eConnectionType Type of connection to the hardware device.
 *        Possible values are: TAL_USB, TAL_PCI, TAL_TCP, TAL_DUMMY.
 * @param sDeviceName 'Name' of hardware or virtual device to connect to, given as string.\n
 *        In case of 'TAL_TCP' this is an Ethernet IP address optionally
 *        followed by a colon and port number (e.g. "127.0.0.1:10010").
 *        If no port is given (e.g. "127.0.0.1") the default port of the hardware 10010 is used.
 *        On Windows a host name may be used instead of an IP address.\n
 *        In case of 'TAL_USB' it is the serial number of the device.\n
 *        In case of 'TAL_PCI' it is the serial number of the device or the device 'index' (that
 *        is, the number of the device if there are more devices of the same
 *        kind; use '0' if only one device is present).
 * @param sTtcFile Name of the ttc-file to download to the target. If 0,
 *        no ttc-file is loaded;
 *        you may specify an .elf file instead of a .ttc file too
 * @param bWaitUntilReady Wait until target is ready, otherwise return after
 *        ttc-file is loaded
 * @param bCleanStartup Load given application to target even if the same
 *        application is already running on the target;
 *        if the flag is not set, connect to an already running application
 *        on the target if it is the same application then the one given
 *
 * @retval TAL_SUCCESS            The function call executed successfully
 * @retval TAL_FAILED             The function call failed to execute
 * @retval TAL_INVALID_ARGUMENT   One or more arguments contain invalid values
 * @retval TAL_NULL_POINTER       The function call failed cause a null pointer is
 *                                supplied where it is not allowed
 * @retval TAL_OUT_OF_MEMORY      The function could not allocate enough memory
 * @retval TAL_ENCODING_ERROR     The function call failed due to an error when
 *                                encoding a package
 * @retval TAL_FILE_NOT_FOUND     unable to open provided filename
 * @retval TAL_COMM_ERROR         The function call failed due to an error in the
 *                                communication with the target
 * @retval TAL_TIMEOUT            Timeout in communication with target occurred
 * @retval TAL_FILE_ACCESS_FAILED File is not present or no valid .ttc file
 *
 * \b Example
 * \snippet Applications/EtherCATd/lib_src/tal_access.c example_TAL_Startup
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_Startup(TAL_SessionHandleType * pSessionHandle,
            TAL_ConnectionType eConnectionType,
            const char * sDeviceName,
            const char * sTtcFile,
            TAL_Boolean bWaitUntilReady,
            TAL_Boolean bCleanStartup);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
startup(TAL_ConnectionType eConnectionType,
        const char * sDeviceName,
        const char * sTtcFile,
        bool bWaitUntilReady,
        bool bCleanStartup);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please the use equivalent C TAL API function TAL_StartupMem instead.
 * @endif
 * @endif
 *
 * @brief Load and initialize a Busmirror target application
 *
 * This function connects to the given Busmirror hardware device, loads
 * the configuration given within a .ttc file located in memory
 * and creates a session with the target device.
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param pSessionHandle Generated session handle (out-parameter)
 * @endif
 * @param eConnectionType Type of connection to the hardware device.
 *        Possible values are: TAL_USB, TAL_PCI, TAL_TCP, TAL_DUMMY.
 * @param sDeviceName 'Name' of hardware device to connect to, given as string.
 *        In case of 'TAL_TCP' this is an Ethernet address or host name, otherwise
 *        it is the serial number of the device or the device 'index' (that
 *        is, the number of the device if there are more devices of the same
 *        kind; use '0' if only one device is present)
 * @param pTtcFileBuf Pointer to the memory area containing the ttc-file
 *        to download to the target.
 * @param nTtcFileSize Size of the ttc-file
 * @param bWaitUntilReady Wait until target is ready, otherwise return after
 *        ttc-file is loaded
 * @param bCleanStartup Load given application to target even if the same
 *        application is already running on the target;
 *        if the flag is not set, connect to an already running application
 *        on the target if it is the same application then the one given
 *
 * @retval TAL_SUCCESS          The function call executed successfully
 * @retval TAL_FAILED           The function call failed to execute
 * @retval TAL_INVALID_ARGUMENT One or more arguments contain invalid values
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer is
 *                              supplied where it is not allowed
 * @retval TAL_OUT_OF_MEMORY    The function could not allocate enough memory
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package
 * @retval TAL_COMM_ERROR       The function call failed due to an error in the
 *                              communication with the target
 * @retval TAL_TIMEOUT          Timeout in communication with target occurred
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_StartupMem(TAL_SessionHandleType * pSessionHandle,
               TAL_ConnectionType      eConnectionType,
               const char            * sDeviceName,
               const uint8           * pTtcFileBuf,
               uint32                  nTtcFileSize,
               TAL_Boolean             bWaitUntilReady,
               TAL_Boolean             bCleanStartup);
#else /* TAL_CXX_API */
#ifndef SWIG /* const uint8* problematic in swig wrapper */
virtual TAL_DEPRECATED TAL_ReturnType
startupMem(TAL_ConnectionType eConnectionType,
           const char * sDeviceName,
           const uint8 * pTtcFileBuf,
           uint32 nTtcFileSize,
           bool bWaitUntilReady,
           bool bCleanStartup);
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_StartupDefault instead.
 * @endif
 * @endif
 *
 * @brief Load and initialize a Busmirror target application
 *
 * This function connects to the given Busmirror hardware device, loads
 * a default configuration and creates a session with the target device.
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param pSessionHandle Generated session handle (out-parameter)
 * @endif
 * @param eHardwareType Type of hardware to connect to
 * @param eConnectionType Type of connection to the hardware device.
 *        Possible values are: TAL_USB, TAL_PCI, TAL_TCP, TAL_DUMMY, TAL_UDP.
 * @param sDeviceName 'Name' of hardware device to connect to, given as string.
 *        In case of 'TAL_TCP' this is an Ethernet address or host name, in
 *        case of 'TAL_UDP' it consists of a source, a destination Ethernet
 *        address, a module slot number (0..3) and a Ethernet interface number
 *        (0..3) like \<src_ip\>:\<dest_ip\>:\<ModuleSlot\>:\<EthInterface\>,
 *        in case of 'TAL_PCI' with eHardwareType 'TAL_EB72XX' it consists of
 *        the serial number of the device and the module slot number like
 *        \<serial\>:\<ModuleSlot\>, with eHardwareType 'TAL_EB5200' it
 *        consists only of the serial number of the device.
 * @param bWaitUntilReady Wait until target is ready, otherwise return after
 *        ttc-file is loaded
 * @param bCleanStartup Load given application to target even if the same
 *        application is already running on the target;
 *        if the flag is not set, connect to an already running application
 *        on the target if it is the same application then the one given
 *
 * @note  In case of 'TAL_PCI' sDeviceName can consist of a device 'index'
 *        instead of the serial number (i.e. the number of the device in case
 *        of several similar devices; use '0' if only one device is available)
 *
 * @note  ATTENTION: for the legacy EB7200 base devices, sDeviceName consists
 *        of a channel index (0..47) instead of a module slot number
 *
 * @retval TAL_SUCCESS          The function call executed successfully
 * @retval TAL_FAILED           The function call failed to execute
 * @retval TAL_INVALID_ARGUMENT One or more arguments contain invalid values
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer is
 *                              supplied where it is not allowed
 * @retval TAL_OUT_OF_MEMORY    The function could not allocate enough memory.
 *                              In Linux the max. receive buffer size is limited
 *                              in /proc/sys/net/core/rmem_max file. This value
 *                              should be increased to 256MB, if the function
 *                              fails (cmd: sysctl -w net.core.rmem_max=268435456)
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package
 * @retval TAL_COMM_ERROR       The function call failed due to an error in the
 *                              communication with the target
 * @retval TAL_TIMEOUT          Timeout in communication with target occurred
 * @retval TAL_NO_DEVICE        The function call failed because the specified
 *                              device was not found. This return value is
 *                              currently only supported for the EB7200
 *
 * \b Example
 * \snippet Applications/EBy2xx_LVDSTest/src/EBy2xx_LVDSTest.cpp example_TAL_StartupDefault
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_StartupDefault(TAL_SessionHandleType * pSessionHandle,
                   TAL_HardwareType        eHardwareType,
                   TAL_ConnectionType      eConnectionType,
                   const char            * sDeviceName,
                   TAL_Boolean             bWaitUntilReady,
                   TAL_Boolean             bCleanStartup);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
startupDefault(TAL_HardwareType eHardwareType,
               TAL_ConnectionType eConnectionType,
               const char * sDeviceName,
               bool bWaitUntilReady,
               bool bCleanStartup);
#endif /* TAL_CXX_API */

#ifdef TAL_CXX_API
/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_Startup instead.
 * @endif
 * @endif
 *
 * @brief Gets the session handle of the TalInterface object.
 *
 * This function returns the session handle. The session handle is needed
 * when using the C API So this API can be used to mix C++ and C TAL api
 * usage in the user application. Some functions are only available in C.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @retval Session handle. 0 if no session is available (startup() was not
 * called)
 */
virtual TAL_DEPRECATED TAL_SessionHandleType
getSessionHandle();
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_DeleteSession instead.
 * @endif
 * @endif
 *
 * @brief Disconnect and Delete an existing session with the target
 *
 * This function deletes an existing session with a target device.
 * This results in a disconnect on TCP, PCI or USB depending on the session
 * type. When using the function based C API a call to this function is
 * mandatory to do not cause memory leaks and to be able to connect again with
 * the target (only one open connection allowed). When using the object
 * oriented API a call of the destructor of the TalInterface class also
 * deletes the session but some object oriented languages do not destroy
 * objects in a predictable way and therefore an explicit call to this function
 * shall be made.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle  handle of the session, which has to be deleted
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @note If no session was established before calling this function the
 *       return value will be \c TAL_FAILED.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_DeleteSession(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
disconnect();
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_ResetAndDeleteSession instead.
 * @endif
 * @endif
 *
 * @brief Reset target device and delete session with target
 *
 * This function tries to reset the target and deletes the session afterwards.
 * What really happens depends on the type of hardware you are using.
 *
 * EB2200, EB5200: The second core, which runs the Firmware.ttc, is halted.
 * The first core, which runs Linux, is not halted. It waits for a new
 * Firmware.ttc.
 *
 * EB7200: The FPGA on the EB7200 is reset.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle  handle of the session, which has to be deleted
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @note If no session was established before calling this function the
 *       return value will be \c TAL_FAILED.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ResetAndDeleteSession(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
reset();
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_ProcessTargetData instead.
 * @endif
 * @endif
 *
 * @brief Process all target data, triggered by nonblocking actions
 *
 * This function receives all data from the target, triggered by non blocking
 * API calls, or for periodic response from the target.
 * When used combined with the Busmirror TopHalf this function e.g. reads the
 * receive buffers of the given session and, if it contains signal
 * values for subscribed signals they are stored in the signal base.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 *
 * @param nMaxIterations   Max. number of iterations the function should try to
 *                         receive data from the target. Using 0 means using a
 *                         built-in default TAL_BH_BGHANDLER_MAX_ITERATIONS
 *                         (currently 10000). Together with the return value of
 *                         this function this parameter can be used to notice
 *                         high receive load.
 *
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @retval TAL_SUCCESS Data available and the function could empty the
 *                     receive-queue within nMaxIterations iterations.
 *
 * @retval TAL_HIGH_LOAD The function could not empty the receive-queue within
 *                       nMaxIterations iteration. Could be used to notice
 *                       high receive load.
 *
 * @retval TAL_FAILED An error occurred during execution
 *
 * \b Example
 * \snippet Applications/EBy2xx_LVDSTest/src/EBy2xx_LVDSTest.cpp example_TAL_ProcessTargetData
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ProcessTargetData(TAL_SessionHandleType sessionHandle,
                      sint16 nMaxIterations);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
processTargetData(sint16 nMaxIterations) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_ProcessTargetDataUntilEvent instead.
 * @endif
 * @endif
 *
 * @brief Process all target data until event was triggered
 *
 * This function receives all data from the target, triggered by non blocking
 * API calls, or for periodic response from the target.
 * When used combined with the Busmirror TopHalf this function e.g. reads the
 * receive buffers of the given session and, if it contains signal
 * values for subscribed signals they are stored in the signal base.
 *
 * In order to receive events you have to register events at the event queue
 * by supplying a TAL_*Callback callback functions as argument to a
 * registration function (this is the default for scripting languages).
 *
 * Events are posted from the context of this function. Therefore this function
 * does not loose a fast updated signal value on systems where oversampling is
 * not possible.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pType type of the event. Call TAL_GetEvent() with this event type to
 * get the event data.
 * @else
 * @param pType Event type of type TalEventType. Call getEvent() with this
 * events type to get the event data.
 * @endif
 *
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @retval TAL_SUCCESS Event available. Process the event and call this
 * function again (preferably without a sleep time).
 *
 * @retval TAL_NO_DATA No new event available. Please continue calling this
 * function (e.g. after a short sleep time) until an event was received.
 *
 * @retval TAL_FAILED An error occurred during execution
 *
 * @retval TAL_NULL_POINTER mandatory argument was a null pointer
 *
 * @remark Do not call TAL_ProcessTargetData() or
 * TAL_StartProcessTargetDataThread() in addition to this function for the
 * same session. Otherwise you will miss events because the other
 * ProcessTargetData function already consumed your "next" event. In other
 * words this function shall be the only one which reads out data from the
 * communication buffers.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ProcessTargetDataUntilEvent(TAL_SessionHandleType sessionHandle,
                                TAL_EventType * pType);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
processTargetDataUntilEvent(TalEventType * pType) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_StartProcessTargetDataThread instead.
 * @endif
 * @endif
 *
 * @brief Start a thread that calls TAL_ProcessTargetData recurrently for the given session
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param timeoutUs interval between two invocations of TAL_ProcessTargetData
 *                  (1000us is the default value)
 *
 * @retval TAL_SUCCESS    The thread was created successfully
 * @retval TAL_NO_SESSION The function call failed, no valid session
 * @retval TAL_FAILED     The thread could not be created
 *
 * @note The TAL is thread safe. You may call each function from different, concurrent threads.
 * This thread safety is reached by a kind of global mutex for each TAL session (i.e. hardware connection).
 *
 * \b Example
 * \snippet Applications/SomeIPTestApp/MirrorApp/src/SomeIPTestAppMirror.cpp example_TAL_StartProcessTargetDataThread
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_StartProcessTargetDataThread(
    TAL_SessionHandleType sessionHandle,
    uint32 timeoutUs);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
startProcessTargetDataThread(uint32 timeoutUs = 1000) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_StopProcessTargetDataThread instead.
 * @endif
 * @endif
 *
 * @brief Stop the thread that was started with TAL_StartProcessTargetDataThread
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_StopProcessTargetDataThread(
    TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
stopProcessTargetDataThread() const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_CANSetEventCallback instead.
 * @endif
 * @endif
 *
 * @brief Set callback for CAN events
 *
 * This function sets the callback for CAN events
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pCallbackFunction callback function\n
 * @else
 * @param sessionHandle handle of the established session
 * @param pCallbackFunction callback function\n
 * @endif
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_CANSetEventCallback(TAL_SessionHandleType sessionHandle,
                           TAL_BM_CANEventCallbackFunctionPointerType pCallbackFunction);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
CANSetEventCallback(TAL_SessionHandleType sessionHandle,
                    TAL_BM_CANEventCallbackFunctionPointerType pCallbackFunction) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_StartNetwork instead.
 * @endif
 * @endif
 *
 * @brief Starts selected network(s)
 *
 * This enables the target to send and receive frames. This means for
 * CAN: the selected controller starts sending the configured frames.
 * FlexRay: both FlexRay controllers are started. If they are configured
 * correctly, other start up buddies are available too or the option 'Enforce
 * FlexRay Startup' was enabled during configuration. The FlexRay controllers
 * situated on the Busmirror will be able to go into the
 * NORMAL_ACTIVE state. If no signals or frame data is sent (CCs buffers are
 * not filled) the FlexRay controllers will start sending NULL frames.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param network network type to be started
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 *
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/BusMirror/API_LinkTest/src/API_LinkTest.c example_TAL_BM_StartNetwork
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_StartNetwork(TAL_SessionHandleType sessionHandle,
                    TAL_BM_NetworkType network);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
startNetwork(TAL_BM_NetworkType network) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_StopNetwork instead.
 * @endif
 * @endif
 *
 * @brief Stops selected network(s)
 *
 * This function prevents the target from sending and receiving frames
 * Stopping the communication means for
 * CAN: the selected controllers stop sending and receiving frames
 * FlexRay: the two FlexRay controllers stop sending and receiving frames at
 * the end of the current communication cycle using the HALT state transition.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param network type to be stopped
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 *
 * @note The function returns after the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *
 * \b Example
 * \snippet Applications/SomeIPTestApp/MirrorApp/src/SomeIPTestAppMirror.cpp example_TAL_BM_StopNetwork
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_StopNetwork(TAL_SessionHandleType sessionHandle,
                   TAL_BM_NetworkType network);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
stopNetwork(TAL_BM_NetworkType network) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTimeSinceLastTargetResponse instead.
 * @endif
 * @endif
 *
 * @brief Return time span since the last packet was received from the target
 *
 * In order to detect that the target device is no longer responding, you
 * may call this function and check the time span since the reception of
 * the last packet. Newer firmware releases (starting with release 3.3)
 * autonomously send an alive indication about all 100ms, that is, an error
 * may have occurred if this function returns a much larger value.
 * The return value 'TAL_NO_DATA' indicates that the used firmware does not
 * send periodic alive indications.
 * To cope with situations where you know that the target cannot send
 * alive indications for a longer period of time (e.g. because the interrupts
 * are locked), you may reset the timer by calling
 * 'TAL_ResetTimeOfLastTargetResponse()' after the blocking period.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 *
 * @param pnLastResponseTimeInMs The time span (in ms) since the last packet
 *                               was received from the target. (if not NULL)
 *
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @retval TAL_SUCCESS Got valid value for pnLastResponseTimeInMs
 *
 * @retval TAL_NO_DATA No alive packet was received at all
 *                    'pnLastResponseTimeInMs' still contains the age of
 *                    the last received packet, but this may be rather
 *                    high when there was no user communication for some
 *                    time
 *
 * \b Example
 * \snippet SupportTools/tal_control_server/src/TCS.cpp example_TAL_GetTimeSinceLastTargetResponse
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTimeSinceLastTargetResponse(TAL_SessionHandleType sessionHandle,
                                   uint32 *pnLastResponseTimeInMs);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getTimeSinceLastTargetResponse(TalUInt *pnLastResponseTimeInMs) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_ResetTimeSinceLastTargetResponse instead.
 * @endif
 * @endif
 *
 * @brief Reset time span since the last packet was received from the target
 *
 * Call this function after periods where you intentionally did not receive
 * alive packets from the target (e.g. because of locked interrupts)
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 *
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @retval TAL_SUCCESS Time span was reset
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ResetTimeSinceLastTargetResponse(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
resetTimeSinceLastTargetResponse() const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetEvent instead.
 * @endif
 * @endif
 *
 * @brief Get the next event from the event queue
 *
 * This function blocks until timeout reached or event is received.
 * You have to register events at the event queue by supplying a TAL_*Callback
 * callback functions as argument to a registration function (this is the
 * default for scripting languages).
 * Events are posted from the context of the ProcessTargetData function.
 * This function also unblocks if you destroy the TAL sessionHandle (this
 * happens also if you delete the TalInterface class).
 *
 * Please note that the event queue only implements a queue for events but not
 * for payload. Depending on the type of the event there may be a payload
 * fifo inside the TAL. E.g. signals, pdus and frames do not have a payload
 * fifo inside the TAL, but a fifo exists for CAN messages and TUM User Data.
 *
 * @li Domain: Host
 * @li Calling: blocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param nTimeout timeout time in milliseconds. Use 0xFFFFFFFF if you want to
 * wait until an infinite time.
 * @param eType type of the event
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pId id of the event. Optional, depending on the type.
 * @param pData data of the event. Optional, depending on the type.
 * @else
 * @param pEvent Event data object of type TalEvent
 * @endif
 *
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @retval TAL_NULL_POINTER mandatory argument was a null pointer
 *
 * @retval TAL_SUCCESS Event available
 *
 * @retval TAL_TIMEOUT No event available within timeout time
 *
 * @retval TAL_FAILED Unspecific error - e.g. OS runs out of memory.
 *
 * @retval TAL_NO_DATA Wait operation was unblocked but no data is available
 * (e.g. sessionHandle was destroyed by user request
 *
 * @retval TAL_OVERFLOW Event data was dropped because system was not able to
 * read out data in-time. The event data queue has space for 1000 elements.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetEvent(TAL_SessionHandleType sessionHandle,
             TAL_EventType eType,
             int * pId,
             unsigned int * pData,
             unsigned int nTimeout);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getEvent(TAL_EventType eType,
         TalEvent * pEvent,
         unsigned int nTimeout) const;
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Get information about a PCI device
 *
 * This function returns information about a connected PCI device according
 * to the given index value. The index value range is dense and starts with
 * zero. If no device can be found for a given index value, the function
 * returns \c TAL_FAILED.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB5200, EB7200
 *
 * @param DeviceIndex Index of the device of interest
 * @param pDeviceInfo   Pointer to the information data structure, which is
 *                      filled by the function.
 *
 * @retval TAL_SUCCESS  The function call executed successfully
 * @retval TAL_NOT_SUPPORTED    The function is currently not supported because
 *                              the TAL_PCI_ENABLED macro is not equal to TAL_ON.
 * @retval TAL_NULL_POINTER     The function call failed because the pDeviceInfo
 *                              parameter is Null.
 * @retval TAL_INVALID_INDEX    The DeviceIndex parameter is higher or equal
 *                              to the TAL_BH_PCIConnectionNumberOfDevices
 *                              variable.
 *
 * @note The caller has to provide an instance of \c TAL_PCIDeviceInfoType,
 *       which is initialised by this function.
 *
 * \b Example
 * \snippet SupportTools/tal_control_server/src/TCS.cpp example_TAL_GetPCIDeviceInfo
 */
TAL_API extern TAL_ReturnType
TAL_GetPCIDeviceInfo(TAL_DeviceIndexType DeviceIndex,
                     TAL_PCIDeviceInfoType * pDeviceInfo);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SetDeviceOption instead.
 * @endif
 * @endif
 *
 * @brief Set device option
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param deviceOpt Following TAL_DeviceOptionTypes are available:
 *                  - TAL_EBY2XX_ENABLE_RAW_CHANNEL - enable raw data channel (0x01 - enabled; 0x00 - disabled)
 *                  - TAL_EBY2XX_WRITE_BLOCK_ID - write BLOCK ID message for EB7200 device
 *                  - TAL_EBHSCR_SET_BUF - provide RX buffer to capture EBHSCR frames
 *                  - TAL_EBY2XX_SET_REGISTER_VALUE - set value in register
 *                  - TAL_EB8200_ENABLE_JUMBO_FRAME_SUPPORT - enable jumbo frame support for EB8200 device
 *                  - TAL_EB8200_SET_PTP_MODE - set PTP mode for EB 8200
 *                  - TAL_EB8200_SET_TIMESTAMP_BASE - set the EBHSCR timestamp base for an EB8200
 *                                                    device; note that this is based on political
 *                                                    time, which will jump and lead to problems. The
 *                                                    TAL EB Time mechanism is a much better choice,
 *                                                    as it is based on a zero-based working clock without
 *                                                    time jumps.
 *                  - TAL_EBY2XX_REPLAY_TIMING_OPTIONS - set grace period and no-report period for the selected
 *                                                      controller (0 or 1). Currently this deviceOpt is only
 *                                                      supported for 1000BaseT1 modules.
 *                  - TAL_SET_PROCESS_TARGET_DATA_THREAD_PRIO - set priority of subsequently started process target
 *                                                              data thread (0 - lowest; 100 - highest)
 *                  - TAL_EBX200_SET_CAN_SAMPLING_POINT: set CAN/CAN-FD sampling point offset
 *                  - TAL_EBX200_SET_EBHSCR_MODE: configure mode for EBHSCR measurement
 *                  - TAL_EBX200_SET_LINE_TERM: set line termination state of specific interface
 *                  - TAL_EBX200_GET_LINE_TERM: get line termination state of specific interface
 *                  - TAL_EBX200_CONTROL_FLEXRAY_TX_COM_OPS: enable/disable FlexRay transmit COM-operations
 * @param pData pointer to data required by function.
 *        - deviceOpt=TAL_EBY2XX_ENABLE_RAW_CHANNEL: pData must be of type uint32*
 *        - deviceOpt=TAL_EBY2XX_WRITE_BLOCK_ID: pData must be of type @ref TAL_DevOpt_Buffer_ro*
 *        - deviceOpt=TAL_EBHSCR_SET_BUF: pData must be of type @ref TAL_DevOpt_Buffer*
 *        - deviceOpt=TAL_EBY2XX_SET_REGISTER_VALUE: pData must be of type @ref TAL_DevOpt_RegAccess*
 *        - deviceOpt=TAL_EB8200_ENABLE_JUMBO_FRAME_SUPPORT: pData must be of type uint32*
 *        - deviceOpt=TAL_EB8200_SET_PTP_MODE: pData must be of type @ref TAL_EB8200PTPMode*
 *        - deviceOpt=TAL_EB8200_SET_TIMESTAMP_BASE: pData must be of type @ref TAL_EB8200TimestampBaseType*
 *        - deviceOpt=TAL_EBY2XX_REPLAY_TIMING_OPTIONS: pData must be of type @ref TAL_DevOpt_ReplayTimingOptions*
 *        - deviceOpt=TAL_SET_PROCESS_TARGET_DATA_THREAD_PRIO: pData must be of type uint32*
 *        - deviceOpt=TAL_EBX200_SET_CAN_SAMPLING_POINT: pData must be of type @ref TAL_DevOpt_CANSamplingPoint*
 *        - deviceOpt=TAL_EBX200_SET_EBHSCR_MODE: pData must be of type @ref TAL_DevOpt_EBHSCRMode*
 *        - deviceOpt=TAL_EBX200_SET_LINE_TERM: pData must be of type @ref TAL_DevOpt_LineTerm*
 *        - deviceOpt=TAL_EBX200_GET_LINE_TERM: pData must be of type @ref TAL_DevOpt_LineTerm*
 *        - deviceOpt=TAL_EBX200_CONTROL_FLEXRAY_TX_COM_OPS: pData must be of type @ref uint32*
 * @param size size of pData argument
 * @retval TAL_SUCCESS the function executed successfully
 * @retval TAL_FAILED the function failed to execute
 * @retval TAL_NOT_SUPPORTED this option is not supported
 * @retval TAL_BUFFER_TOO_SMALL the size parameter is too small for the chosen device option.
 * @retval TAL_INVALID_INDEX in case of TAL_EBY2XX_REPLAY_TIMING_OPTIONS the given eth controller index is invalid
 * @note This function is currently supported only for EB7200 and EB8200 devices
 * @pre A session has to be established before calling this function.
 *
 * \b Example
 * \snippet Applications/EBy2xx_LVDSTest/src/EBy2xx_LVDSTest.cpp example_TAL_SetDeviceOption
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SetDeviceOption(TAL_SessionHandleType sessionHandle,
                    TAL_DeviceOptionType deviceOpt,
                    const void *pData,
                    uint32 size);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
setDeviceOption(TAL_DeviceOptionType deviceOpt,
                const void *pData,
                uint32 size) const;
/**
 * @cond EXCLUDE_FROM_DOCU
 *
 * Deprecated, just kept here for backward compatibility.
 */
virtual TAL_DEPRECATED TAL_ReturnType
setDeviceOption(TAL_DeviceOptionType deviceOpt,
                const TalByteArray *pData) const;
/* @endcond */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetDeviceOption instead.
 * @endif
 * @endif
 *
 * @brief Get device option
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param deviceOpt Following TAL_DeviceOptionTypes are available:
 *                  - TAL_EB7200_GET_STATUS get channel status and event
 *                  - TAL_GET_TEMP_STATUS get temperature status from target device
 *                  - TAL_EB8200_GET_EB1213_TEMP get temperature for EB1213 board in grad celsius
 *                  - TAL_EBY2XX_READ_BLOCK_ID read configuration block for EB7200 and EB8200 devices
 *                  - TAL_EBY2XX_GET_REGISTER_VALUE get value from register for EB7200 and EB8200 devices
 *                  - TAL_EBY2XX_GET_DAQ_TYPE get type of DAQ used on hardware
 * @if TAL_C_API
 * @param pData pointer to data required by function.
 *        - deviceOpt=TAL_EB7200_GET_STATUS: pData must be of type @ref TAL_MeasurementStatusType*
 *        - deviceOpt=TAL_GET_TEMP_STATUS: pData must be of type @ref TAL_TemperatureStatusType*
 *        - deviceOpt=TAL_EB8200_GET_EB1213_TEMP: pData must be of type sint16*
 *        - deviceOpt=TAL_EBY2XX_READ_BLOCK_ID: pData must be of type @ref TAL_DevOpt_Buffer*
 *        - deviceOpt=TAL_EBY2XX_GET_REGISTER_VALUE: pData must be of type @ref TAL_DevOpt_RegAccess*
 *        - deviceOpt=TAL_EBY2XX_GET_DAQ_TYPE: pData must be of type uint32* (possible values: @ref TAL_ModuleType)
 * @else
 * @param pData pointer to TalByteArray.
 * @endif
 * @if TAL_C_API
 * @param size size of data
 * @endif
 * @retval TAL_SUCCESS the function executed successfully
 * @retval TAL_FAILED the function failed to execute
 * @retval TAL_NOT_SUPPORTED this option is not supported
 * @retval TAL_BUFFER_TOO_SMALL the size parameter is too small for the chosen device option.
 *
 * @note   ATTENTION: deviceOpt TAL_EB7200_GET_STATUS is currently only supported for EB7200 base projects
 *
 * @pre A session has to be established before calling this function.
 *
 * \b Example
 * \snippet Applications/EBy2xx_LVDSTest/src/EBy2xx_LVDSTest.cpp example_TAL_GetDeviceOption
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetDeviceOption(TAL_SessionHandleType sessionHandle,
                    TAL_DeviceOptionType deviceOpt,
                    void *pData,
                    uint32 size);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getDeviceOption(TAL_DeviceOptionType deviceOpt,
                TalByteArray *pData) const;
#endif /* TAL_CXX_API */

/**
 *
 * @brief Flush pending data of session.
 *
 * This function flushes pending data (if any) to the target device.
 * It could be used to optimize for low latency.
 *
 * @sa TAL_SetSendThreshold
 *
 * @li Domain: Host
 * @li Calling: blocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, EB7200
 *
 * @if TAL_C_API
 * @param sessionHandle  handle of the session, which has to be flushed
 * @endif
 *
 * @retval TAL_SUCCESS    The function call executed successfully
 * @retval TAL_FAILED     The function call failed to execute
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @note If no session was established before calling this function the
 *       return value will be \c TAL_FAILED.
 *
 * @note This function only has an effect if called after functions
 *       which needs a explicit flush.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks For EB2200 and EB5200, a local send queue which needs
 *          flushing is currently only implemented in the TCP backend because
 *          of performance reasons together with the socket option TCP_NODELAY.
 *          For EB7200, a TX buffer which can be flushed is currently only
 *          implemented for the EB PCIe driver (XDMA).
 *          Calling this function for other backends has currently no effect
 *          therefore.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_Flush(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_ReturnType
flush() const;
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup signal Signal related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated  Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_SendSignalCoded instead.
 * @endif
 * @endif
 *
 * @brief Set the coded value of a sending signal
 *
 * This function updates the coded value for a specific signal in the targets
 * signal base.
 * The new value is transferred immediately, then the function returns.
 * The value is stored on the target in the signal base. Whenever the FlexRay
 * communication drivers needs data for sending the according frames the
 * signal values are taken out of the signal base and packed in the frame to
 * be written in-time into the FlexRay controllers buffer.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param signalIndex   unique identifier for the signal
 * @param pValue        pointer to a data structure, containing the coded
 *                      value
 * @else
 * @param signalIndex unique identifier for the signal
 * @param pSignal pointer to signal data object
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_BUFFER_TOO_SMALL The function call failed, a provided buffer was
 *                              too small
 * @retval TAL_NOT_SUPPORTED The function is not available.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks Signals which are located in cyclic timings are send by the target
 * firmware in the next according FlexRay slot or CAN-message-period
 * automatically. Signals which are located in event-based timings are handled
 * according to configuration. If the signal's ComTransferProperty is set to
 * TRIGGERED (or TRIGGERED_ON_CHANGE) the PDU is sent automatically
 * (TRIGGERED_ON_CHANGE: only if the value changed). If the ComTransferProperty
 * of the signal is PENDING the function TAL_BM_CommitPDU() must be called
 * additionally.
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/BusMirror/API_LinkTest/src/API_LinkTest.c example_TAL_BM_SendSignalCoded
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_SendSignalCoded(TAL_SessionHandleType sessionHandle,
                       TAL_BM_SignalIndexType signalIndex,
                       const TAL_BM_CodedSignalValueType * pValue);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmSendSignal(TAL_BM_SignalIndexType signalIndex,
             TalSignal * pSignal) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_ReceiveSignalCodedWithStatus instead.
 * @endif
 * @endif
 *
 * @brief Get the locally stored coded value and status of a signal
 *
 * This function reads the locally stored coded value and status of
 * signal from the rx signal base.
 * After a signal is subscribed at the target it is automatically transferred
 * to the host whenever it is received. The function
 * @if TAL_C_API
 * #TAL_ProcessTargetData
 * @else
 * #processTargetData
 * @endif
 * at the host reads the receive buffers of all
 * communication back-ends and, if it contains signal values for subscribed
 * signals they are stored in the signal base. This function returns the actual
 * value which is stored in the signal base.
 * Additionally this function returns the signal status
 * (#TAL_BM_SignalStatusType).
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param signalIndex   unique identifier for the signal
 * @param pValue        pointer to a data structure for storing the coded
 *                      value
 * @param pStatus       pointer to a data structure for storing the signal
 *                      status
 * @else
 * @param signalIndex unique identifier for the signal
 * @param pSignal pointer to signal data object
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_INVALID_INDEX The function call failed, index out of bounds or
 *                           unknown signal index
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 *
 * @pre A session has to be established before calling this function.
 *
 * \b Example
 * \snippet SupportTools/tal_control_server/src/TCS_ClientCommand.cpp example_TAL_BM_ReceiveSignalCodedWithStatus
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_ReceiveSignalCodedWithStatus(TAL_SessionHandleType sessionHandle,
                                    TAL_BM_SignalIndexType signalIndex,
                                    TAL_BM_CodedSignalValueType * pValue,
                                    TAL_BM_SignalStatusType * pStatus);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmReceiveSignal(TAL_BM_SignalIndexType signalIndex,
                TalSignal * pSignal) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_RegisterForRecvSignal instead.
 * @endif
 * @endif
 *
 * @brief Register for automatic reception of a signal
 *
 * This function registers the automatic reception of a signal and
 * notification upon receiving the signal from the target.
 * After a signal is subscribed at the target it is automatically transferred
 * to the host whenever it is received from the FlexRay bus.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pRecvSignalCallbackFunction
 *     Pointer to callback function, called after each reception of a signal,
 *     even if an invalid value was received.
 *     Use TAL_BM_ReceiveSignalCodedWithStatus() inside the callback to
 *     determine if an invalid value was received.
 *     If the signal was received inside of a signal group the callbacks are
 *     delayed until all signals of the group are received (to allow
 *     consistent access to the whole group and signal group locking from
 *     within the callback).
 *     If all signals of a signal group should be received out of one
 *     callback it is better to use the signal group callback
 *     (TAL_BM_RegisterForRecvSignalGroup()).
 *     Supply 0 to this parameter if you do not want to register a callback
 *     function (e.g. from scripting code).
 * @endif
 * @param signalIndex   unique identifier for the signal
 * @param recvSignalNotification specification of type of notification
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_INVALID_INDEX  The function call failed, index out of bounds or
 *                            unknown signal index
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is
 *                            supplied where it is not allowed
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_COMM_ERROR     The function call failed, error at the
 *                            communication attempt
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks It is best to keep the number of registered signals as small as
 * possible to do not waste bandwidth on the communication channel.
 *
 * \b Example
 * \snippet SupportTools/tal_control_server/src/TCS_ClientCommand.cpp example_TAL_BM_RegisterForRecvSignal
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForRecvSignal(TAL_SessionHandleType sessionHandle,
                             TAL_BM_SignalIndexType signalIndex,
                             TAL_BM_RecvSignalNotificationType recvSignalNotification,
                             TAL_BM_RecvSignalCallbackFunctionPointerType pRecvSignalCallbackFunction);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
bmRegisterForRecvSignal(TAL_BM_SignalIndexType signalIndex,
                        TAL_BM_RecvSignalNotificationType recvSignalNotification) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
bmRegisterForRecvSignal(TAL_BM_SignalIndexType signalIndex,
                        TAL_BM_RecvSignalNotificationType recvSignalNotification,
                        TAL_BM_RecvSignalCallbackFunctionPointerType pRecvSignalCallbackFunction = TAL_SignalCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_UnregisterForRecvSignal instead.
 * @endif
 * @endif
 *
 * @brief Unregister for automatic reception of a signal
 *
 * This function unregisters the automatic reception of a signal and
 * removes the notification upon receiving the signal from the target.
 * After a signal is subscribed at the target it is automatically transferred
 * to the host whenever it is received from the FlexRay bus. This function
 * stops the automatic signal streaming from the target to the host.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param signalIndex   unique identifier for the signal
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_INVALID_INDEX  The function call failed, index out of bounds or
 *                            unknown signal index
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is
 *                            supplied where it is not allowed
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_COMM_ERROR     The function call failed, error at the
 *                            communication attempt
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_UnregisterForRecvSignal(TAL_SessionHandleType sessionHandle,
                               TAL_BM_SignalIndexType signalIndex);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmUnregisterForRecvSignal(TAL_BM_SignalIndexType signalIndex) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_UnregisterForAllRecvSignal instead.
 * @endif
 * @endif
 *
 * @brief Unregister for automatic reception of all FlexRay signals
 *
 * This function unregisters the automatic reception of all FlexRay signals
 * from the target.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_INVALID_INDEX  The function call failed, index out of bounds or
 *                            unknown signal index
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_COMM_ERROR     The function call failed, error at the
 *                            communication attempt
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_UnregisterForAllRecvSignal(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmUnregisterForAllRecvSignal() const;
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief Set the coded array of a sending signal
 *
 * This function updates the coded array for a specific signal in the targets
 * signal base. Whenever a communication driver needs data for sending the
 * according frames the signal values are taken out of the signal base and are
 * written into the controllers buffer.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle handle of the established session
 * @param nSignalIndex   unique identifier for the signal
 * @param pData         pointer to a data structure, containing the coded
 *                      array
 * @param nDataLength   size in number of bytes of the signal coded array
 *
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is
 *                            supplied where it is not allowed
 * @retval TAL_ENCODING_ERROR The function call failed due to an error when
 *                            encoding a package
 * @retval TAL_COMM_ERROR     The function call failed due to an error in the
 *                            communication with the target
 * @retval TAL_SUCCESS        The function call executed successfully
 * @pre A session has to be established before calling this function.
 *
* @remarks Signals which are located in cyclic timings are send by the target
 * firmware in the next according FlexRay slot or CAN-message-period
 * automatically. Signals which are located in event-based timings are handled
 * according to configuration. If the signal's ComTransferProperty is set to
 * TRIGGERED (or TRIGGERED_ON_CHANGE) the PDU is sent automatically
 * (TRIGGERED_ON_CHANGE: only if the value changed). If the ComTransferProperty
 * of the signal is PENDING the function TAL_BM_CommitPDU() must be called
 * additionally
 *
 * @sa TAL_BM_CommitPDU
 */
TAL_API extern TAL_ReturnType
TAL_BM_SendSignalCodedArray(TAL_SessionHandleType sessionHandle,
                            TAL_BM_SignalIndexType nSignalIndex,
                            const uint8 * pData,
                            uint16 nDataLength);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief Get the locally stored coded array and signal status
 *
 * This function reads the locally stored coded array and status of
 * signal from the rx signal base. After a signal is subscribed at the
 * target it is automatically transferred to the host whenever it is
 * received. The function #TAL_ProcessTargetData at the host reads the
 * receive buffers of all communication back-ends and, if it contains
 * signal values for subscribed signals they are stored in the signal
 * base. This function returns the actual value which is stored in the
 * signal base. Additionally this function returns the signal status
 * (#TAL_BM_SignalStatusType).
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle handle of the established session
 * @param nSignalIndex unique identifier for the signal
 * @param pStatus pointer to a data structure for storing the signal status
 * @param pBuffer pointer to a data structure, containing the coded
 * @param nBufferLength length of the assigned buffer
 * @param pDataLength pointer to a uint16 for storing the the signals data
 *                    length
 *
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_FAILED        The function call failed to execute
 * @retval TAL_INVALID_INDEX The function call failed, index out of bounds or
 *                           unknown signal index
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_DATA        The function call failed because the signal was
 *                           not received at least once
 */
TAL_API extern TAL_ReturnType
TAL_BM_ReceiveSignalCodedArrayWithStatus(TAL_SessionHandleType sessionHandle,
                                         TAL_BM_SignalIndexType nSignalIndex,
                                         uint8 * pBuffer,
                                         uint16 nBufferLength,
                                         uint16 * pDataLength,
                                         TAL_BM_SignalStatusType * pStatus);
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup someip SOME/IP related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpInit instead.
 * @endif
 * @endif
 *
 * @brief Builds up config data structures which are used during runtime.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param config xml SOME/IP config file name
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/e2e/src/E2ETest.cpp example_TAL_SomeIpInit
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpInit(TAL_SessionHandleType sessionHandle,
               const char *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpInit(const char *config) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpDeInit instead.
 * @endif
 * @endif
 *
 * @brief Deletes all temporary used memory.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpDeInit(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpDeInit() const;
#endif /* TAL_CXX_API */

 /**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Initializes the iterator for the config parser for SOME/IP data elements.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it config iterator, will iterate over config data of the elements of specified message
 * and message type.
 * @param someip_msg_id message identifier of the SOME/IP message
 * @param someip_msg_type message type of the SOME/IP message, possible values are:
 * TAL_SOMEIP_REQUEST, TAL_SOMEIP_REQUEST_NO_RETURN, TAL_SOMEIP_REQUEST_NOTIFICATION,
 * TAL_SOMEIP_RESPONSE TAL_SOMEIP_ERROR.
 *
 * @retval TAL_SUCCESS       iterator initialized, a message with someip_msg_id was
 *                           found in the configuration.
 * @retval TAL_FAILED        iterator not initialized, no message with someip_msg_id
 *                           was found in configuration.
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/someip/src/SOMEIPTest.cpp example_TAL_SomeIpConfigInit
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpConfigInit(TAL_SessionHandleType sessionHandle,
                     TAL_SomeIpConfigIterator *it,
                     uint32 someip_msg_id,
                     uint8 someip_msg_type);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpConfigInit( TAL_SomeIpConfigIterator *it,
                     uint32 someip_msg_id,
                     uint8 someip_msg_type) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Get the next config data element of the SOME/IP message.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param it iterator which should be initialized
 * @param config configuration of the data element
 *
 * @retval TAL_SUCCESS       message successfully extracted
 * @retval TAL_NO_DATA       no more SOME/IP message in UDP payload
 */
#ifndef TAL_CXX_API
 TAL_API extern TAL_ReturnType
TAL_SomeIpConfigNext(TAL_SomeIpConfigIterator *it,
                     TAL_SomeIpConfigType *config);

#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpConfigNext( TAL_SomeIpConfigIterator *it,
                 TAL_SomeIpConfigType *config) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpMessageInit instead.
 * @endif
 * @endif
 *
 * @brief Initializes the iterator for the SOME/IP message.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it message iterator
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute
 */
#ifndef TAL_CXX_API

TAL_API extern TAL_ReturnType
TAL_SomeIpMessageInit(TAL_SessionHandleType sessionHandle,
                      TAL_SomeIpMessageIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpMessageInit(TAL_SomeIpMessageIterator *it) const;
#endif /* TAL_CXX_API */

 /**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpMessageNext instead.
 * @endif
 * @endif
 *
 * @brief Get the next SOME/IP message
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param it message iterator
 * @param someip_msg_id message identifier of the SOME/IP message (if not NULL)
 * @param someip_msg_type message type of the SOME/IP message (if not NULL)
 * Possible values are:\n
 * TAL_SOMEIP_REQUEST, TAL_SOMEIP_REQUEST_NO_RETURN,\n
 * TAL_SOMEIP_REQUEST_NOTIFICATION,\n
 * TAL_SOMEIP_RESPONSE TAL_SOMEIP_ERROR.\n
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_FAILED        The function call failed to execute
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/someip/src/SOMEIPTest.cpp example_TAL_SomeIpMessageNext
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpMessageNext(TAL_SomeIpMessageIterator *it,
                      uint32 *someip_msg_id,
                      uint8 *someip_msg_type);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpMessageNext(TAL_SomeIpMessageIterator *it,
                  TalUInt *someip_msg_id,
                  TalUInt *someip_msg_type) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpUdpMessageInit instead.
 * @endif
 * @endif
 *
 * @brief Initializes the iterator for the extraction of the SOME/IP messages out of a UDP payload.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it message iterator
 * @param udp_payload UDP payload
 * @if TAL_C_API
 * @param udp_payload_len length of UDP payload
 * @endif
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/someip/src/SOMEIPTest.cpp example_TAL_SomeIpUdpMessageInit
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpUdpMessageInit(TAL_SessionHandleType sessionHandle,
                         TAL_SomeIpUdpMessageIterator *it,
                         const uint8 *udp_payload,
                         uint32 udp_payload_len);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpUdpMessageInit(TAL_SomeIpUdpMessageIterator *it,
                     const TalByteArray *udp_payload) const;
#endif /* TAL_CXX_API */

 /**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpUdpMessageNext instead.
 * @endif
 * @endif
 *
 * @brief Get the next SOME/IP message out of a UDP payload.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param it iterator which will be used to get the next SOME/IP message
 * @param someip_msg: Points to the SOME/IP-message beginning with the Request
 * ID/Client ID. No data is copied - it points into the udp_payload which was
 * supplied during initialization of the iterator.
 * @if TAL_C_API
 * @param someip_msg_len: length of someip_msg. The length is returned from the
 * second 32 bit word of the SOME/IP header in host endianess. The length is in
 * Byte of the payload beginning with the Request ID/Client ID until the end of
 * the SOME/IP-message.
 * @endif
 * @if TAL_C_API
 * @param someip_msg_id: Message ID is returned in host endianess from the
 * first 32 bit word of the SOME/IP message.
 * @endif
 *
 * @return TAL_SUCCESS message extracted
 * @return TAL_NO_DATA no more SOME/IP message in UDP payload. Or if the
 * remaining bytes are smaller than the SOME/IP header size.
 * @return TAL_BUFFER_TOO_SMALL short-item-count: message length field longer than
 * message, or not even header of SOME/IP message available
 * @return TAL_NOT_SUPPORTED someip protocol version not supported
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpUdpMessageNext(TAL_SomeIpUdpMessageIterator *it,
                         uint32 *someip_msg_id,
                         const uint8 **someip_msg,
                         uint32 *someip_msg_len);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpUdpMessageNext(TAL_SomeIpUdpMessageIterator *it,
                     TalSomeIpMsg *someip_msg) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpMessageToPduId instead.
 * @endif
 * @endif
 *
 * @brief Returns the PDU ID of message.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param someip_msg_id message identifier of the SOME/IP message
 * @param someip_msg_type message type of the SOME/IP message
 * @param pdu_id unique identifier for the pdu
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/someip/src/SOMEIPTest.cpp example_TAL_SomeIpMessageToPduId
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpMessageToPduId(TAL_SessionHandleType sessionHandle,
                         uint32 someip_msg_id,
                         uint8 someip_msg_type,
                         TAL_BM_PDUIndexType *pdu_id);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpMessageToPduId(uint32 someip_msg_id,
                     uint8 someip_msg_type,
                     TalUInt *pdu_id) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpPduToMessageId instead.
 * @endif
 * @endif
 *
 * @brief Find SOME/IP message ID based on custom PDU ID.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param pdu_id unique identifier for the pdu
 * @param someip_msg_id message ID
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_FAILED        The function call failed to execute
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpPduToMessageId(TAL_SessionHandleType sessionHandle,
                         TAL_BM_PDUIndexType pdu_id,
                         uint32 *someip_msg_id);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpPduToMessageId(TAL_BM_PDUIndexType pdu_id,
                     TalUInt *someip_msg_id) const;
#endif /* TAL_CXX_API */



/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpReaderInit instead.
 * @endif
 * @endif
 *
 * @brief Initializes the iterator for the SOME/IP data element parser.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it iterator which keeps track of actually read out SOME/IP element
 * @if TAL_C_API
 * @param someip_msg_id message identifier of the SOME/IP message.
 * @endif
 * @param someip_msg a pointer to the beginning of a SOME/IP message.
 * Consists of SOMEIP header (8 bytes) plus SOME/IP payload (x bytes). No data is copied.
 * The pointer must stay valid until iterator is not accessed any more.
 * @if TAL_C_API
 * @param someip_msg_len the length of the SOME/IP message. Consists of SOME/IP header (8 bytes) plus SOME/IP payload (x bytes).
 * @endif
 * @retval TAL_SUCCESS       iterator initialized, a message with someip_msg_id was
 *                           found in the configuration.
 * @retval TAL_NO_SESSION    the function call failed, no valid session
 * @retval TAL_FAILED        iterator not initialized, no message with someip_msg_id
 *                           was found in configuration.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpReaderInit(TAL_SessionHandleType sessionHandle,
                      TAL_SomeIpElementIterator *it,
                      uint32 someip_msg_id,
                      const uint8 *someip_msg,
                      uint32 someip_msg_len);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpReaderInit(TAL_SomeIpElementIterator *it,
                     const TalSomeIpMsg *someip_msg) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpReaderNext instead.
 * @endif
 * @endif
 *
 * @brief Get the next data element out of the SOME/IP message.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param it iterator which keeps track of actually read out SOME/IP element
 * @param config configuration of the data element. You may supply NULL.
 * @param value union containing the value of the data element. You may supply NULL.
 * @param length_field byte size as read out from the length field; optional
 * for struct, fixed-array and union; mandatory for var-array; set to 0 if not
 * available. You may supply NULL.
 *
 * @retval TAL_SUCCESS element extracted or skipped successfully
 * @retval TAL_No_Data  deserialization finished: no more data elements in
 * SOME/IP message.
 * @retval TAL_BUFFER_TOO_SMALL short-item-count: message shorter than configuration
 * @retval TAL_OUT_OF_MEMORY nesting level too big
 * @retval TAL_FAILED fail to get the next element
 *
 * @note This API can also be used to skip data elements by passing NULL for
 * pointer arguments config, value and lenght_field!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpReaderNext(TAL_SomeIpElementIterator *it,
                     TAL_SomeIpConfigType *config,
                     TAL_SomeIpValueType *value,
                     uint32 *length_field);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpReaderNext(TAL_SomeIpElementIterator *it,
                 TAL_SomeIpConfigType *config,
                 TAL_SomeIpValueType *value,
                 TalUInt *length_field) const;
#endif /* TAL_CXX_API */


#ifndef TAL_CXX_API
/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpWriterInit instead.
 * @endif
 * @endif
 *
 * @brief Initializes the iterator for writing the SOME/IP message. Message type is parsed out of
 * someip_msg[6] to find a unique configuration element.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it write message iterator
 * @param someip_msg_id message identifier of the SOME/IP message
 * @param someip_msg pointer to the write position of the SOME/IP message.
 * SOME/IP message consists of SOME/IP header (8 bytes) plus SOME/IP payload (x bytes).
 * @if TAL_C_API
 * @param someip_msg_len length in bytes of the SOME/IP message.
 * Consists of SOME/IP header (8 bytes) plus SOME/IP payload (x bytes).
 * @endif
 * @retval TAL_SUCCESS       the function call executed successfully
 * @retval TAL_NULL_POINTER  the function call failed because a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_NO_SESSION    the function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute
 */
TAL_API extern TAL_ReturnType
TAL_SomeIpWriterInit(TAL_SessionHandleType sessionHandle,
                     TAL_SomeIpWriterIterator *it,
                     uint32 someip_msg_id,
                     uint8 *someip_msg,
                     uint32 someip_msg_len);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpWriterInit(TAL_SomeIpWriterIterator *it,
                 const TalSomeIpMsg *someip_msg) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpWriterNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the next element. Does not write anything to the message.
 * Only updates the iterator (it->cfg, it->dst (if struct has a length field),
 * it->remaining, it->dim, it->lvl)
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param it write message iterator
 * @param config configuration of the data element
 *        May be NULL. If config is NULL then config is not read out.
 * @param value union containing the value of the data element (the actual value
 * is read out of the message, this can be used to "change" values)
 *        May be NULL. If value is NULL then value is not read out.
 * @param length_field byte size as read out from the length field; optional
 *        for struct, fixed-array and union; mandatory for var-array; set to 0 if not available.
 *        May be NULL. If length_field is NULL then this variable is not written.
 *
 * @retval TAL_NULL_POINTER  the function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_NO_DATA end reached (EOF)
 * @retval TAL_OVERFLOW destination pointer overflow
 * @retval TAL_OUT_OF_MEMORY too deep nesting (we do support TAL_SOMEIP_MAX_NESTING_LEVEL nesting levels)
 * @retval TAL_FAILED the function call failed to execute
 * @retval TAL_SUCCESS the function call executed successfully - you may call Write()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpWriterNext(TAL_SomeIpWriterIterator *it,
                     TAL_SomeIpConfigType *config,
                     TAL_SomeIpValueType *value,
                     uint32 *length_field);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpWriterNext(TAL_SomeIpWriterIterator *it,
                     TAL_SomeIpConfigType *config,
                     TAL_SomeIpValueType *value,
                     TalUInt *length_field) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpWrite instead.
 * @endif
 * @endif
 *
 * @brief Write a SOME/IP value to destination
 *
 * Write value to it->dst depending on it->cfg endianess and it->cfg.type.
 * The following types can be written: boolean, uint8, uint16, uint32, uint64, sint8,
 * sint16, sint32, sint64, float32, float64, union.
 * if it->cfg.type is union the union type field is written.
 *
 * @note This function does neither increase it->cfg, nor it->dst pointer.
 *       Use TAL_SomeIpWriterNext() to do this. This function only writes value
 *       to the actual destination.
 * @note to write fixed strings use function TAL_SomeIpWriteString().
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param it write message iterator
 * @param value the value which shall be written into the SOME/IP message
 *
 * @retval TAL_INVALID_ARGUMENT is returned if it->cfg is a type which cannot be written
 * (fixed-array, var-array, string) by this API.
 * @retval TAL_NULL_POINTER is returned if parameter it or parameter value is NULL.
 * @retval TAL_FAILED the function call failed to execute
 * @retval TAL_SUCCESS the function call executed successfully

 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpWrite(const TAL_SomeIpWriterIterator *it, const TAL_SomeIpValueType *value);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpWrite(const TAL_SomeIpWriterIterator *it, const TAL_SomeIpValueType *value) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpWriteString instead.
 * @endif
 * @endif
 *
 * @brief Write fixed string to destination.
 *
 * Only works if it->cfg.type is string.
 * NOTE: To write a string set inbuf to the first byte of the SOME/IP string.
 * SOME/IP strings must include a BOM in front.
 * SOME/IP supports the following strings: UTF8 (BOM: 0xEF, 0xBB, 0xBF), UTF16LE, UTF16BE.
 * The strings you give to the function shall be NUL terminated! This means
 * string must end with one 0 byte for UTF8 and two bytes 0 for UTF16.
 * If the string val is shorter than the fixed string in the SOME/IP message,
 * remaining bytes are set to 0x00.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param it write message iterator
 * @param inbuf pointer to a buffer containing the SOME/IP string
 * @if TAL_C_API
 * @param inbytes length of the string
 * @endif
 *
 * This interface is compatible with iconv library (included in GNU C Library nowadays).
 *
 * @retval TAL_SUCCESS  The function call executed successfully
 * @retval TAL_INVALID_ARGUMENT is returned if it->cfg =! string
 * @retval TAL_Null_Pointer is returned if parameter it or parameter inbuf is NULL.
 * @retval TAL_OVERFLOW The string was too big for destination, it was not written to destination.
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/someip/src/SOMEIPTest.cpp example_TAL_SomeIpWriteString
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpWriteString(const TAL_SomeIpWriterIterator *it, const char *inbuf, size_t inbytes);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpWriteString(const TAL_SomeIpWriterIterator *it, const TalByteArray *inbuf) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SomeIpWriteArray instead.
 * @endif
 * @endif
 *
 * @brief Write an array of bytes to destination.
 *
 * Only works if it->cfg.type is an array or struct

 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param it write message iterator
 *  @param inbuf pointer to a buffer containing the SOME/IP string
 * @if TAL_C_API
 * @param inbytes length of the string
 * @endif
 *
 * This interface is compatible with iconv library (included in GNU C Library nowadays).
 *
 * @retval TAL_SUCCESS  The function call executed successfully
 * @retval TAL_INVALID_ARGUMENT is returned if it->cfg =! array
 * @retval TAL_NULL_POINTER is returned if parameter it or parameter inbuf is NULL.
 * @retval TAL_OVERFLOW An array was too big for destination, it was not written to destination.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SomeIpWriteArray(TAL_SomeIpWriterIterator *it, const uint8 *inbuf, uint32 inbytes);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
someIpWriteArray(TAL_SomeIpWriterIterator *it, const TalByteArray *inbuf) const;
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup e2e E2E related functions
 * @{
 */
/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_E2E_GetConfig instead.
 * @endif
 * @endif
 *
 * @brief Gets the configuration of the data that will be protected or checked.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session data
 * @endif
 * @param configPtr E2E Configuration of the data that will be protected or checked
 * @param someip_msg_id Message identifier of the SOME/IP message
 * @param someip_msg_type Message type of the SOME/IP message
 * Possible values are:\n
 * TAL_SOMEIP_REQUEST, TAL_SOMEIP_REQUEST_NO_RETURN,\n
 * TAL_SOMEIP_REQUEST_NOTIFICATION,\n
 * TAL_SOMEIP_RESPONSE TAL_SOMEIP_ERROR.\n
 *
 * @retval TAL_SUCCESS        The function call executed successfully
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_NULL_POINTER   Parameter configPtr is NULL
 * @retval TAL_FAILED         The function call failed to execute
 *
 * @note Call TAL_SomeIpInit before, this is where the E2E data gets read out of the configuration xml file.
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/e2e/src/E2ETest.cpp example_TAL_E2E_GetConfig
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_E2E_GetConfig(TAL_SessionHandleType sessionHandle, TAL_E2E_ConfigType* configPtr, uint32 someip_msg_id, uint8 someip_msg_type) ;
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
e2E_GetConfig(TAL_E2E_ConfigType* configPtr, uint32 someip_msg_id, uint8 someip_msg_type) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_E2E_ProtectInit instead.
 * @endif
 * @endif
 *
 * @brief Initializes the E2E protection state.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param statePtr Pointer to the communication state of the data
 *
 * @retval TAL_SUCCESS          The function call executed successfully
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer is supplied where it is not allowed
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_E2E_ProtectInit(TAL_E2E_ProtectStateType* statePtr);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
e2E_ProtectInit(TAL_E2E_ProtectStateType* statePtr) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_E2E_Protect instead.
 * @endif
 * @endif
 *
 * @brief Protects the array to be transmitted using the E2E profiles 4, 5, 6 or 7, depending on the configuration.
 * This includes checksum calculation, handling of the counter.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param configPtr E2E configuration of the data that will be protected
 * @param statePtr Pointer to data communication state
 * @if TAL_C_API
 * @param dataPtr Pointer to data to be transmitted.
 * @param length Length of the data in bytes
 * @else
 * @param e2eData Pointer to data to be transmitted (TalByteArray)
 * @endif
 * @retval TAL_NULL_POINTER   The function call failed because a null pointer is supplied where it is not allowed
 * @retval TAL_INVALID_ARGUMENT  One or more arguments contain invalid values
 * @retval TAL_FAILED The function call failed to execute
 * @retval TAL_SUCCESS The function call executed successfully
 */
 #ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_E2E_Protect(const TAL_E2E_ConfigType* configPtr, TAL_E2E_ProtectStateType* statePtr, uint8* dataPtr, uint32 length);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
e2E_Protect(const TAL_E2E_ConfigType* configPtr, TAL_E2E_ProtectStateType* statePtr, TalByteArray *e2eData) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_E2E_CheckInit instead.
 * @endif
 * @endif
 *
 * @brief Initializes the E2E check state
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param configPtr E2E configuration of the data that will be protected
 * @param statePtr Pointer to data communication state
 *
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is supplied where it is not allowed
 * @retval TAL_INVALID_ARGUMENT  One or more arguments contain invalid values
 * @retval TAL_SUCCESS The function call executed successfully
 */
 #ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_E2E_CheckInit(const TAL_E2E_ConfigType* configPtr, TAL_E2E_CheckStateType* statePtr);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
e2E_CheckInit(const TAL_E2E_ConfigType* configPtr, TAL_E2E_CheckStateType* statePtr) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_E2E_Check instead.
 * @endif
 * @endif
 *
 * @brief Checks the Data received using the E2E profiles  4, 5, 6 or 7, depending on the configuration.
 * This includes CRC calculation, handling of the Counter. The function checks only one single data in one cycle,
 * it does not determine/compute the accumulated state of the communication link.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param configPtr E2E configuration of the data that will be protected
 * @param statePtr Pointer to data communication state
 * @if TAL_C_API
 * @param dataPtr Pointer to data to be transmitted.
 * @param length Length of the data in bytes
 * @else
 * @param e2eData Pointer to data to be transmitted (TalByteArray)
 * @endif
 * @retval TAL_NULL_POINTER The function call failed cause a null pointer is supplied where it is not allowed
 * @retval TAL_INVALID_ARGUMENT  One or more arguments contain invalid values
 * @retval TAL_FAILED The function call failed to execute
 * @retval TAL_SUCCESS The function call executed successfully
 */
 #ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_E2E_Check(const TAL_E2E_ConfigType* configPtr, TAL_E2E_CheckStateType* statePtr, const uint8* dataPtr, uint32 length);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
e2E_Check(const TAL_E2E_ConfigType* configPtr, TAL_E2E_CheckStateType* statePtr, TalByteArray *e2eData) const;
#endif /* TAL_CXX_API */

 /**
 * @}
 */

/**
 * @defgroup signal_group Signal group related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_LockRecvSignalGroup instead.
 * @endif
 * @endif
 *
 * @brief Lock a signal group for consistent reading of signal values
 *
 * This function locks a signal group for consistent reading of the signal
 * values (either physical or coded representation) of this group.
 * If signals are contained within a signal group this function can be used to
 * lock the access to the signal group to be able to read out all signal
 * values within the group without causing the communication back-end to
 * overwrite the same buffers while they are read out using the
 * TAL_ReceiveSignal functions. This function does not have to be used if
 * your simulation application does not care about reading the signal
 * values out of a group in a consistent manner.
 * The implementation is based on double buffers.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle  handle of the established session
 * @endif
 * @param signalGroupID  unique identifier for the signal group
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_INVALID_INDEX The function call failed, index out of bounds or
 *                           unknown signal index
 *
 * @note On the receiving side it is allowed to mix locked access to signals
 * of the same signal group with direct, unlocked access.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks Never use receive signal group locking from within the various TAL
 * callback (e.g. signal receive callback) functions. This is because callback
 * functions are called synchronously directly out of the
 * TAL_ProcessTargetData context. Use signal group locking only outside of
 * such synchronous callbacks!
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_LockRecvSignalGroup(TAL_SessionHandleType sessionHandle,
                           TAL_BM_SignalGroupIndexType signalGroupID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmLockRecvSignalGroup(TAL_BM_SignalGroupIndexType signalGroupID) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_UnlockRecvSignalGroup instead.
 * @endif
 * @endif
 *
 * @brief Unlock a signal group for consistent reading of signal values
 *
 * This function unlocks a signal group for consistent reading of the signal
 * values (either physical or coded representation) of this group.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle  handle of the established session
 * @endif
 * @param signalGroupID  unique identifier for the signal group
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_INVALID_INDEX The function call failed, index out of bounds or
 *                           unknown signal index
 *
 * @note On the receiving side it is allowed to mix locked access to signals
 * of the same signal group with direct, unlocked access.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_UnlockRecvSignalGroup(TAL_SessionHandleType sessionHandle,
                             TAL_BM_SignalGroupIndexType signalGroupID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmUnlockRecvSignalGroup(TAL_BM_SignalGroupIndexType signalGroupID) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_StartSendSignalGroup instead.
 * @endif
 * @endif
 *
 * @brief Prepare a signal group for consistent writing of signal values
 *
 * This function prepares a signal group for consistent writing of the signal
 * values (either physical or coded representation) of this group.
 * If signals are contained within a signal group this function can be used to
 * lock the access to the signal group to be able to write all signal
 * values within the group without letting the target access the individual signal
 * buffers as soon as they are unlocked. This function does not have to be used if
 * your simulation application does not care about sending the signal
 * values of a group in a consistent manner.
 * The implementation is based on double buffers which are switched as soon as
 * write unlock is called.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API

 * @param sessionHandle  handle of the established session
 * @endif
 * @param signalGroupID  unique identifier for the signal group
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_COMM_ERROR     The function call failed, error at the
 *                            communication attempt
 *
 * @note The function returns after the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks On the sending side it is not allowed to mix locked
 * access to signals of the same signal group with direct, unlocked access
 * during one target program run. In other words, once locking is used for a
 * distinct signal group it must be used for the whole live-time of the target
 * application.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_StartSendSignalGroup(TAL_SessionHandleType sessionHandle,
                            TAL_BM_SignalGroupIndexType signalGroupID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmStartSendSignalGroup(TAL_BM_SignalGroupIndexType signalGroupID) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_StopSendSignalGroup instead.
 * @endif
 * @endif
 *
 * @brief Finish the consistent writing of signal values of a signal group
 *
 * This function finished the consistent writing of the signal values
 * (either physical or coded representation) of a signal group.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle  handle of the established session
 * @endif
 * @param signalGroupID  unique identifier for the signal group
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_COMM_ERROR     The function call failed, error at the
 *                            communication attempt
 *
 * @note The function returns after the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks On the sending side it is not allowed to mix locked
 * access to signals of the same signal group with direct, unlocked access
 * during one target program run. In other words, once locking is used for a
 * distinct signal group it must be used for the whole livetime of the target
 * application.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_StopSendSignalGroup(TAL_SessionHandleType sessionHandle,
                           TAL_BM_SignalGroupIndexType signalGroupID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmStopSendSignalGroup(TAL_BM_SignalGroupIndexType signalGroupID) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_RegisterForRecvSignalGroup instead.
 * @endif
 * @endif
 *
 * @brief Register for callback upon reception of a signal group
 *
 * This function registers the callback function upon receiving the signal
 * group (stop-signal-group packet) from the target.
 *
 * @sa TAL_BM_UnregisterForRecvSignalGroup
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: mandatory
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API

 * @param sessionHandle handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pRecvSignalGroupCallbackFunction
 *                      pointer to callback function, called after the
 *                      reception of a signal group
 *                      It is advised to do not use receive signal group
 *                      locking out of this callback function.
 * @endif
 * @param signalGroupID unique identifier for the signal group
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_INVALID_INDEX The function call failed, index out of bounds or
 *                           unknown signal index
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks This function only registers a callback. For automatic signal
 * value updates the function TAL_BM_RegisterForRecvSignal() has to be
 * called additionally.
 *
 * @sa TAL_BM_RegisterForRecvSignal
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForRecvSignalGroup(TAL_SessionHandleType sessionHandle,
                                  TAL_BM_SignalGroupIndexType signalGroupID,
                                  TAL_BM_RecvSignalGroupCallbackFunctionPointerType pRecvSignalGroupCallbackFunction);
#else /* TAL_CXX_API */
#ifdef SWIG
TAL_ReturnType
bmRegisterForRecvSignalGroup(TAL_BM_SignalGroupIndexType signalGroupID) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
bmRegisterForRecvSignalGroup(TAL_BM_SignalGroupIndexType signalGroupID,
                             TAL_BM_RecvSignalGroupCallbackFunctionPointerType pRecvSignalGroupCallbackFunction = TAL_SignalGroupCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_UnregisterForRecvSignalGroup instead.
 * @endif
 * @endif
 *
 * @brief Unregister callback upon reception of signal group
 *
 * This function unregisters the callback function previously registered.
 *
 * @sa TAL_BM_RegisterForRecvSignalGroup
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API

 * @param sessionHandle handle of the established session
 * @endif
 * @param signalGroupID unique identifier for the signal group
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_INVALID_INDEX The function call failed, index out of bounds or
 *                           unknown signal index
 *
 * @pre A session has to be established before calling this function.
 * @pre It only makes sense to unregister previously registered callbacks
 * (TAL_BM_RegisterForRecvSignalGroup()) although it does not have any bad
 * effects if this function is called for a already unregistered signal group.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_UnregisterForRecvSignalGroup(TAL_SessionHandleType sessionHandle,
                                    TAL_BM_SignalGroupIndexType signalGroupID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmUnregisterForRecvSignalGroup(TAL_BM_SignalGroupIndexType signalGroupID) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_UnregisterForAllRecvSignalGroup instead.
 * @endif
 * @endif
 *
 * @brief Unregister callback for all FlexRay signals groups
 *
 * This function unregisters the callback of all FlexRay signal groups.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API

 * @param sessionHandle handle of the established session
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 * @pre It only makes sense to unregister previously registered callbacks
 * (TAL_BM_RegisterForRecvSignalGroup()) although it does not have any bad
 * effects if this function is called although no signal group callback was
 * registered.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_UnregisterForAllRecvSignalGroup(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmUnregisterForAllRecvSignalGroup() const;
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup flexray FlexRay related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_RegisterForPOCStatus instead.
 * @endif
 * @endif
 *
 * @brief Register for cyclic updates of the FlexRay controller status
 *
 * This function starts the cyclic update of the FlexRay controller status. You are able
 * to register a callback function that will be triggered with every update
 * received from the target.
 * The functions TAL_GetTargetPOCStatus and TAL_GetFlexRayCycleCnt may be used to get the POC
 * status and cycle/supercycle counters after using this function.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API

 * @param sessionHandle     handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pCallbackFunction pointer to callback function, called after the
 *                          transmission of the controller status
 * @endif
 * @param nFRCtrlIdx        Index of the FlexRay network (controller).
 *                          Valid values are 0 up to 1.
 * @param nUpdateCycle      time between the updates of the POC Status value
 *                          in multiples of 0.1s, if value is above 1000 it's
 *                          treated as (nUpdateCycle - 1000) miliseconds, setting this
 *                          value to 0 disables the update process, and
 *                          unregisters the callback
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 *
 * @note The function returns before the target handled the request.
 * @note If \c pCallbackFunction is \c NULL, no callback
 *       is triggered.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForPOCStatus(TAL_SessionHandleType sessionHandle,
                            uint8 nFRCtrlIdx,
                            uint16 nUpdateCycle,
                            TAL_BM_ControllerStatusCallbackFunctionPointerType pCallbackFunction);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
registerForPocStatus(uint8 nFRCtrlIdx,
                     uint16 nUpdateCycle) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
registerForPocStatus(uint8 nFRCtrlIdx,
                     uint16 nUpdateCycle,
                     TAL_BM_ControllerStatusCallbackFunctionPointerType pCallbackFunction = TAL_POCCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTargetPOCStatus instead.
 * @endif
 * @endif
 *
 * @brief Returns the last received FlexRay controller state from the target
 *
 * @sa TAL_BM_RegisterForPOCStatus
 *
 * This function returns the currently available FlexRay controller status that was
 * received last (no buffering). All pointers can be \c NULL, only the data
 * where the pointer is not \c NULL will be returned.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param nFRCtrlIdx        Index of the FlexRay network (controller).
 *                          Valid values are 0 up to 1.
 * @if TAL_C_API
 * @param pPOCState         Pointer to the area where POCState has to be stored
 * @param pFreeze           Pointer to the area where pFreeze has to be stored
 * @param pCHIHaltRequest   Pointer to the area where pCHIHaltRequest has to be
 *                          stored
 * @param pColdstartNoise   Pointer to the area where pColdstartNoise has to be
 *                          stored
 * @param pSlotMode         Pointer to the area where pSlotMode has to be stored
 * @param pErrorMode        Pointer to the area where pErrorMode has to be
 *                          stored
 * @param pWakeupStatus     Pointer to the area where pWakeupStatus has to be
 *                          stored
 * @param pStartupState     Pointer to the area where pStartupState has to be
 *                          stored
 * @else
 * @param pStatus pointer to object of type TalFrPOCStatus
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetPOCStatus(TAL_SessionHandleType sessionHandle,
                       uint8 nFRCtrlIdx,
                       TAL_POCStateType * pPOCState,
                       TAL_Boolean * pFreeze,
                       TAL_Boolean * pCHIHaltRequest,
                       TAL_Boolean * pColdstartNoise,
                       TAL_SlotModeType * pSlotMode,
                       TAL_ErrorModeType * pErrorMode,
                       TAL_WakeupStatusType * pWakeupStatus,
                       TAL_StartupStateType * pStartupState);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getTargetPocStatus(uint8 nFRCtrlIdx,
                   TalFrPocStatus * pStatus) const;
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the last received FlexRay cycle and supercycle counters
 *
 * @sa TAL_BM_RegisterForPOCStatus
 *
 * This function returns the cycle and supercycle counters for the given
 * FlexRay controller. All pointers can be \c NULL, only the data
 * where the pointer is not \c NULL will be returned.
 * A supercycle counter of 0 tells you that the FlexRay controller is not yet active
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param nFRCtrlIdx        Index of the FlexRay network (controller).
 *                          Valid values are 0 up to 1.
 * @param sessionHandle     handle of the established session
 * @param pnSuperCycleCnt   Pointer to the area where the super cycle counter has to be stored
 * @param pnCycleCnt        Pointer to the area where the cycle counter has to be stored
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Although nFRCtrlIdx has to match the one given for TAL_BM_RegisterForPOCStatus(),
 * the returned cycle and supercycle counters always refer to controller 0
 */
TAL_API extern TAL_ReturnType
TAL_GetFlexRayCycleCnt(TAL_SessionHandleType sessionHandle,
                       uint8 nFRCtrlIdx,
                       uint32 * pnSuperCycleCnt,
                       uint8 * pnCycleCnt);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_EnableSendFrame instead.
 * @endif
 * @endif
 *
 * @brief Enable sending of a frame
 *
 * This function enables the sending of a frame after it has been disabled
 * using the TAL_BM_DisableSendFrame function.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param frameIndex    unique identifier for the frame
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_COMM_ERROR     The function call failed, error at the
 *                            communication attempt
 *
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_EnableSendFrame(TAL_SessionHandleType sessionHandle,
                       TAL_BM_FrameIndexType frameIndex);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmEnableSendFrame(TAL_BM_FrameIndexType frameIndex) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_DisableSendFrame instead.
 * @endif
 * @endif
 *
 * @brief Disable sending of a FlexRay frame
 *
 * This function disables the sending of a FlexRay frame either by generating
 * a null frame (by not updating the according buffer in the FlexRay
 * controller) or by making the frame disappear (by disabling the according
 * buffer in the FlexRay controller).
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param nRepetition   Not implemented.
 * @endif
 * @param frameIndex    unique identifier for the frame
 * @param disableMethod method specification how the frame shall be disabled.
 * TAL_DISAPPEAR: The frame disappears from the bus
 * TAL_NULL_FRAME: Generate a null frame
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_COMM_ERROR     The function call failed, error at the
 *                            communication attempt
 *
 * @note TAL_DISAPPEAR does not work for sync frames. This is because the
 * FlexRay controller does not support this feature. Please either use
 * TAL_NULL_FRAME instead or change the sync frame in the configuration
 * project.
 *
 * @note TAL_NULL_FRAME does not work for the dynamic segment of FlexRay.
 * This is because the FlexRay controller does not support this feature.
 *
 * @note If disableMethod is TAL_NULL_FRAME the registered TUM callback for
 *       the frame is not called any more at the target.
 *       If disableMethod is TAL_DISAPPEAR the TUM callback is called
 *       anyway.
 *
 * @note If disableMethod is TAL_DISAPPEAR the API works on a slot level.
 * This means disabling only one frame triggering of a slot leads to undefined
 * behaviour if there is another frame triggering available for the same slot.
 * You have to call Disable(Disappear) for all frame triggerings of the
 * according slot.
 *
 * @note This function currently does not support the parameter nRepetition.
 *       The functions assumes nRepetion to be 0.
 *
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_DisableSendFrame(TAL_SessionHandleType sessionHandle,
                        TAL_BM_FrameIndexType frameIndex,
                        TAL_BM_DisabledFrameMethodType disableMethod,
                        uint32 nRepetition);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmDisableSendFrame(TAL_BM_FrameIndexType frameIndex,
                   TAL_BM_DisabledFrameMethodType disableMethod) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_InitFrameTimed instead.
 * @endif
 * @endif
 *
 * @brief Initialize the timed frame based FlexRay interface
 *
 * Initializes the timed frame based FlexRay interface.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param nOptions          Option bitfield to change the behaviour of FlexRay
 *                          Timed send. Available options are:
 *                          TAL_FRAME_TIMED_SEND_ONLY
 *
 * @retval TAL_SUCCESS  Request for initialization of FlexRay timed API was
 *                      successfully sent.
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 *
 * @sa TAL_FrameTimedOptionType
 *
 * @note None.
 *
 * @invariant None.
 *
 * @post None.
 *
 * @remarks This function must be called once before all others of the timed
 *          frame based FlexRay interface.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_InitFrameTimed(TAL_SessionHandleType sessionHandle,
                      TAL_FrameTimedOptionType nOptions);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmInitFrameTimed( TAL_FrameTimedOptionType nOptions = 0 ) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_SendFrameTimed instead.
 * @endif
 * @endif
 *
 * @brief Schedules a timed FlexRay message for transmission.
 *
 * This function copies the given FlexRay message to the internal data
 * structures.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @param frameIndex    unique identifier for the frame triggering
 * @param nTimestamp    Timestamp when the given message should be transmitted
 * @if TAL_C_API
 * @param pBuffer       Pointer to data buffer
 * @param nBufferLength Length of the data (in bytes) in pBuffer
 * @else
 * @param pMsg pointer to object of type TalFrMsg
 * @endif
 *
 *
 * @retval TAL_SUCCESS  Transmit data was written to target successfully.
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 *
 * @note None.
 *
 * @invariant None.
 *
 * @pre TAL_BM_InitFrameTimed must be called once before using this function.
 *
 * @post None.
 *
 * @remarks Only macrotick timestamps are supported.
 *          The macrotick timestamp has the format:
 *          Bit 63-32: SuperCycleCounter,
 *          Bit 31-26: FlexRayCycleCounter,
 *          Bit 25: 0,
 *          Bit 24-8: MacrotickValue,
 *          Bit 7-0: MicrotickValue;
 * For the purpose of this function only the SuperCycleCounter and the
 * FlexRayCycleCounter are relevant. The other fields are ignored.
 * The timestamp is started when the target is powered on. So be sure the
 * send timestamp is in the future of the current target time otherwise your
 * FlexRay message will never be transmitted.
 *
 * @note the frameIndex parameter references a frame triggering object
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_SendFrameTimed(TAL_SessionHandleType sessionHandle,
                      TAL_BM_FrameIndexType frameIndex,
                      uint64 nTimestamp,
                      const uint8 * pBuffer,
                      uint16 nBufferLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmSendFrameTimed(TAL_BM_FrameIndexType frameIndex,
                 uint64 nTimestamp,
                 const TalFrMsg * pMsg) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_SendFrameCond instead.
 * @endif
 * @endif
 *
 * @brief Send a FlexRay frame
 *
 * This function sets the contents of a FlexRay frame either always or once.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @param pBuffer            pointer to content of a frame
 * @param nBufferLength      size in number of bytes of the content of a sending
 *                           frame
 * @else
 * @param pMsg pointer to FlexRay frame message data object.
 * @endif
 * @param frameIndex         unique identifier for the frame / frame triggering
 * @param sendFrameCondition send type of the Frame
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is
 *                            supplied where it is not allowed
 *
 * @note When using firmware generated by Busmirror 3.x, the frameIndex
 *       parameter references a frame object, for Busmirror 4.x it
 *       references a frame triggering object
 *
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_SendFrameCond(TAL_SessionHandleType sessionHandle,
                     TAL_BM_FrameIndexType frameIndex,
                     const uint8 * pBuffer,
                     uint16 nBufferLength,
                     TAL_BM_SendFrameConditionType sendFrameCondition);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmSendFrame(TAL_BM_FrameIndexType frameIndex,
            const TalFrMsg * pMsg,
            TAL_BM_SendFrameConditionType sendFrameCondition) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_ReceiveFrameWithStatus instead.
 * @endif
 * @endif
 *
 * @brief Get the locally stored content of a FlexRay frame
 *
 * This function reads the locally stored content of a FlexRay frame.
 * After a frame is subscribed at the target it is automatically transferred
 * to the host whenever it is received from the FlexRay bus. The function
 * TAL_ProcessTargetData at the host reads the receive buffers of all
 * communication back-ends and, if it contains frame data of subscribed
 * frames they are stored in the frame base. This function returns the actual
 * value which is stored in the frame base.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API

 * @param sessionHandle handle of the established session
 * @endif
 * @param frameIndex    unique identifier for the frame / frame triggering
 * @if TAL_C_API
 * @param pBuffer       pointer to a data structure for storing the
 *                      frame content
 * @param nBufferLength size in number of bytes of the data structure for
 *                      storing the frame content
 * @param pPayloadLength pointer to data element, where current length of
 *                      the frame is stored
 * @param pStatus       Statusinformation of the received frame.
 * @else
 * @param pMsg pointer to FlexRay frame message data object. Please make sure
 * to also check the status of the frame after reception.
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_INVALID_INDEX The function call failed, index out of bounds or
 *                           unknown signal index
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 *
 * @note When using firmware generated by Busmirror 3.x, the frameIndex
 *       parameter references a frame object, for Busmirror 4.x it
 *       references a frame triggering object
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_ReceiveFrameWithStatus(TAL_SessionHandleType sessionHandle,
                              TAL_BM_FrameIndexType frameIndex,
                              uint8 * pBuffer,
                              uint16 nBufferLength,
                              uint16 * pPayloadLength,
                              TAL_BM_FrameStatusType * pStatus);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmReceiveFrame(TAL_BM_FrameIndexType frameIndex,
               TalFrMsg * pMsg) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_RegisterForRecvFrame instead.
 * @endif
 * @endif
 *
 * @brief Register for automatic reception of a FlexRay frame
 *
 * This function registers the automatic reception of a FlexRay frame and
 * notification upon receiving the frame from the target.
 * After a frame is subscribed at the target it is automatically transferred
 * to the host whenever it is received from the FlexRay bus.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: mandatory
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pRecvFrameCallbackFunction
 *                      pointer to callback function, called after the
 *                      reception of a frame
 * @endif
 * @param frameIndex    unique identifier for the frame / frame triggering
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_COMM_ERROR     The function call failed due to a error in the
 *                            communication
 * @retval TAL_INVALID_INDEX  The function call failed, index out of bounds or
 *                            unknown signal index
 * @retval TAL_ENCODING_ERROR The function call failed due to an error when
 *                            encoding a package
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is
 *                            supplied where it is not allowed
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 * @note When using firmware generated by Busmirror 3.x, the frameIndex
 *       parameter references a frame object, for Busmirror 4.x it
 *       references a frame triggering object
 *
 * @remarks It is best to keep the number of registered signals as small as
 * possible to do not waste bandwidth on the communication channel.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForRecvFrame(TAL_SessionHandleType sessionHandle,
                            TAL_BM_FrameIndexType frameIndex,
                            TAL_BM_RecvFrameCallbackFunctionPointerType pRecvFrameCallbackFunction);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
bmRegisterForRecvFrame(TAL_BM_FrameIndexType frameIndex) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
bmRegisterForRecvFrame(TAL_BM_FrameIndexType frameIndex,
                       TAL_BM_RecvFrameCallbackFunctionPointerType pRecvFrameCallbackFunction = TAL_FrameCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_UnregisterForRecvFrame instead.
 * @endif
 * @endif
 *
 * @brief Unregister for automatic reception of a FlexRay frame
 *
 * This function unregisters the automatic reception of a FlexRay frame and
 * removes the notification upon receiving the frame from the target.
 * After a frame is subscribed at the target it is automatically transferred
 * to the host whenever it is received from the FlexRay bus. This function
 * stops the automatic frame data streaming from the target to the host.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle  handle of the established session
 * @endif
 * @param frameIndex     unique identifier for the frame / frame triggering
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_COMM_ERROR     The function call failed due to a error in the
 *                            communication
 * @retval TAL_INVALID_INDEX  The function call failed, index out of bounds or
 *                            unknown signal index
 * @retval TAL_ENCODING_ERROR The function call failed due to an error when
 *                            encoding a package
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_UnregisterForRecvFrame(TAL_SessionHandleType sessionHandle,
                              TAL_BM_FrameIndexType frameIndex);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmUnregisterForRecvFrame(TAL_BM_FrameIndexType frameIndex) const;
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup signal_pdu_decoding Signal and PDU decoding functions
 * @{
 */

 /**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_UnpackPdu instead.
 * @endif
 * @endif
 *
 * @brief Unpack a specific AUTOSAR I-PDU out of a frame
 *
 * This function unpacks an AUTOSAR I-PDU from a supplied frame
 * based on a supplied pdu configuration including update bit handling (if the
 * PDU has an update bit configured).
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param pConfig              PDU configuration
 * @param pFrame               full payload of the frame (bus independent)
 *                             For CAN/CAN-FD       - CAN message payload
 *                             For FlexRay          - FlexRay frame payload
 *                             For AUTOSAR Ethernet - Not supported
 * @if TAL_C_API
 * @param nFrameLength         full length of the payload of the frame (bus independent) in units of bytes.
 * @endif
 * @param ppPdu                array where PDU should be stored
 * @if TAL_C_API
 * @param pPduLength           points to the first byte of the PDU.
 *                             No data is copied - it points into the frame array you supplied.
 *                             So as soon as memory for frame becomes unavailable also accessing ppPdu is invalid.
 * @endif
 *
 * @retval TAL_SUCCESS          The function call executed successfully
 * @retval TAL_NULL_POINTER     The function call failed due to a null argument
 * @retval TAL_NO_DATA          The PDU has an update bit and the update bit is false.
 * @retval TAL_BUFFER_TOO_SMALL The function call failed, the PDU length passes
 *                              the frame end.
 * @retval TAL_INVALID_ARGUMENT The function call failed, the configuration of the PDU
 *                              is invalid.
 *
 * @pre None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_UnpackPdu(const TAL_PduConfigType *pConfig,
              const uint8 *pFrame,
              uint32 nFrameLength,
              const uint8 **ppPdu,
              uint32 *pPduLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
unpackPdu(const TAL_PduConfigType *pConfig,
          const TalByteArray *pFrame,
          TalByteArray *ppPdu) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_UnpackSignal instead.
 * @endif
 * @endif
 *
 * @brief Unpack a specific AUTOSAR Signal out of a AUTOSAR I-PDU
 *
 * This function unpacks an specific AUTOSAR signal out of an I-PDU
 * based on a supplied signal configuration. Signal and Signalgroup update
 * bits are considered.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param pConfig              Signal configuration
 * @param pPdu                 PDU payload
 * @if TAL_C_API
 * @param pdu_length           length of PDU in bytes
 * @endif
 * @param pSignal              variable where the value of the signal should be stored
 *
 * @retval TAL_SUCCESS          The function call executed successfully
 * @retval TAL_NULL_POINTER     The function call failed due to a null argument
 * @retval TAL_NO_DATA          The signal or the group-signal has an update
 *                              bit configured and the update bit was set to false
 * @retval TAL_BUFFER_TOO_SMALL The function call failed, the signal length passes
 *                              the PDU end.
 * @retval TAL_INVALID_ARGUMENT The function call failed, the configuration of the signal
 *                              is invalid.
 *
 * @pre None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_UnpackSignal(const TAL_SignalConfigType *pConfig,
                 const uint8 *pPdu,
                 uint32 pdu_length,
                 uint64 *pSignal);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
unpackSignal(const TAL_SignalConfigType *pConfig,
          const TalByteArray *pPdu,
          TalUInt64 *pSignal) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_UnpackContainerPduInit instead.
 * @endif
 * @endif
 *
 * @brief Initialize a Container PDU iterator for unpacking contained PDUs
 * from a container PDU.
 *
 * This function initializes a container PDU iterator
 * based on a supplied container PDU configuration and updates the
 * iterator configuration for unpacking contained PDUs from a container PDU.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param pIt                  Container PDU iterator
 * @param pConfig              Container PDU configuration
 * @param pContainerPdu        Container PDU contents
 *                             No data is copied - pIt points to the contents of the container PDU
 *                             So, as soon as the contents of the container are unavailable accessing
 *                             the container PDU iterator is also unavailable.
 * @if TAL_C_API
 * @param nContainerPduLength  length of container PDU in bytes
 * @endif
 *
 * @retval TAL_SUCCESS          The function call executed successfully
 * @retval TAL_NULL_POINTER     The function call failed due to a null argument
 * @retval TAL_INVALID_ARGUMENT The function call failed due to an invalid argument
 *
 * @pre None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_UnpackContainerPduInit(TAL_ContainerPduIterator *pIt,
                           const TAL_ContainerPduConfigType *pConfig,
                           const uint8 *pContainerPdu,
                           uint32 nContainerPduLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
unpackContainerPduInit(TAL_ContainerPduIterator *pIt,
          const TAL_ContainerPduConfigType *pConfig,
          const TalByteArray *pContainerPdu) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_UnpackContainerPduNext instead.
 * @endif
 * @endif
 *
 * @brief Sequentially unpack a contained PDU from a container PDU
 *
 * This function unpacks the first contained PDU from a container PDU
 * based on the supplied container PDU iterator. If there are no more contained
 * PDUs in the container TAL_NO_DATA is returned.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param pIt                  Container PDU iterator
 * @param pPduId               PDU id
 * @param ppPdu                Contained PDU
 * @if TAL_C_API
 * @param pPduLength           length of contained PDU in bytes
 * @endif
 *
 * @retval TAL_SUCCESS           The function call executed successfully
 * @retval TAL_NO_DATA           The function call executed successfully, there are no more
 *                               contained PDUs left to read.
 * @retval TAL_NULL_POINTER      The function call failed due to a null argument
 * @retval TAL_BUFFER_TOO_SMALL  The function call failed, the contained PDUs length passes
 *                               the container PDU end.
 * @retval TAL_INVALID_ARGUMENT  The function call failed, the configuration of the container PDU
 *                               is invalid.
 *
 * @pre A container PDU iterator has to be initialized before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_UnpackContainerPduNext(TAL_ContainerPduIterator *pIt,
                           uint32* pPduId,
                           const uint8 **ppPdu,
                           uint32* pPduLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
unpackContainerPduNext(TAL_ContainerPduIterator *pIt,
                       TalUInt *pPduId,
                       TalByteArray *ppPdu) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_UnpackMultiplexedPduSelectorField instead.
 * @endif
 * @endif
 *
 * @brief Unpack a Selector Field out of an Multiplexed PDU
 *
 * This function unpacks a selector field out of a multiplexed PDU
 * based on the supplied multiplexed PDU and PDU configuration.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param pConfig                Multiplexed PDU configuration
 * @param pPdu                   Multiplexed PDU
 * @if TAL_C_API
 * @param nPduLength             length of Multiplexed PDU in bytes
 * @endif
 * @param pMuxValue              Multiplexed PDU
 * @retval TAL_SUCCESS           The function call executed successfully.
 * @retval TAL_NULL_POINTER      The function call failed due to a null argument.
 * @retval TAL_INVALID_ARGUMENT  The function call failed, the configuration of the Multiplexed PDU
 *                               is invalid.
 * @retval TAL_BUFFER_TOO_SMALL  The function call failed. The selector field's bit size and bite offset
 *                               pass the multiplexed pdu boundary.
 * @retval TAL_FAILED            The function call failed. The selector field could not be decoded from
 *                               the multiplexed pdu.
 *
 *
 * @pre None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_UnpackMultiplexedPduSelectorField(const TAL_MultiplexedPduConfigType *pConfig,
                                      const uint8 *pPdu,
                                      const uint32 nPduLength,
                                      uint32 *pMuxValue);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
unpackMultiplexedPduSelectorField(const TAL_MultiplexedPduConfigType *pConfig,
                                  const TalByteArray *pPdu,
                                  TalUInt *pMuxValue) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_UnpackMultiplexedPduPart instead.
 * @endif
 * @endif
 *
 * @brief Unpack a Multiplexed PDU part out of a Multiplexed PDU.
 *
 * This function unpacks a static or dynamic part out of a Multiplexed PDU
 * based on the supplied multiplexed PDU and PDU configuration.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param pConfig                Multiplexed PDU configuration
 * @param pPdu                   Multiplexed PDU
 * @if TAL_C_API
 * @param nPduLength             length of Multiplexed PDU in bytes
 * @endif
 * @if TAL_C_API
 * @param ppPduPart              Unpacked Multiplexed PDU part (static or dynamic)
 * @param pPduPartLength         length of Multiplexed PDU part in bytes
 * @else
 * @param pPduPart               Unpacked Multiplexed PDU part (static or dynamic)
 * @endif
 * @retval TAL_SUCCESS           The function call executed successfully.
 * @retval TAL_NULL_POINTER      The function call failed due to a null argument.
 * @retval TAL_INVALID_ARGUMENT  The function call failed, the configuration of the Multiplexed PDU
 *                               is invalid.
 * @retval TAL_BUFFER_TOO_SMALL  The function call failed. The bitoffset and bit size of the
 *                               selector field pass the pdu boundary.
 * @retval TAL_NO_DATA           The function call failed. The configured selector field
 *                               does not match the decoded one.
 * @retval TAL_FAILED            The function call failed. The selector field could not be
 *                               decoded.
 * @pre None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_UnpackMultiplexedPduPart(const TAL_MultiplexedPduConfigType *pConfig,
                             const uint8 *pPdu,
                             uint32 nPduLength,
                             const uint8 **ppPduPart,
                             uint32 *pPduPartLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
unpackMultiplexedPduPart(const TAL_MultiplexedPduConfigType *pConfig,
                         const TalByteArray *pPdu,
                         TalByteArray *pPduPart) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SignalConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Queries the tresos DB and creates the iterator for the signals.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it signal config iterator, will iterate over config data
 *
 * @retval TAL_SUCCESS       iterator initialized
 * @retval TAL_FAILED        iterator not initialized
 *
 * @note Open the database first, using function TAL_TDB_OpenTresosDB()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SignalConfigInit(TAL_SessionHandleType sessionHandle,
                         TAL_SignalConfigIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
signalConfigInit( TAL_SignalConfigIterator *it) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated  Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SignalConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the next signal config data element.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param it signal config iterator, shall be initialized already
 *
 * @param config returned configuration element
 * All pointers returned (strings) inside this structure are valid until you
 * call this function again. The memory space used to hold strings is freed
 * automatically. Do not pass the pointers returned inside config to free().
 *
 * @retval TAL_SUCCESS       config data element successfully extracted
 *
 * @retval TAL_NO_DATA        no more config data element available
 *
 * @note You have to call this function until TAL_NO_DATA (or another error
 * code) is returned!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SignalConfigNext(TAL_SignalConfigIterator *it,
                     TAL_SignalConfigType *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
signalConfigNext( TAL_SignalConfigIterator *it, TAL_SignalConfigType *config) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_PduConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Queries the tresos DB and creates the iterator for the pdu's.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it pdu config iterator, will iterate over config data
 *
 * @retval TAL_SUCCESS       iterator initialized
 * @retval TAL_FAILED        iterator not initialized
 *
 * @note Open the database first, using function TAL_TDB_OpenTresosDB()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_PduConfigInit(TAL_SessionHandleType sessionHandle,
                  TAL_PduConfigIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
pduConfigInit(TAL_PduConfigIterator *it) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_PduConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the next pdu config data element.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param it pdu config iterator, shall be initialized already
 *
 * @param config returned configuration element
 * All pointers returned (strings) inside this structure are valid until you
 * call this function again. The memory space used to hold strings is freed
 * automatically. Do not pass the pointers returned inside config to free().
 *
 * @retval TAL_SUCCESS       config data element successfully extracted
 *
 * @retval TAL_NO_DATA       no more config data element available
 *
 * @note You have to call this function until TAL_NO_DATA (or another error
 * code) is returned!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_PduConfigNext(TAL_PduConfigIterator *it,
                  TAL_PduConfigType *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
pduConfigNext(TAL_PduConfigIterator *it, TAL_PduConfigType *config) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_MultiplexedPduConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Queries the tresos DB and creates the iterator for the multiplexed pdu's.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it multiplexed pdu config iterator, will iterate over config data
 *
 * @retval TAL_SUCCESS       iterator initialized
 * @retval TAL_FAILED        iterator not initialized
 *
 * @note Open the database first, using function TAL_TDB_OpenTresosDB()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_MultiplexedPduConfigInit(TAL_SessionHandleType sessionHandle,
                             TAL_MultiplexedPduConfigIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
multiplexedPduConfigInit(TAL_MultiplexedPduConfigIterator *it) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_MultiplexedPduConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the next multiplexed pdu config data element.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param it multiplexed pdu config iterator, shall be initialized already
 *
 * @param config returned configuration element
 * All pointers returned (strings) inside this structure are valid until you
 * call this function again. The memory space used to hold strings is freed
 * automatically. Do not pass the pointers returned inside config to free().
 *
 * @retval TAL_SUCCESS       config data element successfully extracted
 *
 * @retval TAL_NO_DATA        no more config data element available
 *
 * @note You have to call this function until TAL_NO_DATA (or another error
 * code) is returned!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_MultiplexedPduConfigNext(TAL_MultiplexedPduConfigIterator *it,
                             TAL_MultiplexedPduConfigType *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
multiplexedPduConfigNext(TAL_MultiplexedPduConfigIterator *it,
                         TAL_MultiplexedPduConfigType *config) const;
#endif /* TAL_CXX_API */
/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_ContainerPduConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Queries the tresos DB and creates the iterator for the container pdu's.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it Container pdu config iterator, will iterate over config data
 *
 * @retval TAL_SUCCESS       iterator initialized
 * @retval TAL_FAILED        iterator not initialized
 *
 * @note Open the database first, using function TAL_TDB_OpenTresosDB()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ContainerPduConfigInit(TAL_SessionHandleType sessionHandle,
                             TAL_ContainerPduConfigIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
containerPduConfigInit(TAL_ContainerPduConfigIterator *it) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_ContainerPduConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the next multiplexed pdu config data element.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param it Container pdu config iterator, shall be initialized already
 *
 * @param config returned configuration element
 * All pointers returned (strings) inside this structure are valid until you
 * call this function again. The memory space used to hold strings is freed
 * automatically. Do not pass the pointers returned inside config to free().
 *
 * @retval TAL_SUCCESS       config data element successfully extracted
 *
 * @retval TAL_NO_DATA        no more config data element available
 *
 * @note You have to call this function until TAL_NO_DATA (or another error
 * code) is returned!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ContainerPduConfigNext(TAL_ContainerPduConfigIterator *it,
                             TAL_ContainerPduConfigType *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
containerPduConfigNext(TAL_ContainerPduConfigIterator *it,
                         TAL_ContainerPduConfigType *config) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_ContainedPduConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Queries the tresos DB and creates the iterator for the contained pdu's.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it Contained pdu config iterator, will iterate over config data
 *
 * @retval TAL_SUCCESS       iterator initialized
 * @retval TAL_FAILED        iterator not initialized
 *
 * @note Open the database first, using function TAL_TDB_OpenTresosDB()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ContainedPduConfigInit(TAL_SessionHandleType sessionHandle,
                             TAL_ContainedPduConfigIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
containedPduConfigInit(TAL_ContainedPduConfigIterator *it) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_ContainedPduConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the next contained pdu config data element.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param it Contained pdu config iterator, shall be initialized already
 *
 * @param config returned configuration element
 * All pointers returned (strings) inside this structure are valid until you
 * call this function again. The memory space used to hold strings is freed
 * automatically. Do not pass the pointers returned inside config to free().
 *
 * @retval TAL_SUCCESS       config data element successfully extracted
 *
 * @retval TAL_NO_DATA        no more config data element available
 *
 * @note You have to call this function until TAL_NO_DATA (or another error
 * code) is returned!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ContainedPduConfigNext(TAL_ContainedPduConfigIterator *it,
                             TAL_ContainedPduConfigType *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
containedPduConfigNext(TAL_ContainedPduConfigIterator *it,
                         TAL_ContainedPduConfigType *config) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SignalGroupConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Queries the tresos DB and creates the iterator for the signalgroups.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it signal group config iterator, will iterate over config data
 *
 * @retval TAL_SUCCESS       iterator initialized
 * @retval TAL_FAILED        iterator not initialized
 *
 * @note Open the database first, using function TAL_TDB_OpenTresosDB()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SignalGroupConfigInit(TAL_SessionHandleType sessionHandle,
                         TAL_SignalGroupConfigIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
signalGroupConfigInit( TAL_SignalGroupConfigIterator *it) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SignalGroupConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the next signal group config data element.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param it signal group config iterator, shall be initialized already
 *
 * @param config returned configuration element
 * All pointers returned (strings) inside this structure are valid until you
 * call this function again. The memory space used to hold strings is freed
 * automatically. Do not pass the pointers returned inside config to free().
 *
 * @retval TAL_SUCCESS       config data element successfully extracted
 *
 * @retval TAL_NO_DATA        no more config data element available
 *
 * @note You have to call this function until TAL_NO_DATA (or another error
 * code) is returned!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SignalGroupConfigNext(TAL_SignalGroupConfigIterator *it,
                     TAL_SignalGroupConfigType *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
signalGroupConfigNext( TAL_SignalGroupConfigIterator *it, TAL_SignalGroupConfigType *config) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_FrameTriggeringConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Queries the tresos DB and creates the iterator for the frame triggering.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it frame triggering config iterator, will iterate over config data
 *
 * @retval TAL_SUCCESS       iterator initialized
 * @retval TAL_FAILED        iterator not initialized
 *
 * @note Open the database first, using function TAL_TDB_OpenTresosDB()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_FrameTriggeringConfigInit(TAL_SessionHandleType sessionHandle,
                              TAL_FrameTriggeringConfigIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
frameTriggeringConfigInit(TAL_FrameTriggeringConfigIterator *it) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_FrameTriggeringConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the next frame triggering config data element
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param it config iterator, shall be initialized already
 *
 * @param config returned configuration element
 * All pointers returned (strings) inside this structure are valid until you
 * call this function again. The memory space used to hold strings is freed
 * automatically. Do not pass the pointers returned inside config to free().
 *
 * @retval TAL_SUCCESS       config data element successfully extracted
 *
 * @retval TAL_NO_DATA        no more config data element available
 *
 * @note You have to call this function until TAL_NO_DATA (or another error
 * code) is returned!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_FrameTriggeringConfigNext(TAL_FrameTriggeringConfigIterator *it,
                              TAL_FrameTriggeringConfigType *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
frameTriggeringConfigNext(TAL_FrameTriggeringConfigIterator *it,
                          TAL_FrameTriggeringConfigType *config) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_CanClusterConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Queries the tresos DB and creates the iterator for the FlexRay node parameters.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it frame triggering config iterator, will iterate over config data
 *
 * @retval TAL_SUCCESS       iterator initialized
 * @retval TAL_FAILED        iterator not initialized
 *
 * @note Open the database first, using function TAL_TDB_OpenTresosDB()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_CanClusterConfigInit(TAL_SessionHandleType sessionHandle,
                         TAL_CanClusterConfigIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
canClusterConfigInit(TAL_CanClusterConfigIterator *it) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_CanClusterConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the Can cluster parameters config data element
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param it config iterator, shall be initialized already
 *
 * @param config returned configuration element
 * All pointers returned (strings) inside this structure are valid until you
 * call this function again. The memory space used to hold strings is freed
 * automatically. Do not pass the pointers returned inside config to free().
 *
 * @retval TAL_SUCCESS       config data element successfully extracted
 *
 * @retval TAL_NO_DATA       no more config data element available
 *
 * @note You have to call this function until TAL_NO_DATA (or another error
 * code) is returned!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_CanClusterConfigNext(TAL_CanClusterConfigIterator *it,
                             TAL_CanClusterConfigType *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
canClusterConfigNext(TAL_CanClusterConfigIterator *it,
                         TAL_CanClusterConfigType *config) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_FlexRayControllerConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Queries the tresos DB and creates the iterator for the FlexRay controller parameters.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it FlexRay controller config iterator, will iterate over config data
 *
 * @retval TAL_SUCCESS       iterator initialized
 * @retval TAL_FAILED        iterator not initialized
 *
 * @note Open the database first, using function TAL_TDB_OpenTresosDB()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_FlexRayControllerConfigInit(TAL_SessionHandleType sessionHandle,
                              TAL_FlexRayControllerConfigIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
flexRayControllerConfigInit(TAL_FlexRayControllerConfigIterator *it) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_FlexRayControllerConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the FlexRay node parameters config data element
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param it config iterator, shall be initialized already
 *
 * @param config returned configuration element
 * All pointers returned (strings) inside this structure are valid until you
 * call this function again. The memory space used to hold strings is freed
 * automatically. Do not pass the pointers returned inside config to free().
 *
 * @retval TAL_SUCCESS       config data element successfully extracted
 *
 * @retval TAL_NO_DATA        no more config data element available
 *
 * @note You have to call this function until TAL_NO_DATA (or another error
 * code) is returned!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_FlexRayControllerConfigNext(TAL_FlexRayControllerConfigIterator *it,
                          TAL_FlexRayControllerConfigType *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
flexRayControllerConfigNext(TAL_FlexRayControllerConfigIterator *it,
                      TAL_FlexRayControllerConfigType *config) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_FlexRayClusterConfigInit instead.
 * @endif
 * @endif
 *
 * @brief Queries the tresos DB and creates the iterator for the FlexRay cluster parameters.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session data
 * @endif
 * @param it FlexRay cluster config iterator, will iterate over config data
 *
 * @retval TAL_SUCCESS       iterator initialized
 * @retval TAL_FAILED        iterator not initialized
 *
 * @note Open the database first, using function TAL_TDB_OpenTresosDB()
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_FlexRayClusterConfigInit(TAL_SessionHandleType sessionHandle,
                             TAL_FlexRayClusterConfigIterator *it);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
flexRayClusterConfigInit(TAL_FlexRayClusterConfigIterator *it) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_FlexRayClusterConfigNext instead.
 * @endif
 * @endif
 *
 * @brief Gets the FlexRay cluster parameters config data element
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param it FlexRay cluster config iterator, shall be initialized already
 *
 * @param config returned configuration element
 * All pointers returned (strings) inside this structure are valid until you
 * call this function again. The memory space used to hold strings is freed
 * automatically. Do not pass the pointers returned inside config to free().
 *
 * @retval TAL_SUCCESS       config data element successfully extracted
 *
 * @retval TAL_NO_DATA        no more config data element available
 *
 * @note You have to call this function until TAL_NO_DATA (or another error
 * code) is returned!
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_FlexRayClusterConfigNext(TAL_FlexRayClusterConfigIterator *it,
                             TAL_FlexRayClusterConfigType *config);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
flexRayClusterConfigNext(TAL_FlexRayClusterConfigIterator *it,
                         TAL_FlexRayClusterConfigType *config) const;
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup pdus PDU related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_CommitPDU instead.
 * @endif
 * @endif
 *
 * @brief Commit an event-based pdu
 *
 * This function triggers an event-based pdu/timing through the AUTOSAR Com
 * API for sending.
 * This includes sending of all signals within this pdu and setting the update
 * bit of the PDU (if one is available) to 1. After that the sending on CAN or
 * FlexRay bus is triggered in the next available send slot.
 * Please note that updating the signals value by means of the
 * TAL_BM_SendSignal functions is not enough to trigger the sending of an
 * event-based timing. To trigger sending this function must be called
 * additionally.
 * Works for both CAN and FlexRay.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param pduIndex      identifier of the event based pdu
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed due to an error when
 *                            encoding a package
 * @retval TAL_COMM_ERROR     The function call failed due to a error in the
 *                            communication
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_CommitPDU(TAL_SessionHandleType sessionHandle,
                 TAL_BM_PDUIndexType pduIndex);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmCommitPdu(TAL_BM_PDUIndexType pduIndex) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_RegisterForRecvPdu instead.
 * @endif
 * @endif
 *
 * @brief Register for automatic reception of a pdu
 *
 * This function registers the automatic reception of a pdu and
 * notification upon receiving the frame from the target.
 * After a pdu is subscribed at the target it is transferred
 * to the host. The condition to trigger a transfer after reception from the
 * FlexRay bus is defined by parameter.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: mandatory
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pRecvPDUCallbackFunction
 *                      pointer to callback function, called after the
 *                      reception of a pdu
 * @endif
 * @param pduIndex      unique identifier for the PDU
 * @param recvPduNotification
 *                      Determines the update policy of the host data.
 *                      As of Busmirror Firmware Revision 4.x please use
 *                      TAL_PDU_UPDATED, because all other options are not
 *                      supported.
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_COMM_ERROR     The function call failed due to a error in the
 *                            communication
 * @retval TAL_INVALID_INDEX  The function call failed, index out of bounds or
 *                            unknown signal index
 * @retval TAL_ENCODING_ERROR The function call failed due to an error when
 *                            encoding a package
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is
 *                            supplied where it is not allowed
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks It is best to keep the number of registered PDUs as small as
 * possible to do not waste bandwidth on the communication channel.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForRecvPdu(TAL_SessionHandleType sessionHandle,
                          TAL_BM_PDUIndexType pduIndex,
                          TAL_BM_RecvPduNotificationType recvPduNotification,
                          TAL_BM_RecvPDUCallbackFunctionPointerType pRecvPDUCallbackFunction);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
bmRegisterForRecvPdu(TAL_BM_PDUIndexType pduIndex,
                     TAL_BM_RecvPduNotificationType recvPduNotification) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
bmRegisterForRecvPdu(TAL_BM_PDUIndexType pduIndex,
                     TAL_BM_RecvPduNotificationType recvPduNotification,
                     TAL_BM_RecvPDUCallbackFunctionPointerType pRecvPDUCallbackFunction = TAL_PDUCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_UnregisterForRecvPdu instead.
 * @endif
 * @endif
 *
 * @brief Unregister for automatic reception of a pdu
 *
 * This function unregisters the automatic reception of a pdu and
 * removes the notification upon receiving the pdu from the target.
 * After a pdu is subscribed at the target it is automatically transferred
 * to the host whenever it is received from the FlexRay bus. This function
 * stops the automatic pdu data streaming from the target to the host.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle  handle of the established session
 * @endif
 * @param pduIndex     unique identifier for the pdu
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_COMM_ERROR     The function call failed due to a error in the
 *                            communication
 * @retval TAL_INVALID_INDEX  The function call failed, index out of bounds or
 *                            unknown pdu index
 * @retval TAL_ENCODING_ERROR The function call failed due to an error when
 *                            encoding a package
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_UnregisterForRecvPdu(TAL_SessionHandleType sessionHandle,
                            TAL_BM_PDUIndexType pduIndex);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmUnregisterForRecvPdu(TAL_BM_PDUIndexType pduIndex) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_UnregisterForAllRecvPdu instead.
 * @endif
 * @endif
 *
 * @brief Unregister for automatic reception of all FlexRay pdus
 *
 * This function unregisters the automatic reception of all FlexRay pdus
 * from the target.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_COMM_ERROR     The function call failed due to a error in the
 *                            communication
 * @retval TAL_ENCODING_ERROR The function call failed due to an error when
 *                            encoding a package
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_UnregisterForAllRecvPdu(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmUnregisterForAllRecvPdu() const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_ReceivePDUWithStatus instead.
 * @endif
 * @endif
 *
 * @brief Get the locally stored content of a pdu
 *
 * This function reads the locally stored content of a pdu.
 * After a pdu is subscribed at the target it is automatically transferred
 * to the host whenever the pdu is received. The function
 * @if TAL_C_API
 * #TAL_ProcessTargetData
 * @else
 * #processTargetData
 * @endif
 * at the host reads the receive buffers of all
 * communication back-ends and, if it contains pdu data of subscribed
 * frames they are stored in the pdu base. This function returns the actual
 * value which is stored in the pdu base. Additionally the functions returns the pdu
 * status (#TAL_BM_PDUStatusType).
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pduIndex      unique identifier for the pdu
 * @param pBuffer       pointer to a data structure for storing the
 *                      pdu content
 * @param nBufferLength size in number of bytes of the data structure for
 *                      storing the pdu content
 * @param pPDULength    pointer to data element, where current length of
 *                      the pdu is stored
 * @param pStatus       Statusinformation of the recieved pdu. May be NULL.
 * @param pUpdateBit    Pointer to the storage area for the updatebit. May be
 * NULL. As of Busmirror 4.x only PDU's with set update bit will be received,
 * thus it is suggested to supply NULL.
 * @else
 * @param pduIndex unique identifier for the pdu
 * @param pPdu pointer to pdu data object. Please make sure to also check
 * the coded status of the pdu after reception.
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_INVALID_INDEX The function call failed, index out of bounds or
 *                           unknown signal index
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 *
 * @note The endianess of the received data is not changed. The pdu data is supplied "raw".
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_ReceivePDUWithStatus(TAL_SessionHandleType sessionHandle,
                            TAL_BM_PDUIndexType pduIndex,
                            uint8 * pBuffer,
                            uint16 nBufferLength,
                            uint16 * pPDULength,
                            TAL_BM_PDUStatusType * pStatus,
                            TAL_BM_PDUUpdateBitType * pUpdateBit);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmReceivePdu(TAL_BM_PDUIndexType pduIndex,
             TalPdu * pPdu) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_SendPDU instead.
 * @endif
 * @endif
 *
 * @brief Send the content of a pdu
 *
 * This function modifies the content of a pdu.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param pduIndex      unique identifier for the pdu
 * @param sendPduUpdate defines what to do with the pdu
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pBuffer       pointer to content of a pdu
 * @param nBufferLength size in number of bytes of the content of a sending
 *                      pdu
 * @else
 * @param pPdu pointer to pdu data object
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is
 *                            supplied where it is not allowed
 *
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *
 * \b Example
 * \snippet Testing/TAL_API/Unpack_Pdu/src/host.cpp example_TAL_BM_SendPDU
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_SendPDU(TAL_SessionHandleType sessionHandle,
               TAL_BM_PDUIndexType pduIndex,
               TAL_BM_SendPduUpdateType sendPduUpdate,
               const uint8 * pBuffer,
               uint16 nBufferLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmSendPdu(TAL_BM_PDUIndexType pduIndex,
          TAL_BM_SendPduUpdateType sendPduUpdate,
          const TalPdu * pPdu) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_EnablePDU instead.
 * @endif
 * @endif
 *
 * @brief Enables sending of specified pdu.
 *
 * This function enables a pdu.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param pduIndex      unique identifier for the pdu
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is
 *                            supplied where it is not allowed
 *
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_EnablePDU(TAL_SessionHandleType sessionHandle,
                 TAL_BM_PDUIndexType pduIndex);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmEnablePdu(TAL_BM_PDUIndexType pduIndex) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_DisablePDU instead.
 * @endif
 * @endif
 *
 * @brief Disables sending of specified pdu.
 *
 * This function disables a pdu.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param pduIndex      unique identifier for the pdu
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is
 *                            supplied where it is not allowed
 *
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_DisablePDU(TAL_SessionHandleType sessionHandle,
                  TAL_BM_PDUIndexType pduIndex);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmDisablePdu(TAL_BM_PDUIndexType pduIndex) const;
#endif /* TAL_CXX_API */

/**
 * @}
 */
/**
 * @defgroup can_functions CAN message based related functions
 * @{
 */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Use TAL_BM_CANFDInit instead
 * @brief Initializes the internal CAN message storage mechanism and
 *        configures the CAN network (controller) to a given baudrate.
 *
 * This function allocates memory for the CANMessageBase and configures
 * the CAN network (controller) to a given baudrate.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @endif
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param BaudRate      Configures the baudrate the CAN network (controller)
 *                      of type TAL_BM_CANBaudRateType.
 * @param MaxNrIds      Max number of expected single CAN message IDs
 *                      used by registration functions
 *                      TAL_BM_RegisterForRecvCANMsg and
 *                      TAL_BM_RegisterForCANTxConfirmation.
 * @param MaxNrOfFilters   Max Number of CAN Filter tables used by registration
 *                         functions TAL_BM_RegisterForRecvCANMsgFilter,
 *                         TAL_BM_RegisterForRecvCANMsgFilterRange and
 *                         TAL_BM_RegisterForCANTxConfirmationFilterRange.
 *                         IMPORTANT: Each received message which is not
 *                         registered with TAL_BM_RegisterForRecvCANMsg or
 *                         TAL_BM_RegisterForCANTxConfirmation
 *                         will trigger a linear search over all filter tables!
 *                         A large number have a heavy impact on the
 *                         performance!
 * @param GlobalRxTxQueueSize  Size in CAN messages of the global Rx/Tx queue.
 *                             All messages which are not registered with one of
 *                             the register functions are stored in this global
 *                             queue. If the value is 0 the global queue and the
 *                             pGlobalRxTxCallback are disabled and the messages
 *                             are discarded.
 * @ifnot SWIG
 * @param pGlobalRxTxCallback  Function pointer of the global queue callback of type
 *                             TAL_BM_RecvCANMessageCallbackFunctionPointerType.
 *                             If a message is stored into the global queue
 *                             this callback is executed. Use value 0
 *                             to disable the callback. If the callback is disabled
 *                             the user is responsible for polling the queue in time.
 * @endif
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_CANBaudRateType
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *
 * @retval TAL_SUCCESS The CAN network (controller) was initialized successfully.
 * @retval TAL_SUCCESS_AGAIN    The CAN network(controller) was already initialized before.
 *                              Ignoring MaxNrIds, MaxNrOfFilter and
 *                              GlobalRxTxQueueSize.
 * @retval TAL_FAILED  An error occurred during CAN network (controller) initialization.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to an error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handles the request.
 *       This function does some memory allocation and should not be called
 *       in time critical context.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks CAN Tx confirmations will not work with deprecated CAN API functions!
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_DEPRECATED TAL_ReturnType
TAL_BM_CANInit(TAL_SessionHandleType sessionHandle,
               uint8 CANCC,
               TAL_BM_CANBaudRateType BaudRate,
               uint16 MaxNrIds,
               uint8 MaxNrOfFilters,
               uint16 GlobalRxTxQueueSize,
               TAL_BM_RecvCANMessageCallbackFunctionPointerType pGlobalRxTxCallback);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
initCan(uint8 CANCC,
        TAL_BM_CANBaudRateType BaudRate,
        uint16 MaxNrIds,
        uint8 MaxNrOfFilters,
        uint16 GlobalRxTxQueueSize) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
initCan(uint8 CANCC,
        TAL_BM_CANBaudRateType BaudRate,
        uint16 MaxNrIds,
        uint8 MaxNrOfFilters,
        uint16 GlobalRxTxQueueSize,
        TAL_BM_RecvCANMessageCallbackFunctionPointerType pGlobalRxTxCallback = TAL_CANCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */
/* @endcond */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_CANFDInit instead.
 * @endif
 * @endif
 *
 * @brief Initializes the internal CAN message storage mechanism and
 *        configures the CAN-FD network (controller) to the given baudrate(s).
 *
 * This function allocates memory for the CANMessageBase and configures
 * the CAN network (controller) to the given baudrate(s).
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @endif
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param NonIso        Configures whether the controller performs communication according to
 *                      ISO11898-1(Bosch CAN specification 2.0 part A,B) (NonIso = 0) or to Bosch
 *                      CAN-FD specification V1.0 (NonIso = 1). NonIso = 1 mode shall only be used
 *                      for backward compatibility with existing projects.
 *                      For new projects it is recommended to use (NonIso = 0) mode.
 * @param BaudRate      Configures the baudrate (bits per second) during arbitration phase of the
 *                      CAN network (controller). Optionally also TAL_CAN_USE_RBS_BAUDRATE can be
 *                      specified (for both BaudRate and BaudRateFD) to use a RBS controller with
 *                      its configured baudrate also for message based functionality.
 *                      Be aware that TAL cannot check whether there is really a RBS controller
 *                      configured and if there isn't CAN won't work (check error channel).
 * @param BaudRateFD    Configures the baudrate (bits per second) during data and CRC phase of the
 *                      CAN network (controller). Optionally also TAL_CAN_USE_RBS_BAUDRATE can be
 *                      specified (for both BaudRate and BaudRateFD) to use a RBS controller with
 *                      its configured baudrate also for message based functionality.
 *                      Be aware that TAL cannot check whether there is really a RBS controller
 *                      configured and if there isn't CAN won't work (check error channel).
 * @param MaxNrIds      Max number of expected single CAN message IDs
 *                      used by registration functions
 *                      TAL_BM_RegisterForRecvCANMsg and
 *                      TAL_BM_RegisterForCANTxConfirmation.
 * @param MaxNrOfFilters   Max Number of CAN Filter tables used by registration
 *                         functions TAL_BM_RegisterForRecvCANMsgFilter,
 *                         TAL_BM_RegisterForRecvCANMsgFilterRange and
 *                         TAL_BM_RegisterForCANTxConfirmationFilterRange.
 *                         IMPORTANT: Each received message which is not
 *                         registered with TAL_BM_RegisterForRecvCANMsg or
 *                         TAL_BM_RegisterForCANTxConfirmation
 *                         will trigger a linear search over all filter tables!
 *                         A large number have a heavy impact on the
 *                         performance!
 * @param GlobalRxTxQueueSize  Size in CAN messages of the global Rx/Tx queue.
 *                             All messages which are not registered with one of
 *                             the register functions are stored in this global
 *                             queue. If the value is 0 the global queue and the
 *                             pGlobalRxTxCallback are disabled and the messages
 *                             are discarded.
 * @ifnot SWIG
 * @param pGlobalRxTxCallback  Function pointer of the global queue callback of type
 *                             TAL_BM_RecvCANMessageCallbackFunctionPointerType.
 *                             If a message is stored into the global queue
 *                             this callback is executed. Use value 0
 *                             to disable the callback. If the callback is disabled
 *                             the user is responsible for polling the queue in time.
 * @endif
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_CAN_USE_RBS_BAUDRATE
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *
 * @retval TAL_SUCCESS The CAN network (controller) was initialized successfully.
 * @retval TAL_SUCCESS_AGAIN    The CAN network(controller) was already initialized before.
 *                              Ignoring MaxNrIds, MaxNrOfFilter and
 *                              GlobalRxTxQueueSize.
 * @retval TAL_FAILED  An error occurred during CAN network (controller) initialization.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to an error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handles the request.
 *       This function does some memory allocation and should not be called
 *       in time critical context.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks CAN Tx confirmations will not work with deprecated CAN API functions!
 *
 * CAN FD controller bit rate calculations are done in a way that the code is trying to reach a destination sampling point of 75% (according to ISO-11898).
 * If another value is to be used, TAL_SetDeviceOption must be called with the TAL_EBX200_SET_CAN_SAMPLING_POINT option before calling TAL_BM_CANFDInit.
 * With this call, the points for the arbitration phase and the data phase can be set in the range from 1% to 100%.
 * We probe for tseg1 + tseg2 + 1 (for sync-phase) and a variable pre-scaler (brp), for a given fixed CAN FD controller clock (on EB5200: 40MHz)
 * to have the smallest possible "bit rate configuration error" for the target baudrate specified via the API (e.g. 500kbit nominal, 2Mbit data rate).
 * We do this probing for both the nominal baudate and the data baudrate for CAN-FD. After probing, the next possible sample point close to 75% is chosen.
 * In reality this may not be 75%; it may even be 60% or 70%, because we can only change the tsec1 register by integer values.
 * Sample point may be different for data phase and arbitration phase.
 * To e.g. set both to exactly the same value (e.g. 62,5%) will not be possible with the real hardware.
 * Please also note that it would be hard to optimize for two things: "smallest sample point configuration error" and "smallest bit rate configuration error".
 *
 * The defined points are also printed by the device after a successful call of this function. (See TAL_GetErrorString)
 *
 * The following table shows description of the parameters used in the example below:
 *
 * |Phase             | Baudrate (Hz)  | Baudrate (Hz)  |  tseg1 / tseg2 / brp  | Sample point |
 * |:---------------: | :------------: | :------------: | :----------------: | :--------------:|
 * |nominal / data    |        125000  |   (125000)     | 239 / 80 / 1       |  0.750000       |
 * |Nominal means arbitration phase, data means data phase of CAN-FD| Target baudrate in Hz | Real baudrate configured: if this value is different than we have a bit rate configuration error| Register values for tseg1, tseg2 and brp.|Real sample point: i.e. the next to 75% possible. 0.75 means 75%|
 *
 * The following example shows controller configuration values (tseg1, tseg2 and brp (baud rate prescaler)) of the algorithm for the BOSCH MCAN Can-FD
 * controller driven by a 40MHz clock for a given baudrate and target sample point of 75%:
 *
 * | Phase   | Baudrate (Hz)| Real Baudrate (Hz)| tseg1 | tseg2 | brp | Sample point |
 * |:------- | ------:      | -----------:      | ----: | ----: | --: | ------------:|
 * | nominal | 125000       | (125000)          |   239 |  80   |   1 | 0.750000 |
 * | nominal | 250000       | (250000)          |   119 |  40   |   1 | 0.750000 |
 * | nominal | 500000       | (500000)          |   59  |  20   |   1 | 0.750000 |
 * | nominal | 1000000      | (1000000)         |   29  |  10   |   1 | 0.750000 |
 * | data    | 1000000      | (1000000)         |   29  |  10   |   1 | 0.750000 |
 * | data    | 2000000      | (2000000)         |   14  |  5    |   1 | 0.750000 |
 * | data    | 4000000      | (4000000)         |   6   |  3    |   1 | 0.700000 |
 * | data    | 8000000      | (8000000)         |   2   |  2    |   1 | 0.600000 |
 * | data    | 10000000     | (10000000)        |   2   |  1    |   1 | 0.750000 |
 *
 *
 *
 */

#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_CANFDInit(TAL_SessionHandleType sessionHandle,
               uint8 CANCC,
               uint8 NonIso,
               uint32 BaudRate,
               uint32 BaudRateFD,
               uint16 MaxNrIds,
               uint8 MaxNrOfFilters,
               uint16 GlobalRxTxQueueSize,
               TAL_BM_RecvCANMessageCallbackFunctionPointerType pGlobalRxTxCallback);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
initCanFD(uint8 CANCC,
        uint8  NonIso,
        uint32 BaudRate,
        uint32 BaudRateFD,
        uint16 MaxNrIds,
        uint8 MaxNrOfFilters,
        uint16 GlobalRxTxQueueSize) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
initCanFD(uint8 CANCC,
        uint8  NonIso,
        uint32 BaudRate,
        uint32 BaudRateFD,
        uint16 MaxNrIds,
        uint8 MaxNrOfFilters,
        uint16 GlobalRxTxQueueSize,
        TAL_BM_RecvCANMessageCallbackFunctionPointerType pGlobalRxTxCallback = TAL_CANCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_CANRelease instead.
 * @endif
 * @endif
 *
 * @brief Release the CAN network (controller).
 *
 * This function deallocates memory of the CANMessageBase.
 * Releasing of can controller is not mandatory because TAL_BM_CANFDInit
 * deallocates memory if called multiple times.
 * Deleting the session also frees up memory.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @endif
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 *
 * @retval TAL_SUCCESS The CAN network (controller) was initialized successfully.
 * @retval TAL_FAILED  An error occurred during CAN network (controller) initialization.
 * @retval TAL_COMM_ERROR       The function call failed due to an error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handles the request.
 *       This function does some memory deallocation and should not be called
 *       in time critical context.
 *
 * @pre A session has to be established before calling this function.
 *
 */

#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_CANRelease(TAL_SessionHandleType sessionHandle,
                  uint8 CANCC);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
releaseCan(uint8 CANCC) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_CANConfigureEvents instead.
 * @endif
 * @endif
 *
 * @brief Configures the CAN global event mask.
 *
 * This function configures which CAN events are passed to the Host system.
 * The errors are then reported via function TAL_GetErrorData
 * with error type set to TAL_ERROR_CAN.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @endif
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param GlobalEventMask  CAN events of type TAL_BM_CANEventFlagsType.
 *                         Combinations of events are allowed.
 *                         If TAL_BM_CAN_EVENT_TX is specified all unregistered
 *                         CAN Tx confirmations are stored inside the global
 *                         Rx/Tx queue.
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_CANEventFlagsType
 *
 * @retval TAL_SUCCESS The options were passed to the target successfully.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to an error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handles the request.
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_CANConfigureEvents(TAL_SessionHandleType sessionHandle,
                          uint8 CANCC,
                          TAL_BM_CANEventFlagsType GlobalEventMask);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
configureCanEvents(uint8 CANCC,
                   TAL_BM_CANEventFlagsType GlobalEventMask) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_CANConfigureTimedSend instead.
 * @endif
 * @endif
 *
 * @brief Configures the CAN timed send.
 *
 * This function configures a period for delay messages. If the transmission of
 * a CAN messages is delayed more than the configured period a TX-Confirmation will
 * be forced with the according error bits set.
 * Please use function TAL_GetErrorData (the error type will be TAL_ERROR_CAN)
 * to receive error window violations.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @endif
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param ErrorWindowTooLate A message TX-confirmation will be forced for CAN
 *                           messages that are delayed more than
 *                           ErrorWindowTooLate and the message was written to
 *                           the CAN controller after the required timestamp already occurred.
 * @param ErrorWindowBlocked A message TX-confirmation will be forced for
 *                           CAN messages that are delayed more than
 *                           ErrorWindowBlocked and the message was delayed
 *                           because the bus was not idle.
 * @param ErrorWindowBusy    A message TX-confirmation will be forced for
 *                           CAN messages that are delayed more than
 *                           ErrorWindowBusy and the message was delayed
 *                           because the CAN controller was busy sending another message.
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 *
 * @retval TAL_SUCCESS The options were passed to the target successfully.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to an error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handles the request.
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_CANConfigureTimedSend(TAL_SessionHandleType sessionHandle,
                             uint8 CANCC,
                             uint64 ErrorWindowTooLate,
                             uint64 ErrorWindowBlocked,
                             uint64 ErrorWindowBusy);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
configureCanTimedSend(uint8 CANCC,
                      uint64 ErrorWindowTooLate,
                      uint64 ErrorWindowBlocked,
                      uint64 ErrorWindowBusy) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_SendCANMsg instead.
 * @endif
 * @endif
 *
 * @brief Sends a CAN message
 *
 * This function sends a CAN message on the given CAN network (controller)
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param MessageID     The CAN message ID (11 or 29 bit).
 * @param bIsExtended   Defines if the CAN message ID is a standard (TAL_FALSE)
 *                      or extended (TAL_TRUE) one.
 * @param MessageType   Type of the CAN message. Use macro
 *                      TAL_BM_CANMESSAGE_DATA to define a CAN data
 *                      message or TAL_BM_CANMESSAGE_REMOTE to define a CAN
 *                      remote message.
 * @param pBuffer       Pointer to the payload data of the CAN message.
 * @param nBufferLength Length of the payload data.
 * @param nTID          Transaction ID assigned to this CAN message by the driver.
 *                      A Transaction ID is always assigned to a CAN message even if
 *                      the function returns TAL_COMM_ERROR.
 *                      Can be used in combination with functions TAL_BM_GetCANEvent
 *                      or TAL_BM_PeekCANEvent to realize a flow-control check of
 *                      sent CAN messages.
 * @else
 * @param CANCC Number of the CAN network (controller). Valid values are 0 up
 * to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param pMsg pointer to can message data object. If you want to correspond
 * this call with a tx confirmations later on you can use the getTransactionId()
 * method of TalCanMsg afterwards.
 * @endif
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_CANMESSAGE_DATA
 * @sa TAL_BM_CANMESSAGE_REMOTE
 * @sa TAL_BM_GetCANEvent
 * @sa TAL_BM_PeekCANEvent
 *
 * @retval TAL_SUCCESS   The function call executed successfully
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to an error in the
 *                              communication.
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note  The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 * \b Example
 * \snippet Testing/TAL_legacy_CAN/Send_Recv_Msg_NewAPI/src/host.cpp example_TAL_BM_SendCANMsg
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_SendCANMsg(TAL_SessionHandleType sessionHandle,
                  uint8 CANCC,
                  TAL_BM_CANMessageIDType MessageID,
                  TAL_Boolean bIsExtended,
                  TAL_BM_CANMsgTypeType MessageType,
                  const uint8 * pBuffer,
                  uint8 nBufferLength,
                  TAL_TransactionIDType * nTID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
sendCanMsg(uint8 CANCC,
           TalCanMsg * pMsg) const;
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_SendCANMsgTimed instead.
 * @endif
 * @endif
 *
 * @brief Sends a timed CAN message
 *
 * This function sends a CAN message on the given CAN network (controller)
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle Handle of the established session.
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param MessageID     The CAN message ID (11 or 29 bit).
 * @param bIsExtended   Defines if the CAN message ID is a standard (TAL_FALSE)
 *                      or extended (TAL_TRUE) one.
 * @param MessageType   Type of the CAN message. Use macro
 *                      TAL_BM_CANMESSAGE_DATA to define a CAN data
 *                      message or TAL_BM_CANMESSAGE_REMOTE to define a CAN
 *                      remote message.
 * @param pBuffer       Pointer to the payload data of the CAN message.
 * @param nBufferLength Length of the payload data.
 * @param nTID          Transaction ID assigned to this CAN message by the driver.
 *                      A Transaction ID is always assigned to a CAN message even if
 *                      the function returns TAL_COMM_ERROR.
 *                      Can be used in combination with functions TAL_BM_GetCANEvent
 *                      or TAL_BM_PeekCANEvent to realize a flow-control check of
 *                      sent CAN messages.
 * @param nTimestamp
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_CANMESSAGE_DATA
 * @sa TAL_BM_CANMESSAGE_REMOTE
 * @sa TAL_BM_GetCANEventTimed
 * @sa TAL_BM_PeekCANEventTimed
 *
 * @retval TAL_SUCCESS   The function call executed successfully
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to an error in the
 *                              communication.
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note  The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 */
TAL_API extern TAL_ReturnType
TAL_BM_SendCANMsgTimed(TAL_SessionHandleType sessionHandle,
                  uint8 CANCC,
                  TAL_BM_CANMessageIDType MessageID,
                  TAL_Boolean bIsExtended,
                  TAL_BM_CANMsgTypeType MessageType,
                  const uint8 * pBuffer,
                  uint8 nBufferLength,
                  TAL_TransactionIDType * nTID,
                  uint64 nTimestamp);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_GetCANEvent instead.
 * @endif
 * @endif
 *
 * @brief Receives a CAN event (CAN Message)
 *
 * This function receives a CAN event (a CAN message) from the given
 * CAN network (controller). CAN events are received messages or received
 * transmit confirmations.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param QueueID       The Queue ID addresses one specific queue in the
 *                      CAN message base.
 *                      The QueueID is used in two different contexts.
 *                      First: When used in context of a callback function of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *                      pass the QueueID (without any macros) to TAL_BM_GetCANEvent
 *                      to receive the content of the CAN message.
 *                      Second: When used without callback function (polling mode)
 *                      use the macros TAL_BM_CAN_QUEUE_ID or TAL_BM_CAN_FILTER_QUEUE_ID or
 *                      TAL_BM_CAN_GLOBAL_QUEUE_ID to read from a specific queue.
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @param pMessageID    ID of received CAN message (11 or 29 bit).
 * @param pIsExtended   TAL_FALSE for a standard, TAL_TRUE for an extended CAN message ID.
 * @param pMessageType  Type of the CAN message. Is either TAL_BM_CANMESSAGE_DATA
 *                      or TAL_BM_CANMESSAGE_REMOTE.
 * @param pTimestamp    Timestamp of the received CAN message. The resolution
 *                      of the timestamp is 1us/tick.
 * @param pBuffer       Pointer to buffer (provided by the user) to store the
 *                      CAN message payload data.
 * @param nBufferLength Max size of the user provided buffer.
 * @param pPayloadLength Length of effective received data copied to the user buffer.
 * @param pStatus       Status of the CAN message of type TAL_BM_CANMessageStatusType.
 * @param nTID          If pStatus is a CAN Tx confirmation this is the transaction ID
 *                      of the CAN message.
 * @else
 * @param pMsg pointer to can message data object
 * @endif
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 * @sa TAL_BM_CAN_QUEUE_ID
 * @sa TAL_BM_CAN_FILTER_QUEUE_ID
 * @sa TAL_BM_CAN_GLOBAL_QUEUE_ID
 * @sa TAL_BM_CANMESSAGE_DATA
 * @sa TAL_BM_CANMESSAGE_REMOTE
 * @sa TAL_BM_CANMessageStatusType
 *
 * @retval TAL_SUCCESS A CAN event (message) was received successfully.
 * @retval TAL_FAILED  Error occurred during function call
 * @retval TAL_NO_DATA No data available in selected queue.
 * @retval TAL_OVERFLOW Queue overflow occurred. At least one CAN message
 *         was lost.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note This function can be used inside a callback of type
 *       TAL_BM_RecvCANMessageCallbackFunctionPointerType or for
 *       polling a specific receive queue.
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_GetCANEvent(TAL_SessionHandleType sessionHandle,
                   uint8 CANCC,
                   TAL_BM_CANMessageIDType QueueID,
                   TAL_BM_CANMessageIDType * pMessageID,
                   TAL_Boolean * pIsExtended,
                   TAL_BM_CANMsgTypeType * pMessageType,
                   uint32 * pTimestamp,
                   uint8 * pBuffer,
                   uint8 nBufferLength,
                   uint8 * pPayloadLength,
                   TAL_BM_CANMessageStatusType * pStatus,
                   TAL_TransactionIDType * nTID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getCanEvent(uint8 CANCC,
            TAL_BM_CANMessageIDType QueueID,
            TalCanMsg * pMsg) const;
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Receives a timed CAN event (CAN Message)
 *
 * This function receives a CAN event (a CAN message) from the given
 * CAN network (controller). CAN events are received messages or received
 * transmit confirmations.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param QueueID       The Queue ID addresses one specific queue in the
 *                      CAN message base.
 *                      The QueueID is used in two different contexts.
 *                      First: When used in context of a callback function of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *                      pass the QueueID (without any macros) to TAL_BM_GetCANEvent
 *                      to receive the content of the CAN message.
 *                      Second: When used without callback function (polling mode)
 *                      use the macros TAL_BM_CAN_QUEUE_ID or TAL_BM_CAN_FILTER_QUEUE_ID or
 *                      TAL_BM_CAN_GLOBAL_QUEUE_ID to read from a specific queue.
 * @param sessionHandle Handle of the established session.
 * @param pMessageID    ID of received CAN message (11 or 29 bit).
 * @param pIsExtended   TAL_FALSE for a standard, TAL_TRUE for an extended CAN message ID.
 * @param pMessageType  Type of the CAN message. Is either TAL_BM_CANMESSAGE_DATA
 *                      or TAL_BM_CANMESSAGE_REMOTE.
 * @param pTimestamp    Timestamp of the received CAN message. The resolution
 *                      of the timestamp is 1us/tick.
 * @param pBuffer       Pointer to buffer (provided by the user) to store the
 *                      CAN message payload data.
 * @param nBufferLength Max size of the user provided buffer.
 * @param pPayloadLength Length of effective received data copied to the user buffer.
 * @param peStatus      Status of the CAN message of type TAL_BM_CANMessageStatusType.
 * @param nTID          If peStatus is a CAN Tx confirmation this is the transaction ID
 *                      of the CAN message.
 * @param pTimestamp64  Timestamp when the message was transmitted
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 * @sa TAL_BM_CAN_QUEUE_ID
 * @sa TAL_BM_CAN_FILTER_QUEUE_ID
 * @sa TAL_BM_CAN_GLOBAL_QUEUE_ID
 * @sa TAL_BM_CANMESSAGE_DATA
 * @sa TAL_BM_CANMESSAGE_REMOTE
 * @sa TAL_BM_CANMessageStatusType
 *
 * @retval TAL_SUCCESS A CAN event (message) was received successfully.
 * @retval TAL_FAILED  Error occurred during function call
 * @retval TAL_NO_DATA No data available in selected queue.
 * @retval TAL_OVERFLOW Queue overflow occurred. At least one CAN message
 *         was lost.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note This function can be used inside a callback of type
 *       TAL_BM_RecvCANMessageCallbackFunctionPointerType or for
 *       polling a specific receive queue.
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 */
TAL_API extern TAL_ReturnType
TAL_BM_GetCANEventTimed(TAL_SessionHandleType sessionHandle,
                   uint8 CANCC,
                   TAL_BM_CANMessageIDType QueueID,
                   TAL_BM_CANMessageIDType * pMessageID,
                   TAL_Boolean * pIsExtended,
                   TAL_BM_CANMsgTypeType * pMessageType,
                   uint32 * pTimestamp,
                   uint8 * pBuffer,
                   uint8 nBufferLength,
                   uint8 * pPayloadLength,
                   TAL_BM_CANMessageStatusType * peStatus,
                   TAL_TransactionIDType * nTID,
                   uint64 * pTimestamp64);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_PeekCANEvent instead.
 * @endif
 * @endif
 *
 * @brief Peek a CAN event (CAN Message)
 *
 * This function receives a CAN event (a CAN message) from the given
 * CAN network (controller). CAN events are received messages or received
 * transmit confirmations.
 * Different to TAL_BM_GetCANEvent this function does not consume
 * the CAN event from the message queue.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param QueueID       The Queue ID addresses one specific queue in the
 *                      CAN message base.
 *                      The QueueID is used in two different contexts.
 *                      First: When used in context of a callback function of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *                      pass the QueueID (without any macros) to TAL_BM_GetCANEvent
 *                      or TAL_BM_PeekCANEvent to receive the content of the CAN message.
 *                      Second: When used without callback function (polling mode)
 *                      use the macros TAL_BM_CAN_QUEUE_ID or TAL_BM_CAN_FILTER_QUEUE_ID or
 *                      TAL_BM_CAN_GLOBAL_QUEUE_ID to read from a specific queue.
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @param pMessageID    ID of received CAN message (11 or 29 bit).
 * @param pIsExtended   TAL_FALSE for a standard, TAL_TRUE for an extended CAN message ID.
 * @param pMessageType  Type of the CAN message. Is either TAL_BM_CANMESSAGE_DATA
 *                      or TAL_BM_CANMESSAGE_REMOTE.
 * @param pTimestamp    Timestamp of the received CAN message. The resolution
 *                      of the timestamp is 1us/tick.
 * @param pBuffer       Pointer to buffer (provided by the user) to store the
 *                      CAN message payload data.
 * @param nBufferLength Max size of the user provided buffer.
 * @param pPayloadLength Length of effective received data copied to the user buffer.
 * @param peStatus      Status of the CAN message of type TAL_BM_CANMessageStatusType.
 * @param nTID          If peStatus is a CAN Tx confirmation this is the transaction ID
 *                      of the CAN message.
 * @else
 * @param pMsg pointer to can message data object
 * @endif
 *
 * @sa TAL_BM_GetCANEvent
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 * @sa TAL_BM_CAN_QUEUE_ID
 * @sa TAL_BM_CAN_FILTER_QUEUE_ID
 * @sa TAL_BM_CAN_GLOBAL_QUEUE_ID
 * @sa TAL_BM_CANMESSAGE_DATA
 * @sa TAL_BM_CANMESSAGE_REMOTE
 * @sa TAL_BM_CANMessageStatusType
 *
 * @retval TAL_SUCCESS A CAN event (message) was received successfully.
 * @retval TAL_FAILED  Error occurred during function call
 * @retval TAL_NO_DATA No data available in selected queue.
 * @retval TAL_OVERFLOW Queue overflow occurred. At least one CAN message
 *         was lost.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note This function can be used inside a callback of type
 *       TAL_BM_RecvCANMessageCallbackFunctionPointerType or for
 *       polling a specific receive queue.
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_PeekCANEvent(TAL_SessionHandleType sessionHandle,
                    uint8 CANCC,
                    TAL_BM_CANMessageIDType QueueID,
                    TAL_BM_CANMessageIDType * pMessageID,
                    TAL_Boolean * pIsExtended,
                    TAL_BM_CANMsgTypeType * pMessageType,
                    uint32 * pTimestamp,
                    uint8 * pBuffer,
                    uint8 nBufferLength,
                    uint8 * pPayloadLength,
                    TAL_BM_CANMessageStatusType * peStatus,
                    TAL_TransactionIDType * nTID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
peekCanEvent(uint8 CANCC,
             TAL_BM_CANMessageIDType QueueID,
             TalCanMsg * pMsg) const;
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Peek a timed CAN event (CAN Message)
 *
 * This function receives a CAN event (a CAN message) from the given
 * CAN network (controller). CAN events are received messages or received
 * transmit confirmations.
 * Different to TAL_BM_GetCANEvent this function does not consume
 * the CAN event from the message queue.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle Handle of the established session.
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param QueueID       The Queue ID addresses one specific queue in the
 *                      CAN message base.
 *                      The QueueID is used in two different contexts.
 *                      First: When used in context of a callback function of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *                      pass the QueueID (without any macros) to TAL_BM_GetCANEvent
 *                      or TAL_BM_PeekCANEvent to receive the content of the CAN message.
 *                      Second: When used without callback function (polling mode)
 *                      use the macros TAL_BM_CAN_QUEUE_ID or TAL_BM_CAN_FILTER_QUEUE_ID or
 *                      TAL_BM_CAN_GLOBAL_QUEUE_ID to read from a specific queue.
 * @param pMessageID    ID of received CAN message (11 or 29 bit).
 * @param pIsExtended   TAL_FALSE for a standard, TAL_TRUE for an extended CAN message ID.
 * @param pMessageType  Type of the CAN message. Is either TAL_BM_CANMESSAGE_DATA
 *                      or TAL_BM_CANMESSAGE_REMOTE.
 * @param pTimestamp    Timestamp of the received CAN message. The resolution
 *                      of the timestamp is 1us/tick.
 * @param pBuffer       Pointer to buffer (provided by the user) to store the
 *                      CAN message payload data.
 * @param nBufferLength Max size of the user provided buffer.
 * @param pPayloadLength Length of effective received data copied to the user buffer.
 * @param pStatus       Status of the CAN message of type TAL_BM_CANMessageStatusType.
 * @param nTID          If pStatus is a CAN Tx confirmation this is the transaction ID
 *                      of the CAN message.
 * @param pTimestamp64  Timestamp when the message was transmitted
 *
 * @sa TAL_BM_GetCANEvent
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 * @sa TAL_BM_CAN_QUEUE_ID
 * @sa TAL_BM_CAN_FILTER_QUEUE_ID
 * @sa TAL_BM_CAN_GLOBAL_QUEUE_ID
 * @sa TAL_BM_CANMESSAGE_DATA
 * @sa TAL_BM_CANMESSAGE_REMOTE
 * @sa TAL_BM_CANMessageStatusType
 *
 * @retval TAL_SUCCESS A CAN event (message) was received successfully.
 * @retval TAL_FAILED  Error occurred during function call
 * @retval TAL_NO_DATA No data available in selected queue.
 * @retval TAL_OVERFLOW Queue overflow occurred. At least one CAN message
 *         was lost.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note This function can be used inside a callback of type
 *       TAL_BM_RecvCANMessageCallbackFunctionPointerType or for
 *       polling a specific receive queue.
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 */
TAL_API extern TAL_ReturnType
TAL_BM_PeekCANEventTimed(TAL_SessionHandleType sessionHandle,
                   uint8 CANCC,
                   TAL_BM_CANMessageIDType QueueID,
                   TAL_BM_CANMessageIDType * pMessageID,
                   TAL_Boolean * pIsExtended,
                   TAL_BM_CANMsgTypeType * pMessageType,
                   uint32 * pTimestamp,
                   uint8 * pBuffer,
                   uint8 nBufferLength,
                   uint8 * pPayloadLength,
                   TAL_BM_CANMessageStatusType * pStatus,
                   TAL_TransactionIDType * nTID,
                   uint64 * pTimestamp64);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_RegisterForRecvCANMsg instead.
 * @endif
 * @endif
 *
 * @brief Registers a single CAN message
 *
 * This function registers a single CAN message. For each registered CAN
 * message a hash queue is allocated to store the CAN message data.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @param Options       Reserved for further use. Pass TAL_BM_CAN_OPT_UNUSED as
 *                      argument.
 * @endif
 * @ifnot SWIG
 * @param pCallback     Function pointer of a notification callback of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType.
 *                      If a message is stored into this queue
 *                      this callback is executed. Use value 0 to
 *                      disable the callback. If the callback is disabled
 *                      the user is responsible for polling the queue in time.
 * @endif
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param MessageID     CAN message ID (11 or 29 bit) this hash queue is
 *                      registered for.
 * @param bIsExtended   TAL_FALSE for a standard, TAL_TRUE for an extended CAN message ID.
 * @param QueueSize     Size of the queue in CAN messages.
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_CAN_OPT_UNUSED
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *
 * @retval TAL_SUCCESS The single CAN message queue was registered successfully.
 * @retval TAL_FAILED  An error occurred while registering the single
 *                     CAN message queue.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to a error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handled the request.
 *       CAN messages which are not registered are stored inside the global
 *       queue (or are discarded if the global queue is disabled).
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 * \b Example
 * \snippet Testing/TAL_legacy_CAN/Send_Recv_Msg_NewAPI/src/host.cpp example_TAL_BM_RegisterForRecvCANMsg
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForRecvCANMsg(TAL_SessionHandleType sessionHandle,
                             uint8 CANCC,
                             TAL_BM_CANMessageIDType MessageID,
                             TAL_Boolean bIsExtended,
                             TAL_BM_CANOptionType Options,
                             uint8 QueueSize,
                             TAL_BM_RecvCANMessageCallbackFunctionPointerType pCallback);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
registerForRecvCanMsg(uint8 CANCC,
                      TAL_BM_CANMessageIDType MessageID,
                      bool bIsExtended,
                      uint8 QueueSize) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
registerForRecvCanMsg(uint8 CANCC,
                      TAL_BM_CANMessageIDType MessageID,
                      bool bIsExtended,
                      uint8 QueueSize,
                      TAL_BM_RecvCANMessageCallbackFunctionPointerType pCallback = TAL_CANCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated use TAL_BM_RegisterForRecvCANMsgFilterRange instead.
 * @brief Registers a CAN message filter
 *
 * This function registers a CAN message filter. For each registered CAN
 * message filter a filter queue is allocated to store the CAN message data.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @param Options       Reserved for further use. Pass TAL_BM_CAN_OPT_UNUSED as
 *                      argument.
 * @endif
 * @ifnot SWIG
 * @param pCallback     Function pointer of a notification callback of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType.
 *                      If a message is stored into this queue
 *                      this callback is executed. Use value 0 to
 *                      disable the callback. If the callback is disabled
 *                      the user is responsible for polling the queue in time.
 * @endif
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param FilterTable   Number of filter table used for this filter.
 * @param FilterValue   Filter value indicates which bits must be set in the
 *                      messageID. ( See notes )
 * @param FilterMask    Filter indicates which bits are optional in the messageID.
 *                      ( See notes )
 * @param QueueSize     Size of the queue in CAN messages.
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_CAN_OPT_UNUSED
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *
 * @retval TAL_SUCCESS The CAN message filter queue was registered
 *                     successfully.
 * @retval TAL_FAILED  An error occurred while registering the
 *                     CAN message filter queue.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to a error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handled the request.
 *       CAN messages which are not registered are stored inside the global
 *       queue (or are discarded if the global queue is disabled).
 * @code The filter rule is:
 *       (CANMsgID AND not(FilterMask)) == (FilterValue AND not(FilterMask))
 *
 *       Bit definitions of FilterValue and FilterMask:
 *       Bit Pos: 31 30 29 28 27 26 25 24 23 .......... 6  5  4  3  2  1  0
 *                |  |  |  |                                              |
 *                |  |  |  +-------- CAN message ID (11 or 29 bit) -------+
 *                |  |  +----- CAN message ID type: 0=STD  1=EXT
 *                +--+----- reserved do not use
 *
 *       Example: For a filter for standard IDs from 0x20 to 0x2F use
 *                FilterValue = 0x20
 *                FilterMask  = 0x0F
 *                For a filter for extended IDs from 0x10 to 0x1F use
 *                FilterValue = 0x20000010
 *                FilterMask  = 0x0000000F
 * @endcode
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 * \b Example
 * \snippet Testing/TAL_legacy_CAN/Send_Recv_Msg_NewAPI/src/host.cpp example_TAL_BM_RegisterForRecvCANMsgFilter
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_DEPRECATED TAL_ReturnType
TAL_BM_RegisterForRecvCANMsgFilter(TAL_SessionHandleType sessionHandle,
                                   uint8 CANCC,
                                   uint32 FilterTable,
                                   uint32 FilterValue,
                                   uint32 FilterMask,
                                   TAL_BM_CANOptionType Options,
                                   uint8 QueueSize,
                                   TAL_BM_RecvCANMessageCallbackFunctionPointerType pCallback);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
registerForRecvCanMsgFilter(uint8 CANCC,
                            uint32 FilterTable,
                            uint32 FilterValue,
                            uint32 FilterMask,
                            uint8 QueueSize) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
registerForRecvCanMsgFilter(uint8 CANCC,
                            uint32 FilterTable,
                            uint32 FilterValue,
                            uint32 FilterMask,
                            uint8 QueueSize,
                            TAL_BM_RecvCANMessageCallbackFunctionPointerType pCallback = TAL_CANCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */
/* @endcond */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_RegisterForRecvCANMsgFilterRange instead.
 * @endif
 * @endif
 *
 * @brief Registers a CAN message filter range
 *
 * This function registers a CAN message filter range. For each registered CAN
 * message filter a filter queue is allocated to store the CAN message data.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @param Options       Reserved for further use. Pass TAL_BM_CAN_OPT_UNUSED as
 *                      argument.
 * @endif
 * @ifnot SWIG
 * @param pCallback     Function pointer of a notification callback of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType.
 *                      If a message is stored into this queue
 *                      this callback is executed. Use value 0 to
 *                      disable the callback. If the callback is disabled
 *                      the user is responsible for polling the queue in time.
 * @endif
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param FilterTable   Number of filter table used for this filter.
 * @param MsgRangeStartID  CAN message ID (11 or 29 bit) the filter range starts.
 * @param MsgRangeEndID    CAN message ID (11 or 29 bit) the filter range ends.
 * @param bIsExtended   Defines if the filter range applies to standard (TAL_FALSE)
 *                      or extended (TAL_TRUE) CAN message IDs.
 * @param QueueSize     Size of the queue in CAN messages.
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_CAN_OPT_UNUSED
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *
 * @retval TAL_SUCCESS The CAN message filter range queue was registered
 *                     successfully.
 * @retval TAL_FAILED  An error occurred while registering the
 *                     CAN message filter range queue.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to a error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handled the request.
 *       CAN messages which are not registered are stored inside the global
 *       queue (or are discarded if the global queue is disabled).
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 * \b Example
 * \snippet Testing/TAL_legacy_CAN/Register_Unregister_RangeFilter_NewAPI/src/host.cpp example_TAL_BM_RegisterForRecvCANMsgFilterRange
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForRecvCANMsgFilterRange(TAL_SessionHandleType sessionHandle,
                                        uint8 CANCC,
                                        uint32 FilterTable,
                                        TAL_BM_CANMessageIDType MsgRangeStartID,
                                        TAL_BM_CANMessageIDType MsgRangeEndID,
                                        TAL_Boolean bIsExtended,
                                        TAL_BM_CANOptionType Options,
                                        uint8 QueueSize,
                                        TAL_BM_RecvCANMessageCallbackFunctionPointerType pCallback);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
registerForRecvCanMsgFilterRange(uint8 CANCC,
                                 uint32 FilterTable,
                                 TAL_BM_CANMessageIDType MsgRangeStartID,
                                 TAL_BM_CANMessageIDType MsgRangeEndID,
                                 bool bIsExtended,
                                 uint8 QueueSize) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
registerForRecvCanMsgFilterRange(uint8 CANCC,
                                 uint32 FilterTable,
                                 TAL_BM_CANMessageIDType MsgRangeStartID,
                                 TAL_BM_CANMessageIDType MsgRangeEndID,
                                 bool bIsExtended,
                                 uint8 QueueSize,
                                 TAL_BM_RecvCANMessageCallbackFunctionPointerType pCallback = TAL_CANCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_UnregisterCANMessageQueue instead.
 * @endif
 * @endif
 *
 * @brief Unregister and delete a CAN message queue
 *
 * This function unregisters and deletes a CAN message queue which was created
 * with one of the TAL_BM_RegisterFor* functions.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @endif
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param QueueID       The Queue ID addresses one specific queue in the
 *                      CAN message base.
 *                      The QueueID is used in two different contexts.
 *                      First: When used in context of a callback function of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *                      pass the QueueID (without any macros) to
 *                      TAL_BM_UnregisterCANMessageQueue
 *                      to delete this queue and discard all stored CAN messages
 *                      within this queue.
 *                      Second: When used without callback function
 *                      use the macros TAL_BM_CAN_QUEUE_ID or TAL_BM_CAN_FILTER_QUEUE_ID or
 *                      TAL_BM_CAN_GLOBAL_QUEUE_ID to unregister (and delete)
 *                      a specific queue.
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 * @sa TAL_BM_CAN_QUEUE_ID
 * @sa TAL_BM_CAN_FILTER_QUEUE_ID
 * @sa TAL_BM_CAN_GLOBAL_QUEUE_ID
 *
 * @retval TAL_SUCCESS The queue was unregistered (and deleted) successfully.
 * @retval TAL_FAILED  The queue addressed by QueueID does not exist.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to a error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *      The queue addressed by QueueID must exist.
 *
 * \b Example
 * \snippet Testing/TAL_legacy_CAN/Register_Unregister_RecvMsg_NewAPI/src/host.cpp example_TAL_BM_UnregisterCANMessageQueue
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_UnregisterCANMessageQueue(TAL_SessionHandleType sessionHandle,
                                 uint8 CANCC,
                                 TAL_BM_CANMessageIDType QueueID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
unregisterCanMessageQueue(uint8 CANCC,
                          TAL_BM_CANMessageIDType QueueID) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_FlushCANQueue instead.
 * @endif
 * @endif
 *
 * @brief Flushes a CAN message queue
 *
 * This function flushes a CAN message queue. All CAN messages in this queue
 * are discarded.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle Handle of the established session.
 * @param Options       Reserved for further use. Pass TAL_BM_CAN_OPT_UNUSED as
 *                      argument.
 * @endif
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param QueueID       The Queue ID addresses one specific queue in the
 *                      CAN message base.
 *                      The QueueID is used in two different contexts.
 *                      First: When used in context of a callback function of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *                      pass the QueueID (without any macros) to TAL_BM_FlushCANQueue
 *                      to discard all stored CAN messages in this queue.
 *                      Second: When used without callback function
 *                      use the macros TAL_BM_CAN_QUEUE_ID or TAL_BM_CAN_FILTER_QUEUE_ID or
 *                      TAL_BM_CAN_GLOBAL_QUEUE_ID to flush a specific queue.
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_CAN_OPT_UNUSED
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 * @sa TAL_BM_CAN_QUEUE_ID
 * @sa TAL_BM_CAN_FILTER_QUEUE_ID
 * @sa TAL_BM_CAN_GLOBAL_QUEUE_ID
 *
 * @retval TAL_SUCCESS The queue was flushed successfully
 * @retval TAL_FAILED  The queue addressed by QueueID does not exist
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *      The queue addressed by QueueID must exist.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_FlushCANQueue(TAL_SessionHandleType sessionHandle,
                     uint8 CANCC,
                     TAL_BM_CANOptionType Options,
                     TAL_BM_CANMessageIDType QueueID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
flushCanQueue(uint8 CANCC,
              TAL_BM_CANMessageIDType QueueID) const;
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Registers a single CAN Tx confirmation
 *
 * This function registers a single CAN Tx confirmation. For each registered
 * CAN Tx confirmation a hash queue is allocated to store the data.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle Handle of the established session.
 * @param Options       Reserved for further use. Pass TAL_BM_CAN_OPT_UNUSED as
 *                      argument.
 * @param pCallback     Function pointer of a notification callback of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType.
 *                      If a message is stored into this queue
 *                      this callback is executed. Use value 0 to
 *                      disable the callback. If the callback is disabled
 *                      the user is responsible for polling the queue in time.
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param MessageID     CAN message ID (11 or 29 bit) this hash queue is
 *                      registered for.
 * @param bIsExtended   TAL_FALSE for a standard, TAL_TRUE for an extended CAN message ID.
 * @param QueueSize     Size of the queue in CAN messages.
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_CAN_OPT_UNUSED
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 * @sa TAL_BM_CANConfigureEvents
 *
 * @retval TAL_SUCCESS The single CAN Tx confirmation queue was registered
 *                     successfully.
 * @retval TAL_FAILED  An error occurred while registering the single
 *                     CAN Tx confirmation queue.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to a error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handled the request.
 *       CAN Tx confirmations which are not registered are stored inside the global
 *       Rx/Tx queue if the flag TAL_BM_CAN_EVENT_TX is set with function
 *       TAL_BM_CANConfigureEvents.
 *       (or are discarded if the flag is not set or
 *       the global queue is disabled).
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 * \b Example
 * \snippet Testing/SIL/CANExample_Test/HostAppl/src/CANExampleTest.cpp example_TAL_BM_RegisterForCANTxConfirmation
 */
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForCANTxConfirmation(TAL_SessionHandleType sessionHandle,
                                    uint8 CANCC,
                                    TAL_BM_CANMessageIDType MessageID,
                                    TAL_Boolean bIsExtended,
                                    TAL_BM_CANOptionType Options,
                                    uint8 QueueSize,
                                    TAL_BM_RecvCANMessageCallbackFunctionPointerType pCallback);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Registers a CAN Tx confirmation filter range
 *
 * This function registers a CAN Tx confirmation filter range. For each registered CAN
 * Tx confirmation filter a filter queue is allocated to store the CAN message data.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle Handle of the established session.
 * @param Options       Reserved for further use. Pass TAL_BM_CAN_OPT_UNUSED as
 *                      argument.
 * @param pCallback     Function pointer of a notification callback of type
 *                      TAL_BM_RecvCANMessageCallbackFunctionPointerType.
 *                      If a message is stored into this queue
 *                      this callback is executed. Use value 0 to
 *                      disable the callback. If the callback is disabled
 *                      the user is responsible for polling the queue in time.
 * @param CANCC         Number of the CAN network (controller).
 *                      Valid values are 0 up to TAL_BM_MAX_NR_CAN_CTRL-1
 * @param FilterTable   Number of filter table used for this filter.
 * @param TxConfRangeStartID  CAN message ID (11 or 29 bit) the filter range starts.
 * @param TxConfRangeEndID    CAN message ID (11 or 29 bit) the filter range ends.
 * @param bIsExtended   Defines if the filter range applies to standard (TAL_FALSE)
 *                      or extended (TAL_TRUE) CAN message IDs.
 * @param QueueSize     Size of the queue in CAN messages.
 *
 * @sa TAL_BM_MAX_NR_CAN_CTRL
 * @sa TAL_BM_CAN_OPT_UNUSED
 * @sa TAL_BM_RecvCANMessageCallbackFunctionPointerType
 *
 * @retval TAL_SUCCESS The CAN Tx confirmation filter range queue was registered
 *                     successfully.
 * @retval TAL_FAILED  An error occurred while registering the
 *                     CAN Tx confirmation filter range queue.
 * @retval TAL_NO_SESSION       The function call failed, no valid session.
 * @retval TAL_ENCODING_ERROR   The function call failed due to an error when
 *                              encoding a package.
 * @retval TAL_COMM_ERROR       The function call failed due to a error in the
 *                              communication.
 * @retval TAL_INVALID_ARGUMENT At least one argument contains invalid values.
 *
 * @note The function returns before the target handled the request.
 *       CAN Tx confirmations which are not registered are stored inside the global
 *       Rx/Tx queue if the flag TAL_BM_CAN_EVENT_TX is set with function
 *       TAL_BM_CANConfigureEvents.
 *       (or are discarded if the flag is not set or
 *       the global queue is disabled).
 *
 * @pre A session has to be established before calling this function.
 *      TAL_BM_CANFDInit must be called before.
 *
 */
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForCANTxConfirmationFilterRange(TAL_SessionHandleType sessionHandle,
                                               uint8 CANCC,
                                               uint32 FilterTable,
                                               TAL_BM_CANMessageIDType TxConfRangeStartID,
                                               TAL_BM_CANMessageIDType TxConfRangeEndID,
                                               TAL_Boolean bIsExtended,
                                               TAL_BM_CANOptionType Options,
                                               uint8 QueueSize,
                                               TAL_BM_RecvCANMessageCallbackFunctionPointerType pCallback);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_GetCANQueueID instead.
 * @endif
 * @endif
 *
 * @brief Create a QueueID for a single CAN message hash queue.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param msg_id    A CAN message ID (11 or 29 bit)
 * @param bExtended Boolean to set the message to a standard (TAL_FALSE)
 *                  or extended (TAL_TRUE) CAN ID.
 *
 * @retval QueueID for the single CAN message hash queue.
 *
 * @note Use this function in the context of registering/unregistering
 *       a single CAN message hash queue
 *       or for sending a single CAN message
 *       or for receiving from a single CAN message hash queue
 *       in polling mode.
 *
 * @remark Use instead of deprecated macro CAN_GET_QUEUE_ID and CAN_GET_SEND_ID
 *
 * @remark Use instead of macro TAL_BM_CAN_QUEUE_ID if you prefer functions
 *
 * \b Example
 * \snippet Testing/TAL_Insp_API/CAN_HS_measurement/src/host.cpp example_TAL_BM_GetCANQueueID
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_BM_CANMessageIDType
TAL_BM_GetCANQueueID(TAL_BM_CANMessageIDType msg_id,
                     TAL_Boolean bExtended);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_BM_CANMessageIDType
getCanQueueId(TAL_BM_CANMessageIDType msg_id,
              bool bExtended) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_GetCANFilterQueueID instead.
 * @endif
 * @endif
 *
 * @brief Create a QueueID for a filter queue
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param FilterNum Number of filter table which should be used.
 *                  The number must be smaller than the maximum number
 *                  of filter tables defined during initialization.
 *
 * @retval QueueID for the selected filter queue
 *
 * @note Use this function only in the context of receiving from a CAN message
 *       filter queue in polling mode.
 *
 * @remark Use instead of deprecated macro CAN_GET_FILTER_QUEUE_ID
 *
 * @remark Use instead of macro TAL_BM_CAN_FILTER_QUEUE_ID if you prefer functions
 *
 * \b Example
 * \snippet Testing/TAL_Insp_API/CAN_HS_measurement/src/host.cpp example_TAL_BM_GetCANFilterQueueID
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_BM_CANMessageIDType
TAL_BM_GetCANFilterQueueID(TAL_BM_CANMessageIDType FilterNum);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_BM_CANMessageIDType
getCanFilterQueueId(TAL_BM_CANMessageIDType FilterNum) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_GetCANGlobalQueueID instead.
 * @endif
 * @endif
 * @brief Create a QueueID for a CAN message when reading from
 *        the global queue (if global queue is activated).
 *
 * @retval QueueID for reading from the global queue.
 *
 * @note Use this function only in the context of receiving from the CAN message
 *       global queue in polling mode.
 *
 * @remark Use instead of deprecated macro CAN_GET_GLOBAL_QUEUE_ID
 *
 * @remark Use instead of macro TAL_BM_CAN_GLOBAL_QUEUE_ID if you prefer functions
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_BM_CANMessageIDType
TAL_BM_GetCANGlobalQueueID(void);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_BM_CANMessageIDType
getCanGlobalQueueId() const;
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup ethernet Ethernet related functions
 * @{
 */


/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SendEthMsgTimed instead.
 * @endif
 * @endif
 *
 * @brief Schedules a timed Ethernet message for transmission.
 *
 * This function copies the given Ethernet message to the internal data
 * structures.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @param nEthCC        Ethernet controller index
 * @param nTimestamp    Timestamp when the given message should be transmitted
 * @if TAL_C_API
 * @param pBuffer       Pointer to data buffer
 * @param nBufferLength Length of the data (in bytes) in pBuffer
 * @else
 * @param pMsg pointer to object of type TalEthMsg
 * @endif
 *
 *
 * @retval TAL_SUCCESS  Transmit data was written to target successfully.
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 * @retval TAL_NOT_FINISHED    The transmit queue to the target is currently blocked and
 *                             the request should be re-tried after some time
 *
 * @note None.
 *
 * @invariant None.
 *
 * @post None.
 *
 * The timestamp format used is the format of the primary timestamp configured with
 * TAL_ConfigureTimebase.
 * If a given timestamp has already been passed or set to 0, the frame is sent
 * immediately.
 * Windows: For PCI connections, the queue size can be specified by setting
 * the registry key
 * HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\services\\EB5200\\Parameters\\membase_fast_tx_array_size
 * (size in MB, default: 4).
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SendEthMsgTimed(TAL_SessionHandleType sessionHandle,
                    uint8 nEthCC,
                    uint64 nTimestamp,
                    const uint8 * pBuffer,
                    uint16 nBufferLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
sendEthMsgTimed(uint8 nEthCC,
                uint64 nTimestamp,
                const TalEthMsg * pMsg) const;
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup digial_io Digital IO related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_ConfigureDigitalChannel instead.
 * @endif
 * @endif
 *
 * @brief Sets the digital pin direction and registers it for automatic
 *        sampling on the target side.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     Handle of the established session
 * @endif
 * @param digitalPinID      Index (starts with 0) of a digital pin
 * @param digitalDirection  Direction specification of the digital I/O pin
 *
 * @sa TAL_BM_RegisterForDigitalIn
 * @sa TAL_BM_DigitalIOPinIDType
 * @sa TAL_BM_DigitalIODirectionType
 *
 * @retval TAL_SUCCESS The function call executed successfully.
 * @retval TAL_FAILED  The function call failed to execute.
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established and the digital I/O have to be initialized
 *      with TAL_BM_RegisterForDigitalIn before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_ConfigureDigitalChannel(TAL_SessionHandleType sessionHandle,
                               TAL_BM_DigitalIOPinIDType digitalPinID,
                               TAL_BM_DigitalIODirectionType digitalDirection);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
configureDigitalChannel(TAL_BM_DigitalIOPinIDType digitalPinID,
                        TAL_BM_DigitalIODirectionType digitalDirection) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_GetDigitalInChannel instead.
 * @endif
 * @endif
 *
 * @brief This function returns the cached value of a digital input channel.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     Handle of the established session
 * @endif
 * @param digitalPinID      Index (starts with 0) of a digital pin.
 * @param digitalValue      Value of the digital input channel.
 *
 * @sa TAL_BM_RegisterForDigitalIn
 * @sa TAL_BM_DigitalIOPinIDType
 * @sa TAL_BM_DigitalIODirectionType
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute.
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 *
 * @pre A session has to be established and the digital I/O have to be initialized
 *      with TAL_BM_RegisterForDigitalIn before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_GetDigitalInChannel(TAL_SessionHandleType sessionHandle,
                           TAL_BM_DigitalIOPinIDType digitalPinID,
                           TAL_BM_DigitalValueType * digitalValue);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getDigitalInChannel(TAL_BM_DigitalIOPinIDType digitalPinID,
                    TalInt * digitalValue) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_PollDigitalInChannel instead.
 * @endif
 * @endif
 *
 * @brief Triggers the sampling of a dio channel.
 *
 * On Target side the corresponding physical pin is sampled and the respective
 * value is packed into a message. The value can be accessed via
 * TAL_BM_GetDigitalInChannel
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if TAL_SetSendThreshold is greater than 0
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     Handle of the established session
 * @endif
 * @param digitalPinID      Index (starts with 0) of a digital pin. If input pin value is
 *                          DIO_READ_ALL_IN_CHANNELS then the values of
 *                          all channels which were previously assigned as input
 *                          by TAL_BM_SetDigitalChannelDirection are requested.
 *
 * @sa TAL_SetSendThreshold
 * @sa TAL_BM_RegisterForDigitalIn
 * @sa TAL_BM_SetDigitalChannelDirection
 * @sa TAL_BM_DigitalIOPinIDType
 * @sa TAL_ProcessTargetData
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute.
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established and the digital I/O have to be initialized
 *      with TAL_BM_RegisterForDigitalIn before calling this function.
 *
 * @post TAL_ProcessTargetData have to be called to trigger the reception of the
 *       sampled digital input pins.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_PollDigitalInChannel(TAL_SessionHandleType sessionHandle,
                            TAL_BM_DigitalIOPinIDType digitalPinID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
pollDigitalInChannel(TAL_BM_DigitalIOPinIDType digitalPinID) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_SetDigitalOutChannel instead.
 * @endif
 * @endif
 *
 * @brief Set value of a digital output channel
 *
 * This function sets the value of a digital output channel on the target device.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if TAL_SetSendThreshold is greater than 0
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     Handle of the established session
 * @endif
 * @param digitalPinID      Index (start with 0) of a digital pin
 * @param digitalValue      New value of the digital pin
 *
 * @sa TAL_SetSendThreshold
 * @sa TAL_BM_RegisterForDigitalIn
 * @sa TAL_BM_DigitalIOPinIDType
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute.
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established and the digital I/O have to be initialized
 *      with TAL_BM_RegisterForDigitalIn before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_SetDigitalOutChannel(TAL_SessionHandleType sessionHandle,
                            TAL_BM_DigitalIOPinIDType digitalPinID,
                            TAL_BM_DigitalValueType digitalValue);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
setDigitalOutChannel(TAL_BM_DigitalIOPinIDType digitalPinID,
                     TAL_BM_DigitalValueType digitalValue) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_RegisterForDigitalIn instead.
 * @endif
 * @endif
 *
 * @brief Registration of dio value receptions.
 *
 * This function registers the automatic sampling and notification
 * of the digital input pins. When registered for automatic sampling
 * it is additionally necessary to configure each input-channel with
 * TAL_BM_ConfigureDigitalChannel. Then for each received value
 * the callback function is invoked and the value is cached.
 * This function also initializes internal data structures for digital
 * I/O usage.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle   Handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pRecvDioCallbackFunction Pointer to callback function of type
 *                   TAL_BM_RecvDioValuesCallbackFunctionPointerType.
 *                   If the value is 0 the callback is disabled.
 * @endif
 * @param dioSamplePeriod Period for automatic sampling in micro-seconds (min
 *                        is 100us)
 * @param dioSampleParam
 *                   TAL_DIO_SEND_EACH_SAMPLE: For periodic sampling and sending of
 *                   all configured input channels.
 *                   TAL_DIO_SEND_WHEN_NEW_VALUE: For periodic sampling and
 *                   sending of changed input channels.
 *                   TAL_DIO_NO_AUTOMATIC_SAMPLING: Disables automatic sampling.
 *                   Sampling and sending of input channels only on request
 *                   with TAL_BM_PollDigitalInChannel. Can be used to
 *                   unregister the automatic callback.
 *
 * @sa TAL_BM_DigitalIOSampleParameterType
 * @sa TAL_BM_ConfigureDigitalChannel
 * @sa TAL_BM_PollDigitalInChannel
 * @sa TAL_BM_RecvDioValuesCallbackFunctionPointerType
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute.
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks When using TAL_DIO_SEND_EACH_SAMPLE the value for every input pin is sent to
 *          the host at the given diosamplePeriod. Take into account that this produces
 *          quite a load on the target->host connection.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForDigitalIn(TAL_SessionHandleType sessionHandle,
                            uint32 dioSamplePeriod,
                            TAL_BM_DigitalIOSampleParameterType dioSampleParam,
                            TAL_BM_RecvDioValuesCallbackFunctionPointerType pRecvDioCallbackFunction);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
registerForDigitalIn(uint32 dioSamplePeriod,
                     TAL_BM_DigitalIOSampleParameterType dioSampleParam) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
registerForDigitalIn(uint32 dioSamplePeriod,
                     TAL_BM_DigitalIOSampleParameterType dioSampleParam,
                     TAL_BM_RecvDioValuesCallbackFunctionPointerType pRecvDioCallbackFunction = TAL_DIOCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup version_info Version and license info functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTALVersion instead.
 * @endif
 * @endif
 *
 * @brief get version information about the target access library
 *
 * This function delivers version information about the target access library.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param pMajorVersion pointer to the storage area of the version major number
 * @param pMinorVersion pointer to the storage area of the version minor number
 * @param pPatchVersion pointer to the storage area of the version patch number
 * @param pVariantName pointer to the storage area for the Variant Name String
 * @param variantNameLength maximum length of the variant name string
 *                          Recommended value: 33
 *                          If the length is less than 33, the string may be
 *                          truncated.
 * @param pDescription pointer to the storage area for the Description String
 * @param descriptionLength maximum length of the description string
 *                          Recommended value: 33
 *                          If the length is less than 33, the string may be
 *                          truncated.
 * @else
 * @param pVersion pointer to object of type TalVersion. All elements of the
 * object are updated during successful function call.
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NULL_POINTER The function call failed cause a null pointer
 *                          is supplied where it is not allowed
 *
 * @note No session has to be established before calling this function because
 * this function only reads out the version of the host library.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTALVersion(uint8 * pMajorVersion,
                  uint8 * pMinorVersion,
                  uint8 * pPatchVersion,
                  char * pVariantName,
                  uint8 variantNameLength,
                  char * pDescription,
                  uint8 descriptionLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getTalVersion(TalVersion * pVersion) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetHostDriverVersion instead.
 * @endif
 * @endif
 *
 * @brief get version information about the target access driver
 *
 * This function delivers version information about the driver sitting below
 * the bottom half of the target access library, if one is available.
 * Some supported bottom half communication backends on some operating systems
 * needs a kernel space driver for proper operation. An example where such a
 * separated driver is needed is the PCI kernel driver under Linux.
 * Ethernet backends usually do not need a special kernel driver. The PCI
 * LabView backend and the USB driver for windows does not need one either
 * because it only works in user space and therefore is directly integrated in
 * the BottomHalf.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @param pDriverVersionInfo pointer to a data area, where version information
 *                           about the target access driver shall be stored
 * @else
 * @param pVersion pointer to object of type TalVersion. All elements of the
 * object are updated during successful function call.
 * @endif
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NOT_SUPPORTED There is no kernel level driver available for the
 *                           queried session or the kernel driver has no
 *                           version information support. Currently only the
 *                           Linux PCI driver supports version information.
 * @retval TAL_NO_SESSION    session handle is invalid
 * @retval TAL_NULL_POINTER  The function call failed cause pDriverVersionInfo
 *                           is a null pointer
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetHostDriverVersion(TAL_SessionHandleType sessionHandle,
                         TAL_VersionInfoType * pDriverVersionInfo);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getHostDriverVersion(TalVersion * pVersion) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTargetHALVersion instead.
 * @endif
 * @endif
 *
 * @brief get version information about the host access library
 *
 * This function delivers version information about the host access library.
 *
 * @sa TAL_GetTargetHWInfo: Get info about exact board type /
 * base board hardware revision.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200 VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @param pMajorVersion      pointer to the storage area of the version major
 *                           number
 * @param pMinorVersion      pointer to the storage area of the version minor
 *                           number
 * @param pPatchVersion      pointer to the storage area of the version patch
 *                           number
 * @param pVariantName       pointer to the storage area for the Variant Name
 *                           String. See remarks.
 * @param variantNameLength  maximum length of the variant name string.
 *                           Recommended value: 33
 *                           If the length is less than 33, the string may be
 *                           truncated.
 * @param pDescription       pointer to the storage area for the Description
 *                           String
 * @param descriptionLength  maximum length of the description string
 *                           Recommended value: 33
 *                           If the length is less than 33, the string may be
 *                           truncated.
 * @else
 * @param pVersion pointer to object of type TalVersion. All elements of the
 * object are updated during successful function call.
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 *
 * @note A session has to be established before calling this function because
 * the HAL is located in the targets software stack.
 *
 * @remarks The variant name string contains information about the hardware platform,
 * e.g. `"EBx200"` for EB2200 / EB5200 targets and `"EB7200"` for EB7200 targets.
 * **Note:** The exact value of the variant string is not fixed and may change
 * with different firmware versions and hardware revisions.
 *
 * @remarks Special behaviour for EB7200: Use this function to read the FGPA ID.
 * The FPGA ID is stored in the description string.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetHALVersion(TAL_SessionHandleType sessionHandle,
                        uint8 * pMajorVersion,
                        uint8 * pMinorVersion,
                        uint8 * pPatchVersion,
                        char * pVariantName,
                        uint8 variantNameLength,
                        char * pDescription,
                        uint8 descriptionLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getTargetHalVersion(TalVersion * pVersion) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTargetRedbootVersion instead.
 * @endif
 * @endif
 *
 * @brief get version information about the target redboot
 *
 * This function delivers version information about the target redboot.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pRedbootMajorVersion pointer to the storage area of the version major
 *                             number
 * @param pRedbootMinorVersion pointer to the storage area of the version minor
 *                             number
 * @else
 * @param pVersion pointer to object of type TalVersion. At the moment Redboot
 * only has a major and minor version. All other elements of TalVersion are
 * irrelevant and predefined to a fixed default.
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 *
 * @note A session has to be established before calling this function
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetRedbootVersion(TAL_SessionHandleType sessionHandle,
                            uint16 * pRedbootMajorVersion,
                            uint16 * pRedbootMinorVersion);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getTargetRedbootVersion(TalVersion * pVersion) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTargetFPGAVersion instead.
 * @endif
 * @endif
 *
 * @brief get version information about the FPGA
 *
 * This function delivers version information about the programmed FPGA design
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pFPGAVersion pointer to the storage area for FPGA version
 * @param pFPGAGeneralImplementation pointer to the storage area of the
 *                                   general implementation versions number of
 *                                   the FPGA
 * @else
 * @param pVersion pointer to object of type TalVersion. At the moment FPGA
 * only has a major (FPGA version) and minor (EBx200: FPGA general
 * implementation, EB7200: SVN revision) version. All other elements of
 * TalVersion are irrelevant and predefined to a fixed default.
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NULL_POINTER The function call failed cause a null pointer
 *                          is supplied where it is not allowed
 *
 * @note A session has to be established before calling this function to
 * be able to query the FPGA version from the target.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetFPGAVersion(TAL_SessionHandleType sessionHandle,
                         uint16 * pFPGAVersion,
                         uint16 * pFPGAGeneralImplementation);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getTargetFpgaVersion(TalVersion * pVersion) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetFwLicenseInfoNext instead.
 * @endif
 * @endif
 *
 * @brief Get info about next firmware license
 *
 * On repeated calls to this function, you get information about all valid
 * firmware licenses on the connected target device.
 * Call 'TAL_GetFwLicenseInfoInit()' to reset the 'license pointer' and
 * get all licenses again.
 *
 * @sa TAL_GetFwLicenseInfoNext
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @param psLicenseName     out parameter where the caller gets the name
 *                          of the license feature as a zero-terminated string
 * @param pnLicenseNum      out parameter where the caller gets the number
 *                          of the license feature
 * @param pnValidityEndYear out parameter where the caller gets the year
 *                          of the end of the validity time of the license
 * @param pnValidityEndMonth out parameter where the caller gets the month
 *                          of the end of the validity time of the license
 * @else
 * @param pLicense pointer to object of type TalLicense
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_NO_DATA No more firmware licenses are available
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function to be
 * able to query license information from the target.
 *
 * @remarks none
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetFwLicenseInfoNext(TAL_SessionHandleType sessionHandle,
                         const char ** psLicenseName,
                         int * pnLicenseNum,
                         int * pnValidityEndYear,
                         int * pnValidityEndMonth);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getFwLicenseInfoNext(TalLicense * pLicense) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetFwLicenseInfoInit instead.
 * @endif
 * @endif
 *
 * @brief Reset internal firmware 'license pointer'
 *
 * Reset the internal firmware 'license pointer' in order that successive
 * calls to 'TAL_GetFwLicenseInfoNext()' start returning license information
 * from the beginning again.
 *
 * @sa TAL_GetFwLicenseInfoInit
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks none
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetFwLicenseInfoInit(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getFwLicenseInfoInit();
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_WriteLicenseFile instead.
 * @endif
 * @endif
 *
 * @brief Transfer license file to target device
 *
 * Transfer license file (either as plain .lic file or as .zip file
 * containing several license files for different target devices) to
 * a target device, replacing a potentially existing license file
 * on the target
 *
 * @li Domain: Host
 * @li Calling: blocking
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param sLicenseFileName  Valid path-name of license file
 * @param HousekeepingFunc  Shall be 'TAL_ProcessTargetData' or a function
 *                          with identical signature in single threaded
 *                          environments. 0 in multi threaded environments
 *                          (where TAL_ProcessTargetData is called within
 *                          a separate thread)
 *
 * @retval TAL_SUCCESS             The license was transferred successfully
 * @retval TAL_FAILED              An error occured
 * @retval TAL_INVALID_ARGUMENT    At least one parameter contains an invalid value
 * @retval TAL_FILE_NOT_FOUND      Unable to open provided filename
 * @retval TAL_FILE_ACCESS_FAILED  Unalbe to access provided filename
 * @retval TAL_NO_SESSION          Session handle is invalid
 * @retval TAL_INVALID_INDEX       The function call failed, index out of bounds
 * @retval TAL_ENCODING_ERROR      The function call failed due to an error when
 *                                 encoding a package
 * @retval TAL_COMM_ERROR          The function call failed due to an error in the
 *                                 communication
 * @retval TAL_OUT_OF_MEMORY       Failed to allocate memory
 * @retval TAL_NULL_POINTER        The function call failed cause a null pointer is
 *                                 supplied where it is not allowed
 * @retval TAL_INVALID_FILE_FORMAT Input file is not a valid license file
 * @retval TAL_LICENSE_NOT_FOUND   The zipped input file does not contain a license
 *                                 for the connected device
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks In contrast to .zip files, there is no check if a plain .lic file
 *          matches the connected device. If a .zip file is given, only the
 *          license files matching the connected device are concatenated and
 *          transferred to the target device.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_WriteLicenseFile(TAL_SessionHandleType sessionHandle,
                     const char * sLicenseFileName,
                     void (*HousekeepingFunc)(TAL_SessionHandleType,sint16));
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
writeLicenseFile(const char * sLicenseFileName,
                 void (*HousekeepingFunc)(TAL_SessionHandleType,sint16) = 0);
#endif /* TAL_CXX_API */



/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetPhysLayerModuleNext instead.
 * @endif
 * @endif
 *
 * @brief Get info about next firmware module
 *
 * On repeated calls to this function, you get information about all valid
 * firmware modules on the connected target device.
 * Call 'TAL_GetPhysLayerModuleInit()' to reset the 'module pointer' and
 * get all modules again.
 *
 * @sa TAL_GetPhysLayerModuleInit
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @param psModuleType     out parameter where the caller gets the name
 *                          of the Module type
 * @param pnSlotNum      out parameter where the caller gets the number
 *                          of the Slot
 * @param pnRevisionNum out parameter where the caller gets the revision
 *                          number
 * @param pnBoardIDNum out parameter where the caller gets the Serial
 *                          number
 * @else
 * @param pModule pointer to object of type TalModule
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_NO_DATA No more firmware modules are available
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function to be
 * able to query module information from the target.
 *
 * @remarks none
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetPhysLayerModuleNext(TAL_SessionHandleType sessionHandle,
                         TAL_ModuleType * psModuleType,
                         uint8 * pnSlotNum,
                         uint8 * pnRevisionNum,
                         uint64 * pnBoardIDNum);

#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getPhysLayerModuleNext(TalModule * pModule) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetPhysLayerModuleInit instead.
 * @endif
 * @endif
 *
 * @brief Reset internal firmware 'module pointer'
 *
 * Reset the internal firmware 'module pointer' in order that successive
 * calls to 'TAL_GetPhysLayerModuleNext()' start returning module information
 * from the beginning again.
 *
 * @sa TAL_GetPhysLayerModuleNext
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks none
 *
 * \b Example
 * \snippet SupportTools/tal_control_server/src/TCS_ClientCommand.cpp example_TAL_GetPhysLayerModuleInit
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetPhysLayerModuleInit(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getPhysLayerModuleInit();
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup target_time Target time related functions
 * @{
 */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Starting from 4.18 there is only one timebase EB_TIME_MASTER, so no need to configure
 *             a timebase.
 * @brief Configure timebase
 *
 * Configures the timebase used for measurement and timed transmission.
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param eTimebase          Timebase selected
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_SUCCESS       The function call failed, measurement is already running
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 *
 * @sa   TAL_TimebaseSelectType
 * @sa   TAL_InspConfigurePacketFormat()
 * @sa   TAL_InspStartMeasurement()
 * @sa   TAL_BM_CANFDInit()
 *
 * @remarks The function should be called before the packet format is changed with
 *          TAL_InspConfigurePacketFormat() and the measurement is started with
 *          TAL_InspStartMeasurement().
 *          On a revision B hardware, the function should be called before the configuration
 *          of the CAN-FD network with TAL_BM_CANFDInit().
 *
 * @pre  None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_DEPRECATED TAL_ReturnType
TAL_ConfigureTimebase(TAL_SessionHandleType sessionHandle,
                          TAL_TimebaseSelectType eTimebase);

TAL_API extern TAL_DEPRECATED TAL_ReturnType
TAL_InspConfigureTimebase(TAL_SessionHandleType sessionHandle,
                          TAL_InspTimebaseSelectType eTimebase);
#else  /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
configureTimebase(TAL_TimebaseSelectType eTimebase);

virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureTimebase(TAL_InspTimebaseSelectType eTimebase);
#endif /* TAL_CXX_API */
/* @endcond */
/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Starting from 4.18 there is only one timebase EB_TIME_MASTER, and also only one
 *             timestamp (no ATS2) so no need to configure a secondary timebase.
 * @brief Configure second (ATS2) timebase
 *
 * Configures the second timebase used for measurement and timed transmission.
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param eTimebase          Timebase selected
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_FAILED        The function call failed, measurement is already running
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 *
 * @sa   TAL_TimebaseSelectType
 * @sa   TAL_InspConfigurePacketFormat()
 * @sa   TAL_InspStartMeasurement()
 *
 * @remarks The function should be called before the packet format is changed with
 *          TAL_InspConfigurePacketFormat() and the measurement is started with
 *          TAL_InspStartMeasurement().
 *
 * @pre  None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_DEPRECATED TAL_ReturnType
TAL_ConfigureTimebaseATS2(TAL_SessionHandleType sessionHandle,
                          TAL_TimebaseSelectType eTimebase);

#else  /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
configureTimebaseATS2(TAL_TimebaseSelectType eTimebase);
#endif /* TAL_CXX_API */
/* @endcond */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Use TAL_GetEBTimeState() instead!
 *
 * @brief Return the current state of the GPS receiver
 *
 * This function reads the state of the GPS receiver and sets pRcvrState.
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle         handle of the established session
 * @endif
 * @param pRcvrState            pointer to receiver state storage.
 *                              see TAL_Types.h for values
 *
 * @retval TAL_SUCCESS          pRcvrStatus was updated with current status.
 * @retval TAL_NO_SESSION       The function call failed, no valid session
 * @retval TAL_NULL_POINTER     receiverStatus must not be 0
 *
 * @sa   TAL_GPSReceiverStateType
 *
 * @pre  None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_DEPRECATED TAL_ReturnType
TAL_GetGpsState(
    TAL_SessionHandleType sessionHandle,
    TAL_GPSReceiverStateType *pRcvrState);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getGpsState(
    TalUInt *pRcvrState) const;
#endif /* TAL_CXX_API */
/* @endcond */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Use @if TAL_C_API TAL_GetEBTimeState()) @else getEBTimeState() instead!
 * @brief Get current target time
 *
 * This function reports the current target time in the format configured on
 * the target.
 * The target sends its time to the host every second. When the host
 * receives the (target time) packet it captures a utc timestamp. When this
 * API is called another utc timestamp is captured, the difference to the utc
 * timestamp at which the target time was received is calculated and this
 * difference is added to the last received target time. The result is an
 * interpolated target time which is returned.
 * There is also a protection to avoid decreasing of time in case the utc time
 * on the host increases faster than the target.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param nTimestamp 64bit target time stamp
 * @param nTimestampType type of the configured time stamp nTimestamp
 * @param nMicroPerMacro how many micro-ticks are in one macro-tick
 * @param nMacroPerCycle how many macro-ticks are in one FlexRay communication cycle
 * @param nCyclePerSupercycle how many FlexRay communication cycles are in one super cycle
 * @else
 * @param pTime pointer to object of type TalTargetTime
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_NO_DATA No more firmware licenses are available
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function to be
 * able to query license information from the target.
 *
 * @note The host receives the target time packet within the
 * TAL_ProcessTargetData() function. Thus the timestamp precision is dependant
 * on the calling period of the TAL_ProcessTargetData() function.
 *
 * @remarks none
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_DEPRECATED TAL_ReturnType
TAL_GetTargetTime(TAL_SessionHandleType sessionHandle,
                  uint64 * nTimestamp,
                  TAL_TimebaseSelectType * nTimestampType,
                  uint8 * nMicroPerMacro,
                  uint16 * nMacroPerCycle,
                  uint8 * nCyclePerSupercycle);
#else
virtual TAL_DEPRECATED TAL_ReturnType
getTargetTime(TalTargetTime * pTime) const;
#endif /* TAL_CXX_API */
/* @endcond */
/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetEBTimeState instead.
 * @endif
 * @endif
 *
 * @brief Get current time state from the target.
 *
 * EB2200, EB5200: The time state information is transmitted to the host periodically
 * and if any value except the nanoseconds count within the timeState type changes.
 * The host captures a reference timestamp when it receives TimeState information from the target
 * and interpolates the reported nano seconds count (ns_cnt) to the time when the function is called.
 *
 * EB7200, EB8200: Current HW timestamp is read out of the device register and is provided per
 * nanoseconds count when the function is called. All other members of the TAL_TimeStateType are not used.
 *
 * VirtualBus: Current HW timestamp is read out from Virtual Time Source and is provided per
 * nanoseconds count when the function is called.

 * @li Domain: Host/Target
 * @li Calling: nonblocking
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pTimeState Pointer to TAL_TimeStateType where time state information is written to
 * @else
 * @param pTimeState Pointer to TAL_TimeStateType
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_NULL_POINTER The function call failed because a null pointer
 *                          was detected
 * @retval TAL_NO_SESSION The function call failed, no valid session
 * @retval TAL_NO_DATA The function call failed, because no valid time state was received from the
 *                     target yet
 * @retval TAL_FAILED  Error occurred during function call
 *
 * @pre A session has to be established before calling this function
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetEBTimeState(TAL_SessionHandleType sessionHandle,
                  TAL_TimeStateType * pTimeState);
#else
virtual TAL_DEPRECATED TAL_ReturnType
getEBTimeState(TAL_TimeStateType * pTimeState) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SetEBTimeOffset instead.
 * @endif
 * @endif
 *
 * @brief Sets the offset between (zero based) EBtime and TAI as well as the number of leap seconds
 *
 * Calling this function transmits the given parameters to the target. On the target the information
 * is initially only stored into a register but not applied immediatly. There is a polling task
 * which checks for updates and actually applying the new values. It may take several ms until the
 * new values are applied on the target (and returned by TAL_GetEBTimeState/getEBTimeState).
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param offset_ns New political time offset in nano seconds. If the specified value is
 *                  TAL_NS_OFF_UNKNOWN it is ignored
 * @param leap_sec  Number of TAI leap seconds in seconds (maximum supported value is 63).
 *                  If the specified value is TAL_LEAP_SEC_CNT_UNKNOWN it is ignored.
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SetEBTimeOffset(TAL_SessionHandleType sessionHandle,
                    sint64 offset_ns,
                    uint16 leap_sec);
#else
virtual TAL_DEPRECATED TAL_ReturnType
setEBTimeOffset(sint64 offset_ns, uint16 leap_sec) const;
#endif /* TAL_CXX_API */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Starting from 4.18 the target doesn't support the macrotick timebase.
 *
 * @brief Add microticks (25ns) to macrotick timestamp
 *
 *
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param nMtTime 64bit time in macrotick-format
 * @param nTicksToAdd number of microticks to add to nMtTime
 * @else
 * @param nMtTime 64bit time in macrotick-format
 * @param nTicksToAdd number of microticks to add to nMtTime
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  No macrotick parameters available
 * @retval TAL_NULL_POINTER nMtTime is NULL
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_DEPRECATED TAL_ReturnType
TAL_MacrotickTsAdd(TAL_SessionHandleType sessionHandle,
                   uint64 * nMtTime,
                   sint64   nTicksToAdd);
#else
#ifndef SWIG /* uint64* problematic in swig wrapper */
virtual TAL_DEPRECATED TAL_ReturnType
macrotickTsAdd(uint64 *nMtTime, sint64 nTicksToAdd) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */
/* @endcond */
/**
 * @}
 */

/**
 * @defgroup target_user_module Target User Module related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TUM_RegisterForRecvUserDataNotification instead.
 * @endif
 * @endif
 *
 * @brief Register for automatic reception of user data from a TUM
 *
 * This function registers the automatic reception of user data and the
 * notification upon receiving the data from the target user module.
 *
 * @sa TAL_TUM_UnregisterForRecvUserDataNotification
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pRecvUserDataCallbackFnct
 *                      pointer to callback function, called after the
 *                      reception of the user data. This argument is optional:
 *                      Supply a NULL pointer if do not want to a callback
 *                      function to be called upon reception of a
 *                      UserData package from the target.
 * @endif
 * @param nTUM_ID       unique identifier for the target user module
 * @param nTUM_InstanceID unique identifier for the instance of a target
 *                      user module
 * @param nFifoByteDepth Depth of the storage fifo for the received TUM
 * data packets in bytes. The FIFO must be big enough to buffer the received
 * data packets internally between the TAL_ProcessTargetData() and the
 * TAL_TUM_ReceiveUserData() API call. If zero the default value (100kB) will
 * be used.
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_ALREADY_REGISTERED The function called failed because the TUM
 *                                instance is already registered
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TUM_RegisterForRecvUserDataNotification(TAL_SessionHandleType sessionHandle,
                                            TAL_TUM_IDType nTUM_ID,
                                            TAL_TUM_InstanceIDType nTUM_InstanceID,
                                            uint32 nFifoByteDepth,
                                            TAL_TUM_RecvUserDataCallbackFunctionPointerType pRecvUserDataCallbackFnct);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
registerForRecvUserDataNotification(TAL_TUM_IDType nTUM_ID,
                                    TAL_TUM_InstanceIDType nTUM_InstanceID,
                                    uint32 nFifoByteDepth) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
registerForRecvUserDataNotification(TAL_TUM_IDType nTUM_ID,
                                    TAL_TUM_InstanceIDType nTUM_InstanceID,
                                    uint32 nFifoByteDepth,
                                    TAL_TUM_RecvUserDataCallbackFunctionPointerType pRecvUserDataCallbackFnct = TAL_TUMCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TUM_UnregisterForRecvUserData instead.
 * @endif
 * @endif
 *
 * @brief Unregister for automatic reception of user data from a TUM
 *
 * This function unregisters the automatic reception of user data and the
 * notification upon receiving the data from the target user module.
 *
 * @sa TAL_TUM_UnregisterForRecvUserData
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param nTUM_ID       unique identifier for the target user module
 * @param nTUM_InstanceID unique identifier for the instance of a target
 *                      user module
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TUM_UnregisterForRecvUserData(TAL_SessionHandleType sessionHandle,
                                  TAL_TUM_IDType nTUM_ID,
                                  TAL_TUM_InstanceIDType nTUM_InstanceID);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
unregisterForRecvUserData(TAL_TUM_IDType nTUM_ID,
                          TAL_TUM_InstanceIDType nTUM_InstanceID) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TUM_SendUserData instead.
 * @endif
 * @endif
 *
 * @brief Send user data to an instance of a target user module
 *
 * This function sends user data to one or all instances of a target
 * user module.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa TAL_SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param nTUM_ID       unique identifier for the target user module
 * @param nTUM_InstanceID unique identifier for the instance of a target
 *                      user module
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pUserData     pointer to the provided user data
 * @param nUserDataLength size in number of bytes of the provided user data (0 .. 1014)
 * @else
 * @param pUserData pointer to user data object
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_INVALID_INDEX   The function call failed, index out of bounds
 *                             or unknown signal index
 *
 * @note An error message is provided in case of TUM is not available.
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *
 * \b Example
 * \snippet Testing/MAid/TcpIpClient/test.cpp example_TAL_TUM_SendUserData
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TUM_SendUserData(TAL_SessionHandleType sessionHandle,
                     TAL_TUM_IDType nTUM_ID,
                     TAL_TUM_InstanceIDType nTUM_InstanceID,
                     const uint8 * pUserData,
                     uint16 nUserDataLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
sendUserData(TAL_TUM_IDType nTUM_ID,
             TAL_TUM_InstanceIDType nTUM_InstanceID,
             const TalUserData * pUserData) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TUM_ReceiveUserData instead.
 * @endif
 * @endif
 *
 * @brief Receives user data from a target user module
 *
 * This function receives the next TUM user data buffer from the target in
 * the order it was received from the target (FIFO).
 * If the provided buffer is too small TAL_BUFFER_TOO_SMALL is returned and no
 * data is copied. If no user data was received TAL_NO_DATA is returned.
 *
 * @sa TAL_TUM_RegisterForRecvUserData
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param nTUM_ID       identifier for the TUM of the wanted UserData
 * @param nTUM_InstanceID identifier for the TUM instance of the wanted
 *                      UserData, only used if UserData was registered for a
 *                      specific TUM instance.
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pUserData     pointer to a memory area where the received user data
 *                      is written to. The user supplies a buffer pUserData of
 *                      size nUserDataLength.
 * @param nUserDataLength size in number of bytes of the data buffer pUserData.
 *                        The function then writes at most nUserDataLength
 *                        bytes of data (to avoid overwriting memory) into the
 *                        buffer pUserData.
 * @param pRealLength   pointer to memory where the real size of the received
 *                      user data is written to. The real length of the data
 *                      written into pUserData is written to pRealLength.
 * @else
 * @param pUserData pointer to user data object
 * @endif
 *
 * @retval TAL_SUCCESS  The function call executed successfully
 * @retval TAL_OVERFLOW The function call executed successfully, but
 *                      previously data was lost due to a queue overflow
 * @retval TAL_NO_DATA  There is no data for the nTUM_ID / nTUM_InstanceID pair
 * @retval TAL_INVALID_INDEX    The nTUM_ID / nTUM_InstanceID pair is not registered
 * @retval TAL_NO_SESSION       The function call failed, no valid session
 * @retval TAL_BUFFER_TOO_SMALL The function call failed, a provided buffer was
 *                              too small
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed
 * @retval TAL_FAILED           Other failure
 *
 * @pre A session has to be established before calling this function.
 *
 * @note This function can be used in programming environments which does not
 * support callback functions instead of supplying a pointer to a callback
 * function during TAL_TUM_RegisterForRecvUserData.
 *
 * @note The maximum size of a received block of user data is 1014 bytes
 *
 * @remarks The reception must be registered in advance at the target by
 * calling the function TAL_TUM_RegisterForRecvUserData.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TUM_ReceiveUserData(TAL_SessionHandleType sessionHandle,
                        TAL_TUM_IDType nTUM_ID,
                        TAL_TUM_InstanceIDType nTUM_InstanceID,
                        uint8 * pUserData,
                        uint16 nUserDataLength,
                        uint16 * pRealLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
receiveUserData(TAL_TUM_IDType nTUM_ID,
                TAL_TUM_InstanceIDType nTUM_InstanceID,
                TalUserData * pUserData) const;
#endif /* TAL_CXX_API */

#ifdef TAL_CXX_API
/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TUM_ReceiveUserData instead.
 * @endif
 * @endif
 *
 * @brief Receives large user data from a target user module
 *
 * This function is suited for large data packets (>1024 bytes payload).
 * This function receives the next TUM user data buffer from the target in
 * the order it was received from the target (FIFO), appends it to the large
 * data packet, and checks if the data packet is complete.
 * Therefore it must be called more than once (depending on payload size) until
 * TAL_SUCCESS is returned.
 * The buffer provided with the 'pUserData' argument is not available to the
 * calling application until 'TAL_SUCCESS' is returned.
 *
 * If the provided buffer is too small TAL_BUFFER_TOO_SMALL is returned and no
 * data is copied. If no user data was received TAL_NO_DATA is returned.
 *
 * @sa TAL_TUM_RegisterForRecvUserData
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param nTUM_ID       identifier for the TUM of the wanted UserData
 * @param nTUM_InstanceID identifier for the TUM instance of the wanted
 *                      UserData, only used if UserData was registered for a
 *                      specific TUM instance.
 * @param pUserData pointer to large user data object
 *
 * @retval TAL_SUCCESS A whole large data packet was received and is accessible
 *                     to the caller via the methods of the TalUserDataLarge
 *                     object pUserData.
 * @retval TAL_NOT_FINISHED A chunk with matching multiplexer value was
 *                          received, but the data packet was not yet
 *                          transmitted completely
 * @retval TAL_DONT_MATCH The multiplexer value of the received chunk does
 *                        not match
 * @retval TAL_BUFFER_TOO_SMALL The provided buffer is too small for the
 *                              received data packet
 * @retval TAL_OUT_OF_SEQUENCE The received packet was ignored because it is
 *                             out of sequence
 * @retval TAL_NO_DATA  There is no data for the nTUM_ID / nTUM_InstanceID pair
 * @retval TAL_INVALID_INDEX   The nTUM_ID / nTUM_InstanceID pair is not registered
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_FAILED   Other failure
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks The reception must be registered in advance at the target by
 * calling the function TAL_TUM_RegisterForRecvUserData.
 *
 */
virtual TAL_DEPRECATED TAL_ReturnType
receiveUserData(TAL_TUM_IDType nTUM_ID,
                TAL_TUM_InstanceIDType nTUM_InstanceID,
                TalUserDataLarge * pUserData) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TUM_SendDataPacket instead.
 * @endif
 * @endif
 *
 * @brief Send a (possibly large) data packet on a data channel
 *
 * This function sends a data packet via a data channel to the target. If
 * necessary, the function splits the packet into chunks and sends these
 * chunks as independent packets. One call to this function suffices to send
 * even large packets - segmentation into smaller chunks happens automatically
 * inside this function.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param nTUM_ID       unique identifier for the target user module
 * @param nTUM_InstanceID unique identifier for the instance of a target
 *                      user module
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pUserData     pointer to the provided user data
 * @param nUserDataLength size in number of bytes of the provided user data.
 *                        max size supported is 2^23 - 1 bytes.
 * @param nMaxChunkDataSize Maximum size of a single chunk (excluding chunk
 *                      header). The maximum supported size is 1010 currently.
 *                      If set to 0 or a value larger than the maximum
 *                      supported size, it is set to the maximum supported size
 * @param nMuxVal       This value is written into the first byte of each
 *                      data chunk transmitted to the target. It may be used
 *                      either to distinguish between several DataPacket
 *                      connections which are open concurrently or to
 *                      intermix 'normal' data transmission (via
 *                      'TAL_TUM_SendUserData()') with chunked data
 *                      transmission
 * @else
 * @param pUserData pointer to the large user data object
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_INVALID_INDEX   The function call failed, index out of bounds
 *                             or unknown signal index
 *
 * @note An error message is provided in case of TUM is not available.
 * @note The function returns before the target handled the request.
 *
 * @pre A session has to be established before calling this function.
 *
 * \b Example
 * \snippet Testing/SIL/TpTestDaimler/src/ECUA.cpp example_TAL_TUM_SendDataPacket
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TUM_SendDataPacket(TAL_SessionHandleType sessionHandle,
                       TAL_TUM_IDType nTUM_ID,
                       TAL_TUM_InstanceIDType nTUM_InstanceID,
                       const uint8 * pUserData,
                       uint32 nUserDataLength,
                       uint16 nMaxChunkDataSize,
                       uint8 nMuxVal);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
sendUserData(TAL_TUM_IDType nTUM_ID,
             TAL_TUM_InstanceIDType nTUM_InstanceID,
             const TalUserDataLarge * pUserData) const;
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief Initialize reception of a (possibly large) data packet
 * on a data channel
 *
 * This function prepares the system for the reception of a possible
 * large data packet. It gets a buffer from the user and creates a
 * handle which is used within subsequent calls to
 * 'TAL_TUM_CheckRecvDataPacket()' until the complete packet was received.
 *
 * The buffer provided with the 'pBuffer' argument is not available to the
 * calling application until 'TAL_SUCCESS' is returned by
 * 'TAL_TUM_CheckRecvDataPacket()'.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param pBuffer         pointer to the buffer which is used for storing the
 *                        received data
 * @param nBufferSize     size of buffer
 * @param pHandle         A pointer to a 'TAL_TUM_RxDataPacketHandle'
 *                        structure which must be provided by the calling
 *                        application. The same pointer has to be given to
 *                        succeeding calls to 'TAL_TUM_CheckRecvDataPacket()'.
 *                        It may be possible to have several 'RecvDataPacket'
 *                        connections open in parallel when using different
 *                        Mux-Values and different handles.
 * @param nMuxVal         This value is contained within the first byte of
 *                        each received data chunk. It may be used
 *                        either to distinguish between several DataPacket
 *                        connections which are open concurrently or to
 *                        intermix 'normal' data transmission with chunked data
 *                        transmission.
 *
 * @retval TAL_SUCCESS The handle was created successfully
 * @retval TAL_FAILED  The function call failed to execute
 *
 * \b Example
 * \snippet Testing/SIL/TpTestDaimler/src/TpTestHost.cpp example_TAL_TUM_PrepareRecvDataPacket
 */
TAL_API extern TAL_ReturnType
TAL_TUM_PrepareRecvDataPacket(uint8 * pBuffer,
                              uint32 nBufferSize,
                              TAL_TUM_RxDataPacketHandle * pHandle,
                              uint8 nMuxVal);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief This function returns a reference to a valid RxDataPacketHandle
 *
 * Usage of this function is optional, you may also define the
 * RxDataPacketHandle by yourself. Especially when using languages not
 * allowing definition of structures, you shall use this function.
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param ppHandle The RxDataPacketHandle to return
 *
 * @retval TAL_SUCCESS The handle was returned successfully
 * @retval TAL_FAILED  There was an error when trying to return a handle
 */
TAL_API extern TAL_ReturnType
TAL_TUM_GetRxDataPacketHandle(TAL_TUM_RxDataPacketHandle ** ppHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief This function returns a reference to a valid RxDataPacketHandle
 *
 * Usage of this function is optional, you may also define the
 * RxDataPacketHandle by yourself. Especially when using languages not
 * allowing definition of structures, you shall use this function.
 *
 * @param pHandle The RxDataPacketHandle to free
 */
TAL_API extern void
TAL_TUM_FreeRxDataPacketHandle(TAL_TUM_RxDataPacketHandle * pHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief Check if a received chunk of data is part of a data packet
 * transmission
 *
 * This function checks, if the handed over chunk of data is part of a
 * data packet. If so, the contents is stored and, if the data packet
 * is complete, it is handed over to the caller.
 *
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param pData           chunk of user data received by a '...RecvUserData'
 *                        function
 * @param nDataLength     size of data chunk
 * @param pHandle         A pointer to the 'TAL_TUM_RxDataPacketHandle'
 *                        structure which was created by
 *                        'TAL_TUM_PrepareRecvDataPacket()'.
 *                        pHandle->pBuffer points to the received data
 *                        packet upon complete reception of a data packet.
 *                        pHandle->nDataLength contains the size of the received
 *                        data packet in units of bytes.
 *
 * @retval TAL_SUCCESS A whole data packet was received and is accessible to
 *                     the caller via pHandle->pBuffer and pHandle->nDataLength
 *                     or via the functions 'TAL_TUM_GetDataPacketPtr()' and
 *                     'TAL_TUM_GetDataPacketSize()'.
 *                     The buffer may be reused within subsequent calls to
 *                     'TAL_TUM_CheckRecvDataPacket()' unless you issue a
 *                     'TAL_TUM_PrepareRecvDataPacket()' call providing another
 *                     buffer
 * @retval TAL_NOT_FINISHED A chunk with matching multiplexer value was
 *                          received, but the data packet was not yet
 *                          transmitted completely
 * @retval TAL_DONT_MATCH The multiplexer value of the received chunk does
 *                        not match
 * @retval TAL_BUFFER_TOO_SMALL The provided buffer is too small for the
 *                             received data packet
 * @retval TAL_OUT_OF_SEQUENCE The received packet was ignored because it is
 *                             out of sequence
 * @retval TAL_FAILED  The function call failed to execute
 */
TAL_API extern TAL_ReturnType
TAL_TUM_CheckRecvDataPacket(const uint8 * pData,
                            uint16 nDataLength,
                            TAL_TUM_RxDataPacketHandle * pHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief Get size of received data packet
 *
 * @param pHandle Handle of received data packet
 *
 * @retval Size of received data packet
 */
TAL_API extern uint32
TAL_TUM_GetDataPacketSize(const TAL_TUM_RxDataPacketHandle * pHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief Get pointer to received data packet
 *
 * @param pHandle Handle of received data packet
 *
 * @retval Pointer to payload of received data packet
 */
TAL_API extern uint8 *
TAL_TUM_GetDataPacketPtr(const TAL_TUM_RxDataPacketHandle * pHandle);
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup error Error handling functions
 * @{
 */

#ifndef TAL_CXX_API
/**
 * @brief Get the first occurred error in human readable form
 *
 * This function dequeues the next error data from the error queue and returns
 * a string describing the occurred error and its optional arguments in human
 * readable form.
 * If no error is in the queue this function returns TAL_SUCCESS and
 * pIsErrorPresent is set to TAL_FALSE.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @param sessionHandle      handle of the established session
 * @param pErrorString       Pointer to a character array of size
 *                           nErrorStringMax where the error string should
 *                           be stored.
 *                           The message starts with (II) for informational
 *                           messages, (WW) for warning messages and (EE)
 *                           for error messages. If the message is not
 *                           prefixed its also an error message.
 * @param nErrorStringMax    number of characters of the pErrorString array.
 * @param pIsErrorPresent    pointer to store the information if a error was
 *                           present. TAL_TRUE if an error was dequeued.
 *                           TAL_FALSE if no error was in the error queue.
 *
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_BUFFER_TOO_SMALL The function call failed, a provided buffer was
 *                              too small
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed
 * @retval TAL_NO_SESSION       The function call failed, no valid session
 */
TAL_API extern TAL_ReturnType
TAL_GetErrorString(TAL_SessionHandleType sessionHandle,
                   char * pErrorString,
                   uint16 nErrorStringMax,
                   TAL_Boolean * pIsErrorPresent);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetErrorData instead.
 * @endif
 * @endif
 *
 * @brief Get the the error data for the first occured error
 *
 * This function dequeues the next error data from the error queue and returns
 * the data in the same form it was received from the target. The user must
 * interpret the data returned or call the function
 * TAL_ConvertErrorDataToString() to additionally get human readable output.
 * Normally the function TAL_GetErrorString() should be used instead, because it
 * directly returns the error data in human readable form.
 * If no error is in the queue this function returns TAL_SUCCESS and
 * pIsErrorPresent is set to TAL_FALSE.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @param pErrorNumber       pointer to a data structure where a number
 *                           describing the error should be stored.
 * @param pErrorDataElement  pointer to a data structure where the number of
 *                           additional error arguments received should be
 *                           stored. If the corresponding error does not have
 *                           additional arguments then 0 is returned.
 * @param pErrorData         pointer to an uint32 array where additional error
 *                           arguments should be stored.
 * @param nErrorDataMax      size of the uint32 array the pErrorData argument
 *                           points to (in multiples of uint32 elements).
 *                           Not more than nErrorDataMax error data arguments
 *                           are written to the pErrorData array. If output
 *                           is truncated TAL_FAILED is returned.
 * @param pIsErrorPresent    pointer to store the information if a error was
 *                           present. TAL_TRUE if an error was dequeued.
 *                           TAL_FALSE if no error was in the error queue.
 * @else
 * @param pError pointer to error data object
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_BUFFER_TOO_SMALL The function call failed, a provided buffer was
 *                              too small
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed
 * @retval TAL_NO_SESSION       The function call failed, no valid session
 * @ifnot TAL_C_API
 * @retval TAL_NO_DATA          No data available
 * @endif
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetErrorData(TAL_SessionHandleType sessionHandle,
                 TAL_ErrnoType * pErrorNumber,
                 uint8 * pErrorDataElement,
                 uint32 * pErrorData,
                 uint8 nErrorDataMax,
                 TAL_Boolean * pIsErrorPresent);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getError(TalError * pError) const;
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief Convert error data to a error string
 *
 * This function gets an error number and its corresponding error arguments
 * and returns a string describing the error number and its arguments.
 * This function should be used, if both the human readable error string and
 * the error data is of interrest for the calling program. Then it can be used
 * in conjunction with the function TAL_GetErrorData().
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param nErrorNumber       number decribing the error
 * @param pErrorData         optional pointer to an uint32 array describing
 *                           the error in detail. If not used its value is 0.
 * @param nErrorDataElement  optional number of elements of the pErrorData
 *                           array. If not used its value is 0.
 * @param pErrorString       Pointer to a character array of size
 *                           nErrorStringMax where the error string should
 *                           be stored.
 *                           The message starts with (II) for informational
 *                           messages, (WW) for warning messages and (EE)
 *                           for error messages. If the message is not
 *                           prefixed its also an error message.
 * @param nErrorStringMax    number of characters of the pErrorString array.
 *                           Not more characters (including the trailing \\0)
 *                           than nErrorStringMax are written to the
 *                           pErrorString array. If output is truncated
 *                           TAL_FAILED is returned.
 *
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute (e.g. output of
 *                     error string truncated because supplied buffer is too
 *                     short).
 * @retval TAL_BUFFER_TOO_SMALL The function call failed, a provided buffer was
 *                              too small
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 */
TAL_API extern TAL_ReturnType
TAL_ConvertErrorDataToString(TAL_ErrnoType nErrorNumber,
                             const uint32 * pErrorData,
                             uint8 nErrorDataElement,
                             char * pErrorString,
                             uint16 nErrorStringMax);
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup target_performance CPU load and memory info related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_RegisterForTargetCPULoad instead.
 * @endif
 * @endif
 *
 * @brief Get CPU load of the target device
 *
 * This function enables the user to continiously be informed about the CPU
 * load on the target device
 *
 * @sa TAL_GetTargetCPULoad
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pCallbackFunction pointer to callback function, called at the end of
 *                          reading the CPU utilisation from the target.
 *                          If the callback is NULL, the data will still be
 *                          stored within the TAL and can be read via
 *                          TAL_GetTargetCPULoad
 * @endif
 * @param nUpdateCycle      time between the updates of the CPU load value
 *                          in multiples of 0.1s, setting this value to 0
 *                          disables the update process, and unregisteres the
 *                          callback
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package for the target
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks none
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_RegisterForTargetCPULoad(TAL_SessionHandleType sessionHandle,
                             uint16 nUpdateCycle,
                             TAL_CPULoadFunctionPointerType pCallbackFunction);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
registerForTargetCpuLoad(uint16 nUpdateCycle) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
registerForTargetCpuLoad(uint16 nUpdateCycle,
                         TAL_CPULoadFunctionPointerType pCallbackFunction = TAL_CPUCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTargetCPULoad instead.
 * @endif
 * @endif
 *
 * @brief Get CPU load of the target device
 *
 * This function enables the user to read the results of the measurement of
 * CPU load on the target initiated by calling TAL_RegisterForTargetCPULoad.
 * It gives an estimated percentage load for the last 100 milliseconds, 1
 * second and 10 seconds. The values returned are percent of the CPU load. So
 * if 99 is returned in rAverage_1s this means in the last second the CPU load
 * was as high as 99 percent.
 *
 * @sa TAL_RegisterForTargetCPULoad
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @param pAverage_point1s  Average CPU load over the last 0.1s
 * @param pAverage_1s       Average CPU load over the last 1s
 * @param pAverage_10s      Average CPU load over the last 10s
 * @else
 * @param pLoad pointer to TalCpuLoad object
 * @endif
 *
 * @retval TAL_SUCCESS      The function call executed successfully
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 * @pre TAL_RegisterForTargetCPULoad has to be used in order to start
 *      transferring the measured data to the host.
 *
 * @remarks none
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetCPULoad(TAL_SessionHandleType sessionHandle,
                     uint32 * pAverage_point1s,
                     uint32 * pAverage_1s,
                     uint32 * pAverage_10s);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getTargetCpuLoad(TalCpuLoad * pLoad) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_RegisterForTargetRAMUsage instead.
 * @endif
 * @endif
 *
 * @brief Get RAM utilisation of the target device
 *
 * This function enables the user to continuously be informed about the RAM
 * usage on the target device
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pCallbackFunction pointer to callback function, called at the end of
 *                          reading the RAM usage from the target.
 *                          If the callback is NULL, the data will still be
 *                          stored within the TAL and can be read via
 *                          TAL_GetTargetRAMUsage
 * @ifnot TAL_C_API
 * @param pCommCallbackFunction pointer to callback function, called at the end of
 *                              reading the RAM usage from the target.
 *                              If the callback is NULL, a previously registered
 *                              function will be disabled, but the data will still be
 *                              stored within the TAL and can be read via
 *                              TAL_GetTargetCommRAMUsage
 * @endif
 * @endif
 * @param nUpdateCycle      time between the updates of the RAM usage value
 *                          in multiples of 0.1s, setting this value to 0
 *                          disables the update process, and unregisters the
 *                          callback
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks none
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_RegisterForTargetRAMUsage(TAL_SessionHandleType sessionHandle,
                              uint16 nUpdateCycle,
                              TAL_RAMUsageFunctionPointerType pCallbackFunction);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
registerForTargetRamUsage(uint16 nUpdateCycle) const;
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
registerForTargetRamUsage(uint16 nUpdateCycle,
                          TAL_RAMUsageFunctionPointerType pCallbackFunction = TAL_RAMCallback,
                          TAL_CommRAMUsageFunctionPointerType pCommCallbackFunction = 0) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 *
 * @if TAL_C_API
 * @brief Get communication RAM utilisation of the target device
 *
 * This function enables the user to register a function which continuously
 * gets informed about communication RAM usage on the target device.
 * You need to call 'TAL_RegisterForTargetRAMUsage' in order to start
 * transmission of the utilisation parameters to the host
 *
 * @sa TAL_RegisterForTargetRAMUsage
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle         handle of the established session
 * @param pCommCallbackFunction pointer to callback function, called at the end of
 *                              reading the RAM usage from the target.
 *                              If the callback is NULL, a previously registered
 *                              function will be disabled, but the data will still be
 *                              stored within the TAL and can be read via
 *                              TAL_GetTargetCommRAMUsage
 *
 * @retval TAL_SUCCESS          The function call executed successfully
 * @retval TAL_NO_SESSION       The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 *
 * @endif
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_RegisterForTargetCommRAMUsage(TAL_SessionHandleType sessionHandle,
                                  TAL_CommRAMUsageFunctionPointerType pCommCallbackFunction);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTargetRAMUsage instead.
 * @endif
 * @endif
 *
 * @brief Get RAM usage of the target device
 *
 * This function enables the user to read the results of the measurement of
 * RAM usage on the target initiated by calling TAL_RegisterForTargetRAMUsage
 *
 * @sa TAL_RegisterForTargetRAMUsage
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @param pMemorySize       Full size of the target memory in bytes
 * @param pUsedMemory       Size of used memory on the target in bytes
 * @param pFreeMemory       Available free memory on the target in bytes
 * @else
 * @param pUsage pointer to TalRamUsage object
 * @endif
 *
 * @retval TAL_SUCCESS      The function call executed successfully
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 * @pre TAL_RegisterForTargetRAMUsage has to be used in order to start
 *      transferring the measured data to the host.
 *
 * @remarks none
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetRAMUsage(TAL_SessionHandleType sessionHandle,
                      uint32 * pMemorySize,
                      uint32 * pUsedMemory,
                      uint32 * pFreeMemory);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getTargetRamUsage(TalRamUsage * pUsage) const;
#endif /* TAL_CXX_API */

/**
 *
 * @if TAL_C_API
 * @brief Get Communication RAM usage of the target device
 *
 * This function enables the user to read percentages of available
 * free space within various communication queues
 *
 * @sa TAL_RegisterForTargetRAMUsage
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle     handle of the established session
 * @param pFreeSpaceOutputFifo  percentage of free space in output
 *                              queue from target to host
 *                              (-1 ... value not available)
 * @param pFreeSpaceInputFifo   percentage of free space in input
 *                              queue from host to target
 *                              (-1 ... value not available)
 * @param pFreeSpaceOutputFifo2 percentage of free space in 2nd
 *                              output queue from target to host
 *                              (-1 ... value not available)
 * @param pFreeSpaceInputFifo2  percentage of free space in 2nd
 *                              input queue from target to host
 *                              (-1 ... value not available)
 * @param pFreeSpaceFrQueue0    percentage of free space in queue containing
 *                              timed FlexRay frames to send
 *                              (-1 ... value not available)
 * @param pFreeSpaceFrQueue1    percentage of free space in queue containing
 *                              timed FlexRay frames to send
 *                              (-1 ... value not available)
 * @param pFreeSpaceFrQueue2    percentage of free space in queue containing
 *                              timed FlexRay frames to send
 *                              (-1 ... value not available)
 * @param pFreeSpaceCanQueue0   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 * @param pFreeSpaceCanQueue1   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 * @param pFreeSpaceCanQueue2   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 * @param pFreeSpaceCanQueue3   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 * @param pFreeSpaceCanQueue4   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 * @param pFreeSpaceCanQueue5   percentage of free space in queue containing
 *                              timed CAN frames to send
 *                              (-1 ... value not available)
 *
 * @retval TAL_SUCCESS      The function call executed successfully
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 * @pre TAL_RegisterForTargetRAMUsage has to be used in order to start
 *      transferring the measured data to the host.
 *
 * @endif
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetCommRAMUsage(TAL_SessionHandleType sessionHandle,
                          sint8 * pFreeSpaceOutputFifo,
                          sint8 * pFreeSpaceInputFifo,
                          sint8 * pFreeSpaceOutputFifo2,
                          sint8 * pFreeSpaceInputFifo2,
                          sint8 * pFreeSpaceFrQueue0,
                          sint8 * pFreeSpaceFrQueue1,
                          sint8 * pFreeSpaceFrQueue2,
                          sint8 * pFreeSpaceCanQueue0,
                          sint8 * pFreeSpaceCanQueue1,
                          sint8 * pFreeSpaceCanQueue2,
                          sint8 * pFreeSpaceCanQueue3,
                          sint8 * pFreeSpaceCanQueue4,
                          sint8 * pFreeSpaceCanQueue5);
#endif /* TAL_CXX_API */

/**
 *
 * @if TAL_C_API
 * @brief Get Communication RAM usage of the target device of a specific queue
 *
 * This function enables the user to read percentages of available
 * free space within various communication queues
 *
 * @sa TAL_RegisterForTargetRAMUsage
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, EB7200
 *
 * @param sessionHandle         handle of the established session
 * @param nQueueID              ID for selected queue
 *                              For EB7200, following Queue IDs are available:
 *                              - ID 0: TX queue of EB PCIe driver (XDMA)
 *                              - ID 1: Best-effort queue for TX interface 0
 *                              - ID 2: Time-triggered queue for TX interface 0
 *                              - ID 3: Best-efford queue for TX interface 1
 *                              - ID 4: Time-triggered queue for TX interface 1
 * @param pFreeQueueSpace       percentage of free space in the selected queue
 *                              (-1 ... value not available)
 *
 * @retval TAL_SUCCESS          The function call executed successfully
 * @retval TAL_NO_SESSION       The function call failed, no valid session
 * @retval TAL_INVALID_INDEX    wrong queue Index
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed
 * @retval TAL_NOT_SUPPORTED    The function with the given param nQueueID or
 *                              for the configured CRB module is not supported
 * @retval TAL_NO_CONNECTION    The function call failed, no valid connection
 *                              to target
 *
 * @pre A session has to be established before calling this function.
 * @pre For EB2200 and EB5200, TAL_RegisterForTargetRAMUsage has to be used in
 *      order to start transferring the measured data to the host.
 *
 * @remark For EB7200, currently only supported Ethernet CRB for the EB PCIe
 *         driver (XDMA).
 *
 * @endif
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetCommRAMUsageByID(TAL_SessionHandleType sessionHandle,
                              TAL_CommRAMUsageQueueType nQueueID,
                              sint8 * pFreeQueueSpace);
#endif /* TAL_CXX_API */

/**
 * @cond EXCLUDE_FROM_DOCU
 * @if TAL_C_API
 * @brief Get RAM and usage and Communication RAM usage for all queues of the target device
 *
 * This function enables the user to read the results of the measurement of
 * RAM usage and the percentages of available free space within various communication queues
 * on the target initiated by calling TAL_RegisterForTargetRAMUsage
 *
 * This function is not included in user docu because it is considered
 * "internal" and is only used for copying the data from the session
 * internal variables to the TalRamUsage object
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle     handle of the established session
 * @param pMemorySize       Full size of the target memory in bytes
 * @param pUsedMemory       Size of used memory on the target in bytes
 * @param pFreeMemory       Available free memory on the target in bytes
 * @param pFreeQueueSpace   Destination array for holding the queue data
 *
 * @retval TAL_SUCCESS      The function call executed successfully
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_NULL_POINTER The function call failed cause a null pointer
 *                          is supplied where it is not allowed.
 *
 * @pre A session has to be established before calling this function.
 * @pre TAL_RegisterForTargetRAMUsage has to be used in order to start
 *      transferring the measured data to the host.
 *
 * @remarks none
 *
 * @endif
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetCommRAMUsageAllIDs(TAL_SessionHandleType sessionHandle,
                                uint32 * pMemorySize,
                                uint32 * pUsedMemory,
                                uint32 * pFreeMemory,
                                sint8 * pFreeQueueSpace);
#endif /* TAL_CXX_API */
/* @endcond */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTargetStatus instead.
 * @endif
 * @endif
 *
 * @brief Get state information about the target
 *
 * This function provides the state of the target
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle  handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pTargetStatus  pointer to a data structure, where the current
 *                       state of the target shall be stored
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 *
 * @invariant None.
 *
 * @pre None.
 *
 * @post None.
 *
 * @remarks None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetStatus(TAL_SessionHandleType sessionHandle,
                    TAL_TargetStatusType * pTargetStatus);
#else /* TAL_CXX_API */
#ifndef SWIG /* TAL_TargetStatusType* problematic in swig wrapper */
virtual TAL_DEPRECATED TAL_ReturnType
getTargetStatus(TAL_TargetStatusType * pTargetStatus) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTargetHWInfo instead.
 * @endif
 * @endif
 *
 * @brief get version information about the target hardware
 *
 * This function delivers information about the target hardware.
 *
 * @sa TAL_GetTargetHALVersion
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @ifnot SWIG
 * @param pSerialNr       Pointer to buffer where the serial number of the
 *                        target hardware is stored.
 * @param pBoardID        Pointer to buffer where the board ID string of the
 *                        target hardware is stored.
 * @param nBoardIDLength  Size of the supplied buffer for the board ID.
 * @param pMacAddr        Pointer to buffer where the MAC address of the
 *                        target hardware is stored. For EB2200 this is
 *                        the MAC address which is used for connection with
 *                        the host. For EB5200 this is an empty string.
 * @param nMacAddrLength  Size of the supplied buffer for the MAC address
 * @param pRamSizeInBytes Pointer to buffer where the RAM size of the
 *                        target hardware is stored.
 * @param pFlashSizeInBytes   Pointer to buffer where the FLASH size of the
 *                            target hardware is stored.
 * @param pSramSizeInBytes Pointer to buffer where the SRAM size of the
 *                         target hardware is stored.
 * @param pCompactFlashSizeInBytes  Pointer to buffer where the Compact Flash
 *                                  size of the target hardware is stored.
 * @param pCompactFlashType   Pointer to buffer where the Compact Flash Type
 *                            of the target hardware is stored.
 * @param nCompactFlashTypeLength   Size of the supplied buffer for the
 *                                  Compact Flash Type.
 * @param pHwVariantName   Pointer to buffer where the target hardware variant
 *                         name is stored.
 * @param nHwVariantNameLength   Size of the supplied buffer for the target
 *                               hardware variant name.
 * @endif
 *
 * @retval TAL_SUCCESS      The function call executed successfully
 * @retval TAL_FAILED       The function call failed to execute.
 * @retval TAL_NO_SESSION   No session to target established.
 * @retval TAL_NULL_POINTER The function call failed cause a null pointer
 *                          is supplied where it is not allowed
 * @retval TAL_BUFFER_TOO_SMALL A supplied buffer is too small for the data.
 *
 * @note A session has to be established before calling this function.
 *
 * @remarks The hardware variant name string contains information about
 * the actual board type and revision, e.g. `"EB5200RevA"`, `"EB2200RevB1"`,
 * `"EB5200RevB2"`, `"EB7200"`, and so on.
 * **Note:** The exact value of the variant string is not fixed and may change
 * with different firmware versions and hardware revisions.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTargetHWInfo(TAL_SessionHandleType sessionHandle,
                    uint16* pSerialNr,
                    char* pBoardID,
                    uint8 nBoardIDLength,
                    char* pMacAddr,
                    uint8 nMacAddrLength,
                    uint32* pRamSizeInBytes,
                    uint32* pFlashSizeInBytes,
                    uint32* pSramSizeInBytes,
                    uint64* pCompactFlashSizeInBytes,
                    char* pCompactFlashType,
                    uint8 nCompactFlashTypeLength,
                    char* pHwVariantName,
                    uint8 nHwVariantNameLength);
#else /* TAL_CXX_API */
#ifndef SWIG /* cant be wrapped to swig - use getTargetHardwareInfo() instead! */
virtual TAL_DEPRECATED TAL_ReturnType
getTargetHWInfo(uint16* pSerialNr,
                char* pBoardID,
                uint8 nBoardIDLength,
                char* pMacAddr,
                uint8 nMacAddrLength,
                uint32* pRamSizeInBytes,
                uint32* pFlashSizeInBytes,
                uint32* pSramSizeInBytes,
                uint64* pCompactFlashSizeInBytes,
                char* pCompactFlashType,
                uint8 nCompactFlashTypeLength,
                char* pHwVariantName,
                uint8 nHwVariantNameLength) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

#ifdef  TAL_CXX_API
/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetTargetHWInfo instead.
 * @endif
 * @endif
 *
 * @brief get version information about the target hardware
 *
 * This function delivers information about the target hardware
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param pInfo pointer to TalTargetHardwareInfo object
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute.
 * @retval TAL_NO_SESSION No session to target established.
 * @retval TAL_NULL_POINTER The function call failed cause a null pointer
 *                          is supplied where it is not allowed
 * @retval TAL_BUFFER_TOO_SMALL A supplied buffer is too small for the data.
 *
 * @note A session has to be established before calling this function.
 *
 */
virtual TAL_DEPRECATED TAL_ReturnType
getTargetHardwareInfo(TalTargetHardwareInfo *pInfo) const;
#endif

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetFifoUsage instead.
 * @endif
 * @endif
 *
 * @brief Get amount of total/free space within the communication FIFOs
 *
 * This function returns the number of total and of free bytes within the
 * send and receive FIFOs used for communication with the target device
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pTxFreeBytes number of free bytes in Tx FIFO
 * @param pTxTotalBytes total number of bytes in Tx FIFO
 * @param pRxFreeBytes number of free bytes in Rx FIFO
 * @param pRxTotalBytes total number of bytes in Rx FIFO
 * @else
 * @param pFifoUsage pointer to object of type TalFifoUsage.
 * All elements of the object are updated during successful function call.
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @return TAL_NOT_SUPPORTED The function not supported for the target device
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetFifoUsage(TAL_SessionHandleType sessionHandle,
                 uint32 *pTxFreeBytes,
                 uint32 *pTxTotalBytes,
                 uint32 *pRxFreeBytes,
                 uint32 *pRxTotalBytes);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getFifoUsage(TalFifoUsage *pFifoUsage);
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup busmirror_tcp TCP related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_Flush instead.
 * @endif
 * @endif
 *
 * @brief Set the send threshold
 *
 * The send threshold is the limit of the local send queue where its contents
 * are automatically commited for transmission to the target.
 *
 * @sa TAL_Flush
 *
 * @li Domain: Host
 * @li Calling: blocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle  handle of the session, which has to be flushed
 * @endif
 * @param sendThreshold  limit where local send queue is committed for
 *                       transmission
 *
 * @retval TAL_SUCCESS    The function call executed successfully
 * @retval TAL_FAILED     The function call failed to execute
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @note If no connection was established before calling this function the
 *       return value will be \c TAL_FAILED.
 *
 * @note The default threshold before calling this function is set to 0.
 *       If the threshold is set to a value different from 0 the function
 *       TAL_Flush could be called to empty the send queue at specific
 *       points.
 *
 * @pre A session has to be established before calling this function.
 *
 * @remarks A local send queue which send threshold can be changed is
 *          currently only implemented in the TCP backend because of
 *          performance reasons.
 *          Calling this function for other backends has currently no effect
 *          therefore.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SetSendThreshold(TAL_SessionHandleType sessionHandle,
                     uint32 sendThreshold);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
setSendThreshold(uint32 sendThreshold) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_SetConnectTimeout instead.
 * @endif
 * @endif
 *
 * @brief Set the connect timeout
 *
 * The connect timeout is the maximum time after that creating a
 * TCP session with TAL_Create***Session fails.
 *
 * @li Domain: Host
 * @li Calling: blocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, VirtualBus
 *
 * @param ConnectTimeoutMs   Connect timeout in ms.
 *
 * @retval TAL_SUCCESS   The function call executed successfully
 *
 * @note The default Connect before calling this function
 *       is set to 10000 which equates to 10  seconds.
 *
 * @pre None.
 *
 * @remarks None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SetConnectTimeout(uint32 ConnectTimeoutMs);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
setConnectTimeout(uint32 ConnectTimeoutMs) const;
#endif /* TAL_CXX_API */

/**
 * @}
 */

#if (TAL_TH_BM_PHYSICAL_ENABLED == TAL_ON)

/**
 * @addtogroup signal
 * @{
 */

#ifndef TAL_CXX_API
/**
 * @brief Convert a physical value of a sending signal to its coded value
 * and prepare it for sending
 *
 * This function converts the physical signal to a coded signal and updates
 * the coded value for a specific signal in the targets signal base.
 * The new value is converted to the coded value on the host (according to the
 * conversion table read out of the TCS file), transferred immediately, then
 * the function returns. The value is stored on the target in the signal base.
 * Whenever the FlexRay communication drivers needs data for sending the
 * according frames the signal values are taken out of the signal base and
 * packed in the frame to be written in-time into the FlexRay controllers
 * buffer.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle handle of the established session
 * @param signalIndex   unique identifier for the signal
 * @param value         physical value
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 *
 * @note The value is converted on the host from the physical to the coded
 *       value representation.
 *
 * @invariant None.
 *
 * @pre A session has to be established before calling this function.
 *
 * @post None.
 *
 * @remarks Signals which are located in cyclic timings are send by the target
 * firmware in the next according FlexRay slot or CAN-message-period
 * automatically. Signals which are located in event-based timings are handled
 * according to configuration. If the signal's ComTransferProperty is set to
 * TRIGGERED (or TRIGGERED_ON_CHANGE) the PDU is sent automatically
 * (TRIGGERED_ON_CHANGE: only if the value changed). If the ComTransferProperty
 * of the signal is PENDING the function TAL_BM_CommitPDU() must be called
 * additionally
 *
 * \b Example
 * \snippet Testing/TAL_legacy_FR/Signal_Conv_SCALE-LINEAR/src/host.cpp example_TAL_BM_SendSignalPhys
 */
TAL_API extern TAL_ReturnType
TAL_BM_SendSignalPhys(TAL_SessionHandleType sessionHandle,
                      TAL_BM_SignalIndexType signalIndex,
                      TAL_BM_PhysicalSignalValueType value);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief Set the coded value of a sending signal to its symbol value
 *
 * This function updates the physical value for a specific signal in the host
 * signal base according to the given symbol name (enumerated constant name).
 * The new value is converted to the coded value on the host (according to the
 * conversion table read out of the TCS file), transferred immediately, then
 * the function returns. The value is stored on the target in the signal base.
 * Whenever the FlexRay communication drivers needs data for sending the
 * according frames the signal values are taken out of the signal base and
 * packed in the frame to be written in-time into the FlexRay controllers
 * buffer.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: explicit flush needed if threshold greater than 0
 *            @sa SetSendThreshold
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle handle of the established session
 * @param signalIndex   unique identifier for the signal
 * @param pSymbolName   pointer to the symbol name (coded in utf8)
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 *
 * @note The value is converted on the host from the physical to the coded
 *       value representation according to the given symbol name.
 *
 * @invariant None.
 *
 * @pre A session has to be established before calling this function.
 *
 * @post None.
 *
* @remarks Signals which are located in cyclic timings are send by the target
 * firmware in the next according FlexRay slot or CAN-message-period
 * automatically. Signals which are located in event-based timings are handled
 * according to configuration. If the signal's ComTransferProperty is set to
 * TRIGGERED (or TRIGGERED_ON_CHANGE) the PDU is sent automatically
 * (TRIGGERED_ON_CHANGE: only if the value changed). If the ComTransferProperty
 * of the signal is PENDING the function TAL_BM_CommitPDU() must be called
 * additionally
 */
TAL_API extern TAL_ReturnType
TAL_BM_SendSignalSymbol(TAL_SessionHandleType sessionHandle,
                        TAL_BM_SignalIndexType signalIndex,
                        const uint8 * pSymbolName);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 * @brief Get the physical value of a signal and the status of the underlying
 * coded signal
 *
 * This function reads the locally stored coded value of signal from the
 * signal base and converts it into its physical representation.
 * After a signal is subscribed at the target it is automatically transferred
 * to the host whenever the signal is received. The function
 * #TAL_ProcessTargetData at the host reads the receive buffers of all
 * communication back-ends and, if it contains signal values for subscribed
 * signals they are stored in the signal base. This function converts the actual
 * value which is stored in the signal base to its physical representation
 * before returning it.
 * Additionally this function returns the signal status of the stored coded
 * value (#TAL_BM_SignalStatusType).
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle   handle of the established session
 * @param signalIndex     unique identifier for the signal
 * @param pValue          pointer to a data structure for storing the physical
 *                        value
 *                        Only valid if the physical status is TAL_VALUE or TAL_MIXED.
 * @param pStatusPhysical pointer to a data structure for storing the signal
 *                        status of the physical signal
 * @param pStatus         pointer to a data structure for storing the signal
 *                        status of the underlying coded signal
 * @param pSymbolName     pointer to store the symbol name (coded in
 *                        utf8) in (0 .. symbol name is not stored).
 *                        The string gets zero terminated.
 *                        Only valid if the physical status is TAL_SYMBOL or TAL_MIXED.
 * @param nSymbolNameLength size of the provided (user) buffer (pSymbolName)
 *                          in bytes for storing the symbol name
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed
 * @retval TAL_NO_SESSION       The function call failed, no valid session
 * @retval TAL_BUFFER_TOO_SMALL The buffer for the symbol name is too small,
 *                              thus the symbol was not copied. The remaining
 *                              functionality of the call succeeded
 *
 * @note The value is converted on the host from the coded to the physical
 *       value representation.
 *
 * @invariant None.
 *
 * @pre A session has to be established before calling this function.
 *
 * @post None.
 *
 * @remarks None.
 */
TAL_API extern TAL_ReturnType
TAL_BM_ReceiveSignalPhysWithStatus(TAL_SessionHandleType sessionHandle,
                                   TAL_BM_SignalIndexType signalIndex,
                                   TAL_BM_PhysicalSignalValueType * pValue,
                                   TAL_BM_PhysicalSignalStatusType * pStatusPhysical,
                                   TAL_BM_SignalStatusType * pStatus,
                                   uint8 * pSymbolName,
                                   uint32 nSymbolNameLength);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the coded value of a symbol
 *
 * This function converts a symbol (enumerated constant name) into its coded value.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle   handle of the established session
 * @param signalIndex     unique identifier for the signal
 * @param pCoded          Pointer to where the Coded value should be stored
 * @param pSymbolName     Symbolname
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_CONVERSION   The function call failed, unable to find
 *                             conversion, Symbol not found for given signal
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 *
 * @invariant None.
 *
 * @pre A session has to be established before calling this function.
 *
 * @post None.
 *
 * @remarks None.
 *
 */
TAL_API extern TAL_ReturnType
TAL_BM_SymbolToCoded(TAL_SessionHandleType sessionHandle,
                     TAL_BM_SignalIndexType signalIndex,
                     TAL_BM_CodedSignalValueType * pCoded,
                     const char * pSymbolName);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_CodedToPhysical64 instead.
 * @endif
 * @endif
 *
 * @brief Converts a 64 bit Coded value into a Physical one
 *
 * This function converts a Coded value into a Physical value
 * Using this function together with TAL_BM_ReceiveSignalCodedWithStatus has a
 * similar effect as calling TAL_BM_ReceiveSignalPhys directly. As a side
 * effect the coded representation can be used for other purposes (e.g.
 * displaying it in a GUI) too.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle   handle of the established session
 * @param signalIndex     unique identifier for the signal
 * @param pCoded          Pointer to the 64 bit Coded value that should be converted
 * @param pPhysical       Pointer to the location where the Physical Value
 *                        should be stored. (if NULL, no value is provided)
 *                        Only valid if the physical status is TAL_VALUE or TAL_MIXED.
 * @param pStatusPhysical pointer to a data structure for storing the signal
 *                        status of the physical signal. (if NULL, no value is provided)
 * @param pSymbolName     pointer to store the symbol name (coded in
 *                        utf8) in (0 .. symbol name is not stored).
 *                        The string gets zero terminated.
 *                        (if NULL, no value is provided)
 *                        Only valid if the physical status is TAL_SYMBOL or TAL_MIXED.
 * @param nSymbolNameLength size of the provided (user) buffer (pSymbolName)
 *                          in bytes for storing the symbol name
 * @else
 * @param signalIndex unique identifier for the signal
 * @param pSignal pointer to signal data object, the conversion function
 * converts the coded value inside this object to the physical value. Please
 * make sure to check the physical status of the object after conversion,
 * because it is possible that the conversion fails.
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_CONVERSION    The function call failed, unable to find
 *                              conversion
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed
 * @retval TAL_NO_SESSION       The function call failed, no valid session
 * @retval TAL_BUFFER_TOO_SMALL The buffer for the symbol name is too small,
 *                              thus the symbol was not copied. The remaining
 *                              functionality of the call succeeded
 *
 * @invariant None.
 *
 * @pre A session has to be established before calling this function.
 *
 * @post None.
 *
 * @remarks None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_CodedToPhysical64(TAL_SessionHandleType sessionHandle,
                         TAL_BM_SignalIndexType signalIndex,
                         uint64 * pCoded,
                         TAL_BM_PhysicalSignalValueType * pPhysical,
                         TAL_BM_PhysicalSignalStatusType * pStatusPhysical,
                         uint8 * pSymbolName,
                         uint32 nSymbolNameLength);
#else /* TAL_CXX_API */
/* reason for different name from C is that C++ API did not need change to
 * support 64 bits - we did not want to break API compatibility for exising
 * applications just because of naming. */
virtual TAL_DEPRECATED TAL_ReturnType
bmCodedToPhysical(TAL_BM_SignalIndexType signalIndex,
                  TalSignal * pSignal) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_PhysicalToCoded64 instead.
 * @endif
 * @endif
 *
 * @brief Converts a Physical Value into a 64 bit Coded one
 *
 * This function converts a Physical value into a 64 bit Coded value.
 * Using this function together with TAL_BM_SendSignalCoded has a similar
 * effect as calling TAL_BM_SendSignalPhys directly. As a side effect the
 * coded representation can be used for other purposes (e.g. displaying it in
 * a GUI) too. Cannot be used to convert a symbol (enumerated constant name).
 * For converting symbols use TAL_BM_SymbolToCoded.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle   handle of the established session
 * @param signalIndex     unique identifier for the signal
 * @param pPhysical       Pointer to the Physical value that should be
 *                        converted
 * @param pCoded          Pointer to where the 64 bit Coded value should be stored
 * @else
 * @param signalIndex unique identifier for the signal
 * @param pSignal pointer to signal data object, the conversion function
 * converts the physical value inside this object to the coded value.
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_CONVERSION   The function call failed, unable to find
 *                             conversion
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 *
 * @invariant None.
 *
 * @pre A session has to be established before calling this function.
 *
 * @post None.
 *
 * @remarks None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_PhysicalToCoded64(TAL_SessionHandleType sessionHandle,
                       TAL_BM_SignalIndexType signalIndex,
                       TAL_BM_PhysicalSignalValueType * pPhysical,
                       uint64 * pCoded);
#else /* TAL_CXX_API */
/* reason for different name from C is that C++ API did not need change to
 * support 64 bits - we did not want to break API compatibility for exising
 * applications just because of naming. */
virtual TAL_DEPRECATED TAL_ReturnType
bmPhysicalToCoded(TAL_BM_SignalIndexType signalIndex,
                  TalSignal * pSignal) const;
#endif /* TAL_CXX_API */

/**
 * @}
 */

#endif /* (TAL_TH_BM_PHYSICAL_ENABLED == TAL_ON) */

/**
 * @defgroup measurement Measurement related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_InspConfigureFlexRayAsync instead.
 * @endif
 * @endif
 *
 * @brief Configure target for asynchronous FlexRay monitoring
 *
 * This function shall be called before calling
 * TAL_InspStartMeasurement() to receive FlexRay measurement packets.
 * In case a FlexRay RBS is running, synchronous measurement is done automatically (only valid for EBHSCR
 * monitoring because of compatibility reasons)
 *
 * @li Domain: Host/Target
 * @li Calling: blocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 *
 * @param eFrChEnableMask specifies which FlexRay channels shall be monitored.
 * @sa TAL_FRChannelType
 *
 * @param ePhysicalLayerType Unused. Use any value (e.g.
 * TAL_PHYSICAL_LAYER_TYPE_UNKNOWN).
 *
 * @param gdBit FlexRay Bitduration in microseconds
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_COMM_ERROR     The function call failed, error at the
 *                            communication attempt
 *
 * @pre A session has to be established before calling this function.
 *
 * \b Example
 * \snippet Testing/TAL_legacy_FR/Register_Unregister_RecvSignal/src/host.cpp example_TAL_InspConfigureFlexRayAsync
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspConfigureFlexRayAsync(TAL_SessionHandleType sessionHandle,
                              TAL_FRChannelType eFrChEnableMask,
                              TAL_PhysicalLayerType ePhysicalLayerType,
                              float32 gdBit);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureFlexRayAsync(TAL_FRChannelType eFrChEnableMask,
                          TAL_PhysicalLayerType ePhysicalLayerType,
                          float32 gdBit) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_InspConfigureFlexRaySync instead.
 * @endif
 * @endif
 * @brief Configure target for mixed (sync/async) FlexRay-Monitoring
 *
 * Configure target for mixed (sync/async) FlexRay-Monitoring
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @param eFrChEnableMask specifies which FlexRay channels shall be monitored.
 * @sa TAL_FRChannelType
 *
 * @param ePhysicalLayerType Unused. Use any value (e.g.
 * TAL_PHYSICAL_LAYER_TYPE_UNKNOWN).
 *
 * @param gdBit          FlexRay Bitduration [us]
 * @param gdTSSTransmitter    Number of bits in the Transmission
 *                            Start Sequence. [gdBit]
 * @param pDelayCompensationA Value used to compensate for reception delays
 *                            on the indicated channel. [Microtick (25ns)]
 * @param pDelayCompensationB Value used to compensate for reception delays
 *                            on the indicated channel. [Microtick (25ns)]
 * @param gdCycle             Duration of a communication Cycle[us]
 * @param gdMacrotick         Duration of a Macrotick. [us]
 * @param gdStaticSlot        Duration of a static slot. [gdMacrotick]
 * @param gNumberOfStaticSlots Number of static slots in the static segment.
 * @param gdActionPointOffset Number of macroticks the action point is offset from the
 *                            beginning of a static slot or symbol window.[gdMacrotick]
 * @param gPayloadLengthStatic Payload length of a static frame. [16bit Words]
 * @param gdDynamicSlotIdlePhase Duration of the idle phase within a dynamic slot. [Minislots]
 * @param gdMinislot          Duration of a Minislot. [gdMacrotick]
 * @param gdMinislotActionPointOffset Number of macroticks the minislot action point is offset
 *                                    from the beginning of a minislot. [gdMacrotick]
 * @param pLatestTx           Number of the last minislot in which a frame transmission
 *                            can start in the dynamic segment.
 * @param gdNIT               Duration of the Network Idle Time. [gdMacrotick]
 * @param gdSymbolWindow Duration of the symbol window. [gdMacrotick]
 * @param gOffsetCorrectionStart Start of the offset correction phase within the NIT, expressed
 *                               as the number of macroticks from the start of cycle.[gdMacrotick]
 * @param gOffsetCorrectionMax Cluster global magnitude of the maximum necessary
 *                             offset correction value.[us]
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspConfigureFlexRaySync(TAL_SessionHandleType sessionHandle,
                             TAL_FRChannelType     eFrChEnableMask,
                             TAL_PhysicalLayerType ePhysicalLayerType,
                             float32 gdBit,
                             uint8   gdTSSTransmitter,
                             uint8   pDelayCompensationA,
                             uint8   pDelayCompensationB,
                             uint16  gdCycle,
                             float32 gdMacrotick,
                             uint16  gdStaticSlot,
                             uint16  gNumberOfStaticSlots,
                             uint8   gdActionPointOffset,
                             uint8   gPayloadLengthStatic,
                             uint8   gdDynamicSlotIdlePhase,
                             uint8   gdMinislot,
                             uint8   gdMinislotActionPointOffset,
                             uint16  pLatestTx,
                             uint16  gdNIT,
                             uint8   gdSymbolWindow,
                             uint16  gOffsetCorrectionStart,
                             float32 gOffsetCorrectionMax);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureFlexRaySync(TAL_FRChannelType     eFrChEnableMask,
                         TAL_PhysicalLayerType ePhysicalLayerType,
                         float32 gdBit,
                         uint8   gdTSSTransmitter,
                         uint8   pDelayCompensationA,
                         uint8   pDelayCompensationB,
                         uint16  gdCycle,
                         float32 gdMacrotick,
                         uint16  gdStaticSlot,
                         uint16  gNumberOfStaticSlots,
                         uint8   gdActionPointOffset,
                         uint8   gPayloadLengthStatic,
                         uint8   gdDynamicSlotIdlePhase,
                         uint8   gdMinislot,
                         uint8   gdMinislotActionPointOffset,
                         uint16  pLatestTx,
                         uint16  gdNIT,
                         uint8   gdSymbolWindow,
                         uint16  gOffsetCorrectionStart,
                         float32 gOffsetCorrectionMax) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_InspConfigureCAN instead.
 * @endif
 * @endif
 * @brief Configure target for CAN-Monitoring
 *
 * Configure target for CAN-Monitoring
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param CtrlIdx  Select CAN controller
 *                 0 = Controller #0
 *                 1 = Controller #1
 *                 2 = Controller #2
 *                 3 = Controller #3
 *                 4 = Controller #4
 *                 5 = Controller #5
 * @param Enable   0 = Disable
 *                 1 = Enable
 * @param Baudrate        Baudrate of CAN network
 *                        Supported values are: 100000, 125000, 250000,
 *                        500000, 1000000
 * @param BitSampleOffset CAN Bit-Sample Offset in [%]
 *                        This parameter is currently unused because it
 *                        is automatically calculated from the Baudrate.
 * @param bHighSpeed      Transceiver Type to use
 *                        0 ... LowSpeed Transceiver (only for
 *                              CAN controller #1)
 *                        1 ... HighSpeed Transceiver
 *                        This parameter is currently unused.
 *
 * \b Example
 * \snippet Testing/Examples/SILDemoCAN/HostAppl/src/SILMeasurement.cpp example_TAL_InspConfigureCAN
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspConfigureCAN(TAL_SessionHandleType sessionHandle,
                     int CtrlIdx,
                     int Enable,
                     int Baudrate,
                     int BitSampleOffset,
                     TAL_Boolean bHighSpeed);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureCAN(int CtrlIdx,
                 int Enable,
                 int Baudrate,
                 int BitSampleOffset,
                 bool bHighSpeed ) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_InspConfigureCANFD instead.
 * @endif
 * @endif
 * @brief Configure target for CANFD-Monitoring
 *
 * Configure target for CANFD-Monitoring
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param CtrlIdx  Select CAN controller
 *                 0 = Controller #0
 *                 1 = Controller #1
 *                 2 = Controller #2
 *                 3 = Controller #3
 *                 4 = Controller #4
 *                 5 = Controller #5
 * @param Enable   0 = Disable
 *                 1 = Enable
 * @param NonIso   0 = Iso, CAN FD frame format according to ISO standard 11898-1:2015. For new projects it is recommended to use Iso mode.
 *                 1 = NonIso, CAN FD frame format according to Bosch CAN FD specification V1.0. NonIso mode shall only be used for backward compatibility with existing projects.
 * @param Baudrate      Configures the baudrate (bits per second) during arbitration phase of the CAN network
 *                      (controller)
 * @param BaudrateFD    Configures the baudrateFD (bits per second) during data and CRC phase of the CAN network
 *                      (controller)
 */
 #ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspConfigureCANFD(TAL_SessionHandleType sessionHandle,
                       int CtrlIdx,
                       int Enable,
                       int NonIso,
                       int Baudrate,
                       int BaudrateFD);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureCANFD(int CtrlIdx,
                   int Enable,
                   int NonIso,
                   int Baudrate,
                   int BaudrateFD ) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_InspConfigureEth instead.
 * @endif
 * @endif
 * @brief Configure target for Ethernet monitoring
 *
 * Configure target for Ethernet monitoring
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * For EB7200 or EB8200 with a EB1235 (1000BaseT1) module: Values marked with * are allowed
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param CtrlIdx  Select Ethernet controller (eTSEC)
 *                 0* = Controller #0
 *                 1* = Controller #1
 * @param eBaudRate    Speed of Ethernet network
 *                     TAL_BM_ETH_SPEED_10_MBPS = 10 Mbps
 *                     TAL_BM_ETH_SPEED_100_MBPS* = 100 Mbps
 *                     TAL_BM_ETH_SPEED_1000_MBPS* = 1000 Mbps
 *                     TAL_BM_ETH_SPEED_AN = speed (and duplex mode) shall be determined using auto negotiation (if possible)
 * @param eDuplex   Duplex mode of Ethernet network
 *                     TAL_BM_ETH_DUPLEX_HALF Half duplex mode
 *                     TAL_BM_ETH_DUPLEX_FULL* Full duplex mode
 * @param bBroadrMaster For BroadR-Reach Ethernet this parameter selects if the Ethernet transceiver
 *                      associated to the given controller shall be master or slave.
 *                      In case no BroadR-Reach physical layer is used this parameter is ignored.
 *                      0* = BroadR-Reach transceiver is slave
 *                      1* = BroadR-Reach transceiver is master
 * @param bBack2Back For BroadR-Reach Ethernet this parameter selects if both Ethernet transceiver
 *                   shall be set to either normal mode (both controllers can be used independently for
 *                   receiving and transmitting Ethernet data) or back-2-back mode (packets can only be
 *                   received, Ethernet trafic is forwarded from one interface to the other).
 *                   EB2200/EB5200: If this mode is activated, the back-2-back mode is activated for both controllers.
 *                   EB7200/EB8200: If this mode is activated, the back-2-back mode is activated only for the given controller.
 *                   Therefore, the data will be forwarded only from the given controller to the other.
 *                   In case no BroadR-Reach physical layer is used this parameter is ignored.
 *                   0* = back-2-back mode is deactivated
 *                   1* = back-2-back mode is deactivated
 * @param flags Controller / Transceiver specific settings See @ref TAL_BM_EthFlags
 *
 * @retval TAL_SUCCESS         The function call executed successfully
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 * @retval TAL_INVALID_INDEX   Given index is out of range
 * @retval TAL_NOT_SUPPORTED   The function is not supported for the connected module
 *
 * @note For EB7200, activation of back-2-back mode disables automatically replay mode, otherwise
 *       replay mode is activated per default.
 *
 * \b Example
 * \snippet Applications/HostBasedRbs/src/TalEth.cpp example_TAL_InspConfigureEth
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspConfigureEth(TAL_SessionHandleType sessionHandle,
                     int CtrlIdx,
                     TAL_BM_EthBaudRateType eBaudRate,
                     TAL_BM_EthDuplexType eDuplex,
                     TAL_Boolean bBroadrMaster,
                     TAL_Boolean bBack2Back,
                     uint32 flags);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureEth(uint8 CtrlIdx,
                 TAL_BM_EthBaudRateType eBaudRate,
                 TAL_BM_EthDuplexType eDuplex,
                 TAL_Boolean bBroadrMaster,
                 TAL_Boolean bBack2Back,
                 uint32 flags) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_InspConfigureLINController instead.
 * @endif
 * @endif
 * @brief Configure target for LIN monitoring
 *
 * Configure target for LIN monitoring
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param CtrlIdx   Select LIN controller
 *                 0 = Controller #0
 *                 1 = Controller #1
 *                 ...
 * @param Enable    0 = Disable
 *                  1 = Enable
 * @param BaudRate  LIN Baud Rate - Available Baudrates:
 *                   1200
 *                   2400
 *                   4800
 *                   6400
 *                   7200
 *                   9600
 *                  10000
 *                  10400
 *                  12800
 *                  14400
 *                  19200 (EU default)
 *                  20000
 */
#ifndef TAL_CXX_API
TAL_API extern  TAL_ReturnType
TAL_InspConfigureLINController(TAL_SessionHandleType sessionHandle,
                     int CtrlIdx,
                     int Enable,
                     int BaudRate);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureLINController(int CtrlIdx,
                 int Enable,
                 int BaudRate) const;
#endif /* TAL_CXX_API */


/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_InspConfigureADIO instead.
 * @endif
 * @endif
 * @brief Configure Analog-Digital Input-Sampling
 *
 * Configure Analog-Digital Input-Sampling
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param Enable     0 = Disable
 *                   1 = Enable
 * @param SampleRate Sample Rate [10us]
 *                   possible values range from 10 to 16383 x 10us
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspConfigureADIO(TAL_SessionHandleType sessionHandle,
                      int Enable,
                      int SampleRate);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureADIO(int Enable,
                  int SampleRate) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_InspConfigureDETI instead.
 * @endif
 * @endif
 * @brief Configure Digital Event triggered input (DETI)
 *
 * Configure Digital Event triggered input (DETI)
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param Enable    0 = Disable DETI
 *                  1 = Enable DETI
 * @param PosMask   Set Bit to '1' to configure input to trigger on positive edge
 *                  Bit8  ... Input 0
 *                  Bit9  ... Input 1
 *                  Bit10 ... Input 2
 *                  Bit11 ... Input 3
 * @param NegMask   Set Bit to '1' to configure input to trigger on negative edge
 *                  Bit8  ... Input 0
 *                  Bit9  ... Input 1
 *                  Bit10 ... Input 2
 *                  Bit11 ... Input 3
 *
 * \b Example
 * \snippet Applications/DigitalIO/deti/src/main.cpp example_TAL_InspConfigureDETI
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspConfigureDETI(TAL_SessionHandleType sessionHandle,
                      int Enable,
                      int PosMask,
                      int NegMask);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureDETI(int Enable,
                  int PosMask,
                  int NegMask) const;
#endif /* TAL_CXX_API */

/**
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Starting from 4.18 there is only one timebase EB_TIME_MASTER, and also only one
 *             timestamp (no ATS2) so no need to configure a secondary timebase.
 *             Start and stop timestamp is enabled by default.
 *
 * @brief Configures the Inspector measurement packet format
 *
 * Configures the Inspector measurement packet format
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param nPacketFormatMask  Selected measurement packet format
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_FAILED        The function call failed, measurement is already running
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 *
 * @sa   TAL_INSP_PACKET_FORMAT_DUAL_TIMESTAMP
 * @sa   TAL_INSP_PACKET_FORMAT_ATS2_TIMESTAMP
 * @sa   TAL_ConfigureTimebaseATS2()
 *
 * @remarks The function should be called before measurement is started.
 * @remarks If TAL_INSP_PACKET_FORMAT_ATS2_TIMESTAMP is enabled, TAL_ConfigureTimebaseATS2()
 *          has to be called before to use extended packet format.
 *
 * @pre  None.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_DEPRECATED TAL_ReturnType
TAL_InspConfigurePacketFormat(TAL_SessionHandleType sessionHandle,
                              TAL_ScalarInspPacketFormatMaskType nPacketFormatMask);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigurePacketFormat(TAL_ScalarInspPacketFormatMaskType nPacketFormatMask);
#endif /* TAL_CXX_API */
/* @endcond */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_InspStartMeasurement instead.
 * @endif
 * @endif
 *
 * @brief Starts the measurement
 *
 * This function registers the automatic reception of measurement data from
 * the target. After measurement is started at the target it is automatically
 * transferred to the host whenever it is received from the bus.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param sLogFile parameter kept for compatibility reasons. To perform online measurement without
 * sqlite file support, supply a NULL pointer or an empty string.
 * @param nTruncate unused parameter.
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_COMM_ERROR     The function call failed, error at the
 *                            communication attempt
 * @retval TAL_NOT_SUPPORTED  User passed non empty string to function.
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @remark For EB7200, replay can only be done if measurement is started,
 *         currently only supported for 1000Base-T1
 *
 * @sa TAL_InspConfigureEth
 *
 * @pre A session has to be established before calling this function.
 *
 * @pre At least one measurement unit must be configured before calling this
 * function. E.g. to receive data from asynchronous FlexRay measurement unit
 * call TAL_InspConfigureFlexRayAsync() before.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspStartMeasurement(TAL_SessionHandleType sessionHandle,
                         const char *sLogFile,
                         sint64 nTruncate);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspStartMeasurement(const char *sLogFile,
                     sint64 nTruncate);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_StopMeasurement instead.
 * @endif
 * @endif
 *
 * @brief Stops a running measurement
 *
 * This function unregisters the automatic reception of measurement data from
 * the target. After measurement is started at the target it is automatically
 * transferred to the host whenever it is received from the bus. This function
 * stops the automatic data streaming from the target to the host.
 * If TAL_InspStartMeasurement() was called with a valid logfile name this
 * function will also trigger the closing of the logfile as soon as the
 * stop-measurement packet is received from the target. Please call
 * TAL_IsMeasurementStopped() after this function to wait for successful
 * transmission of all measurement packets from the target to the host.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR The function call failed, error encoding a package
 * @retval TAL_COMM_ERROR     The function call failed, error at the
 *                            communication attempt
 *
 * @note The function returns before the target handled the request and thus
 *       no information about the result of the execution on the target
 *       can be given.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_StopMeasurement(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
stopMeasurement() const;
#endif /* TAL_CXX_API */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Use TAL_GetDeviceOption with deviceOpt=TAL_EB7200_GET_STATUS instead.
 * @brief Get channel status and channel event
 *
 * This function receives the status and event of the associated channel.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB7200 Base project
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pStatus Pointer of a struct where the values of the status and event
          registers are stored
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_COMM_ERROR    The function call failed, error at the
 *                           communication attempt
 * @retval TAL_NOT_SUPPORTED Not supported for this type of device
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetMeasurementStatus(TAL_SessionHandleType sessionHandle,
                         TAL_MeasurementStatusType *pStatus);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getMeasurementStatus(TAL_MeasurementStatusType *pStatus) const;
#endif /* TAL_CXX_API */
/* @endcond */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Use TAL_SetDeviceOption with deviceOpt=TAL_EBHSCR_SET_BUF instead.
 * @brief supply receive buffers to TAL Library
 *
 * This function provides a pointer to a data area, where the received data
 * packets are stored. TAL_ProcessTargetData() reads packets from device
 * directly into the user provided buffer. Inside the measure data callback
 * the user application has to copy away data, because the data is only valid
 * inside this callback invocation. Another approach is to provide the next
 * buffer calling TAL_ProvideRxPacketBuffer() inside the measure data callback.
 * So the users provides a new buffer, thus the TAL will not access the
 * previously provided buffer any more.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB7200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pBuf Pointer to where the received data should be stored
 * @param size Size of the provided buffer
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_COMM_ERROR    The function call failed, error at the
 *                           communication attempt
 * @retval TAL_NOT_SUPPORTED Not supported for this type of device
 *
 * @note This function is currently only supported for EB7200.
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ProvideRxPacketBuffer(TAL_SessionHandleType sessionHandle,
                          uint8 *pBuf,
                          uint32 size);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
provideRxPacketBuffer(uint8 *pBuf, uint32 size) const;
#endif /* TAL_CXX_API */
/* @endcond */

/**
 *
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Use TAL_GetDeviceOption with deviceOpt=TAL_GET_TEMP_STATUS instead
 * @brief Get temperature status and fan speed
 *
 * This function receives the temperature status and fan speed
 * of the EB2200/EB5200/EB7200/EB8200 device.
 *
 * @li Domain: Host/Target
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param pStatus Pointer of a struct where the values of the
 *                temperature status and fan speed are stored
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_COMM_ERROR    The function call failed, error at the
 *                           communication attempt
 *
 * @note   This function is currently only supported for EB7200 and EB5200
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetTemperatureStatus(TAL_SessionHandleType sessionHandle,
                         TAL_TemperatureStatusType *pStatus);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getTemperatureStatus(TAL_TemperatureStatusType *pStatus) const;
#endif /* TAL_CXX_API */
/* @endcond */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_IsMeasurementStopped instead.
 * @endif
 * @endif
 *
 * @brief Checks if measurement is stopped successfully
 *
 * This function returns TAL_NOT_FINISHED between reception of
 * start-measurement and stop-measurement packet from the target. It shall be
 * used after TAL_StopMeasurement() to make sure that all measurement packets
 * were received from the target successfully before calling
 * TAL_StopProcessTargetDataThread() and TAL_DeleteSession().
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 *
 * @retval TAL_SUCCESS measurement is inactive. Stop-measurement packet was
 * received from target.
 * @retval TAL_NOT_FINISHED measurement is active. Start-measurement packet
 * was received from target.
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_CONNECTION The function call failed, no valid connection to target
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_IsMeasurementStopped(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
isMeasurementStopped() const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_RegisterForMeasurementData instead.
 * @endif
 * @endif
 *
 * @brief Register a measurement data callback
 *
 * This function registers a notification upon receiving the data from the
 * target.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 * @param pCallback pointer to callback function, called after the reception
 * of measurement data
 *
 * @retval TAL_SUCCESS    The function call executed successfully
 * @retval TAL_FAILED     The function call failed to execute
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_RegisterForMeasurementData(TAL_SessionHandleType sessionHandle,
                               TAL_MeasurementCallbackFunctionPointerType pCallback);
#else /* TAL_CXX_API */
#ifndef SWIG /* cant be wrapped to swig because of function callback. A easily
                wrappable function would read measurement data from a queue
                inside the TAL. */
virtual TAL_DEPRECATED TAL_ReturnType
registerForMeasurementData(TAL_MeasurementCallbackFunctionPointerType pCallback) const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_UnregisterForMeasurementData instead.
 * @endif
 * @endif
 *
 * @brief Unregister the measurement data callback
 *
 * This function removes the notification upon receiving measurement data from
 * the target.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @endif
 *
 * @retval TAL_SUCCESS    The function call executed successfully
 * @retval TAL_FAILED     The function call failed to execute
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_UnregisterForMeasurementData(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
#ifndef SWIG /* makes no sense to wrap this function if the accoring
                registration function cant be wrapped */
virtual TAL_DEPRECATED TAL_ReturnType
unregisterForMeasurementData() const;
#endif /* SWIG */
#endif /* TAL_CXX_API */

#ifdef TAL_CXX_API
/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API / measurement data class is deprecated. Please use the C TAL API function TAL_RegisterForMeasurementData to capture raw measurement data packets instead.
 * @endif
 * @endif
 *
 * @brief Register a measurement class data callback
 *
 * This function registers a notification upon receiving the data from the
 * target. It provides a pointer to class TAL_MeasureData with which the
 * received data is abstracted in a common way.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param pCallback pointer to callback function, called after the reception
 * of measurement data
 * @param pContext Context of calling function. Is returned within the callback.
 *
 * @retval TAL_SUCCESS    The function call executed successfully
 * @retval TAL_FAILED     The function call failed to execute
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 *
 * @sa TAL_MeasureData
 *
 */
#ifndef SWIG /* cant be wrapped to swig because of function callback. A easily
                wrappable function would read measurement data from a queue
                inside the TAL. */
virtual TAL_DEPRECATED TAL_ReturnType
registerForMeasurementDataClass(TAL_MeasurementClassCallbackFunctionPointerType pCallback,
                                void* pContext);
#endif /* SWIG */
#endif /* TAL_CXX_API */

#ifdef TAL_CXX_API
/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API / measurement data class is deprecated. Please change the application to make use of the newer PCAP-based logging instead.
 * @endif
 * @endif
 *
 * @brief Unregister the measurement class data callback
 *
 * This function removes the notification upon receiving measurement data from
 * the target.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @retval TAL_SUCCESS    The function call executed successfully
 * @retval TAL_FAILED     The function call failed to execute
 * @retval TAL_NO_SESSION The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef SWIG /* makes no sense to wrap this function if the accoring
                registration function cant be wrapped */
virtual TAL_DEPRECATED TAL_ReturnType
unregisterForMeasurementDataClass();
#endif /* SWIG */
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the error code of the last TAL_*MeasurementData* function
 *        call
 *
 * This function returns the error code of the last TAL_*Measurmenent*
 * function call.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval TAL error code of the last call to TAL_*MeasurementData* function
 *
 * @pre A session has to be established before calling this function.
 *
 */
TAL_API extern TAL_ReturnType
TAL_GetMeasurementDataLastError(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Major Number of the given measurement data packet
 *
 * This function returns the Major number of the given measurement data packet
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param pMeasurementData       Pointer to measurement data packet
 * @param nMeasurementDataLength Length of measurement data packet
 *
 * @retval Major number of given measurement data packet or
 *         TAL_Numbers::TAL_Major_Invalid in the case of an internal error.
 *
 * @pre A session has to be established before calling this function.
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 * @sa TAL_Numbers.h
 *
 */
TAL_API extern uint8
TAL_GetMeasurementDataMajor(const uint8 * pMeasurementData,
                            uint32 nMeasurementDataLength);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Minor Number of the given measurement data packet
 *
 * This function returns the Minor number of the given measurement data packet
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param pMeasurementData       Pointer to measurement data packet
 * @param nMeasurementDataLength Length of measurement data packet
 *
 * @retval Minor number of given measurement data packet or
 *         TAL_Numbers::TAL_Major_Invalid in the case of an internal error.
 *
 * @pre A session has to be established before calling this function.
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 * @sa TAL_Numbers.h
 *
 */
TAL_API extern uint8
TAL_GetMeasurementDataMinor(const uint8 * pMeasurementData,
                            uint32 nMeasurementDataLength);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Timestamp of the measurement data packet
 *
 * This function returns the Timestamp of the measurement data packet.
 * Depending on the packet the interpretation differs:
 * - FlexRay:    Absolut timestamp in [ns]
 * - CAN:        Absolut timestamp in [ns]
 * - LIN:        Absolut timestamp in [ns]
 * - Marker:     Seconds since 1.1.1970. On hardware without real-time clock
 *               (EB5200) seconds since power-on.
 * - Analog:     Absolut timestamp in [ns]
 * - Digital:    Absolut timestamp in [ns]
 * - Triggerout: Absolut timestamp in [ns]
 * - Control:    Absolut timestamp in [ns]
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Timestamp of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA    returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 * @note If you use the bPlus time as the time base, the bits 61, 62, 63 of
 *       the received time stamp are used to identify the time stamp as bPlus
 *       time. To get a correct time stamp, these bits should be masked out.
 */
TAL_API extern uint64
TAL_GetMeasurementDataTime(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Start Timestamp of the measurement data packet
 *
 * This function returns the Start Timestamp of the measurement data packet.
 * Depending on the packet the interpretation differs:
 * - FlexRay:    Absolut timestamp in [ns]
 * - CAN:        Absolut timestamp in [ns]
 * - LIN:        Absolut timestamp in [ns]
 * - Marker:     Seconds since 1.1.1970. On hardware without real-time clock
 *               (EB5200) seconds since power-on.
 * - Analog:     Absolut timestamp in [ns]
 * - Digital:    Absolut timestamp in [ns]
 * - Triggerout: Absolut timestamp in [ns]
 * - Control:    Absolut timestamp in [ns]
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Start Timestamp of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA    returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 * @note If you use the bPlus time as the time base, the bits 61, 62, 63 of
 *       the received time stamp are used to identify the time stamp as bPlus
 *       time. To get a correct time stamp, these bits should be masked out.
 */
TAL_API extern uint64
TAL_GetMeasurementDataStartTime(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Bus number of the measurement data packet
 *
 * This function returns the Bus number of the measurement data packet.
 * Depending on the packet the interpretation differs:
 * - FlexRay:      1
 * - CAN:          2
 * - LIN:          3
 * - Ethernet 0:   4
 * - Ethernet 1:   5
 * - Marker:     128
 * - Analog:     129
 * - Digital:    130
 * - Triggerout: 131
 * - Control:    132
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Bus number of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA    returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern uint8
TAL_GetMeasurementDataBus(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Channel number of the measurement data packet
 *
 * This function returns the Channel number of the measurement data packet.
 * Depending on the packet the interpretation differs:
 * - FlexRay:    1 = CC1_ChA; 2 = CC1_ChB; 4 = CC2_ChA; 8 = CC2_ChB;
 *               17 = CC3_ChA; 18 = CC3_ChB; 20 = CC4_ChA; 24 = CC4_ChB
 * - CAN:        1 = CH1; 2 = CH2; 3 = CH3; 4 = CH4;
 *               5 = CH5; 6 = CH6; 7 = CH7; 8 = CH8
 * - LIN:        1 = CH1; 2 = CH2; 3 = CH3; 4 = CH4
 * - Ethernet:   VLAN ID of the ethernet data packet
 *               -1 = undefined VLAN-ID
 *               positive Numbers = VLAN-ID
 * - Marker:     1 = TriggerMarker or GeneralMarker; 4 = User
 * - Analog:     1
 * - Digital:    1 = Value; 2 = DETI
 * - Triggerout: N/A
 * - Control:    N/A
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Channel number of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern uint8
TAL_GetMeasurementDataChannel(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Slot number of the measurement data packet
 *
 * This function returns the Slot number of the measurement data packet.
 * Depending on the packet the interpretation differs:
 * - FlexRay:    positive Numbers = FlexRay Slot;
 *               -1 = SymbolWindow;
 *               -2 = NetworkIdleTime
 * - CAN:        N/A
 * - LIN:        N/A
 * - Ethernet:   Source MAC address of the ethernet data packet
 *               -1 = invalid address
 *               positive Numbers = MAC address
 * - Marker:     N/A
 * - Analog:     N/A
 * - Digital:    N/A
 * - Triggerout: N/A
 * - Control:    N/A
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Slot number of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern sint64
TAL_GetMeasurementDataSlot(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Slot Status of the measurement data packet
 *
 * This function returns the Slot Status of the measurement data packet.
 * Depending on the packet the interpretation differs:
 * - FlexRay:    FlexRay Slot Status
 * - CAN:        N/A
 * - LIN:        N/A
 * - Ethernet:   VLAN priority of the ethernet data packet
 *               -1 = undefined VLAN priority
 *               bit0: drop data packet flag
 *               bit1..bit3: VLAN priority
 * - Marker:     N/A
 * - Analog:     N/A
 * - Digital:    N/A
 * - Triggerout: N/A
 * - Control:    N/A
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Slot Status of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern sint32
TAL_GetMeasurementDataSlotStatus(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Header of the measurement data packet
 *
 * This function returns the Header of the measurement data packet.
 * Depending on the packet the interpretation differs:
 * - FlexRay:    Bits from Frame Header
 * - CAN:        bit 0: remote transmission frame (0 = normal frame, 1 = remote frame)
 *               bit 1: CAN-FD frame (FDF) (0= normal CAN frame, 1 CAN-FD frame)
 *               bit 2: baud rate  switching (only for CAN-FD frames) (0 = no baud rate switching,
 *                      1 = baud rate switching)
 * - LIN:        1 = classic checksum; 2 = enhanced checksum
 * - Ethernet:   Ethertype of the ethernet data packet
 * - Marker:     N/A
 * - Analog:     N/A
 * - Digital:    N/A
 * - Triggerout: N/A
 * - Control:    1 = stop record; 2 = start record
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Header of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern uint32
TAL_GetMeasurementDataHeader(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the ID of the measurement data packet
 *
 * This function returns the ID of the measurement data packet.
 * Depending on the packet the interpretation differs:
 * - FlexRay:    0 - 2047 frame ID; -1 = Noise; -2 = Symbol; -3 = CAS;
 *               -4 = MTS; -5 = WUS; -6 = Bitstream
 * - CAN:        CAN ID; -1 = Unknown
 * @sa TAL_CanIdType on how to interpret the CAN-ID
 * - LIN:        LIN ID; -1 = Unknown; -2 = Wakeup
 * - Ethernet:   Destination MAC address of the ethernet data packet
 *               -1 = invalid address
 *               positive Numbers = MAC address
 * - Marker:     1 = TriggerMarker; 2 = GeneralMarker; UserDefined
 * - Analog:     N/A
 * - Digital:    N/A
 * - Triggerout: N/A
 * - Control:    N/A
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval ID of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern sint64
TAL_GetMeasurementDataId(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Cycle counter of the measurement data packet
 *
 * This function returns the Cycle counter of the measurement data packet.
 * Depending on the packet the interpretation differs:
 * - FlexRay:    Cycle counter from frame header
 * - CAN:        N/A
 * - LIN:        N/A
 * - Ethernet:   N/A
 * - Marker:     N/A
 * - Analog:     N/A
 * - Digital:    N/A
 * - Triggerout: N/A
 * - Control:    N/A
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Cycle counter of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern uint8
TAL_GetMeasurementDataCycleCount(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Header CRC of the measurement data packet
 *
 * This function returns the Header CRC of the measurement data packet.
 * Depending on the packet the interpretation differs:
 * - FlexRay:    Header CRC from frame
 * - CAN:        N/A
 * - LIN:        Checksum
 * - Ethernet:   N/A
 * - Marker:     N/A
 * - Analog:     N/A
 * - Digital:    N/A
 * - Triggerout: N/A
 * - Control:    N/A
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Header CRC of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern uint32
TAL_GetMeasurementDataHeaderCrc(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the length of the FlexRay, CAN, LIN and Ethernet message.
 *
 * This function returns the info of the FlexRay, CAN, LIN and Ethernet message.
 *
 * For FlexRay symbols this function returns the length in gdBit.
 * For LIN Wakeup symbols this function returns the legnth in us.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Length of the measurement data packet payload.
 * Depending on the packet interpretation differs:
 * - FlexRay:           Payload length in byte
 * - FlexRay Symbol:    Symbol length in gdBit
 * - FlexRay Bitstream: Length in Bit
 * - CAN:               Payload length in byte
 * - LIN:               Payload length in byte
 * - LIN Wakeup:        length in [us]
 * - Ethernet:          Payload length in byte
 * - Marker:            N/A
 * - Analog:            N/A
 * - Digital:           N/A
 * - Triggerout:        N/A
 * - Control:           N/A
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern uint32
TAL_GetMeasurementDataLength(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Payload Length of the measurement data packet
 *
 * This function returns the Payload Length of the measurement data packet.
 * Packets listed here do not have a payload:
 * - FlexRay Noise:      N/A
 * - FlexRay Symbol:     N/A
 * - FlexRay SlotStatus: N/A
 * - LIN Wakeup:         N/A
 * - Control:            N/A
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Payload Length of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern uint32
TAL_GetMeasurementDataPayloadLength(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Payload of the measurement data packet
 *
 * This function returns the Payload of the measurement data packet
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param sessionHandle     handle of the established session
 * @param PayloadBuffer     pointer to user provided buffer the payload is copied to
 * @param PayloadBufferSize length of the user provided buffer
 *
 * @retval Bytes copied to user provided buffer
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern uint32
TAL_GetMeasurementDataPayload(TAL_SessionHandleType sessionHandle,
                              uint8 * PayloadBuffer,
                              uint32 PayloadBufferSize);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Returns the Status of the measurement data packet
 *
 * This function returns the Status of the measurement data packet
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Status of the measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @section f_FlexRay FlexRay frame status
 * - Bit  0 Valid
 * - Bit  1 TSSVIOL
 * - Bit  2 HCRCERR
 * - Bit  3 FCRCERR
 * - Bit  4 FESERR
 * - Bit  5 FSSERR
 * - Bit  6 BSSERR
 * - Bit  7 BVIOL
 * - Bit  8 NITVIOL
 * - Bit  9 SWVIOL
 * - Bit 10 SOVERR
 * - Bit 11 NERR
 * - Bit 12 SYNCERR
 * - Bit 13 SUERR
 * - Bit 14 SUWSYERR
 * - Bit 15 FIDERR
 * - Bit 16 CCERR
 * - Bit 17 SPLERR
 * @section f_CAN CAN frame status
 * - Bit  0 Valid
 * - Bit  1 Stuff error
 * - Bit  2 Form error
 * - Bit  3 CRC error
 * @section f_LIN LIN frame status
 * - Bit  0 Valid
 * - Bit  1 SYN
 * - Bit  2 PAR
 * - Bit  3 RES
 * - Bit  4 DAT
 * - Bit  5 CHK
 * - Bit  6 STA
 * - Bit  7 STO
 * @section f_ETHERNET ETHERNET status
 * - Bit  0 Valid
 * - Bit  4 Tx Frame
 * - Bit  5 Tx Truncation
 * - Bit  6 Tx Underrun
 * - Bit  7 Tx Retransmission limit reached
 * - Bit  8 Tx Late collision detected
 * - Bit  9 Tx Defer indication
 * - Bit 12 Rx Frame
 * - Bit 13 Rx Truncation
 * - Bit 14 Rx Overrun
 * - Bit 15 Rx CRC Error
 * - Bit 16 Rx Short Frame
 * - Bit 17 Rx No octal alligned frame
 * - Bit 18 Rx Frame length violation
 * - Bit 19 Rx Multicast frame
 * - Bit 20 Rx Broadcast frame
 * - Bit 21 Rx Promiscuous mode
 * @section f_CONTROL control status
 * - 0x00 Start monitoring
 * - 0x01 Normal stop monitoring
 * - 0x02 Stop monitoring Invalid Packetsize
 * - 0x03 Stop monitoring Start Job failed
 * - 0x04 Stop monitoring Target connection lost
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern uint32
TAL_GetMeasurementDataStatus(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Checks if the measurement data packet is valid
 *
 * This function checks if the measurement data packet is valid.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: none
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param sessionHandle handle of the established session
 *
 * @retval Valid or Invalid measurement data packet
 *
 * @pre A session has to be established before calling this function.
 *
 * @note Use
 *       TAL_GetMeasurementDataLastError() afterwards to get the error code.
 *       TAL_SUCCESS   returned data of getter function is valid
 *       TAL_NO_DATA   returned data of getter function is invalid
 *
 * @note You shall use this function only in the context of a
 *       measurement data notification function previously registered with
 *       TAL_RegisterForMeasurementData()
 *
 */
TAL_API extern TAL_Boolean
TAL_IsMeasurementDataValid(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Initialize a thread to capture IP of clients connected to SrcIpAddr
 *
 * This function inializes a thread to caputre IP address of EB2200 devices connected to host
 * It can detect EB2200 connected via Ethernet or USB
 *
 * Supported Hardware: EB2200
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_FAILED        The thread failed to execute
 */
TAL_API extern TAL_ReturnType
TAL_GetEthDeviceInit(void);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief Initialize the pointer to the first captured EB devices
 *
 * This function initalizes iterator to the first captured EB devices.
 * This iterator will contain information once TAL_GetEthDeviceNext is called and a device is found.
 *
 * Supported Hardware: EB2200
 *
 * @param it pointer to the first element on the list of detected devices
 *
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NULL_POINTER  Error due to Passing a Null Pointer to the function
 */
TAL_API extern TAL_ReturnType
TAL_GetEthDeviceFirst(TAL_EthDiscoveryIterator *it);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief provides information about EB device connected to Ethernet/USB Interface
 *
 * The function will provide inforamtion on EB devices connected to Etherner or USB interfaces
 *
 * Supported Hardware: EB2200
 *
 * @param it pointer to device information on the latest returned device information
 * @param DeviceInfo pointer to device's IP address, host IP address and interface description
 *
 * @retval TAL_SUCCESS       The function call successfully returned with device's information
 * @retval TAL_NO_DATA       No new devices are discovered
 * @retval TAL_NULL_POINTER  Error due to Passing a Null Pointer to the function
 *
 * @note The function may need a couple of seconds after the first call to reterieve information
 *       on EB2200, depending on how fast the devices can respond. Time might increase if devices
 *       are connected through network
 */
TAL_API extern TAL_ReturnType
TAL_GetEthDeviceNext(TAL_EthDiscoveryIterator *it, TAL_EthDeviceInfoType* DeviceInfo);
#endif /* TAL_CXX_API */

#ifndef TAL_CXX_API
/**
 *
 * @brief calls class destructor of TAL_GetEthDeviceInit
 *
 * Supported Hardware: EB2200
 *
 */

TAL_API extern TAL_ReturnType
TAL_Close_GetEthDevice(void);
#endif /* TAL_CXX_API */


/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_OpenPcap instead.
 * @endif
 * @endif
 *
 * @brief opens a pcap file or a pcap named pipe for writing
 *
 * Use this function to write pcap data.
 * For wireshark live capture please use the named pipe options.
 * For writing to a file please use the file option.
 * You have to call this function either to open a file, a server pipe, or a
 * client pipe.
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @param sPath path to the named pipe or file (on Windows pipe names shall have a name like: \\\\\.\\pipe\\wireshark)
 *
 * @param opt Pcap options @sa TAL_PcapOptionType
 *
 * @param nSnaplen amount of data bytes that will be written to a pcap writer. For EB2200 and
 * EB5200, please use 262144. For EB7200 and EB8200 please use 7000000.
 *
 * @remark Named pipe support is currently only supported on Microsoft Windows
 *
 * @retval TAL_SUCCESS      The function call executed successfully
 * @retval TAL_FAILED       The function call failed to execute
 * @retval TAL_NO_SESSION   The function call failed, no valid session. Session is created
 *                          during a call to
 * @if TAL_C_API
 *                          #TAL_StartupDefault or #TAL_Startup functions.
 * @else
 *                          #startupDefault or #startup functions.
 * @endif
    * @retval TAL_NULL_POINTER The function call failed because a null pointer is
 *                          supplied where it is not allowed
 * @retval TAL_FILE_ACCESS_FAILED Unable to access provided filename
 *
 * @note Libpcap file format:\n
 * @code
 * |Global Header|Packet Header|Data Packet|Packet Header|Data Packet| ... |
 * @endcode
 * More info:\n  https://wiki.wireshark.org/Development/LibpcapFileFormat
 *
 * \b Example
 * \snippet Testing/TAL_legacy_FR/Register_Unregister_RecvSignal/src/host.cpp example_TAL_OpenPcap
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_OpenPcap(TAL_SessionHandleType sessionHandle,
             const char *sPath, TAL_PcapOptionType opt, unsigned int nSnaplen);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
openPcap(const char *sPath, TAL_PcapOptionType opt, unsigned int nSnaplen) const;
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_ClosePcap instead.
 * @endif
 * @endif
 *
 * @brief close an open pcap file or named pipe
 *
 * This closes the file or pipe handle
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute
 * @retval TAL_NO_SESSION   The function call failed, no valid session. Session is created
 *                          during a call to
 * @if TAL_C_API
 *                          #TAL_StartupDefault or #TAL_Startup functions.
 * @else
 *                          #startupDefault or #startup functions.
 * @endif

 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ClosePcap(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
closePcap() const;
#endif /* TAL_CXX_API */


/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_WriteToPcap instead.
 * @endif
 * @endif
 *
 * @brief write a packet to a pcap file
 *
 * During online or offline play data will be written to this file.
 * After closing the logfile it may be opened using wireshark for
 * offline analysis.
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200, VirtualBus
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @param pMeasureData      Pointer to measurement data packet
 *
 * @retval TAL_SUCCESS      The function call executed successfully
 * @retval TAL_NULL_POINTER The function call failed because a null pointer is
 *                          supplied where it is not allowed
 * @retval TAL_NO_SESSION   The function call failed, no valid session. Session is created
 *                          during a call to
 * @if TAL_C_API
 *                          #TAL_StartupDefault or #TAL_Startup functions.
 * @else
 *                          #startupDefault or #startup functions.
 * @endif

 */

#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_WriteToPcap(TAL_SessionHandleType sessionHandle, void *pMeasureData);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
writeToPcap(TalMeasureData *pMeasureData) const;
#endif /* TAL_CXX_API */

/**
 * @cond EXCLUDE_FROM_DOCU
 * @deprecated Use TAL_WriteEBHSCRToPcap instead
 *
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_WriteToPcapEBHSCR instead.
 * @endif
 * @endif
 *
 * @brief write a EBHSCR packet to a pcap file
 *
 * During online or offline play data will be written to this file.
 * After closing the logfile it may be opened using wireshark for
 * offline analysis.
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @param pData             Pointer to the data packet.
 *                          The data packet passed to this function,
 *                          consists of a Pcap Packet Header
 *                          (16 bytes) part and an EBHSCR packet part.
 *                          This way we avoid copying large buffers.
 *
 * @param length            Length of EBHSCR data packet in bytes,
 *                          not including 16 bytes of Pcap packet header
 *
 * @param utcTime           The UTC end-time of the data packet. utcTime is in uint64 format
 *
 * @retval TAL_SUCCESS      The function call executed successfully
 * @retval TAL_NULL_POINTER The function call failed because a null pointer is
 *                          supplied where it is not allowed
 * @retval TAL_NO_SESSION   The function call failed, no valid session. Session is created
 *                          during a call to
 * @if TAL_C_API
 *                          #TAL_StartupDefault or #TAL_Startup functions.
 * @else
 *                          #startupDefault or #startup functions.
 * @endif
 *
 * @note                    Timestamps in EBHSCR packets are zero based
 *                          nanosecond counter.
 *                          Whenever an EBHSCR packet is received,
 *                          the Pcap timestamp can be calculated by adding
 *                          the initial second offset to the timestamp
 *                          from the EBHSCR packet.
 *                          Initial seconds offset of Epoch is dependent on platform,
 *                          and can be calculated in Linux and Windows using time()
 *                          function from time.h
 *                          If XTSS functions are available, then the Pcap timestamp
 *                          can be synchronized to e.g. GPS second.
 *
 * @remarks                 EBHSCR packets can be very big (up to 7MB), to avoid
 *                          copying large packets receive buffers can be supplied
 *                          to the TAL Library from the application.
 *                          Use
 * @if TAL_C_API
 *                          #TAL_SetDeviceOption
 * @else
 *                          #setDeviceOption
 * @endif
 *                          with deviceOpt=#TAL_EBHSCR_SET_BUF,
 *                          after
 * @if TAL_C_API
 *                          #TAL_RegisterForMeasurementData().
 * @else
 *                          #registerForMeasurementData().
 * @endif
 *                          This function provides a pointer to a data area,
 *                          where the received data packets are stored.
 * @if TAL_C_API
 *                          #TAL_ProcessTargetData()
 * @else
 *                          #processTargetData()
 * @endif
 *                          reads packets from device
 *                          directly into the user provided buffer.
 *                          To further avoid copying data when calling the
 * @if TAL_C_API
 *                          #TAL_WriteToPcapEBHSCR(),
 * @else
 *                          #writeToPcapEBHSCR(),
 * @endif
 *                          payload has to be written to an offset which is
 *                          the size of Pcap Packet Header.
 *
 * \b Example
 * @code
 * #define PCAP_PACKET_HEADER_SIZE 16
 * static uint8 buffer[EBHSCR_MAX_PACKET_SIZE+PCAP_PACKET_HEADER_SIZE];
 * ...
 * // Set the EBHSCR buffer, and also reserve additional space (PCAP_PACKET_HEADER_SIZE) in the front of the measurement packet
 * //   to insert the PCAP-header later without a need for copying the whole EBHSCR buffer into a bigger buffer
 * TAL_DevOpt_Buffer opt;
 * opt.buf = buffer + PCAP_PACKET_HEADER_SIZE;
 * opt.size = sizeof(buffer) - PCAP_PACKET_HEADER_SIZE;
 * TAL_SetDeviceOption(sessionHandle, TAL_EBHSCR_SET_BUF, &opt, sizeof(opt));
 * ...
 * // In the EBHSCR measurement callback:
 * // pData is the pointer to the first byte of the EBHSCR measurement packet
 * // size is the length of the EBHSCR measurement packet
 * TAL_WriteToPcapEBHSCR(sessionHandle, const_cast<uint8*>(pData - PCAP_PACKET_HEADER_SIZE), size, utcTime);
 * @endcode
 */

#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_WriteToPcapEBHSCR(TAL_SessionHandleType sessionHandle, uint8 *pData, uint32 length, uint64 utcTime);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
writeToPcapEBHSCR( uint8 *pData, uint32 length, uint64 utcTime) const;
#endif /* TAL_CXX_API */
/* @endcond */

/**
 * @brief write a EBHSCR packet to a pcap file
 *
 * During online or offline play data will be written to this file.
 * After closing the logfile it may be opened using wireshark for
 * offline analysis.
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @param pEBHSCR           Pointer to the EBHSCR format data packet.
 *
 * @param utcTime           The UTC end-time of the data packet. utcTime is in uint64 format.
 *                          If 0, the time is taken out of the EBHSCR packet
 *
 * @retval TAL_SUCCESS      The function call executed successfully
 * @retval TAL_NULL_POINTER The function call failed because a null pointer is
 *                          supplied where it is not allowed
 * @retval TAL_NO_SESSION   The function call failed, no valid session. Session is created
 *                          during a call to
 * @if TAL_C_API
 *                          #TAL_StartupDefault or #TAL_Startup functions.
 * @else
 *                          #startupDefault or #startup functions.
 * @endif
 *
 */

#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_WriteEBHSCRToPcap(TAL_SessionHandleType sessionHandle, const struct ebhscr_ua *pEBHSCR, uint64 utcTime);
#endif /* TAL_CXX_API */
/* @endcond */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_IsPcapEOF instead.
 * @endif
 * @endif
 *
 * @brief check if EOF flag is set on pcap writer
 *
 * The pipe writer sets this flag if a client closes the pipe.
 * Instead of creating an error, the EOF flag is set. The file
 * writer currently does not set this flag.  This indicator is reset
 * every time openFile or openNamedPipe is called.
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @retval TAL_SUCCESS      The function call executed successfully. Pipe opened.
 * @retval TAL_NO_DATA      No data available, pipe closed
 * @retval TAL_NO_SESSION   The function call failed, no valid session.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_IsPcapEOF(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
isPcapEOF( void) const;
#endif /* TAL_CXX_API */

 /**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_IsPcapError instead.
 * @endif
 * @endif
 *
 * @brief check if Error flag is set on pcap writer
 *
 * Every error that occurs during writing to the file or the named
 * pipe is logged by setting the error count indicator. This
 * indicator is reset every time openFile or openNamedPipe is called.
 * If this flag is set the pcap logfile or pipe may be incomplete or
 * corrupted.
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 *
 * @retval TAL_SUCCESS      The function call executed successfully. Pipe opened.
 * @retval TAL_FAILED       An error occured
 * @retval TAL_NO_SESSION   The function call failed, no valid session.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_IsPcapError(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
isPcapError( void) const;
#endif /* TAL_CXX_API */

/**
 *
 * @brief Register a ebhscr data callback
 *
 * This function registers a notification upon receiving the data from the
 * target. Multiple callbacks can be registered with this function. The data
 * will be provided in ebhscr format.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @param sessionHandle handle of the established session
 * @param callback pointer to callback function, called after the reception
 * of measurement data
 * @param context Context of calling function. Is returned within the callback.
 *
 * @retval TAL_SUCCESS              The function call executed successfully
 * @retval TAL_INVALID_ARGUMENT     The function call failed, passed callback is invalid
 * @retval TAL_NO_BUFFER_AVAILABLE  The function call failed, too much callbacks registered
 * @retval TAL_NO_SESSION           The function call failed, no valid session
 *
 * @pre A session has to be established before calling this function.
 *
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_RegisterForRecvEBHSCR(
    TAL_SessionHandleType sessionHandle,
    TAL_EBHSCRCallbackType callback,
    void *context);
#endif /* TAL_CXX_API */

/**
 *
 * @brief Unregister a ebhscr data callback
 *
 * This function unregisters the callback function previously registered.
 *
 * @li Domain: Host
 * @li Calling: nonblocking
 * @li Callback: optional
 * @li Flush: implicit
 *
 * Supported Hardware: EB2200, EB5200, EB7200, EB8200
 *
 * @param sessionHandle handle of the established session
 * @param callback pointer to callback function, to be unregistered
 *
 * @retval TAL_SUCCESS              The function call executed successfully
 * @retval TAL_NOT_REGISTERED       The function call failed, passed callback was not registered
 *
 * @pre A session has to be established before calling this function.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_UnregisterForRecvEBHSCR(
    TAL_SessionHandleType sessionHandle,
    TAL_EBHSCRCallbackType callback);
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup Tresos DB related funtions

 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_OpenTresosDB instead.
 * @endif
 * @endif
 *
 * @brief creates a connection to a tresos db
 *
 * This function creates a database connection to a tresos db.
 * Needs to be called before any other TAL_TDB-function is called.
 * Once finished, the connection has to be closed with
 * TAL_TDB_CloseTresosDB.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pcDatabaseFilename
 * @retval TAL_SUCCESS        The function call executed successfully
 * @retval TAL_NO_SESSION     The function call failed, no valid session
 * @retval TAL_FAILED         The function call failed to execute:
 *                            There is already a open connection to a tresos db
 * @retval TAL_NULL_POINTER   The function call failed cause a null pointer is
 *                            supplied where it is not allowed
 * @retval TAL_FILE_NOT_FOUND unable to open provided filename
 *
 * @note  There can be only one active connection to a tresos db.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_OpenTresosDB(TAL_SessionHandleType sessionHandle,
                     const char * pcDatabaseFilename);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbOpenTresosDb(const char * pcDatabaseFilename);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_CloseTresosDB instead.
 * @endif
 * @endif
 *
 * @brief closes a previously opened connection to a tresos db
 *
 * This function closes the connection to the tresos db.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database could not be closed
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_CloseTresosDB(TAL_SessionHandleType sessionHandle);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbCloseTresosDb();
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_SignalNameToId instead.
 * @endif
 * @endif
 *
 * @brief Returns the signal index of a given signal label
 *
 * This functions returns the signal index of a provided signal label (or cluster and label).
 * If both (RX and TX) indices are available, the function returns
 * the TX index.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pSignalName        The signal label; it can either be SignalName, or ClusterName:SignalName
 * @param nId                The signal index of the provided signal label
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database access failed
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_INVALID_INDEX Signal-Label not found
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_SignalNameToId(TAL_SessionHandleType sessionHandle,
                       const char *pSignalName,
                       uint32 *nId);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbSignalNameToId(const char *pSignalName,
                  TalUInt *nId);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_RxSignalNameToId instead.
 * @endif
 * @endif
 *
 * @brief Returns the signal RX index of a given signal label
 *
 * This functions returns the signal RX index of a provided signal label (or cluster and label)
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pSignalName        The signal label; it can either be SignalName, or ClusterName:SignalName
 * @param nId                The signal index of the provided signal label
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database access failed
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_INVALID_INDEX Signal-Label not found
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_RxSignalNameToId(TAL_SessionHandleType sessionHandle,
                       const char *pSignalName,
                       uint32 *nId);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbRxSignalNameToId(const char *pSignalName,
                  TalUInt *nId);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_TxSignalNameToId instead.
 * @endif
 * @endif
 *
 * @brief Returns the signal TX index of a given signal label
 *
 * This functions returns the signal TX index of a provided signal label (or cluster and label)
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pSignalName        The signal label; it can either be SignalName, or ClusterName:SignalName
 * @param nId                The signal index of the provided signal label
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database access failed
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_INVALID_INDEX Signal-Label not found
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_TxSignalNameToId(TAL_SessionHandleType sessionHandle,
                       const char *pSignalName,
                       uint32 *nId);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbTxSignalNameToId(const char *pSignalName,
                  TalUInt *nId);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_PduNameToId instead.
 * @endif
 * @endif
 *
 * @brief Returns the pdu index of a given pdu label
 *
 * This functions returns the pdu index of a provided pdu label (or cluster and label).
 * If both (RX and TX) indices are available, the function returns
 * the TX index.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pPduName           The pdu label; it can either be PduName, or ClusterName:PduName
 * @param nId                The pdu index of the provided pdu label
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database access failed
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_INVALID_INDEX Signal-Label not found
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_PduNameToId(TAL_SessionHandleType sessionHandle,
                    const char *pPduName,
                    uint32 *nId);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbPduNameToId(const char *pPduName,
               TalUInt *nId);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_RxPduNameToId instead.
 * @endif
 * @endif
 *
 * @brief Returns the pdu RX index of a given pdu label (or cluster and label)
 *
 * This functions returns the pdu RX index of a provided pdu label
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pPduName           The pdu label; it can either be PduName, or ClusterName:PduName
 * @param nId                The pdu index of the provided pdu label
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database access failed
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_INVALID_INDEX Signal-Label not found
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_RxPduNameToId(TAL_SessionHandleType sessionHandle,
                    const char *pPduName,
                    uint32 *nId);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbRxPduNameToId(const char *pPduName,
               TalUInt *nId);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_TxPduNameToId instead.
 * @endif
 * @endif
 *
 * @brief Returns the TX pdu index of a given pdu label
 *
 * This functions returns the TX pdu index of a provided pdu label (or cluster and label)
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pPduName           The pdu label; it can either be PduName, or ClusterName:PduName
 * @param nId                The pdu index of the provided pdu label
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database access failed
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_INVALID_INDEX Signal-Label not found
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_TxPduNameToId(TAL_SessionHandleType sessionHandle,
                    const char *pPduName,
                    uint32 *nId);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbTxPduNameToId(const char *pPduName,
               TalUInt *nId);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_FrameNameToId instead.
 * @endif
 * @endif
 *
 * @brief Returns the frametriggering index of a given frametriggering label
 *
 * This functions returns the frametriggering index of a provided
 * frametriggering label (or cluster and label).If both (RX and TX) indices are available,
 * the function returns the TX index.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pFrameName         The frame label; it can either be FrameName, or ClusterName:FrameName
 * @param nId                The frametriggering index of the provided frame label
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database access failed
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_INVALID_INDEX Signal-Label not found
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_FrameNameToId(TAL_SessionHandleType sessionHandle,
                    const char *pFrameName,
                    TAL_BM_FrameIndexType *nId);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbFrameNameToId(const char *pFrameName,
               TalUInt *nId);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_RxFrameNameToId instead.
 * @endif
 * @endif
 *
 * @brief Returns the frametriggering RX index of a given frametriggering label
 *
 * This functions returns the frametriggering index of a provided
 * frametriggering label (or cluster and label).
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pFrameName         The frame label; it can either be FrameName, or ClusterName:FrameName
 * @param nId                The frametriggering index of the provided frame label
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database access failed
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_INVALID_INDEX Signal-Label not found
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_RxFrameNameToId(TAL_SessionHandleType sessionHandle,
                    const char *pFrameName,
                    TAL_BM_FrameIndexType *nId);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbRxFrameNameToId(const char *pFrameName,
               TalUInt *nId);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_TxFrameNameToId instead.
 * @endif
 * @endif
 *
 * @brief Returns the frametriggering TX index of a given frametriggering label
 *
 * This functions returns the frametriggering index of a provided
 * frametriggering label (or cluster and label).
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pFrameName         The frame label; it can either be FrameName, or ClusterName:FrameName
 * @param nId                The frametriggering index of the provided frame label
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database access failed
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_INVALID_INDEX Signal-Label not found
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_TxFrameNameToId(TAL_SessionHandleType sessionHandle,
                    const char *pFrameName,
                    TAL_BM_FrameIndexType *nId);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbTxFrameNameToId(const char *pFrameName,
               TalUInt *nId);
#endif /* TAL_CXX_API */


/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_TDB_ServiceNameToId instead.
 * @endif
 * @endif
 *
 * @brief Returns the service index of a given service label
 *
 * This functions returns the service index of a provided service label.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @if TAL_C_API
 * @param sessionHandle      handle of the established session
 * @endif
 * @param pServiceName       The service label
 * @param nId                The service index of the provided service label
 * @retval TAL_SUCCESS       The function call executed successfully
 * @retval TAL_NO_SESSION    The function call failed, no valid session
 * @retval TAL_FAILED        The function call failed to execute:
 *                           Database access failed
 * @retval TAL_NULL_POINTER  The function call failed cause a null pointer is
 *                           supplied where it is not allowed
 * @retval TAL_INVALID_INDEX Signal-Label not found
 *
 * @pre  Requires an open connection to a tresos db
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_TDB_ServiceNameToId(TAL_SessionHandleType sessionHandle,
                       const char *pServiceName,
                       uint32 *nId);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
tdbServiceNameToId(const char *pServiceName,
                   TalUInt *nId);
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup sd_functions Service discovery related functions
 * @{
 */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_SdSetState instead.
 * @endif
 * @endif
 *
 * @brief Set the state of a specific service
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle    handle of the established session
 * @endif
 * @param nId      Id of the service
 * @param state    State which the service shall change to
 *
 * @retval TAL_FAILED   Service discovery state change request failed
 * @retval TAL_SUCCESS  Service discovery state change request successful
 *
 * @note None.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_SdSetState(
    TAL_SessionHandleType sessionHandle,
    uint32 nId,
    TAL_BM_SdSetStateType state);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmSdSetState(uint32 nId,
             TAL_BM_SdSetStateType state) const;
#endif

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_BM_SdGetState instead.
 * @endif
 * @endif
 *
 * @brief Get the current state of a specific service
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param nId           Id of the service
 * @param state         Current state of the service
 * @param serviceType   Type of the service
 *
 * @retval TAL_INVALID_INDEX Given index is out of range
 * @retval TAL_FAILED        Current state could not be retrieved
 * @retval TAL_SUCCESS       Retrieval of current service state successful
 * *
 * @note None.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_SdGetState(
    TAL_SessionHandleType sessionHandle,
    uint32 nId,
    TAL_BM_SdCurrentStateType *state,
    TAL_BM_SdGetStateServiceType serviceType);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
bmSdGetState(uint32 nId,
             TalInt *state,
             TAL_BM_SdGetStateServiceType serviceType) const;
#endif

/**
 *
 * @brief Register a callback for service discovery state change
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established session
 * @endif
 * @param pCallback         Pointer to callback function
 *
 * @retval TAL_FAILED       Registration failed
 * @retval TAL_SUCCESS      Registration successful
 * *
 * @note None.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_BM_RegisterForCurrentState(
        TAL_SessionHandleType sessionHandle,
        TAL_SdCurrentStateEventCallbackFunctionPointerType pCallback);
#endif
/**
 * @}
 */

/**
 * @defgroup lin_functions LIN message based related functions
 * @{
 */

 /**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_LinConfigureChannel instead.
 * @endif
 * @endif
*
 * @brief initialise a lin hardware channel
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established sessionHandle
 * @endif
 * @param nLinCtrlIdx       index of lin controller, starting with 0
 * @param eBaudRate         lin channel baudrate (bits per second), e.g. 9600
 * @ifnot SWIG
 * @param pCallback         function pointer to receive handler
 * @endif
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_LinConfigureChannel(TAL_SessionHandleType sessionHandle,
                        uint8 nLinCtrlIdx,
                        uint32 eBaudRate,
                        TAL_LinCallbackFunctionPointerType pCallback);
#else /* TAL_CXX_API */
#ifdef SWIG
virtual TAL_DEPRECATED TAL_ReturnType
initLin(uint8 nLinCtrlIdx,
        uint32 eBaudRate);
#else /* SWIG */
virtual TAL_DEPRECATED TAL_ReturnType
initLin(uint8 nLinCtrlIdx,
        uint32 eBaudRate,
        TAL_LinCallbackFunctionPointerType pCallback = TAL_LinCallback);
#endif /* SWIG */
#endif /* TAL_CXX_API */

 /**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_LinCreateScheduleTable instead.
 * @endif
 * @endif
 *
 * @brief Creates an LIN schedule table
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established sessionHandle
 * @endif
 * @param nLinCtrlIdx    LIN controller index starting from 0
 * @param nIndex         LIN schedule table index
 * @param nSize          LIN schedule table size in units of LIN frames
 * @param nTimeBaseMs    LIN schedule table time base in ms
 *
 * @retval TAL_SUCCESS         The function call executed successfully
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 *
 * @note If the Schedule Table with given nIndex already exists it will
 *       be overwritten.
 *       All entries have to be set with function TAL_LinSetScheduleTableEntry()
 *
 * @sa TAL_LinSetScheduleTableEntry
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_LinCreateScheduleTable(TAL_SessionHandleType sessionHandle,
                           uint8 nLinCtrlIdx,
                           uint8 nIndex,
                           uint8 nSize,
                           uint32 nTimeBaseMs);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
createLinScheduleTableEntry(uint8 nLinCtrlIdx,
                            uint8 nIndex,
                            uint8 nSize,
                            uint32 nTimeBaseMs);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_LinSetScheduleTableEntry instead.
 * @endif
 * @endif
 *
 * @brief Sets an entry in the given LIN schedule table
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle         handle of the established sessionHandle
 * @param nLinCtrlIdx           LIN controller index starting from 0
 * @endif
 * @param nScheduleTableIndex   Index of Schedule Table in which the entry is
 *                              set
 * @param nIndex                Schedule Table entry index
 *
 * @if TAL_C_API
 * @param checksumModel         Enhanced or classic checksum
 * @param response              Determine whether the frames response is generated by
 *                              the master node or a slave node
 * @param nMessageId            The frames identifier. Parity-bits are calculated
 *                              by the controller
 * @param pData                 Pointer to payload buffer
 * @param nPayloadLength        Length of payload buffer
 * @param nDelayMs              The frames delay within the schedule table
 * @else
 * @param msg                   Frame to add to schedule table. Make sure to
 *                              set controller index, time, checksum model,
 *                              response type, payload, data length, time
 *                              offset and message id
 * @endif
 *
 * @retval TAL_SUCCESS         The function call executed successfully
 * @retval TAL_NULL_POINTER    pPdu must not be 0
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 *
 * @note This function updates also the PDU payload data.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_LinSetScheduleTableEntry(TAL_SessionHandleType sessionHandle,
                             uint8 nLinCtrlIdx,
                             uint8 nScheduleTableIndex,
                             uint8 nIndex,
                             TAL_Lin_FrameCsModelType checksumModel,
                             TAL_Lin_FrameResponseType response,
                             uint8 nMessageId,
                             const uint8 *pData,
                             uint8 nPayloadLength,
                             uint32 nDelayMs);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
setLinScheduleTableEntry(uint8 nScheduleTableIndex,
                         uint8 nIndex,
                         TalLinMsg *msg);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_LinStopScheduleTable instead.
 * @endif
 * @endif
 *
 * @brief Stop execution of the actual processed LIN Schedule Table
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established sessionHandle
 * @endif
 * @param nLinCtrlIdx          LIN controller index starting from 0
 *
 * @retval TAL_SUCCESS         The function call executed successfully
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 *
 * @note In Master Mode: The actual processed Schedule Table is processed to its end.
 *       In Slave Mode:  The actual processed Schedule Table is stopped.
 *
 * @remark Since the Schedule table is processed in an independent task, this
 *         function marks the table for termination. Depending on the size of
 *         the schedule table this may take some time after this function
 *         has returned.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_LinStopScheduleTable(TAL_SessionHandleType sessionHandle,
                         uint8 nLinCtrlIdx);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
stopLinScheduleTable(uint8 nLinCtrlIdx);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_LinExecuteScheduleTable instead.
 * @endif
 * @endif
 *
 * @brief Executes a given LIN Schedule Table on a LIN controller
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established sessionHandle
 * @endif
 * @param nLinCtrlIdx           LIN controller index starting from 0
 * @param nScheduleTableIndex   Schedule Table to execute
 * @param mode                  Schedule Table execution mode
 * @param nWakeupDelayMs        Delay after wakeup symbol to start communication
 *                              0 ... no wakeup is sent
 *
 * @retval TAL_SUCCESS         The function call executed successfully
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 *
 * @note Mode Continuous: The switch of the schedule table is done if the
 *       current schedule table has finished.
 *       Mode Once: If a continuous schedule table is running it is interrupted
 *       and resumed after the once schedule table has finished. If a once
 *       schedule table is running the new once schedule table is executed after
 *       the current has finished.
 *       There is no queueing for schedule tables if this function is called
 *       several times.
 *
 * @remark If nWakeupDelayMs != 0 before starting the scheduler a wakeup symbol
 *         is sent on the LIN bus in master mode only. After the wakeup symbol
 *         is sent the execution of the given schedule table is delayed by the
 *         given amount of time.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_LinExecuteScheduleTable(TAL_SessionHandleType sessionHandle,
                            uint8 nLinCtrlIdx,
                            uint8 nScheduleTableIndex,
                            TAL_Lin_ScheduleTableExecModeType mode,
                            uint32 nWakeupDelayMs);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
executeLinScheduleTable(uint8 nLinCtrlIdx,
                        uint8 nScheduleTableIndex,
                        TAL_Lin_ScheduleTableExecModeType mode,
                        uint32 nWakeupDelayMs);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_LinUpdateData instead.
 * @endif
 * @endif
 *
 * @brief Update data of a frame in the schedule table
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established sessionHandle
 * @param nLinCtrlIdx       LIN controller index starting from 0
 * @param nMessageId        LIN Header id for which the data is registered.
 * @param pPayload          Pointer to the payload data of the LIN response.
 * @param nPayloadLength    Length of the payload data.
 * @else
 * @param msg               Frame to update. Make sure that message id,
 *                          controller index, payload data and length are
 *                          set correctly. All other values are ignored.
 * @endif
 *
 * @retval TAL_SUCCESS         The function call executed successfully
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 *
 * @note None.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_LinUpdateData(TAL_SessionHandleType sessionHandle,
                  uint8 nLinCtrlIdx,
                  uint8 nMessageId,
                  const uint8 *pPayload,
                  uint8 nPayloadLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
updateLinMsg(TalLinMsg *msg);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_LinUpdateFrameResponseType instead.
 * @endif
 * @endif
 *
 * @brief Update the response type of a frame in the schedule table
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established sessionHandle
 * @param nLinCtrlIdx       LIN controller index starting from 0
 * @param nMessageId        LIN Header id for which the data is registered.
 * @param response          LIN Frame response type
 * @else
 * @param msg               Frame to update. Make sure that message id and
 *                          controller index are set correctly. All other
 *                          values are ignored.
 * @endif
 *
 * @retval TAL_SUCCESS         The function call executed successfully
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 *
 * @note None.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_LinUpdateFrameResponseType(TAL_SessionHandleType sessionHandle,
                               uint8 nLinCtrlIdx,
                               uint8 nMessageId,
                               TAL_Lin_FrameResponseType response);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
updateLinFrameResponseType(TalLinMsg *msg);
#endif /* TAL_CXX_API */


/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_GetLinFifoEntry instead.
 * @endif
 * @endif
 *
 * @brief Read an element out of the LIN Fifo
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle             handle of the established sessionHandle
 * @param pnLinCtrlIdx              LIN controller index is stored here if not NULL
 * @param pStatus                   Status flags are stored here if not NULL
 * @param pChecksumModel            Type of received checksum is stored here if not NULL
 * @param pnMessageId               The frames message id is stored here if not NULL
 * @param pData                     Pointer to buffer, where data can be stored
 * @param nDataLength               Length of available buffer
 * @param pnReceivedPayloadLength   Received payload length if not NULL
 * @else
 * @param msg                       All relevant data are stored in this object.
 *                                  This include: controller index, status flags,
 *                                  checksum model, message id, data and data length.
 * @endif
 *
 * @retval TAL_SUCCESS         The function call executed successfully
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *                             encoding a package
 * @retval TAL_NO_DATA         Fifo is currently empty
 * @if TAL_C_API
 * @retval TAL_NULL_POINTER    pData can not be null
 * @else
 * @retval TAL_NULL_POINTER    msg object can not be null
 * @endif
 *
 * @note None.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetLinFifoEntry(TAL_SessionHandleType sessionHandle,
                    uint8 *pnLinCtrlIdx,
                    TAL_Lin_StatusType *pStatus,
                    TAL_Lin_FrameCsModelType *pChecksumModel,
                    uint8 *pnMessageId,
                    uint8 *pData,
                    uint8 nDataLength,
                    uint8 *pnReceivedPayloadLength);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
getLinFifoEntry(TalLinMsg *msg);
#endif /* TAL_CXX_API */

/**
 * @ifnot TAL_C_API
 * @ifnot SWIG
 * @deprecated Deprecated in 21.06.
 * The C++ TAL API is deprecated. Please use the equivalent C TAL API function TAL_LinPrintScheduleTable instead.
 * @endif
 * @endif
 *
 * @brief prints out the schedule table to the error queue in human readable form
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @if TAL_C_API
 * @param sessionHandle     handle of the established sessionHandle
 * @endif
 * @param nLinCtrlIdx       print schedule table for this LIN controller index
 *
 * @retval TAL_SUCCESS         The function call executed successfully
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR  The function call failed due to an error when
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_LinPrintScheduleTable(TAL_SessionHandleType sessionHandle,
                          uint8 nLinCtrlIdx);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
printLinScheduleTable(uint8 nLinCtrlIdx);
#endif /* TAL_CXX_API */

/**
 * @}
 */


/**
 * @cond EXCLUDE_FROM_DOCU
 * @brief Send binary packet to TAL
 *
 * This function may be used to simulate packets for any current and future EB
 * device. Only use this function if you know the binary packet format of the
 * EB device you want to simulate.
 *
 * This function is not included in user documentation because it is considered
 * internal and should only be used to test the TAL.
 *
 * Supported Hardware: None. This function is used to simulate any EB device,
 * for component-testing TAL.
 *
 * @param pPacket pointer to the packet which shall be sent; the caller is
 * responsible for providing the correct packet format: EBHSCR for EB7200 and
 * EB8200, TAL protocol primitives for EB2200 and EB5200.
 *
 * @if TAL_C_API
 * @param sessionHandle handle of the established session
 * @param length length in bytes of the packet
 * @endif
 *
 * @retval TAL_SUCCESS The function call executed successfully
 *
 * @retval TAL_NO_SESSION The function call failed, no valid session. You may
 * use a dummy session.
 *
 * @retval TAL_NULL_POINTER mandatory argument was a null pointer
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/SwScope/src/main.cpp example_TAL_SendResponse
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SendResponse(TAL_SessionHandleType sessionHandle,
                 const unsigned char * pPacket,
                 unsigned int length);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
sendResponse(const TalByteArray * pPacket) const;
#endif /* TAL_CXX_API */
/* @endcond */

/**
 * @cond EXCLUDE_FROM_DOCU
 * @brief Configure target for asynchronous-only single channel FlexRay-Monitoring
 *
 * Configure target for asynchronous-only single channel FlexRay-Monitoring
 *
 * Supported Hardware: EB2200, EB5200, VirtualBus
 *
 * @param eFrChEnableMask Unused. Use any value (e.g. TAL_CHANNEL_AA)
 * @sa TAL_FRChannelType
 *
 * @param ePhysicalLayerType Unused. Use any value (e.g.
 * TAL_PHYSICAL_LAYER_TYPE_UNKNOWN).
 *
 * @param gdBit          FlexRay Bitduration [us]
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspConfigureFlexRaySingleChannel(TAL_SessionHandleType sessionHandle,
                                      TAL_FRChannelType     eFrChEnableMask,
                                      TAL_PhysicalLayerType ePhysicalLayerType,
                                      float32               gdBit);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureFlexRaySingleChannel(TAL_FRChannelType     eFrChEnableMask,
                                  TAL_PhysicalLayerType ePhysicalLayerType,
                                  float32               gdBit ) const;
#endif /* TAL_CXX_API */
/* @endcond */

/**
 * @if TAL_C_API
 * @brief Load TCS file for Virtualbus
 *
 * With EB 2200 / EB 5200 based hardware, the TCS file is embedded into the TTC file and is automatically loaded.
 * With VirtualBus, the TCS file requires separate handling. This function manually loads the TCS file which is required for the correct conversion of values.
 *
 * Supported Hardware: VirtualBus
 *
 * @param sessionHandle handle of the established session
 * @param sTcsFile Path to the TCS file
 *
 * @retval TAL_SUCCESS          The function call executed successfully
 * @retval TAL_NO_SESSION       The provided session handle is invalid
 * @retval TAL_FAILED           The function call failed to open and read
 *                              the file specified.
 * @retval TAL_NO_CONVERSION    The function failed to get the conversion table.
 * @endif
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_LoadTcsFile(TAL_SessionHandleType sessionHandle,
                const char * sTcsFile);
#endif /* TAL_CXX_API */

/**
 * @cond EXCLUDE_FROM_DOCU
 * @brief Configure trigger out pins
 *
 * Configure trigger out pins
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param nPinNumber     Pin Index (0-3)
 * @param FrameStatusChA FlexRay Frame-Status on Channel A
 * @param FrameStatusChB FlexRay Frame-Status on Channel B
 * @param Timing         Timing events
 *                         1 = AP Ch A
 *                         2 = AP Ch B
 *                         4 = SS Ch A
 *                         8 = SS Ch B
 *                        16 = NIT Start
 *                        32 = SW start
 *                        64 = Dyn Segment start
 *                       128 = Cycle start
 *                       256 = Minislot
 *                       512 = Macrotick
 * @param Mode           0 = Continuous
 *                       1 = Single shot
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspConfigureOutPins(TAL_SessionHandleType sessionHandle,
                         int nPinNumber,
                         int FrameStatusChA,
                         int FrameStatusChB,
                         int Timing,
                         int Mode);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspConfigureOutPins(int nPinNumber,
                     int FrameStatusChA,
                     int FrameStatusChB,
                     int Timing,
                     int Mode) const;
#endif /* TAL_CXX_API */
/* @endcond */

/**
 * @cond EXCLUDE_FROM_DOCU
 * @brief Arm trigger out pin
 *
 * Arm trigger out pin
 *
 * Supported Hardware: EB2200, EB5200
 *
 * @param nPinNumber     Pin Index (0-3)
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_InspArmOutPins(TAL_SessionHandleType sessionHandle,
                   int nPinNumber);
#else /* TAL_CXX_API */
virtual TAL_DEPRECATED TAL_ReturnType
inspArmOutPins(int nPinNumber) const;
#endif /* TAL_CXX_API */
/* @endcond */

/*
 * Not exported to public scripting api.
 */
#ifndef SWIG

/*
 * @cond EXCLUDE_FROM_DOCU
 * C++-Only API which shall not go into documentation (unreleased API) goes in here.
 */
#ifdef TAL_CXX_API
virtual void
setSessionHandle(TAL_SessionHandleType sessionHandleArg);
#endif /* TAL_CXX_API */
/* @endcond */


/**
 * @if TAL_C_API
 *
 * @brief Updates firmware
 *
 * This function updates the firmware.
 *
 *
 * Supported Hardware: EB7200, EB8200
 *
 * @param sessionHandle     handle of the established session
 * @param filename          file to be flashed to the target
 * @param flags             supports various options for flashing on a bit-basis
 *                              TAL_FWUP_BULKERASE  ==> performs a bulk erase for the FPGA
 *                              TAL_FWUP_FORCE      ==> a force flag that bypasses the module configuration-check
 * @param callback          callback function with two parameter;
 *                              (percentage) returns the progress of the firmwareupdate operation in percentage
 *                              (FWUpdateStatus) returns text on the status of firmwareupdate operations such as bulk erase
 *                          recommended function definition:
 *                              if ((FWUpdateStatus != NULL) && (FWUpdateStatus[0] != '\0'))
 *                              {
 *                                  printf("%s\n",FWUpdateStatus);
 *                              }
 *                              else
 *                              {
 *                                  printf("Progress = %d%%\r", flashPercentage);
 *                                  fflush(stdout);
 *                              }
 *                          Alternatively NULL can be used as a parameter instead of callback function
 *
 * @retval TAL_SUCCESS         Firmware update successfully performed
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_INCOMPATIBLE_HARDWARE      The function call failed, hardware is not compatible with supplied files
 * @retval TAL_FILE_NOT_FOUND      The function call failed, file is not found
 * @retval TAL_INVALID_FILE_FORMAT      The function call failed, an invalid file format is supplied
 *
 * @note None.
 *
 * @invariant None.
 *
 * @post None.
 *
 * @remarks None.
 *
 * @endif
 */

#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
    TAL_FirmwareUpdate(TAL_SessionHandleType sessionHandle, const char* filename, uint32 flags, void (*callback)(uint8 percentage, const char* FWUpdateStatus));
#endif /* TAL_CXX_API */


/**
 * @if TAL_C_API
 * @brief searches a specific folder for compatible FPGA designs
 *
 * This function searches a specific folder for compatible FPGA designs
 *
 *
 * Supported Hardware: EB7200, EB8200
 *
 * @param sessionHandle     handle of the established session
 * @param directory         Directory to be searched
 * @param CompatBinFiles    outputs path(s) to FPGA designs compatible with connected target device
 *                          paths are separated with a new line (\n)
 * @param CompatBinFilesLength allocated memory size for CompatBinFiles output
 * @param IsNewestVersion   if set, only latest comptabile FPGA design is returned to CompatBinFiles parameter
 * @param IsGolden          if set, the function searches for golden designs. Else it searches for conventional productive FPGA designs.
 *
 * @retval TAL_SUCCESS         Firmware search successfully performed
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 * @retval TAL_COMM_ERROR      The function call failed due to a error in the
 *                             communication
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 * @retval TAL_FILE_NOT_FOUND      The function call failed, file is not found
 * @retval TAL_INVALID_FILE_FORMAT      The function call failed, an invalid file format is supplied
 *
 * @note None.
 *
 * @invariant None.
 *
 * @post None.
 *
 * @remarks None.
 *
 * @endif
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
    TAL_FirmwareSearch(TAL_SessionHandleType sessionHandle, const char* directory, char* CompatBinFiles, uint32 CompatBinFilesLength, TAL_Boolean IsNewestVersion, TAL_Boolean IsGolden);
#endif /* TAL_CXX_API */

/**
 * @if TAL_C_API
 * @brief sets a directory required by TAL_FirmwareUpdate function
 *
 * This function defines the directory where the TAL_FirmwareUpdate function
 * searches for golden FPGA file. This is required for some processes that
 * are carried out in the background.
 * The default directory used by TAL_FirmwareUpdate is the same directory as \p filename
 * and if no files are found, it searches "..\..\Firmwares_and_FPGA_Designs" folder
 * which is conventionally available inside the Essentials package.
 * This function TAL_SetFirmwareBaseDir needs to be called only if firmware update functionality is used outside
 * the Essentials package
 *
 *
 * Supported Hardware: EB7200, EB8200
 *
 * @param sessionHandle     handle of the established session
 * @param Path              Directory to be set
 *
 * @retval TAL_SUCCESS         Firmware search successfully performed
 * @retval TAL_NO_SESSION      The function call failed, no valid session
 *
 * @note None.
 *
 * @invariant None.
 *
 * @post None.
 *
 * @remarks None.
 *
 * @endif
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SetFirmwareBaseDir(TAL_SessionHandleType sessionHandle, const char* Path);
#endif /* TAL_CXX_API */


/**
 * @defgroup hbr_functions Host-based RBS related functions
 * @{
 */

/**
 * @brief Initializes the Hostbased RBS by using the supplied configuration files.
 *
 * @param sessionHandle Handle of the established session to the SD device
 * @param serviceConfig Path to the configuration file which holds information about services that shall be used by the Hostbased RBS
 * @param networkConfig Path to the configuration file which holds information about the network devices that shall be used by the Hostbased RBS

 * @retval TAL_SUCCESS      Initialization successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed, check the paths of the provided configuration files
 *
 * \b Example
 * @code
 *   if (TAL_HBR_Init(<sessionHandle>, "config/RBS.json", "config/Network.json") == TAL_SUCCESS)
 *   {
 *       // Proceed...
 *   }
 * @endcode
 *
 * @note Note that the session passed to the HBR_Init function needs to be the session where the target application, which
 * provides the SOME/IP SD information, has been loaded to. The passed session handle is only supported if the RBS uses
 * the TAL link driver. This means that the Host-based RBS can communicate with the RBS that does the SD communication
 * (classic RBS) solely over TAL functions, and does not need any external network ports
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_Init(TAL_SessionHandleType sessionHandle, const char* serviceConfig, const char* networkConfig);
#endif /* TAL_CXX_API */

/**
 * @brief Shuts the Hostbased RBS down
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 *
 * @retval TAL_SUCCESS      Shutdown was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed
 *
 * \b Example
 * @code
 *   if (TAL_HBR_DeInit(<sessionHandle>) == TAL_SUCCESS)
 *   {
 *       // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_DeInit(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

/**
 * @brief Adds a session to the Host-based RBS. This session will be used as an additional communication device and will
 * support sending and receiving.
 *
 * @param hbrSessionHandle Handle of the session that was used to initialize the HBR
 * @param deviceSessionHandle Handle of the session to the device that should be added
 *
 * @retval TAL_SUCCESS      Shutdown was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed
 *
 * \b Example
 * @code
 *   if (TAL_HBR_AddSession(<hbrSessionHandle>, <deviceSessionHandle>) == TAL_SUCCESS)
 *   {
 *       // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_AddSession(TAL_SessionHandleType hbrSessionHandle, TAL_SessionHandleType deviceSessionHandle);
#endif /* TAL_CXX_API */

/**
 * @brief Instructs the Hostbased RBS to provide/offer a new service. Also sets up all needed components to
 * service configured events and methods. This information is taken from the serviceConfig provided during
 * initialization.
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 * @param serviceId     Service Id of the service that shall be provided
 * @param instanceId    Instance Id of the service that shall be provided
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed
 *
 * \b Example
 * @code
 *   if (TAL_HBR_ProvideService(<sessionHandle>, 0xd066, 0x01) == TAL_SUCCESS)
 *   {
 *       // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_ProvideService(TAL_SessionHandleType sessionHandle, uint16 serviceId, uint16 instanceId);
#endif /* TAL_CXX_API */

/**
 * @brief Instructs the Hostbased RBS to provide/offer all services. Also sets up all needed components to
 * service configured events and methods. This information is taken from the serviceConfig provided during
 * initialization.
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed
 *
 * \b Example
 * @code
 *   if (TAL_HBR_ProvideAllServices(<sessionHandle>) == TAL_SUCCESS)
 *   {
 *       // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_ProvideAllServices(TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

/**
 * @brief Instructs the Hostbased RBS to require a new service.  Also sets up all needed components to
 * service configured events and methods. This information is taken from the serviceConfig provided during
 * initialization.
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 * @param serviceId     Service Id of the service that is required
 * @param instanceId    Instance Id of the service that is required
 * @param ipAddress     IP address identifying the ECU the service shall be required from (source)
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed
 *
 * \b Example
 * @code
 *   if (TAL_HBR_RequireService(<sessionHandle>, 0xd066, 0x01, "192.168.0.1") == TAL_SUCCESS)
 *   {
 *       // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_RequireService(TAL_SessionHandleType sessionHandle, uint16 serviceId, uint16 instanceId, const char* ipAddress);
#endif /* TAL_CXX_API */

/**
 * @cond @EXCLUDE_FROM_DOCU
 */

/**
 * @brief Constructs a new buffer with the provided size in which payload for SOME/IP Pdus can be stored in.
 * This function has to be used for the complete sending API of the Hostbased RBS. One must not provide a self-allocated
 * buffer to the sending functions of the Hostbased RBS.
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 * @param payloadSize   Size of the buffer that is needed
 * @param pOut          Pointer pointing to the first byte of the allocated buffer
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_RequestBuffer(TAL_SessionHandleType sessionHandle, size_t payloadSize, uint8** pOut);
#endif /* TAL_CXX_API */

/* @endcond */

/**
 * @brief Sends the PDU contained in the payload of the EBHSCR header. The EBHSCR header must be of type PDU.
 * For SOME/IP, the SoAd header needs to be prepended to the PDU.
 *
 * Please consult the HBR user guide for further information about mandatory information that needs to be filled out in
 * the EBHSCR header.
 *
 * Note that this function might block if one of the following conditions are met:
 * - The timestamp given exceeds the configured advance time, that was set by calling TAL_ReplayInit()
 * - The interface is overloaded
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 * @param pEbhscrPdu Pointer to the EBHSCR header containing the to-be-sent PDU as payload
 * @param pBuffer Optional buffer object which contains the ebhscrPdu and can be used by the HBR to avoid copies. Not used at the moment - provide nullptr or NULL
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed, incorrect EBHSCR header
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 **/
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_SendPdu(TAL_SessionHandleType sessionHandle, uint64* pEbhscrPdu, TAL_HBR_Buffer* pBuffer);
#endif /* TAL_CXX_API */

/**
 * @brief Registers the provided callback to be called when a new client subscribes to the service specified. The
 * callback is only called for the first subscribed client, not for every new subscribed one. If all clients
 * unregister from the service, and then one subscribes again, the callback is also called.
 * The callback is only issued after the client subscribe has been acknowledged.
 * If the service is already subscribed at the time of the callback registration, the callback is issued immediately.
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 * @param serviceId     ServiceId identifying the service that the registration shall be activated for
 * @param instanceId    InstanceId identifying the service that the registration shall be activated for
 * @param eventGroupId  EventgroupId of the EventGroup in the service that the registration shall be activated for
 * @param callback      Callback that shall be called when the first client subscribes
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed
 *
 * \b Example
 * @code
 *   // Definition of the callback
 *   void subscribedClientCallback(TAL_SessionHandleType sessionHandle, uint16_t serviceId, uint16_t instanceId, uint16_t eventgroupId)
 *   {
 *       // ...
 *   }
 *
 *   // Registering for subscribed clients
 *   if (TAL_HBR_RegisterForSubscribedClient(<sessionHandle>, 0xd066, 0x1, 0x1, subscribedClientCallback) == TAL_SUCCESS)
 *   {
 *      // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_RegisterForSubscribedClient(TAL_SessionHandleType sessionHandle, uint16 serviceId, uint16 instanceId, uint16 eventGroupId, TAL_HBR_ClientSubscribedCallbackType callback);
#endif /* TAL_CXX_API */

/**
 * @brief Unregisters from notifications about newly subscribed clients for the given service.
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 * @param serviceId     ServiceId identifying the service that the registration shall be deactivated for
 * @param instanceId    InstanceId identifying the service that the registration shall be deactivated for
 * @param eventGroupId  EventgroupId of the EventGroup in the service that the registration shall be deactivated for
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed
 *
 *  \b Example
 * @code
 *   if (TAL_HBR_UnregisterForSubscribedClient(<sessionHandle>, 0xd066, 0x1, 0x1) == TAL_SUCCESS)
 *   {
 *      // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_UnregisterForSubscribedClient(TAL_SessionHandleType sessionHandle, uint16 serviceId, uint16 instanceId, uint16 eventGroupId);
#endif /* TAL_CXX_API */

/**
 * @brief Registers the provided callback to be called when the specified service becomes available. Becoming
 * available means that the service is being offered. If the registration is issued when the service has already
 * been offered before, the callback is called immediately. A registered callback will only be called once.
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 * @param serviceId     ServiceId identifying the service that the registration shall be activated for
 * @param instanceId    InstanceId identifying the service that the registration shall be activated for
 * @param callback      Callback that shall be called when the service is offered
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed
 *
 * \b Example
 * @code
 *   // Definition of the callback
 *   void serviceAvailableCallback(TAL_SessionHandleType sessionHandle, uint16 serviceId, uint16 instanceId)
 *   {
 *       // ...
 *   }
 *
 *   // Registering for service availability
 *   if (TAL_HBR_RegisterForServiceAvailability(<sessionHandle>, 0xd066, 0x1, serviceAvailableCallback) == TAL_SUCCESS)
 *   {
 *      // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_RegisterForServiceAvailability(TAL_SessionHandleType sessionHandle, uint16 serviceId, uint16 instanceId, TAL_HBR_ServiceAvailableCallbackType callback);
#endif /* TAL_CXX_API */

/**
 * @brief Unregisters from notifications about the availability of the provided service
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 * @param serviceId     ServiceId identifying the service that the registration shall be deactivated for
 * @param instanceId    InstanceId identifying the service that the registration shall be deactivated for
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed
 *
 * \b Example
 * @code
 *   if (TAL_HBR_UnregisterForServiceAvailability(<sessionHandle>, 0xd066, 0x1) == TAL_SUCCESS)
 *   {
 *      // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_UnregisterForServiceAvailability(TAL_SessionHandleType sessionHandle, uint16 serviceId, uint16 instanceId);
#endif /* TAL_CXX_API */

/**
 * @brief Registers the provided callback for receival of all method related PDUs (Message Type: REQUEST (0x00) or REQUEST_NO_RETURN (0x01))
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 * @param callback Callback that shall be called with EBHSCR Pdu
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 *
 * \b Example
 * @code
 *   // Definition of the callback
 *   void MethodPduRecvCallback(TAL_SessionHandleType sessionHandle, const uint64* ebhscrPdu)
 *   {
 *       // ...
 *   }
 *
 *   // Register for receival of method request PDUs
 *   if (TAL_HBR_RegisterForRecvPduAllMethods(<sessionHandle>, MethodPduRecvCallback) == TAL_SUCCESS)
 *   {
 *      // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_RegisterForRecvPduAllMethods(TAL_SessionHandleType sessionHandle, TAL_HBR_PduReceivedCallbackType callback);
#endif /* TAL_CXX_API */

/**
 * @brief Unregisters from the notification about all method related PDUs
 *
 * @param sessionHandle Handle of the established session that was used to initialize the HBR or was added using the AddSession function
 * @param callback Callback that was used to register
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 *
 * \b Example
 * @code
 *   // Definition of the callback
 *   void MethodPduRecvCallback(TAL_SessionHandleType sessionHandle, const uint64* ebhscrPdu)
 *   {
 *       // ...
 *   }
 *
 *   // Unregister from the receival of method request PDUs
 *   if (TAL_HBR_UnregisterForRecvPduAllMethods(<sessionHandle>, MethodPduRecvCallback) == TAL_SUCCESS)
 *   {
 *      // Proceed...
 *   }
 * @endcode
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_HBR_UnregisterForRecvPduAllMethods(TAL_SessionHandleType sessionHandle, TAL_HBR_PduReceivedCallbackType callback);
#endif /* TAL_CXX_API */

/**
 * @}
 */


/**
 * @defgroup replay Replay functions
 * @{
 */

/**
 * @brief Determines the current device time, adds a default 'maximum advance'
 * time to it, calculates the difference of this sum to the current replay time
 * and stores it internally as correction factor for all further time shifting.
 *
 * @param sessionHandle handle of the established session
 * @param currentReplayTimeNs current replay time in nanosecconds
 * @param advanceTimeNs advance time in nanoseconds
 * @param pTimeOffsetNs correction factor in nanoseconds
 *
 * @retval TAL_SUCCESS      Function call was successful
 * @retval TAL_NO_SESSION   The function call failed, no valid session
 * @retval TAL_FAILED       The function call failed
 * @retval TAL_NO_DATA      The function call failed, because no valid time state was received from the
 *                          target yet. In this case, call the function, after some wait time (e.g.100ms), again.
 *
 * @note If the value of the argument \p advanceTimeNs is 0, the default replay value of 500ms is used instead.
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ReplayInit(
    TAL_SessionHandleType sessionHandle,
    uint64 currentReplayTimeNs,
    uint64 advanceTimeNs,
    sint64 *pTimeOffsetNs);
#endif /* TAL_CXX_API */

/**
 * @brief Initalization function for following sessions.
 *
 * @param sessionHandle handle of the established session
 * @param timeOffsetNs correction factor in nanoseconds
 * @param advanceTimeNs advance time in nanoseconds
 *
 * @retval TAL_SUCCESS      Function call was successful
 *
 * @note If the value of the argument \p advanceTimeNs is 0, the default replay value of 500ms is used instead.
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ReplayInitFollower(
    TAL_SessionHandleType sessionHandle,
    sint64 timeOffsetNs,
    uint64 advanceTimeNs);
#endif /* TAL_CXX_API */

/**
 * @brief This function takes a timed or best-effort EBHSCR packet, performs
 * timeshifting if necessary. May block if the maximum advance time has not been
 * achieved. Modifies the given EBHSCR packet by writing the timeshifted timestamp
 * to the header in order to avoid copying the whole packet.
 *
 * @param sessionHandle handle of the established session
 * @param pEBHSCR EBHSCR packet
 *
 * @retval TAL_SUCCESS           Function call was successful
 * @retval TAL_NULL_POINTER      The function call failed cause a null pointer
 *                               is supplied where it is not allowed
 * @retval TAL_NO_SESSION        The function call failed, no valid session
 * @retval TAL_ENCODING_ERROR    The function call failed due to an error when
 *                               encoding a package
 * @retval TAL_COMM_ERROR        The function call failed due to a error in the
 *                               communication
 * @retval TAL_INVALID_ARGUMENT  EBHSCR header information contains invalid
 *                               protocol information. For now, CAN and Ethernet
 *                               are supported.
 * @retval TAL_NOT_FINISHED      Replay has been stopped, before the packet had
 *                               been transmitted.
 *
 * @note If the EBHSCR packet contains an FCS, it is going to be ignored and recalculated
 * by the hardware. If the EBHSCR Packet contains an FCS, the respective flag in the
 * EBHSCR header must be set.
 *
 * @note The given EBHSCR header is modified. If it should be re-used, please make sure to
 * reset the start timestamp field in the EBHSCR header.
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ReplayEBHSCR(
    TAL_SessionHandleType sessionHandle,
    struct ebhscr * pEBHSCR);
#endif /* TAL_CXX_API */

/**
 * @brief Stop all blocking replays.
 *
 * This function may be called to stop all pending replay actions.
 * You have to call TAL_ReplayInit()/TAL_ReplayInitFollower again when you
 * want to restart replaying.
 *
 * @param sessionHandle handle of the established session
 *
 * @retval TAL_SUCCESS           Function call was successful
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ReplayStop(
    TAL_SessionHandleType sessionHandle);
#endif /* TAL_CXX_API */

/**
 * @brief Check if a timed packet with the given timestamp would be blocked
 * on the given channel because the intended replay time is too far in the future.
 * The intended replay time is checked against the current replay time + advance time.
 * If the intended replay time would exceed the current replay time + advance time,
 * a sleep is necessary. The required sleep time is provided with the output parameter
 * waitTimeNs.
 *
 * @param sessionHandle handle of the established session
 * @param intendedReplayTimeNs Intended replay time (replay time, no target time)
 * @param waitTimeNs The time that needs to be waited in nanoseconds until the
 * frame could be replayed without violating the advance time. Is set to 0 in
 * case the advance time is not being violated.
 *
 * @retval TAL_SUCCESS          The function call executed successfully
 * @retval TAL_FAILED           Error occurred during function call
 * @retval TAL_NO_SESSION       The function call failed, no valid session
 * @retval TAL_OVERFLOW         The function calculated a wait time which is
 *                              unrealistically large.
 * @retval TAL_NULL_POINTER     The function call failed cause a null pointer
 *                              is supplied where it is not allowed
 * @retval TAL_NO_DATA          The function call failed, because no valid time
 *                              state was received from the target yet. In this case,
 *                              call the function again.
 * @retval TAL_NOT_SUPPORTED    The function is currently not supported
 *
 * @pre A session has to be established before calling this function. Target Data needs
 * to be processed (either by calling the respective function, or by using the thread
 * provided by the TAL)
 *
 * @note This API function is considered to be work-in-progress. If you use it,
 * you may have to adapt your application for future releases of this API.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_ReplayCheckAdvanceTime(
    TAL_SessionHandleType sessionHandle,
    uint64 intendedReplayTimeNs,
    uint64 * waitTimeNs);
#endif /* TAL_CXX_API */

/**
 * @}
 */

/**
 * @defgroup SecOC SecOC related functions (prototype)
 * @{
 */

/**
 *
 * @brief Gets the crypto Context for the given crypto algorithm.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param Algo The crypto algorithm which shall be used.
 * @param CryptoContext The Address of a void pointer where the Context will be stored.
 * @param Key The key for the crypto.
 *
 * @retval TAL_SUCCESS        The function call executed successfully
 * @retval TAL_FAILED         The function call failed to execute
 *
 * \note
 * Null pointers are not supported.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SecOC_CryptoInit(
    TAL_Crypto_AlgorithmType Algo,
    const uint8 *Key,
    void **CryptoContext);
#endif /* TAL_CXX_API */

/**
 *
 * @brief Frees all memory allocated in TAL_SecOC_CryptoInit
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param CryptoContext Pointer to the crypto context which shall be freed
 *
 * @retval TAL_SUCCESS        The function call executed successfully
 * @retval TAL_FAILED         The function call failed to execute
 *
 * \note
 * Null pointers are not supported.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SecOC_CryptoDeinit(void *CryptoContext);
#endif /* TAL_CXX_API */

/**
 *
 * @brief Generates the secured PDU using the given configuration.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param Profile The SecOC Security profile which determines all needed parameters.
 * @param CryptoContext The Cryptocontext holding the key.
 * @param DataId The Data ID for the corresponding I-PUD
 * @param FreshnessValue The freshness value for the corresponding I-PDU.
 * @param AuthenticPDU Pointer to the Authentic I-PDU
 * @param AuthenticPDULength Length of the Authentic I-PDU
 * @param SecuredPDU Pointer to the secured I-PDU
 * @param SecuredPDULength Input and output parameter. As an input, it provides the size of the SecuredPDU array.
 *                         The function would change the value of this parameter to the actual length of the
 *                         generated secured PDU
 *
 * @retval TAL_SUCCESS        The function call executed successfully
 * @retval TAL_FAILED         The function call failed to execute
 *
 * \note
 * Null pointers are not supported.
 * Call TAL_SecOC_CryptoInit before this function to get the CryptoContext.
 * The Secured PDU is composed of (header + authentic PDU + cryptographic PDU)
 * The CryptographicPDU can be directly extracted from the Secured PDU with an offset
 * (Profile->HeaderLength + AuthenticPDULength)
 * For a more detailed explanation see Example.
 *
 * \b Example
 * \snippet ESW/HostDriver/TargetAccessLibrary/unittests/TopHalf/SecOC/src/test_TAL_API_SecOC.cpp example_TAL_SecOC_Generate
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SecOC_Generate(
    const TAL_SecOC_ProfileType *Profile,
    const void *CryptoContext,
    uint16 DataId,
    uint64 FreshnessValue,
    const uint8 *AuthenticPDU,
    uint32 AuthenticPDULength,
    uint8 *SecuredPDU,
    uint32 *SecuredPDULength);
#endif /* TAL_CXX_API */

/**
 *
 * @brief verifies the Secured I-PDU and give back the authentic I-PDU on success.
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param Profile The SecOC Security profile which determines all needed parameters.
 * @param CryptoContext The Cryptocontext holding the key.
 * @param DataId The Data ID for the corresponding I-PUD
 * @param FreshnessValue Address of Freshness Value from the receiver side
 * @param SecuredPDU Pointer to the start of the secured I-PDU
 * @param SecuredPDULength Length of the secured I-PDU
 * @param AuthenticPDU Pointer to the pointer of the memory where the authentic I-PDU is stored
 * @param AuthenticPDULength Pointer to the memory where the length of the authentic I-PDU will be stored.
 *
 * @retval TAL_SUCCESS          The verification of the PDU was successful.
 * @retval TAL_BUFFER_TOO_SMALL SecuredPDULength is smaller than required length for secured PDU.
 * @retval TAL_FAILED           The verification of the PDU failed.
 *
 * \note
 * Null pointers are not supported.
 * No message linker checks are carried out in this function. 
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SecOC_Verify_SecuredPDU(
    const TAL_SecOC_ProfileType *Profile,
    const void *CryptoContext,
    uint16 DataId,
    uint64 FreshnessValue,
    const uint8 *SecuredPDU,
    uint32 SecuredPDULength,
    const uint8 **AuthenticPDU,
    uint32 *AuthenticPDULength);
#endif /* TAL_CXX_API */

/**
 * @brief Checks if the message linker in the cryptographic PDU matches the authentic PDU.
 * If they match, the function verifies the cryptographic PDU
 *
 * Supported Hardware: Software implementation in TAL, no hardware dependencies
 *
 * @param Profile The SecOC Security profile which determines all needed parameters.
 * @param CryptoContext The Cryptocontext holding the key.
 * @param DataId The Data ID for the corresponding I-PUD
 * @param FreshnessValue Address of Freshness Value from the receiver side
 * @param AuthenticPDU Pointer to the start of the authentic I-PDU.
 * @param AuthenticPDULength The length of the authentic I-PDU.
 * @param CryptographicPDU Pointer to the start of the cryptographic I-PDU.
 * @param CryptographicPDULength The length of the cryptographic I-PDU.
 *
 * @retval TAL_SUCCESS        The function call executed successfully
 * @retval TAL_DONT_MATCH     The message linker do not match
 * @retval TAL_FAILED         The verification of cryptographic PDU failed
 *
 * @note Null pointers are not supported.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SecOC_Verify_CryptoPDU(
    const TAL_SecOC_ProfileType *Profile,
    const void *CryptoContext,
    uint16 DataId,
    uint64 FreshnessValue,
    const uint8 *AuthenticPDU,
    uint32 AuthenticPDULength,
    const uint8 *CryptographicPDU,
    uint32 CryptographicPDULength);
#endif /* TAL_CXX_API */

/**
 * @}
 */

/*
 * @brief Send a packet to the target device
 *
 * This function does directly and immediately send an ebhscr packet to the
 * target device, without checking buffer fill levels. If you need a higher
 * layer function considering advance time and buffer fill levels please
 * consider using TAL_ReplayEBHSCR instead.
 *
 * Supported Hardware: EB2200, EB5200, EB7200
 *
 * @param sessionHandle Handle of the established session.
 * @param pEBHSCR       Pointer to the EBHSCR packet struct.
 *
 * @retval TAL_SUCCESS              The function call executed successfully
 * @retval TAL_FAILED               Error occurred during function call
 * @retval TAL_NO_SESSION           The function call failed, no valid session
 * @retval TAL_NO_CONNECTION        The function call failed, no valid
 *                                  connection to target
 * @retval TAL_NULL_POINTER         The function call failed cause a null
 *                                  pointer is supplied where it is not allowed
 * @retval TAL_NO_BUFFER_AVAILABLE  The transmit queue to the target is
 *                                  currently blocked and the request should
 *                                  be re-tried after some time
 * @retval TAL_NOT_SUPPORTED        The function is currently not supported
 * @retval TAL_INVALID_ARGUMENT     One or more arguments contain invalid
 *                                  values
 *
 * @note For EB7200 and EB8200, this function does not interpret nor check
 *       packet contents, only the payload length is read according to the
 *       EBHSCR specification. For EB2200 and EB5200, only Ethernet or CAN
 *       packets are supported for now.
 *
 * @pre A session has to be established before calling this function.
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_SendEBHSCR(
    TAL_SessionHandleType sessionHandle,
    const struct ebhscr * pEBHSCR);
#endif /* TAL_CXX_API */

/**
 * @cond EXCLUDE_FROM_DOCU
 * @brief Get index of PCI device for a given serial number
 *
 * This function takes a EB device serial number and returns the PCI device
 * index of the device with this serial number if present, otherwise
 * TAL_FAILED.
 *
 * @li Domain: Host
 * @li Calling: blocking
 * @li Callback: none
 *
 * Supported Hardware: EB5200, EB7200
 *
 * @param pDeviceIndex Index of the found device
 * @param nBoardSerialNumber Serial number of board to look for
 *
 * @retval TAL_SUCCESS The function call executed successfully
 * @retval TAL_FAILED  The function call failed to execute or the device
 *                     with the given serial number could not be found.
 * @retval TAL_NOT_SUPPORTED  The function is currently not supported
 * @retval TAL_NULL_POINTER    The function call failed cause a null pointer
 *                             is supplied where it is not allowed
 *
 */
#ifndef TAL_CXX_API
TAL_API extern TAL_ReturnType
TAL_GetPCIDeviceIndex(TAL_DeviceIndexType * pDeviceIndex,
                      uint32 nBoardSerialNumber);
#endif/* TAL_CXX_API */
/* @endcond */


#endif /* SWIG */

#if (defined __cplusplus) && (!defined TAL_CXX_API)
} /* extern "C" */
#endif

#ifdef TAL_CXX_API
}; /* class TAL */
#endif /* TAL_CXX_API */

#endif /* _TAL_H_ */
