/**
 * File    : TAL_MeasureData.h
 *
 * Module  : TAL_MeasureData
 *
 * Description: Header of TAL_MeasureData class
 *
 * Copyright 2002-2012 Elektrobit Austria GmbH, http://www.elektrobit.com
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Elektrobit Austria GmbH ("Confidential Information").
 *
 * You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms and
 * conditions of the License Agreement you entered into with
 * Elektrobit Austria GmbH.
 *
 * Remarks :
 *
 * PLATFORM DEPENDANT [yes/no]: no
 * TO BE CHANGED BY USER [yes/no]: no
 *
 */

#ifndef _TAL_MEASUREDATA_H_
#define _TAL_MEASUREDATA_H_

/******************************************************************************
 Include Section
******************************************************************************/
#include "TAL_Types.h"


/******************************************************************************
 Global Macros
******************************************************************************/


/******************************************************************************
 Global Data Types
******************************************************************************/


/**
 * @brief timestamp correction factor source
 *
 * @typedef TAL_InspTimeCorrSource
 *  Define the source of the timestamp correction factor for the UTC time
 */
typedef enum
{
     TAL_INSP_TIME_CORR_SOURCE_NONE = 0
    /**< there is no time corection source */
    ,TAL_INSP_TIME_CORR_SOURCE_HOST_CLOCK = 1
    /**< use local host clock as time correction source */
    ,TAL_INSP_TIME_CORR_SOURCE_RTC = 2
    /**< use real-time clock on target as time correction source */
    ,TAL_INSP_TIME_CORR_SOURCE_GPS = 3
    /**< use GPS clock on target as time correction source */
    ,TAL_INSP_TIME_CORR_SOURCE_GPS_UTC = 4
    /**< use GPS clock (UTS timestamp format) on target as time correction source */
} TAL_InspTimeCorrSource;

/// @brief Data unit type
typedef enum
{
     TAL_CLEAR  = 0 ///< Clear communication data
    ,TAL_ALIVE  = 1 ///< Alive packet
    ,TAL_FRAME  = 2 ///< Frame
    ,TAL_PDU    = 3 ///< Protocol Data Unit
    ,TAL_SIGNAL = 4 ///< Signal
    ,TAL_MUXPDU = 5 ///< Multiplexed PDU
} TAL_DataType;

/// @brief Bus type
typedef enum
{
     TAL_BUS_UNKNOWN    =   0 ///< @brief Unknown Protocol. Not used.
    ,TAL_FLEXRAY    =   1 ///< @brief FlexRay
    ,TAL_CAN        =   2 ///< @brief Controller Area Network
    ,TAL_LIN        =   3 ///< @brief Local Interconnect Network
    ,TAL_ETHERNET   =   4 ///< @brief Ethernet Network
    ,TAL_ETHERNET2  =   5 ///< @brief Ethernet Network2 (multiple controller functionality)
    ,TAL_MARKER     = 128 ///< @brief Embedded Logging user defined markers
    ,TAL_ANALOG     = 129 ///< @brief Analog Input/Output
    ,TAL_DIGITAL    = 130 ///< @brief Digital Input/Output
    ,TAL_TRIGGEROUT = 131 ///< @brief Trigger out event
    ,TAL_CONTROL    = 132 ///< @brief Control event
    ,TAL_GPS        = 133 ///< @brief GPS NMEA data
}TAL_BusType;

/// @brief CAN header bits
typedef enum
{
     TAL_CAN_RTR    = 0x01 ///< @brief Remote transmission request
    ,TAL_CAN_FDF    = 0x02 ///< @brief FD frame
    ,TAL_CAN_FD_BRS = 0x04 ///< @brief Baud rate switching
    ,TAL_CAN_FD_ESI = 0x08 ///< @brief ESI flag
}TAL_CanHdrType;


/// @brief Ethernet status
typedef enum
{
     TAL_ETHERNET_VALID           = 0x00000001 ///< @brief Valid Ethernet frame
    ,TAL_ETHERNET_TX_FR_INDICATOR = 0x00000010 ///< @brief Tx Frame
    ,TAL_ETHERNET_TX_TR_INDICATOR = 0x00000020 ///< @brief Tx Truncation
    ,TAL_ETHERNET_TX_UN_INDICATOR = 0x00000040 ///< @brief Tx Underrun
    ,TAL_ETHERNET_TX_RL_INDICATOR = 0x00000080 ///< @brief Tx Retransmission limit reached
    ,TAL_ETHERNET_TX_LC_INDICATOR = 0x00000100 ///< @brief Tx Late collision detected
    ,TAL_ETHERNET_TX_DI_INDICATOR = 0x00000200 ///< @brief Tx Defer indication
    ,TAL_ETHERNET_RX_FR_INDICATOR = 0x00001000 ///< @brief Rx Frame
    ,TAL_ETHERNET_RX_TR_INDICATOR = 0x00002000 ///< @brief Rx Truncation
    ,TAL_ETHERNET_RX_OV_INDICATOR = 0x00004000 ///< @brief Rx Overrun
    ,TAL_ETHERNET_RX_CR_INDICATOR = 0x00008000 ///< @brief Rx CRC Error
    ,TAL_ETHERNET_RX_SH_INDICATOR = 0x00010000 ///< @brief Rx Short Frame
    ,TAL_ETHERNET_RX_NO_INDICATOR = 0x00020000 ///< @brief Rx Non octal alligned frame
    ,TAL_ETHERNET_RX_LG_INDICATOR = 0x00040000 ///< @brief Rx Frame length violation
    ,TAL_ETHERNET_RX_MC_INDICATOR = 0x00080000 ///< @brief Rx Multicast frame
    ,TAL_ETHERNET_RX_BC_INDICATOR = 0x00100000 ///< @brief Rx Broadcast frame
    ,TAL_ETHERNET_RX_PM_INDICATOR = 0x00200000 ///< @brief Rx Promiscuous mode
} TAL_EthernetStatusType;

/// @name CAN message status
typedef enum
{            
     TAL_CAN_VALID          = 0x0001 ///< @brief Valid CAN message
    ,TAL_CAN_STUFF_ERROR    = 0x0002 ///< @brief Stuff error
    ,TAL_CAN_FORM_ERROR     = 0x0004 ///< @brief Form error
    ,TAL_CAN_CRC_ERROR      = 0x0008 ///< @brief CRC error
    ,TAL_CAN_ACK_ERROR      = 0x0010 ///< @brief Acknowledge error
    ,TAL_CAN_BIT0_ACK_ERROR = 0x0020 ///< @brief Bit 0 or acknowledge error
    ,TAL_CAN_BIT1_ERROR     = 0x0040 ///< @brief Bit 1 error
} TAL_CanStatusType;

/// @name FlexRay id
typedef enum
{

     TAL_FLEXRAY_MIN                  =    1   ///< @brief Lowest FlexRay frame identifier
    ,TAL_FLEXRAY_MAX                  = 2047   ///< @brief Highest FlexRay frame identifier
    ,TAL_FLEXRAY_UNKNOWN              =   -1   ///< @brief Unknown FlexRay identifier (e.g. Noise)
    ,TAL_FLEXRAY_SYMBOL               =   -2   ///< @brief FlexRay symbol
    ,TAL_FLEXRAY_CAS                  =   -3   ///< @brief FlexRay Collision avoidance symbol
    ,TAL_FLEXRAY_MTS                  =   -4   ///< @brief FlexRay Media access test symbol
    ,TAL_FLEXRAY_WUS                  =   -5   ///< @brief FlexRay Wakeup symbol
    ,TAL_FLEXRAY_BITSTREAM            =   -6   ///< @brief FlexRay Bitstream
    ,TAL_FLEXRAY_DATA_OVERFLOW        =   -7  ///< @brief FlexRay Data measurement channel overflow
    ,TAL_FLEXRAY_SLOTSTATUS_OVERFLOW  =   -8  ///< @brief FlexRay Slot Status measurement channel overflow
} TAL_FlexRayIdType;

typedef enum
{
/// @name FlexRay frame status
     TAL_FLEXRAY_VALID     = 0x0001  ///< @brief Valid FlexRay frame
    ,TAL_FLEXRAY_TSSVIOL   = 0x0002  ///< @brief Transmission start sequence violation
    ,TAL_FLEXRAY_HCRCERR   = 0x0004  ///< @brief Header CRC error
    ,TAL_FLEXRAY_FCRCERR   = 0x0008  ///< @brief Frame CRC error
    ,TAL_FLEXRAY_FESERR    = 0x0010  ///< @brief Frame end sequence error
    ,TAL_FLEXRAY_FSSERR    = 0x0020  ///< @brief Frame start sequence error
    ,TAL_FLEXRAY_BSSERR    = 0x0040  ///< @brief Byte start sequence error
    ,TAL_FLEXRAY_BVIOL     = 0x0080  ///< @brief Boundary violation
    ,TAL_FLEXRAY_NITVIOL   = 0x0100  ///< @brief Network idle time violation
    ,TAL_FLEXRAY_SWVIOL    = 0x0200  ///< @brief Symbol window violation
    ,TAL_FLEXRAY_SOVERR    = 0x0400  ///< @brief Slot overbooked error
    ,TAL_FLEXRAY_NERR      = 0x0800  ///< @brief Nullframe in dynamic segment error
    ,TAL_FLEXRAY_SYNCERR   = 0x1000  ///< @brief Sync frame in dynamic segment error
    ,TAL_FLEXRAY_SUERR     = 0x2000  ///< @brief Startup frame in dynamic segment error
    ,TAL_FLEXRAY_SUWSYERR  = 0x4000  ///< @brief Sync or startup frame in dynamic segment error
    ,TAL_FLEXRAY_FIDERR    = 0x8000  ///< @brief Frame identifier error 
    ,TAL_FLEXRAY_CCERR     = 0x10000 ///< @brief Cycle counter error 
    ,TAL_FLEXRAY_SPLERR    = 0x20000 ///< @brief Static payload length error

} TAL_FlexRayStatusType;

/// @name FlexRay header bits

typedef enum
{            
     TAL_FLEXRAY_STARTUP_FRAME_INDICATOR    = 0x01  ///< @brief Startup frame indicator
    ,TAL_FLEXRAY_SYNC_FRAME_INDICATOR       = 0x02  ///< @brief Sync frame indicator
    ,TAL_FLEXRAY_NULL_FRAME_INDICATOR       = 0x04  ///< @brief Null frame indicator. Attention inverse logic: If this bit is set it is not a NULL Frame!
    ,TAL_FLEXRAY_PAYLOAD_PREAMBLE_INDICATOR = 0x08  ///< @brief Payload preamble indicator
    ,TAL_FLEXRAY_RESERVED                   = 0x10  ///< @brief Reserved bit

} TAL_FlexRayHdrStatusType;

/// @brief Ethernet packet without VLAN-ID
#define TAL_ETHERNET_UNDEFINED_VLAN -1

/******************************************************************************
 Forward Declarations
******************************************************************************/
class TalByteArray;

/******************************************************************************
 Classes
******************************************************************************/

class TAL_API TalMeasureData
{

    friend class TalPPMeasureData;

public:
    /*
     * public methods
     */

    /**
     * @brief Constructor
     */
    TalMeasureData();

    /**
     * @brief Destructor
     */
    virtual ~TalMeasureData();

    /**
     *
     * @brief Get Major number of measurement data packet
     *
     * Get Major number of measurement data packet. The major number can be used to
     * determine the kind of packet.
     *
     * @retval Major number of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa TAL_Numbers.h
     * @sa GetLastError
     *
     */
    virtual uint8 GetMajor( void );

    /*
     * @brief Set the major number of measurement data packet.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetMajor( uint8 );

    /**
     *
     * @brief Get Minor number of measurement data packet
     *
     * Get Minor number of measurement data packet
     *
     * @retval Minor number of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa TAL_Numbers.h
     * @sa GetLastError
     *
     */
    virtual uint8  GetMinor( void );

    /*
     * @brief Set the minor number of measurement data packet.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetMinor( uint8 );

    /**
     *
     * @brief Get End-Timestamp of measurement data packet
     *
     * Get End-Timestamp of measurement data packet. 
     * Depending on the measurement data packet the interpretation differs:
     * - FlexRay:    Absolut End-timestamp in [ns]
     * - CAN:        Absolut End-timestamp in [ns]
     * - LIN:        Absolut End-timestamp in [ns]
     * - Ethernet:   Absolut End-timestamp in [ns]
     * - Marker:     Seconds since 1.1.1970. On hardware without real-time clock
     *               (EB5200) seconds since power-on.
     * - Analog:     Absolut timestamp in [ns]
     * - Digital:    Absolut timestamp in [ns]
     * - Triggerout: Absolut timestamp in [ns]
     * - Control:    Absolut timestamp in [ns]
     *
     * @retval Timestamp of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     */
    virtual uint64 GetTime( void );

    /*
     * @brief Set the timestamp
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetTime( uint64 );

    /**
     *
     * @brief Get end-timestamp of measurement data packet as UTC time
     *
     * Get End-Timestamp of measurement data packet. Deliver it in units of nanoseconds.
     * If possible, deliver the time relative to Jan 1st, 1970.
     *
     * @retval Timesetamp of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     * @deprecated This function is only for old inspector functionality.
     * Should not be used anymore!
     */
    virtual uint64 GetUTCTime( void );

    /*
     * @brief Set the UTC time.
     *
     * @param nUTCTime The UTC end-time of the data packet given
     *        in nanoseconds from Jan 1st, 1970.
     *
     * @attention This method is not part of the public API.
     *
     * @deprecated This function is only for old inspector functionality.
     * Should not be used anymore!
     */
    virtual void SetUTCTime( uint64 nUTCTime );

    /**
     *
     * @brief Get Start-Timestamp of measurement data packet
     *
     * Get Start-Timestamp of measurement data packet. 
     * Depending on the measurement data packet the interpretation differs:
     * - FlexRay:    Absolut start-timestamp in [ns]
     * - CAN:        Absolut start-timestamp in [ns]
     * - LIN:        Absolut start-timestamp in [ns]
     * - Ethernet    Absolut start-timestamp in [ns]
     * - Marker:     Seconds since 1.1.1970. On hardware without real-time clock
     *               (EB5200) seconds since power-on.
     * - Analog:     Absolut timestamp in [ns]
     * - Digital:    Absolut timestamp in [ns]
     * - Triggerout: Absolut timestamp in [ns]
     * - Control:    Absolut timestamp in [ns]
     *
     * @retval Timestamp of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     */
    virtual uint64 GetStartTime( void );

    /*
     * @brief Set the start time.
     *
     * @param nStartTime The start-time of the data packet.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetStartTime( uint64 nStartTime );

    /**
     *
     * @brief Get start-timestamp of measurement data packet as UTC time
     *
     * Get Start-Timestamp of measurement data packet. Deliver it in units of
     * nanoseconds.  If possible, deliver the time relative to Jan 1st, 1970.
     *
     * @retval Timestamp of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     * @deprecated This function is only for old inspector functionality.
     * Should not be used anymore!
     */
    virtual uint64 GetUTCStartTime( void );

    /*
     * @brief Set the UTC start-time.
     *
     * @param nUTCStartTime The UTC start-time of the data packet given
     *        in nanoseconds from Jan 1st, 1970.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetUTCStartTime( uint64 nUTCStartTime );

    /**
     *
     * @brief Get second (ATS2) End-Timestamp of measurement data packet
     *
     * Get End-Timestamp of measurement data packet. 
     * Depending on the measurement data packet the interpretation differs:
     * - FlexRay:    Absolut End-timestamp in [ns]
     * - CAN:        Absolut End-timestamp in [ns]
     * - LIN:        Absolut End-timestamp in [ns]
     * - Ethernet:   Absolut End-timestamp in [ns]
     * - Marker:     Seconds since 1.1.1970. On hardware without real-time clock
     *               (EB5200) seconds since power-on.
     * - Analog:     Absolut timestamp in [ns]
     * - Digital:    Absolut timestamp in [ns]
     * - Triggerout: Absolut timestamp in [ns]
     * - Control:    Absolut timestamp in [ns]
     *
     * @retval Timestamp of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     * @deprecated Starting from 4.18 there is only one timebase EB_TIME_MASTER and also only one
     *             timestamp (no ATS2). Only here to use new TAL with older Firmware
     */
    virtual uint64 GetTimeATS2( void );

    /*
     * @brief Set the second (ATS2) End-Timestamp
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetTimeATS2( uint64 );

    /**
     *
     * @brief Get second (ATS2) Start-Timestamp of measurement data packet
     *
     * Get Start-Timestamp of measurement data packet. 
     * Depending on the measurement data packet the interpretation differs:
     * - FlexRay:    Absolut start-timestamp in [ns]
     * - CAN:        Absolut start-timestamp in [ns]
     * - LIN:        Absolut start-timestamp in [ns]
     * - Ethernet    Absolut start-timestamp in [ns]
     * - Marker:     Seconds since 1.1.1970. On hardware without real-time clock
     *               (EB5200) seconds since power-on.
     * - Analog:     Absolut timestamp in [ns]
     * - Digital:    Absolut timestamp in [ns]
     * - Triggerout: Absolut timestamp in [ns]
     * - Control:    Absolut timestamp in [ns]
     *
     * @retval Timestamp of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     * @deprecated Starting from 4.18 there is only one timebase EB_TIME_MASTER and also only one
     *             timestamp (no ATS2). Only here to use new TAL with older Firmware
     */
    virtual uint64 GetStartTimeATS2( void );

    /*
     * @brief Set the start time for the second (ATS2) timestamp pair.
     *
     * @param nStartTime The start-time of the data packet.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetStartTimeATS2( uint64 nStartTime );

    /**
     *
     * @brief Get Bus number of measurement data packet
     *
     * Get Bus number of measurement data packet. 
     * Depending on the measurement data packet the interpretation differs:
     * - FlexRay:      1
     * - CAN:          2
     * - LIN:          3
     * - Ethernet 0:   4
     * - Ethernet 1:   5
     * - Marker:     128
     * - Analog:     129
     * - Digital:    130
     * - Triggerout: 131
     * - Control:    132
     *
     * @retval Bus number of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     * @sa TAL_BusType
     *
     */
    virtual uint8  GetBus( void );

    /*
     * @brief Set the bus.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetBus( uint8 nBus );

    /**
     *
     * @brief Get Channel number of measurement data packet
     *
     * Get Channel number of measurement data packet. 
     * Depending on the measurement data packet the interpretation differs:
     * - FlexRay:    1 = CC1_ChA; 2 = CC1_ChB; 4 = CC2_ChA; 8 = CC2_ChB;
     *               17 = CC3_ChA; 18 = CC3_ChB; 20 = CC4_ChA; 24 = CC4_ChB
     * - CAN:        1 = CH1; 2 = CH2; 3 = CH3; 4 = CH4;
     *               5 = CH5; 6 = CH6; 7 = CH7; 8 = CH8
     * - LIN:        1 = CH1; 2 = CH2; 3 = CH3; 4 = CH4
     * - Ethernet:   VLAN-ID of the ethernet data packet
     *               -1 = undefined VLAN-ID
     *               positive Numbers = VLAN-ID
     * - Marker:     1 = TriggerMarker or GeneralMarker; 4 = User
     * - Analog:     1
     * - Digital:    1 = Value; 2 = DETI
     * - Triggerout: N/A
     * - Control:    N/A
     *
     * @retval Channel number of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     * @sa 
     */
    virtual sint32 GetChannel( void );

    /*
     * @brief Set the channel.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetChannel( sint32 nChannel );

    /**
     *
     * @brief Get Slot number of measurement data packet
     *
     * Get Slot number of measurement data packet. 
     * Depending on the measurement data packet the interpretation differs:
     * - FlexRay:    positive Numbers = FlexRay Slot; -1 = SymbolWindow;
     *               -2 = NetworkIdleTime
     *               -3 = CycleStart
     * - CAN:        N/A
     * - LIN:        N/A
     * - Ethernet:   Source MAC address of the ethernet data packet
     *               -1 = invalid address
     *               positive Numbers = MAC address
     * - Marker:     N/A
     * - Analog:     N/A
     * - Digital:    N/A
     * - Triggerout: N/A
     * - Control:    N/A
     *
     * @retval Slot number of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     */
    virtual sint64  GetSlot( void );

    /*
     * @brief Set the slot.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetSlot( sint64 nSlot );

    /**
     *
     * @brief Get Slot Status of measurement data packet
     *
     * Get Slot Status of measurement data packet. 
     * Depending on the measurement data packet the interpretation differs:
     * - FlexRay:    FlexRay Slot Status
     * - CAN:        N/A
     * - LIN:        N/A
     * - Ethernet:   VLAN priority of the ethernet data packet
     *               -1 = undefined VLAN priority
     *               bit0: drop data packet flag
     *               bit1..bit3: VLAN priority
     * - Marker:     N/A
     * - Analog:     N/A
     * - Digital:    N/A
     * - Triggerout: N/A
     * - Control:    N/A
     *
     * @retval Slot Status of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     * @sa TAL_ETHERNET_UNDEFINED_VLAN
     */
    virtual sint32 GetSlotStatus( void );

    /*
     * @brief Set the slot status.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetSlotStatus( sint32 nSlotStatus );

    /**
     *
     * @brief Get Header of measurement data packet
     *
     * Get Header of measurement data packet. 
     * Depending of the measurement data packet the interpretation differs:
     * - FlexRay:    Bits from Frame Header
     * - CAN:        bit 0: remote transmission frame (0 = normal frame, 1 = remote frame)
     *               bit 1: CAN-FD frame (FDF) (0 = normal CAN frame; 1 = CAN-FD frame)
     *               bit 2: baud rate switching (only for CAN-FD frames) (0 = no baud rate switching
     *                      1 = baud rate switching)
     *               bit 3: ESI (-> ERRP) flag
     * - LIN:        1 = classic checksum; 2 = enhanced checksum
     * - Ethernet:   Ethertype of the ethernet data packet
     * - Marker:     N/A
     * - Analog:     N/A
     * - Digital:    N/A
     * - Triggerout: N/A
     * - Control:    1 = stop record; 2 = start record
     *
     * @retval Header of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     * @sa TAL_CanHdrType
     * @sa TAL_FlexRayHdrStatusType
     */
    virtual uint32 GetHeader( void );

    /*
     * @brief Set the header.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetHeader( uint32 nHeader );

    /**
     *
     * @brief Get ID of measurement data packet
     *
     * Get ID of measurement data packet.
     * Depending of the measurement data packet the interpretation differs:
     * - FlexRay:     0 - 2047 frame ID;
     *               -1 = Noise;
     *               -2 = Symbol;
     *               -3 = CAS;
     *               -4 = MTS;
     *               -5 = WUS;
     *               -6 = Bitstream
     * - CAN:        CAN ID; -1 = Unknown
     * - LIN:        LIN ID; -1 = Unknown; -2 = Wakeup
     * - Ethernet:   Destination MAC address of the ethernet data packet
     *               -1 = invalid address
     *               positive Numbers = MAC address
     * - Marker:     1 = TriggerMarker; 2 = GeneralMarker; UserDefined
     * - Analog:     N/A
     * - Digital:    N/A
     * - Triggerout: N/A
     * - Control:    N/A
     *
     * @retval ID of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     * @sa TAL_CanIdType
     * @sa TAL_FlexRayIdType
     */
    virtual sint64 GetId( void );

    /*
     * @brief Set the identifier.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetId( sint64 nId );

    /**
     *
     * @brief Get FlexRay CycleCount of measurement data packet
     *
     * Get CycleCount of measurement data packet.
     * Depending of the measurement data packet the interpretation differs:
     * - FlexRay:    Cycle counter from frame header
     * - CAN:        N/A
     * - LIN:        N/A
     * - Ethernet    N/A
     * - Marker:     N/A
     * - Analog:     N/A
     * - Digital:    N/A
     * - Triggerout: N/A
     * - Control:    N/A
     *
     * @retval FlexRay CycleCount of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     */
    virtual uint8  GetCycleCount( void );

    /*
     * @brief Set the cycle count.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetCycleCount( uint8 nCycleCount );

    /**
     *
     * @brief Get HeaderCRC of measurement data packet
     *
     * Get HeaderCRC of measurement data packet.
     * Depending on the measurement data packet the interpretation differs:
     * - FlexRay:    Header CRC from frame
     * - CAN:        N/A
     * - LIN:        Checksum
     * - Ethernet:   N/A
     * - Marker:     N/A
     * - Analog:     N/A
     * - Digital:    N/A
     * - Triggerout: N/A
     * - Control:    N/A
     *
     * @retval HeaderCRC of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     */
    virtual uint32 GetHeaderCrc( void );

    /*
     * @brief Set the header CRC.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetHeaderCrc( uint32 nHeaderCrc );

    /**
     *
     * @brief Returns the length info of the FlexRay, CAN and LIN message header.
     *
     * This function returns the length info of the FPGA packet.
     * Depending on the measurement data packet the interpretation differs:
     * - FlexRay:           Payload length in byte
     * - FlexRay Symbol:    Symbol length in gdBit
     * - FlexRay Bitstream: Length in Bit
     * - CAN:               Payload length in byte
     * - LIN:               Payload length in byte
     * - LIN Wakeup:        length in [us]
     * - Ethernet:          Payload length in byte
     * - Marker:            N/A
     * - Analog:            N/A
     * - Digital:           N/A
     * - Triggerout:        N/A
     * - Control:           N/A
     *
     * @retval Length of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     */
    virtual uint32 GetLength( void );

    /*
     * @brief Set the length.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetLength( uint32 );

    /**
     *
     * @brief Get Payload Length of measurement data packet
     *
     * Get Payload Length of measurement data packet in bytes. Thats the length which
     * shall be used for GetPayload and GetPayloadPtr functions.
     * Packets listed here do not have a payload:
     * - FlexRay Noise:      N/A
     * - FlexRay Symbol:     N/A
     * - FlexRay SlotStatus: N/A
     * - LIN Wakeup:         N/A
     * - Control:            N/A
     *
     * @retval Payload Length of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     */
    virtual uint32 GetPayloadLength( void );

    /**
     *
     * @brief Convert macro tick based raw timestamp to nano seconds
     *
     * If the timestamp format is TAL_INSP_TIMESTAMP_FORMAT_FR_MACROTICK
     * then this function shall be used to convert the macro tick based  
     * raw timestamp to nano seconds.
     * 
     * @param nRawTime macro tick based raw timestamp
     * @param nCyclePerSupercycle number of cycles per supercycle
     * @param nMacroPerCycle number of macroticks per cycle
     * @param nMicroPerMacro number of microticks per macrotick
     *
     * @retval nano seconds
     *
     */
    static uint64 ConvertMacrotickTimeToNs(
        const uint64 nRawTime, 
        const uint8  nCyclePerSupercycle,
        const uint16 nMacroPerCycle,
        const uint8  nMicroPerMacro);

    /**
     *
     * @brief Convert GPS UTC based raw timestamp to nano seconds
     *
     * If the timestamp format is TAL_INSP_TIMESTAMP_FORMAT_GPS_UTC
     * then this function shall be used to convert the UTC based  
     * raw timestamp to nano seconds.
     * 
     * @param nRawTime UTC based raw timestamp
     *
     * @retval nano seconds
     *
     */
    static uint64 ConvertGPSUTCTimeToNs(
        const uint64 nRawTime);

    /**
     *
     * @brief Return the Synchronization status of a macro tick based timestamp
     *
     * If the timestamp format is TAL_INSP_TIMESTAMP_FORMAT_FR_MACROTICK
     * then this function shall be used to get the synchronization status
     * of this timestamp.
     * 
     * @param nRawTime macro tick based raw timestamp
     *
     * @retval Synchronization status
     *
     */
    static bool MacrotickTimeIsSync(
        const uint64 nRawTime);

    /**
     *
     * @brief Return the Synchronization status of a GPS UTC timestamp
     *
     * If the timestamp format is TAL_INSP_TIMESTAMP_FORMAT_GPS_UTC
     * then this function shall be used to get the synchronization status
     * of this timestamp.
     * 
     * @param nRawTime UTC based raw timestamp
     *
     * @retval Synchronization status
     *
     */
    static bool GPSUTCTimeIsSync(
        const uint64 nRawTime);


#ifndef SWIG
    /**
     *
     * @brief Get Payload data of measurement data packet
     *
     * Copies Payload data of measurement data packet to the supplied buffer. Use
     * GetPayloadLength method to know beforehand the size requirements before
     * calling this method.
     *
     * @param PayloadBuffer     User provided buffer the payload data is
     *                          copied to. The user is responsible to allocate
     *                          and later delete the buffer.
     * @param PayloadBufferSize Size of the user provided buffer in bytes
     *
     * @retval Number of bytes copied to user provided buffer
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *       TAL_NULL_POINTER PayloadBuffer must not be 0
     *       TAL_BufferToSmall User provided buffer is to small for payload data
     *
     * @sa GetLastError
     *
     */
    virtual uint32 GetPayload(uint8 * PayloadBuffer,
                      uint32 PayloadBufferSize );

    /**
     *
     * @brief Get pointer to Payload of measurement data packet
     *
     * Get pointer to Payload of measurement data packet. This pointer is only valid
     * as long as the data supplied to the Process method is available.
     * Attention: No cache of the data is hold inside this class because of
     * performance and size issues. If you cant process the data immediately
     * as long as the data is still available or if you dont know whats that
     * all about just use the GetPayload method instead to get a copy of the
     * payload for later data processing.
     *
     * @retval Pointer to Payload of measurement data packet
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @note Use method GetPayloadLength() to determine the length of the
     *       payload. Access beyond this length will result in undetermined
     *       behaviour.
     *
     * @sa GetLastError
     *
     */
    virtual const uint8* GetPayloadPtr( void );
#endif

    /**
     * @brief Get Payload data of measurement data packet
     *
     * Copies Payload data of measurement data packet to the supplied buffer. Use
     * GetPayloadLength method to know beforehand the size requirements before
     * calling this method.
     *
     * The only difference to the other overloaded method is the paramter
     * TalByteArray which is simpler to use and also available for scripting.
     *
     * @param pPayload User provided buffer the payload data is
     *                 copied to.
     *
     * @retval Number of bytes copied to user provided buffer
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *       TAL_NULL_POINTER PayloadBuffer must not be 0
     *       TAL_BufferToSmall User provided buffer is to small for payload data
     *
     * @sa GetLastError
     *
     */
    virtual uint32 GetPayload(TalByteArray *pPayload);

#ifndef SWIG /* uint8* problematic in swig wrapper */
    /*
     * @brief Set the payload.
     *
     * @param pPayloadBuffer Pointer to the payload data.
     * @param nPayloadSize   Number of bytes of payload data.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetPayload(
                    const uint8* pPayloadBuffer,
                    uint32 nPayloadSize
                    );
#endif

    /**
     *
     * @brief Get Status of measurement data packet
     *
     * Get Status of measurement data packet. Contains the Frame Status for FlexRay
     * packets.
     *
     * @retval Status of measurement data packet
     *
     * @section f_FlexRay FlexRay frame status
     * - Bit  0 Valid
     * - Bit  1 TSSVIOL
     * - Bit  2 HCRCERR
     * - Bit  3 FCRCERR
     * - Bit  4 FESERR
     * - Bit  5 FSSERR
     * - Bit  6 BSSERR
     * - Bit  7 BVIOL
     * - Bit  8 NITVIOL
     * - Bit  9 SWVIOL
     * - Bit 10 SOVERR
     * - Bit 11 NERR
     * - Bit 12 SYNCERR
     * - Bit 13 SUERR
     * - Bit 14 SUWSYERR
     * - Bit 15 FIDERR
     * - Bit 16 CCERR
     * - Bit 17 SPLERR
     * @section f_CAN CAN frame status
     * - Bit  0 Valid
     * - Bit  1 Stuff error
     * - Bit  2 Form error
     * - Bit  3 CRC error
     * @section f_LIN LIN frame status
     * - Bit  0 Valid
     * - Bit  1 SYN
     * - Bit  2 PAR
     * - Bit  3 RES
     * - Bit  4 DAT
     * - Bit  5 CHK
     * - Bit  6 STA
     * - Bit  7 STO 
     * @section f_ETHERNET ETHERNET status
     * - Bit  0 Valid
     * - Bit  4 Tx Frame
     * - Bit  5 Tx Truncation
     * - Bit  6 Tx Underrun 
     * - Bit  7 Tx Retransmission limit reached
     * - Bit  8 Tx Late collision detected
     * - Bit  9 Tx Defer indication
     * - Bit 12 Rx Frame
     * - Bit 13 Rx Truncation
     * - Bit 14 Rx Overrun
     * - Bit 15 Rx CRC Error
     * - Bit 16 Rx Short Frame
     * - Bit 17 Rx No octal alligned frame
     * - Bit 18 Rx Frame length violation
     * - Bit 19 Rx Multicast frame
     * - Bit 20 Rx Broadcast frame
     * - Bit 21 Rx Promiscuous mode
     * @section f_CONTROL control status
     * - 0x00 Start monitoring
     * - 0x01 Normal stop monitoring
     * - 0x02 Stop monitoring Invalid Packetsize
     * - 0x03 Stop monitoring Start Job failed
     * - 0x04 Stop monitoring Target connection lost
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     * @sa TAL_FlexRayStatusType
     * @sa TAL_CanStatusType
     * @sa TAL_EthernetStatusType
     */
    virtual uint32 GetStatus( void );

    /*
     * @brief Set the status.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetStatus( uint32 nStatus );

    /**
     * @brief Check if the data can be used a timereference for the
     * calculation of UTC timestamps
     */
    virtual bool IsTimeReference( void );

    /**
     * @brief Sets that the data can be used a timereference for the
     * calculation of UTC timestamps
     */
    virtual void SetTimeReference( bool bTimeCorrection );

    /**
     *
     * @brief Checks if the measurement data is valid
     *
     * Checks if the measurement data is valid. Call GetStatus to get the detailed
     * error status.
     *
     * @retval Valid or Invalid measurement data
     *
     * @note To get the last error status call GetLastError() afterwards.
     *       TAL_SUCCESS Returned data was valid
     *       TAL_NO_DATA Returned data was invalid
     *
     * @sa GetLastError
     *
     */
    virtual bool IsValid( void );

    /**
     *
     * @brief Returns the error code of the last called method
     *
     * Returns the error code of the last called method
     *
     * @retval Last error code. Depends on the method called before.
     *
     */
    virtual TAL_ReturnType GetLastError( void ) const;

    /**
     *
     * @brief Returns the actual OID
     *
     * Returns the actual OID
     *
     * @retval Actual OID
     *
     * @note The StartMonitoring packet resets the OID to 1
     *
     */
    virtual sint64 GetOID( void ) const;

    /*
     * @brief Set the OID.
     *
     * @attention This method is not part of the public API.
     */
    virtual void SetOID( sint64 nOID );

    /**
     *
     * @brief Returns the timebase format
     *
     * Returns the actual timebase format used by the
     * Measurement controller (MCTRL)
     *
     * @retval Timebase format
     *
     * @note None.
     *
     */
    virtual TAL_ScalarInspTimestampFormat GetTimestampFormat( void );

    virtual void SetTimestampFormat( TAL_ScalarInspTimestampFormat nTimestampFormat );

    /**
     *
     * @brief Returns the timebase format for second timestamp
     *
     * Returns the actual timebase format used by the
     * Measurement controller (MCTRL) for the second timestamp (if present)
     *
     * @retval Timebase format
     *
     * @note None.
     *
     * @deprecated Starting from 4.18 there is only one timebase EB_TIME_MASTER and also only one
     *             timestamp (no ATS2). Only here to use new TAL with older Firmware
     */
    virtual TAL_ScalarInspTimestampFormat GetTimestampFormatATS2( void );

    virtual void SetTimestampFormatATS2( TAL_ScalarInspTimestampFormat nTimestampFormat );

    /**
     *
     * @brief Returns the source of the time correction
     *
     * Returns the actual source for the UTC time correction factor
     *
     * @retval Time correction source
     *
     */
    virtual TAL_InspTimeCorrSource GetTimeCorrectionSource( void );

    virtual void SetTimeCorrectionSource( TAL_InspTimeCorrSource eTimeCorrSource );

    /*
     * public members
     */

protected:

    /**
     * @brief Check if DataPacket pointer has changed
     *
     * @param pDataPacket data packet for which object is to be created
     *
     * @retval true DataPacket pointer has changed
     */
    bool DataPacketChanged(const uint8 *pDataPacket)
    {
        return pDataPacket != m_pDataPacket;
    }

    /**
     * @brief Reset all members and set DataPacket pointer
     *
     * @param pDataPacket Pointer to respective data packet
     */
    virtual void ResetAll(const uint8 *pDataPacket);

    /*
     * private members
     */
    TAL_ReturnType m_LastError;

    sint64 m_nOID;   /* database key */
    TAL_ScalarInspTimestampFormat m_nTimestampFormat;
    TAL_TimebaseSelectType    m_eTimestampSource;
    TAL_InspTimeCorrSource        m_eTimeCorrSource;
    TAL_ScalarInspTimestampFormat m_nTimestampFormatATS2;
    TAL_TimebaseSelectType    m_eTimestampSourceATS2;

    uint8  m_nMajor;
    bool   m_bMajorValid;
    uint8  m_nMinor;
    bool   m_bMinorValid;

    //Time members
    uint64 m_nTime;
    bool   m_bTimeValid;
    uint64 m_nTimeATS2;
    bool   m_bTimeValidATS2;
    uint64 m_nUTCTime;
    bool   m_bUTCTimeValid;

    uint64 m_nStartTime;
    bool   m_bStartTimeValid;
    uint64 m_nStartTimeATS2;
    bool   m_bStartTimeValidATS2;
    uint64 m_nUTCStartTime;
    bool   m_bUTCStartTimeValid;

    uint8  m_nBus;
    bool   m_bBusValid;
    sint32 m_nChannel;
    bool   m_bChannelValid;
    sint64 m_nSlot;
    bool   m_bSlotValid;
    sint32 m_nSlotStatus;
    bool   m_bSlotStatusValid;
    uint32 m_nHeader;
    bool   m_bHeaderValid;
    sint64 m_nId;
    bool   m_bIdValid;
    uint8  m_nCycleCount;
    bool   m_bCycleCountValid;
    uint32 m_nHeaderCrc;
    bool   m_bHeaderCrcValid;
    uint32 m_nLength;
    bool   m_bLengthValid;
    uint32 m_nPayloadLength;
    bool   m_bPayloadLengthValid;
    const uint8* m_pPayload;
    uint32 m_nStatus;
    bool   m_bStatusValid;

    bool   m_bTimeReference;

    const uint8 *m_pDataPacket; // data packet referenced by object

private:
    /*
     * Prevent assignment operator and copy constructor
     */
    TalMeasureData & operator = (const TalMeasureData & rhs);

    TalMeasureData(const TalMeasureData & rhs);
};

#endif /* _TAL_MEASUREDATA_H_ */
